mkdir build
cd build
cmake ..
make -j
cd ..
