sudo apt update
sudo apt install -y qt5-default qtcreator qtbase5-dev qt5-qmake cmake libqt5charts5 libqt5charts5-dev
