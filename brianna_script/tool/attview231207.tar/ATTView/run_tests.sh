cd build/
ctest
