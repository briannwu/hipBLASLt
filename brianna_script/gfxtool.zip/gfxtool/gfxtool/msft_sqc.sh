#!/bin/bash

MYDEVS=`sudo ./mi300 -?d | tail -8 | awk '{print $1}'`

MYDEV1=`echo $MYDEVS | awk '{print $1}' | sed 's/^*//'`
echo "DEV1: $MYDEV1"

MYDEV2=`echo $MYDEVS | awk '{print $2}' | sed 's/^*//'`
echo "DEV2: $MYDEV2"

MYDEV3=`echo $MYDEVS | awk '{print $3}' | sed 's/^*//'`
echo "DEV3: $MYDEV3"

MYDEV4=`echo $MYDEVS | awk '{print $4}' | sed 's/^*//'`
echo "DEV4: $MYDEV4"

MYDEV5=`echo $MYDEVS | awk '{print $5}' | sed 's/^*//'`
echo "DEV5: $MYDEV5"

MYDEV6=`echo $MYDEVS | awk '{print $6}' | sed 's/^*//'`
echo "DEV6: $MYDEV6"

MYDEV7=`echo $MYDEVS | awk '{print $7}' | sed 's/^*//'`
echo "DEV7: $MYDEV7"

MYDEV8=`echo $MYDEVS | awk '{print $8}' | sed 's/^*//'`
echo "DEV8: $MYDEV8"




SQC_WR="0x010a2000" # 1
#SQC_WR="0x0a0a2000" # 10
echo "Setting SQC_CONFIG prefetch: $SQC_WR "
#sudo ./mi300 cmd mmw mmSQC_CONFIG  $SQC_WR --XCCID=0-7 -i $MYDEV1
#sudo ./mi300 cmd mmw mmSQC_CONFIG  $SQC_WR --XCCID=0-7 -i $MYDEV2
#sudo ./mi300 cmd mmw mmSQC_CONFIG  $SQC_WR --XCCID=0-7 -i $MYDEV3
#sudo ./mi300 cmd mmw mmSQC_CONFIG  $SQC_WR --XCCID=0-7 -i $MYDEV4
#sudo ./mi300 cmd mmw mmSQC_CONFIG  $SQC_WR --XCCID=0-7 -i $MYDEV5
#sudo ./mi300 cmd mmw mmSQC_CONFIG  $SQC_WR --XCCID=0-7 -i $MYDEV6
#sudo ./mi300 cmd mmw mmSQC_CONFIG  $SQC_WR --XCCID=0-7 -i $MYDEV7
sudo ./mi300 cmd mmw mmSQC_CONFIG  $SQC_WR --XCCID=0-7 -i $MYDEV8
sleep 1

#echo "Reading GPU0"
#sudo ./mi300 cmd mmrp mmSQC_CONFIG --XCCID=0-7 -i $MYDEV1
#echo "Reading GPU1"
#sudo ./mi300 cmd mmrp mmSQC_CONFIG --XCCID=0-7 -i $MYDEV2
#echo "Reading GPU2"
#sudo ./mi300 cmd mmrp mmSQC_CONFIG --XCCID=0-7 -i $MYDEV3
#echo "Reading GPU3"
#sudo ./mi300 cmd mmrp mmSQC_CONFIG --XCCID=0-7 -i $MYDEV4
#echo "Reading GPU4"
#sudo ./mi300 cmd mmrp mmSQC_CONFIG --XCCID=0-7 -i $MYDEV5
#echo "Reading GPU5"
#sudo ./mi300 cmd mmrp mmSQC_CONFIG --XCCID=0-7 -i $MYDEV6
#echo "Reading GPU6"
#sudo ./mi300 cmd mmrp mmSQC_CONFIG --XCCID=0-7 -i $MYDEV7
echo "Reading GPU7"
sudo ./mi300 cmd mmrp mmSQC_CONFIG --XCCID=0-7 -i $MYDEV8
