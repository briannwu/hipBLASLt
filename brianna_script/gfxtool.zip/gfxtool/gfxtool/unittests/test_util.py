import inspect
import os
import sys
if sys.version_info.major == 2:
    import commands as subprocess
    from cStringIO import StringIO
else:
    import subprocess
    from io import StringIO


#test_folder = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
#print(test_folder)

project_folder = ""
def __addpath():
    # project_folder = ..../gfxtool
    global project_folder
    test_folder = os.path.dirname(os.path.realpath(__file__))
    project_folder = os.path.dirname(test_folder)

    sys.path.insert(0,project_folder)
    sys.path.insert(0,'..')
__addpath()

diag = False
asic = False
csid = False

def listDevices(did = 0):
    a,b0 = subprocess.getstatusoutput(''.join([project_folder, "/bin/db32 ", " cmd cslist"] ))
    a,b0 = subprocess.getstatusoutput(''.join([project_folder, "/navi21 ", " -?d"] ))
    b0 = b0.split('\n')
    if did == 0:
        gpulist = [i for i in b0 if 'Disp' in i or 'VGA' in i or 'Acce' in i]
        print ('\n'.join(gpulist))
        def getDevicesMap(devicelist):
             devicemap = {}
             for i in gpulist:
                 fields = i[1:].strip().split()
                 deviceid = fields[4]
                 _csid = int(fields[0])
                 if deviceid in devicemap:
                     devicemap[deviceid].append(_csid)
                 else:
                     devicemap[deviceid]= [_csid]
             return devicemap
        def onedevice(fields): return [fields[0], fields[4]]
        devicelist = [onedevice(i[1:].strip().split())  for i in gpulist]
        return devicelist
    b1 = [int(i[1:].strip().split(' ')[0]) for i in b0 if "%x"%did in i]
    b = tuple(b1)
    return b


deviceIdName = {'740c':'mi200', '73a2':'navi21', '7420':'navi24', '740f':'mi200', '73bf':'navi31'}
def detectDevice():
    devices = listDevices()
    #device: [csid, deviceid, devicename]
    theDevice = False
    for device in devices:
        if device[1] in deviceIdName:
            if len(device) == 2: device.append(deviceIdName[device[1]])
            theDevice = device
            break
    return theDevice
def load(options):
    global diag
    global asic
    global csid
    _csid = False
    _deviceid = False
    if asic == False:
        [_csid, _deviceid, asic] = detectDevice()
        print(asic)
    else:
        if csid: _csid = csid

    import importlib
    diag = importlib.import_module(asic)
    globals()[asic] = diag
    #if asic == 'mi200':
    #    import mi200
    #    diag = mi200
    #elif asic == 'navi24':
    #    import navi24
    #    diag = navi24

    if options.xccid : diag.setXCC(int(options.xccid))

    if _csid == False:
        #if default device is not asic, select the correct csid
        default_deviceid = "%x"%diag.cfg.did()
        devices = diag.cfg.devices()
        def getKerFromValue(my_dict, value): return list(my_dict.keys())[list(my_dict.values()).index(value)]
        try:
            expectedDid = getKerFromValue(deviceIdName, asic)
            if expectedDid != default_deviceid:
              _csid = diag.cfg.devices(int(expectedDid, 16))[0]
              csid = _csid
        except :
            diag.Fmt.warn("The default Device may not be " + asic)
            diag.Fmt.warn("please run: unitests/run.py asic_name csid")
            pass

    if _csid:
        _csid = int(_csid)
        diag.db32I.CS(_csid)
        diag.db32S.CS(_csid)
    csid = _csid

    sys.path.insert(0,project_folder + "/unittests/suites_" + asic)

