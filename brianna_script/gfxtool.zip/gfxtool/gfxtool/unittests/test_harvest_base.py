import unittest
import test_util 
import sys
diag = test_util.diag

class TestHarvest(unittest.TestCase):
    def setUp(self):
        self.nativeCU = diag.GC__NUM_TOTAL_SH * diag.GC__NUM_WGP_PER_SA * 2  
        import importlib
        try:
            globals()["debe_samples"] = importlib.import_module("debe_samples_" + test_util.asic)
        except Exception as e:
            pass

    def tearDown(self):
        pass

    def do_test_checkCUHarvestable_000(self):
        #def var_exist(var): return  var in globals().keys()
        #if not var_exist('debe_samples'): return
        nativeCU = self.nativeCU 
        balancedCU = self.nativeCU 
        useDebe = True 
        for sample in debe_samples.debe_samples:
            debestr = sample[0]
            for case in sample[1:]:
                expect = 0
                checkCU = True
                balancedCU = self.nativeCU 
                if isinstance(case, tuple):
                    if len(case) == 1:
                        expect     = case[0]
                    elif len(case) == 2:
                        expect     = case[0]
                        balancedCU = case[1]
                    elif len(case) == 3:
                        expect     = case[0]
                        nativeCU   = case[1]
                        balancedCU = case[2]
                    elif len(case) == 4:
                        expect     = case[0]
                        nativeSE   = case[1]
                        downSE     = case[2]
                        balancedCU = case[3]
                        checkCU = False
                    else:
                        raise Exception("Unsupported param")
                else:
                    expect = case
                if checkCU :
                    r = diag.cfg.checkCUHarvestable(nativeCU, balancedCU, useDebe, debe=debestr)
                else :
                    r = diag.cfg.checkSEHarvestable(nativeSE, downSE, useDebe, debe=debestr, balancedCU=balancedCU)
                self.assertEqual(r, expect)
