import unittest
import sys
import test_util
from test_util import diag

class TestGeneral(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def do_test_findBadWGPGfx10(self, _expected_badWGP, _expected_output, repeat, **kw):
        #save
        oldv = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        _expected_badWGP_str = ','.join(["%d"%i for i in _expected_badWGP])
        cmd_debug00 = "%s/%s -e 'cfg.debug00(%s)' -i%s"%(test_util.project_folder, test_util.asic, _expected_badWGP_str, test_util.csid)
        diag.Fmt.configlogger(18)
        with diag.Capturing() as output:
            diag.cfg.findBadWGPGfx10(cmd_debug00, repeat, **kw)
        #restore
        v = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG, *oldv)
        self.assertEqual(any([i in output.getvalue() for i in _expected_output]) , True)

    def _test_findBadWGPGfx10(self):
        _expected_badWGP = [2]
        _expected_output = ("Verify: Test passes after disable [2]")
        _repeat = 1
        self.do_test_findBadWGPGfx10(_expected_badWGP, _expected_output, _repeat)

    def test_findBadWGPGfx10_002(self):
        _expected_badWGP = [2, 3]
        _expected_output = ("Verify: Test passes after disable [2, 3]", "Verify: Test passes after disable [3, 2]")
        _repeat = 1
        self.do_test_findBadWGPGfx10(_expected_badWGP, _expected_output, _repeat)


#def suite():
#   suite = unittest.TestSuite()
#   suite.addTests(unittest.makeSuite(TestGeneral))
#   return suite


