import unittest
import sys
import test_util
from test_util import diag

class TestCpdma(unittest.TestCase):
    def setUp(self):
        self.nBytes = 0x100000
        pass

    def tearDown(self):
        pass

    def do_test_cpdma(self, fbSrc, fbDst, size):
        #diag.mm.write(fbSrc, size, 0xaa00aa00)
        #diag.mm.write(fbDst, size, 0xbb00bb00)
        diag.cpdma.d2m(0xaa00aa00, fbSrc, size)
        diag.cpdma.finish()
        diag.cpdma.d2m(0xbb00bb00, fbDst, size)
        diag.cpdma.finish()
        diag.cpdma.m2m(fbSrc, fbDst, size)
        diag.cpdma.finish()
        datas = diag.mm.read(fbDst, size//4)
        self.assertEqual(any([t != 0xaa00aa00 for t in datas]), False)
    def test_m2m(self):
        fbBase = diag.mmr(diag.mmGCMC_VM_FB_LOCATION_BASE) << 24
        fbSrc = fbBase + 0x10000000
        fbDst = fbBase + 0x30000000
        size = self.nBytes
        self.do_test_cpdma(fbSrc, fbDst, size)

#def suite():
#   suite = unittest.TestSuite()
#   suite.addTests(unittest.makeSuite(TestCpdma))
#   return suite


