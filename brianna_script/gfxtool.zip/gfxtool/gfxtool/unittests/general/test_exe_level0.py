import unittest
#from . import test_util
from test_util import diag

class TestExe(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000(self):
        pass

    def test_e_mmr(self):
        cmd = "mmr(mmGRBM_STATUS)"
        diag.options.cmd = cmd
        with diag.Capturing() as output:
            diag.runecmd(cmd)
        self.assertEqual("mmGRBM_STATUS" in output.getvalue(), True)

    def test_e_cfg_info(self):
        cmd = "cfg.info()"
        diag.options.cmd = cmd
        with diag.Capturing() as output:
            diag.runecmd(cmd)
        self.assertEqual("mmCC_GC_SHADER_ARRAY_CONFIG" in output.getvalue(), True)

#def suite():
#   suite = unittest.TestSuite()
#   suite.addTests(unittest.makeSuite(TestGeneral))
#   return suite


