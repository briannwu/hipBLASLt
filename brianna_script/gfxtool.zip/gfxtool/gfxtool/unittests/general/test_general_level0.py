import unittest
import sys
import test_util
from test_util import diag

class TestGeneral(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000(self):
        pass

    def test_mmr(self):
        v = diag.mmr(diag.mmGRBM_STATUS)
        self.assertEqual(True, True)

    def test_mmrp(self):
        with diag.Capturing() as output:
            v = diag.mmrp(diag.mmGRBM_STATUS)
        self.assertEqual("mmGRBM_STATUS" in output.getvalue(), True)
    def test_cfg(self):
        cfg = diag.CFG()
        cfg.info()
        self.assertEqual(True, True)
    def test_reg(self):
        reg = diag.REG()
        self.assertEqual(True, True)
    def test_cpdma(self):
        dma = diag.CPDMA()
        self.assertEqual(True, True)
    def test_sq(self):
        sq = diag.SQ()
        self.assertEqual(True, True)
    def test_mm(self):
        mm = diag.MM()
        mm.info()
        self.assertEqual(True, True)
    def test_cg(self):
        cgcg=diag.CGCG()
        self.assertEqual(True, True)
    def test_each_cu_003(self):
        eachcu = diag.each.cu(diag.mmTCP_CNTL)
        self.assertEqual(len(eachcu), diag.GC__NUM_SA_PER_SE * diag.GC__NUM_SE * 16 *  diag.GC__NUM_CU_PER_WGP)
    def test_each_cu_slot(self):
        eachcuslot = diag.each.cuslot(diag.mmTCP_CNTL)
        self.assertEqual(len(eachcuslot), diag.GC__NUM_SA_PER_SE * diag.GC__NUM_SE * 16 * diag.GC__NUM_CU_PER_WGP )
    def test_each_cu_existing(self):
        eachcuexisting = diag.each.cuexisting(diag.mmTCP_CNTL)
        self.assertEqual(len(eachcuexisting), diag.GC__NUM_SA_PER_SE * diag.GC__NUM_SE * len(diag.RANGE_WGP) * diag.GC__NUM_CU_PER_WGP )
    def test_each_wgp_006(self):
        self.test_each_wgp_existing()
    def test_each_wgp_slot(self):
        eachwgpslot = diag.each.wgpslot(diag.mmTCP_CNTL)
        self.assertEqual(len(eachwgpslot), diag.GC__NUM_SA_PER_SE * diag.GC__NUM_SE * 16)
    def test_each_wgp_existing(self):
        eachwgpexisting = diag.each.wgpexisting(diag.mmTCP_CNTL)
        self.assertEqual(len(eachwgpexisting), diag.GC__NUM_SA_PER_SE * diag.GC__NUM_SE * len(diag.RANGE_WGP) )

