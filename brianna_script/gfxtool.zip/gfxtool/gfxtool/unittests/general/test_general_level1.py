import unittest
import sys
import test_util
from test_util import diag

class TestGeneral(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000(self):
        pass

    def test_mmr(self):
        v = diag.mmr(diag.mmGRBM_STATUS)
        self.assertEqual(v > 0, True)

    def test_mmrp(self):
        with diag.Capturing() as output:
            v = diag.mmrp(diag.mmGRBM_STATUS)
        self.assertEqual(v > 0, True)
        self.assertEqual("mmGRBM_STATUS" in output.getvalue(), True)

    def do_test_RegGuard(self, test_reg):
        test_reg = 0
        oldv = diag.mmr(test_reg)
        with diag.RegGuard(test_reg):
            diag.mmw(test_reg, 8)
            changev = diag.mmr(test_reg)
            self.assertEqual(changev, 8)
        checkv = diag.mmr(test_reg)
        self.assertEqual(oldv, checkv)

    def test_RegGuard_001(self):
        self.do_test_RegGuard(0)

    def test_RegGuard_002(self):
        test_reg = 0
        oldv1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        with diag.RegGuard(('sa',diag.mmGC_USER_SHADER_ARRAY_CONFIG)):
            diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG, oldv1[0] + 0x10000)
            changev1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
            self.assertEqual(changev1 == oldv1, False)
            self.assertEqual(changev1[0] == oldv1[0] + 0x10000, True)
        checkv1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        self.assertEqual(checkv1 == oldv1, True)

    def test_RegGuard_003(self):
        test_reg = 0
        oldv0 = diag.mmr(test_reg)
        oldv1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        with diag.RegGuard(test_reg, ('sa',diag.mmGC_USER_SHADER_ARRAY_CONFIG)):
            diag.mmw(test_reg, 8)
            diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG, oldv1[0] + 0x10000)
            changev0 = diag.mmr(test_reg)
            changev1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
            self.assertEqual(changev0, 8)
            self.assertEqual(changev1 == oldv1, False)
        checkv0 = diag.mmr(test_reg)
        checkv1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        self.assertEqual(oldv0, checkv0)
        self.assertEqual(checkv1 == oldv1, True)

    def test_RegGuard_004(self):
        test_reg = 0
        oldv1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        with self.assertRaises(Exception) as context:
            with diag.RegGuard(test_reg, ('se',diag.mmGC_USER_SHADER_ARRAY_CONFIG)):
                diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG, oldv1[0] + 0x10000)
                changev1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
                self.assertEqual(changev1 == oldv1, False)
            checkv1 = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
            self.assertEqual(checkv1 == oldv1, True)
        self.assertTrue('Not Implemented' in str(context.exception))


    def test_disableWGP(self):
        with diag.RegGuard(('sa',diag.mmGC_USER_SHADER_ARRAY_CONFIG)):
             with diag.Capturing() as output:
                 diag.cfg.disableWGP(0)
             newv = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        self.assertEqual(newv[0]&0x10000 , 0x10000)

    def test_each_sh_001(self):
        old = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        expect = diag.UserList([(1<<(i+16)) | old[i]  for i in range(diag.GC__NUM_TOTAL_SH)])
        with diag.RegGuard(('sa',diag.mmGC_USER_SHADER_ARRAY_CONFIG)):
            diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG, *expect)
            actual = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
            self.assertEqual(actual == expect, True)

    def test_each_sh_002(self):
        old = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
        init = diag.UserList([1<<(i+16)  for i in range(diag.GC__NUM_TOTAL_SH)])
        expects = diag.UserList([1<<(i+16)  for i in range(diag.GC__NUM_TOTAL_SH)])
        expect = 0x50000 | old[0]
        expects[0] = expect
        with diag.RegGuard(('sa',diag.mmGC_USER_SHADER_ARRAY_CONFIG)):
            diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG, *init)
            diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG, expect)
            actual = diag.each.sa(diag.mmGC_USER_SHADER_ARRAY_CONFIG)
            # The fused bits may not be writtable
            for i in range(diag.GC__NUM_TOTAL_SH) :
                actual[i] = actual[i] & (((1<<diag.GC__NUM_WGP_PER_SA)-1) << 16)
                expects[i] = expects[i] & (((1<<diag.GC__NUM_WGP_PER_SA)-1) << 16)
            self.assertEqual(actual == expects, True)



