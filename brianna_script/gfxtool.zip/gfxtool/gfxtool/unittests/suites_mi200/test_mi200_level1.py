import unittest
from test_util import diag as mi200
diag = mi200

class TestGeneral(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000(self):
        pass

    def test_deviceid(self):
        deviceid = mi200.cfg.did()
        self.assertEqual(deviceid ==  0x740c or deviceid ==  0x740f, True)

    def test_002(self):
        a = 1
        self.assertEqual(a, 1)
    def test_debe(self):
        r = True
        with diag.RegGuard(('sa',diag.mmGC_USER_SHADER_ARRAY_CONFIG)):
            print("")
            mi200.cfg.disableCU(1, 16, 39)
            debe = mi200.cfg.debe()
            expected =  "000000000000000000000000011111110000000000000000000000000000000011000000000000001101000000000000110000000001000011000000000000001100000000000000110000001000000011000000000000011100000000000010"
            debeBits = mi200.Debe()
            debeBits.assign(debe)
            d1 = debeBits.SE0SH0CU  & 2
            d16 = debeBits.SE1SH0CU & 1
            d39 = debeBits.SE2SH0CU & 0x80
            r = ( d1 != 0) and  (d16 != 0) and (d39 != 0)
        self.assertEqual(r, True)

