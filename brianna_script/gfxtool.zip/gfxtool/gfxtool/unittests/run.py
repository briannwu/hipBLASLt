#!/usr/bin/python3
import unittest
import sys
import  test_util
from optparse import OptionParser

MSG_USAGE = '''  -e'cmds'\n  -e 'reg.dumpCPheader()'
    print("unittests/run.py test_level project_name csid")
    print("  test_level or test_file.py   ")
    print("                0,1,2.  Default is all")
    print("                or test_file_name.py")
    print("  project_name  navi21, mi200, ... . Default will be the live gpu")
    print("  csid          Default will be first avaliable one")
    print("example:")
    print(" unittests/run.py             #run all suites on the live gpu")
    print(" unittests/run.py 1           #run level 0-1 suites on the live gpu")
    print(" unittests/run.py 1 navi21    #run level 0-1 suites on navi21")
    print(" unittests/run.py 1 navi21 16 #run level 0-1 suites on navi21 and set csid 16")
'''
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-v', '--verbose', dest='verbose', type='string', default='25.4', help="-v a.b logger.level=a;Fmt.VERBOSE=b")
optParser.add_option('--XCCID', dest='xccid', type='string', default='0', help="xccid, 0,1,2,...7")
optParser.add_option('--AID', dest='aid', type=int, default=0, help="aid")
optParser.add_option('--externaldb32', dest='externaldb32', action="store_true", help="use external executable db32")
optParser.add_option('--db32', dest='db32', type="string", default="so", help="select backend[so(dll), external, tcore]")
options, args = optParser.parse_args(sys.argv[1:] if __name__ == '__main__' else [""])

def help():
    print(MSG_USAGE)
if len(sys.argv) == 2 and (sys.argv[1] == "-h" or sys.argv[1] == "--help"):
    help()
    exit(0)
project = False
suites_level=2
try:
    if len(sys.argv) > 1 :
        _c = sys.argv[1][0]
        if(_c >= '0' and _c <= '9'): suites_level = int(sys.argv[1])
        elif (_c == 't'): suites_level = sys.argv[1]
        else: suites_level = sys.argv[1]
        #else: raise RuntimeError('')
    if len(sys.argv) > 2 :
        project = sys.argv[2]
        test_util.asic = project
    if len(sys.argv) > 3 :
        project_csid = int(sys.argv[3])
        test_util.csid = project_csid
except:
    help()
    exit(1)
test_util.load(options)


if __name__ == '__main__':
   runner = unittest.TextTestRunner(verbosity=2)
   all_suites = ()
   all_patterns = []
   #if suites_level == 2:
   #    all_patterns = ["test*.py"]
   #elif suites_level == 1:
   #    all_patterns = ["test*level0.py", "test*level0.py"]
   #elif suites_level == 0:
   #    all_patterns = ["test*level0.py"]
   if test_util.diag.isNumber(suites_level):
       all_patterns = ["test*level%d.py"%i for i in range(suites_level + 1)]
   else:
       all_patterns = [suites_level]
   if True:
       suite_list = []
       for apattern in all_patterns:
           suite_list.append(unittest.defaultTestLoader.discover('general', pattern=apattern))
           try:
               suite_list.append(unittest.defaultTestLoader.discover("suites_"+test_util.asic, pattern=apattern, top_level_dir=test_util.project_folder))
           except Exception as e:
               print(e)
       all_suites = tuple(suite_list)
   alltests = unittest.TestSuite(all_suites)
   result = runner.run(alltests)
   sys.exit(not result.wasSuccessful())
