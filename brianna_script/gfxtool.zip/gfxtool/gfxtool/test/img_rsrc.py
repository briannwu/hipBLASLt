def img_rsrc_gfx10(*rsrcs):
   import aux_sq_ko_reg as aux
   img = aux.sq_img_rsrc_t_gfx10(*rsrcs)
   print(img)
def img_rsrc_gfx11(*rsrcs):
   import aux_sq_ko_reg as aux
   img = aux.sq_img_rsrc_t_gfx11(*rsrcs)
   print(img)
def img_rsrc_gfx12(*rsrcs):
   import aux_sq_ko_reg as aux
   img = aux.sq_img_rsrc_t_gfx12(*rsrcs)
   print(img)
def img_rsrc_b0(*rsrcs):
   import aux_sq_ko_reg as aux
   img = aux.sq_img_rsrc_compat_b0_t(*rsrcs)
   print(img)
def img_rsrc_b1(*rsrcs):
   import aux_sq_ko_reg as aux
   img = aux.sq_img_rsrc_compat_b1_t(*rsrcs)
   print(img)

def img_rsrc_has_pack_issue(*rsrcs):
  import sq_ko_reg
  img = sq_ko_reg.union__sq_img_rsrc_u()
  for i in range(len(rsrcs)): img.u32All[i] = rsrcs[i]
  fmter = "%%%ds %%X"%24
  index = 0
  for t in img.bits._fields_ :
      seperator = '\n' if (index % Settings.mDumpColumns) == 0 else '\t'
      if index == len(img.bits._fields_) -1 : seperator = '\n'
      s = getattr(img.bits, t[0])
      str = fmter%(t[0], s)
      if s != 0:
          Fmt.bad(fmter%(t[0], s))
      elif Settings.FILTER0 == False:
          #myprint(fmter%(t[0], s), end=seperator)
          myprint(fmter%(t[0], s))
      index = index + 1

def buf_rsrcXXX(*rsrcs):
   import aux_sq_ko_reg as aux
   buf = aux.sq_buf_rsrc_t(*rsrcs)
   print(buf)
def buf_rsrc(*rsrcs):
   import aux_sq_ko_reg as aux
   sq_buf_rsrc_t = aux.sq_buf_rsrc_t_gfx12
   if GFX_IP_MAJOR == 11:
     sq_buf_rsrc_t = aux.sq_buf_rsrc_t_gfx11
   elif GFX_IP_MAJOR == 10:
     sq_buf_rsrc_t = aux.sq_buf_rsrc_t_gfx10
   else:
     sq_buf_rsrc_t = aux.sq_buf_rsrc_t_gfx12
   if len(rsrcs) == 1:
      mystr = rsrcs[0]
      mystrs = mystr.split()
      myrsrcs = [int(i,16) for i in mystrs]
   else: myrsrcs = rsrcs

   buf = sq_buf_rsrc_t(*myrsrcs)
   print(buf)


def img_rsrc(*rsrcs):
   import aux_sq_ko_reg as aux
   sq_img_rsrc_t = aux.sq_img_rsrc_t_gfx12
   if GFX_IP_MAJOR == 11:
     sq_img_rsrc_t = aux.sq_img_rsrc_t_gfx11
   elif GFX_IP_MAJOR == 10:
     sq_img_rsrc_t = aux.sq_img_rsrc_t_gfx10
   else:
     sq_img_rsrc_t = aux.sq_img_rsrc_t_gfx12
   if len(rsrcs) == 1:
      mystr = rsrcs[0]
      mystrs = mystr.split()
      myrsrcs = [int(i,16) for i in mystrs]
   else: myrsrcs = rsrcs

   img = sq_img_rsrc_t(*myrsrcs)
   print(img)

ret = 1
