stream GRBM_SH_reg
field[0] = 1'h clken
field[1] = 1'h send
field[2] = 16'h addr
field[3] = 1'h op
field[4] = 32'h wd
endstream

data
GRBM_SH_reg 1 1 2e0c 1 00000000 @ 00000001
GRBM_SH_reg 1 1 2e0d 1 00000000 @ 00000002
GRBM_SH_reg 1 1 2e12 1 00000042 @ 00000003
GRBM_SH_reg 1 1 2e13 1 00000090 @ 00000004
GRBM_SH_reg 1 1 2e28 1 00000000 @ 00000005
GRBM_SH_reg 1 1 2e2a 1 7f2f384a @ 00000006
enddata
	0xb0802004, 0x930a0008,
	0x360000ff, 0x000003ff,
	0xd70f6a04, 0x0002000a,
	0x34140882, 0x7e160280,
	0xbefc03ff, 0x000004ff,
	0xdc319000, 0x0804000a,
	0xbf8c0000, 0xdc708000,
	0x0006080a, 0xbf8c0000,
	0xbf810000, 0xbf9f0000,
	0xbf9f0000, 0xbf9f0000,
	0xbf9f0000, 0xbf9f0000,
