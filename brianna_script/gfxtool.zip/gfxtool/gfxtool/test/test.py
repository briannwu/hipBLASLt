from db32 import *

def status():
    mmrp(mmGRBM_STATUS)
