stream GRBM_SH_reg
field[0] = 1'h clken
field[1] = 1'h send
field[2] = 16'h addr
field[3] = 1'h op
field[4] = 32'h wd
endstream

data
GRBM_SH_reg 1 1 2e0c 1 00000000 @ 00000001
GRBM_SH_reg 1 1 2e0d 1 00000000 @ 00000002
GRBM_SH_reg 1 1 2e12 1 00000042 @ 00000003
GRBM_SH_reg 1 1 2e13 1 00000090 @ 00000004
GRBM_SH_reg 1 1 2e28 1 00000000 @ 00000005
GRBM_SH_reg 1 1 2e2a 1 2c6b3f5b @ 00000006
enddata
	0xb0802006, 0x960a0008,
	0x360000ff, 0x000003ff,
	0xd7006a04, 0x0002000a,
	0x30140882, 0x7e160280,
	0xbefd00ff, 0x000004ff,
	0xdc526000, 0x0804000a,
	0xbf890000, 0xdc6a0000,
	0x0006080a, 0xbf890000,
	0xbfb00000, 0xbf9f0000,
	0xbf9f0000, 0xbf9f0000,
	0xbf9f0000, 0xbf9f0000,
