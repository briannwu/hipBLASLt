from db32 import *
from ip_sq import *
def watch(stall_seconds = 0.5, clear_screen = True):
    from datetime import datetime
    STATUS_IDLE = 0
    STATUS_RUNNING = 1
    STATUS_HANG = 2
    def readActiveWave():
      sti0 = []
      with Capturing() as output:
        st  = SQ.dumpSQIND(ixSQ_WAVE_STATUS, 'all',0,'all')
        sti = [k//GC__NUM_WAVES_PER_SIMD  for k in range(0, len(st)) if ((st[k] & 0x10000) ==0x10000) ]
        sti0 = [k for k in range(0, len(st)) if ((st[k] & 0x10000) ==0x10000) ]
      print(sti0)
      return sti
    cuwgp = "CUs" if GFX_IP_MAJOR == 9 else "WGPs"
    def parseid(wgpid):
        return "SE%dSA%dWGP%d"%(wgpid//GC__NUM_WGP_PER_SE, (wgpid % GC__NUM_WGP_PER_SE) // GC__NUM_WGP_PER_SA, int(wgpid%GC__NUM_WGP_PER_SA))
    def wgpstring(wgplist):
        return " ".join([parseid(wgpid) for wgpid in wgplist])
    def one():
        actives = readActiveWave()
        simdlist = list(dict.fromkeys(actives))
        culist = list(dict.fromkeys([ i // 4 for i in simdlist]))
        myhelp = "For this specific function: for SExSAyWGPz, wgpid = x * %d + y * %d + z" %(GC__NUM_WGP_PER_SE,GC__NUM_WGP_PER_SA)  
        output = '\n'.join([
            repr(actives),
            "Total Active SIMDs : %d " %  len(simdlist),
            "",
            "Total Active %s: %d " % (cuwgp, len(culist)), 
            repr(culist),
            wgpstring(culist),
            myhelp
        ])
        return output
    watchon(one, stall_seconds, clear_screen)


watch(None,False)

ret = 1
exports = {'watch':watch}
exports = [watch]
