def dump(stall_seconds = 1.0 / 1000000.0 , xccs=[], stdinmode = 0, ENABLE_CHECK_CEUE=3):
    import time
    mmPARTITION_COMPUTE_CAP = 0x3a04 //4
    xccbits = (mmr(mmPARTITION_COMPUTE_CAP) >> 10) & 0xff
    myxccs = [ i for i in range(8) if (1<<i) & xccbits]
    if len(xccs)>0:myxccs = xccs
    index = 0
    mmMP1_PUB_SCRATCH10 = 0x3b100b8 // 4
    mmMP1_PUB_SCRATCH11 = 0x3b100bc // 4
    mmMP1_PUB_SCRATCH12 = 0x3b100c0 // 4
    mmMP1_PUB_SCRATCH13 = 0x3b100c4 // 4
    mystrs = []
    a = [0] * 40
    b = [0] * 40
    c = [0] * 40
    d = [0] * 40
    e = [0] * 40
    f = [0] * 40
    g = [0] * 40
    h = [0] * 40
    def oneCUue(se,sh,cu):
        e[se*10+cu] = mmr(mmSP0_UE_ERR_STATUS_LO)
        f[se*10+cu] = mmr(mmSP0_UE_ERR_STATUS_HI)
        g[se*10+cu] = mmr(mmSP1_UE_ERR_STATUS_LO)
        h[se*10+cu] = mmr(mmSP1_UE_ERR_STATUS_HI)
    def oneCUce(se,sh,cu):
        a[se*10+cu] = mmr(mmSP0_CE_ERR_STATUS_LO)
        b[se*10+cu] = mmr(mmSP0_CE_ERR_STATUS_HI)
        c[se*10+cu] = mmr(mmSP1_CE_ERR_STATUS_LO)
        d[se*10+cu] = mmr(mmSP1_CE_ERR_STATUS_HI)
    def oneCUuece(se,sh,cu):
        a[se*10+cu] = mmr(mmSP0_CE_ERR_STATUS_LO)
        b[se*10+cu] = mmr(mmSP0_CE_ERR_STATUS_HI)
        c[se*10+cu] = mmr(mmSP1_CE_ERR_STATUS_LO)
        d[se*10+cu] = mmr(mmSP1_CE_ERR_STATUS_HI)
        e[se*10+cu] = mmr(mmSP0_UE_ERR_STATUS_LO)
        f[se*10+cu] = mmr(mmSP0_UE_ERR_STATUS_HI)
        g[se*10+cu] = mmr(mmSP1_UE_ERR_STATUS_LO)
        h[se*10+cu] = mmr(mmSP1_UE_ERR_STATUS_HI)
    oneCU = oneCUce if ENABLE_CHECK_CEUE == 1 else oneCUuece
    if ENABLE_CHECK_CEUE == 2 : oneCU = oneCUue
    with open(options.output, 'w') as file:
     with mystdin(stdinmode) as stdin :
      while True:
        myus = time.time_ns()//1000
        myuslo = myus & 0xffffffff
        myushi = (myus>>32) & 0xffffffff
        smn.mmw(mmMP1_PUB_SCRATCH10, myuslo)
        smn.mmw(mmMP1_PUB_SCRATCH11, myushi)
        mystrs.append("\n%s: %s.%s\n"%(str(myus),str(myushi), str(myuslo))) 
        
        for xcc in myxccs:
            useXCC(xcc)
            each.cuexisting(oneCU)
            if ENABLE_CHECK_CEUE & 2 > 0:
                 if any(a) or any(b) or any(c) or any(d): 
                    mystrs.append("CE \n%s \n%s \n%s \n%s"%(str(a), str(b),str(c),str(d)))
            if ENABLE_CHECK_CEUE & 1 > 0:
                if any(e) or any(f) or any(g) or any(h): 
                   mystrs.append("UE \n%s \n%s \n%s \n%s"%(str(e), str(f),str(g),str(h)))
        index = index +1
        if (index &0x3ff == 0):
             file.write('\n'.join(mystrs))
             mystrs = []
             print("%d.."%index,end=".", flush=True)
             file.flush()            
             char = stdin.getch()
             if(char == "q" or char == '\x1b'):break
        if stall_seconds != 0: time.sleep(stall_seconds)
ret = 1
if not (options.rcmd or  options.cmd) : 
   dump( 0, [4,5], 0) 
