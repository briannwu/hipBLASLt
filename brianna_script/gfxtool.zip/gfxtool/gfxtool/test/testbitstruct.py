from ctypes import *
class BitStruct():
   import bitstruct as bs
   def __init__(self, *dwords):
           self._u32All = [0]*self._ndwords_
           if len(dwords) == 0 :
               self.parse()
               return
           if isinstance(dwords[0], list) or isinstance(dwords[0], tuple):
               for i, k in enumerate(dwords[0]): self.u32All[i] = k
           else:
               for i, k in enumerate(dwords): self.u32All[i] = k
           self.parse()
   def hexlist(self, _l):
           s = ' '.join("0x%x"%i for i in _l)
           return s
   def parse(self):
           self._img_rsrc =BitStruct.bs.pack("<" + "u32"*self._ndwords_, *tuple(self.u32All))
           self.bits = BitStruct.bs.unpack(self._packdes_, self._img_rsrc)
   def print(self):
           self.parse()
           for i, k in enumerate(self._fields_):
               print("%28s 0x%x"%(k[0], self.bits[i]))
   def __setitem__(self, index, value):
       self._u32All[index] = value
       self.parse()
   def __getitem__(self, index):
       return self._u32All[index]

   def __len__(self):
        return self._ndwords_

   @property
   def u32All(self):
      return self._u32All
   @u32All.setter
   def u32All(self, r):
       print("setter")
       pass
   @staticmethod
   def getpackdes(_fields_):
       des = ''.join("u%d"%k[2] for k in _fields_)
       ndwords = sum([k[2] for k in _fields_])
       return "<" + des, ndwords
class sq_img_rsrc_t (BitStruct):
       _fields_ = [
        ('base_address', c_uint64, 40),
        ('min_lod', c_uint32, 12),
        ('format', c_uint32, 9),
        ('_reserved_61_61', c_uint32, 1),
        ('width', c_uint32, 16),
        ('height', c_uint32, 16),
        ('_reserved_94_94', c_uint32, 1),
        ('resource_level', c_uint32, 1),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('base_level', c_uint32, 4),
        ('last_level', c_uint32, 4),
        ('sw_mode', c_uint32, 5),
        ('bc_swizzle', c_uint32, 3),
        ('type', c_uint32, 4),
        ('depth', c_uint32, 16),
        ('base_array', c_uint32, 16),
        ('array_pitch', c_uint32, 4),
        ('max_mip', c_uint32, 4),
        ('min_lod_warn', c_uint32, 12),
        ('perf_mod', c_uint32, 3),
        ('corner_samples', c_uint32, 1),
        ('linked_resource', c_uint32, 1),
        ('lod_hdw_cnt_en', c_uint32, 1),
        ('prt_default', c_uint32, 1),
        ('_reserved_190_187', c_uint32, 4),
        ('big_page', c_uint32, 1),
        ('counter_bank_id', c_uint32, 8),
        ('_reserved_201_200', c_uint32, 2),
        ('iterate_256', c_uint32, 1),
        ('_reserved_206_203', c_uint32, 4),
        ('max_uncompressed_block_size', c_uint32, 2),
        ('max_compressed_block_size', c_uint32, 2),
        ('meta_pipe_aligned', c_uint32, 1),
        ('write_compress_enable', c_uint32, 1),
        ('compression_en', c_uint32, 1),
        ('alpha_is_on_msb', c_uint32, 1),
        ('color_transform', c_uint32, 1),
        ('meta_data_address', c_uint64, 40),
       ]
       _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)
img = sq_img_rsrc_t([0xf4010600, 0xc0700000, 0x801fc01f, 0xe1800fac, 0x00000000, 0x00000000, 0x00680000, 0x00f40108])
img.print()
img.u32All[0] = 0xaa
img.print()
img = sq_img_rsrc_t(0xf4010600, 0xc0700000)
img[0] = 0xbb
img.print()
