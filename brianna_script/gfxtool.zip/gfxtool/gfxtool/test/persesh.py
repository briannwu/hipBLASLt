#!/usr/bin/python
import sys
from db32 import *
import os
import commands
from optparse import OptionParser
MSG_USAGE = " -e'cmds'"
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-e', '--execute', dest='cmd', type='string' , default="")
options, args = optParser.parse_args(sys.argv[1:])

if len(sys.argv) <2:
    print (MSG_USAGE) 
    exit(1)


#perseshGFX9("mmr(mmCC_GC_SHADER_ARRAY_CONFIG)\nmmr(mmCC_GC_SHADER_ARRAY_CONFIG)")
perseshGFX9(options.cmd)

