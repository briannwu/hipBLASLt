stream GRBM_SH_reg
field[0] = 1'h clken
field[1] = 1'h send
field[2] = 16'h addr
field[3] = 1'h op
field[4] = 32'h wd
endstream

data
GRBM_SH_reg 1 1 2e0c 1 00000000 @ 00000001
GRBM_SH_reg 1 1 2e0d 1 00000000 @ 00000002
GRBM_SH_reg 1 1 2e12 1 00000041 @ 00000003
GRBM_SH_reg 1 1 2e13 1 00000090 @ 00000004
GRBM_SH_reg 1 1 2e28 1 00000000 @ 00000005
GRBM_SH_reg 1 1 2e2a 1 eabc2cde @ 00000006
enddata
	0xb0804009, 0x960a0075,
	0x360000ff, 0x000003ff,
	0xd7006a04, 0x0002000a,
	0x30140882, 0x7e160280,
	0xbefd00ff, 0x000004ff,
	0xee050004, 0x000c0008,
	0x0000000a, 0xbfc00000,
	0xee068006, 0x04000000,
	0x0000000a, 0xbfc10000,
	0xbfb00000, 0xbf9f0000,
	0xbf9f0000, 0xbf9f0000,
	0xbf9f0000, 0xbf9f0000,
