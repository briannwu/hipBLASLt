def halt_resume(**kwargs):
    global isHalted
    isHalted = True
    stall_seconds = kwargs['sleep'] if 'sleep' in kwargs else 0.001
    def one(xcc):
        global isHalted
        if isHalted:
            SQ.resume()
        else:
            SQ.halt()
        return ""
    def preloop():
        global isHalted
        isHalted = not isHalted
    if GC__VARIANT == mi300 :
        watchXCC(one, [], 0.001, True, preloop)
    else:
        watch(one, 0.001, True, preloop)

    def resumeALL(xcc):
        SQ.resume()
    each.xcc(resumeALL)

if not (options.rcmd or  options.cmd) :
    halt_resume()
