#!/usr/bin/python

import os
import sys
from subprocess import call
from optparse import OptionParser
MSG_USAGE = " -n loops -e 'cmds'"
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-c', '--cu',  dest='thecu', type=int , default=-1)
optParser.add_option('-n', '--numOfLoops',  dest='loops', type=int , default=10)
optParser.add_option('-e', '--execute', dest='cmd', type='string' , default="")
options, args = optParser.parse_args(sys.argv[1:])
Cmd = options.cmd
Cmd = "sudo " + Cmd
Blocklist = []
def enableCU(cuid):
    se = cuid // 16
    lid = cuid % 16
    grbm_gfx_index = (se<<16) & 0xffffffff
    grbm_gfx_index_hex = "%X" % grbm_gfx_index
    gc_user_shader_array_config =  ( (~(1 << lid)) << 16) & 0xffff0000
    gc_user_shader_array_config_hex = "%X" % gc_user_shader_array_config
    print grbm_gfx_index_hex
    print gc_user_shader_array_config_hex
    cmd = "csselect 33 \n"
    cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 89c0 " + gc_user_shader_array_config_hex + "\n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32script", "w")
    f.write(cmd)
    f.close()
    r = os.popen("sudo ./db32 exe db32script").read()
    print cmd
    print r
def runaCU(cuid):
    enableCU(cuid)
    passes = 0
    print "Running on cu: " , cuid
    for i in range(0,options.loops):
        print "runing on cu: ", cuid, " at " , i
        r = os.popen(Cmd).read()
        print r
        if "Total Pass: 1" in r:
            passes = passes + 1
    print "on CU ", cuid, " passes: ", passes
    print passes * 100.0 / options.loops, "% pass"
    return passes

if options.thecu == -1:
    pall = []
    for i in range(0,64):
        if i in Blocklist:
            pall.append( 0)
            print i,  " is blocked"
        else:
            pi = runaCU(i)
            pall.append( pi)

    for i in range(0,64):
        print  i,   pall[i]
else:
    pi = runaCU(options.thecu)
    print "passes:", pi
    print pi * 100.0 / options.loops, "% pass"

