#!/usr/bin/python3
import sys
import os
import csv
if sys.version_info.major == 2:
    import commands as subprocess
else:
    import subprocess
from excel import Excel
if sys.version_info.major == 2:
    import commands as subprocess
else:
    import subprocess
from optparse import OptionParser
from statistics import mean

MSG_USAGE = " -i chip_offset.h -o chip_offset.py \n \
droop1 is calculated by v_pin - v_load \n \
psm_droop is calculated by v_dev - v_load \n \
droop2 is calculated by v_dev(idle) - v_dev(active)"
optParser = OptionParser(MSG_USAGE)
optParser.add_option('--ll', '--loadline', dest='loadline', type='float' , default=0.00035)
optParser.add_option('-i', '--input', dest='input', type='string' , default="pm.log.csv")
optParser.add_option('-o', '--output', dest='output', type='string' , default="")
optParser.add_option('-x', '--prefix', dest='prefix', type='string' , default="")
optParser.add_option('-d', '--device', dest='device', type='string' , default="0")
optParser.add_option('-s', '--save', dest='save', type='string' , default="")
optParser.add_option( '--aid', dest='aid', type=int, default=0xff)
optParser.add_option( '--gfx1', dest='gfx1', action="store_true")
optParser.add_option( '--gfx0', dest='gfx0', action="store_true", default=True)
options, args = optParser.parse_args(sys.argv[1:])

if options.output == "":
    options.output = ".droop." + options.input
options.output = "droop." + options.prefix + options.output

def getKeyIndex(header, keys):
    return [header.index(key) for key in keys]


def getKeys(csvfile, keys, psmKeys, psmCountKeys):
    with open(csvfile) as csf:
        reader = csv.reader(csf)
        header = []
        # print(header)
        row_id = 0
        rows = []
        keyIndex = []
        psmkeyIndex = []
        psmCountkeyIndex = []
        for row in reader:
            if row_id == 0 :
                header = row
                keyIndex = getKeyIndex(header, keys)
                psmkeyIndex = getKeyIndex(header, psmKeys)
                psmCountkeyIndex = getKeyIndex(header, psmCountKeys)
            else:
                #rows.append(row)
                item = [float(row[kid]) for kid in keyIndex]
                psms = [float(row[kid]) for kid in psmkeyIndex]
                psmc = [float(row[kid]) for kid in psmCountkeyIndex]
                item.append(min(psms))
                item.append(min(psmc))
                rows.append(item)
            row_id = row_id + 1
        return rows
def writecsv(csvfile, *datas):
    with open(csvfile, "w") as csf:
        writer = csv.writer(csf)
        for data in datas: writer.writerows(data)

def getminpsm():
    excel = Excel(options.input)
    GFXID = "GFX1" if options.gfx1 == True else "GFX0"
    GPU = "GPU%s"%options.device
    GPU0_FLAG = " GPU0"
    if not excel.haskey(GPU + ' SVI2 Set Voltage VDDCR_' + GFXID):
        GFXID = "GFX"
        GPU0_FLAG = ""
 
    is_dsmLog = excel.haskey('System_TimestampLo')
    AID0XCD0_exist = excel.haskey('GPU0 Minimum PSM Count AID0 XCD0 GFX PSM#0 ')
    AID = 0
    psmCountKeys = []
    psmKeysAID = [ GPU + ' Minimum PSM Voltage AID%d Voltage#%d '%(AID,i) for i in range(0,30)]
    psmCountKeysAID = [ GPU + ' Minimum PSM Count AID%d PSM#%d '%(AID,i) for i in range(0,30)]
    startAID = 0 if AID0XCD0_exist else 1
    for AID in range(startAID,4):
        for XCD in range(0,2):
            psmKeysXCD0 = [ GPU + ' Minimum PSM Voltage AID%d XCD%d GFX Voltage#%d '%(AID,XCD,i) for i in range(0,28)]
            psmCountKeysXCD0 = [ GPU + ' Minimum PSM Count AID%d XCD%d GFX PSM#%d '%(AID,XCD,i) for i in range(0,28)]
            psmCountKeys = psmCountKeys + psmCountKeysXCD0
    if is_dsmLog:
        if options.aid < 4:
            psmCountKeys = ['Data_XCD_%d_minofminGFXPsmCount'%myXCD for myXCD in range(options.aid*2,options.aid*2+2)]
        else:
            #psmCountKeys = ['Data_XCD_%d_minofminGFXPsmCount'%myXCD for myXCD in range(0,8)]
            psmCountKeys = ['Data_XCD_%d_minofminGFXPsmCount'%myXCD for myXCD in range(4,6)]
        if False:
             psmCountKeys = [ ]
             for XCD in range(0,2):
                 psmCountKeysXCD0 = ['XCD%d_AvfsDebugTable_minPsmCount_%d'%(XCD,i) for i in range(0,28)]
                 psmCountKeys = psmCountKeys + psmCountKeysXCD0
    #_rows = getKeys(options.input, keys, psmKeys, psmCountKeys)


    #psmKeys = psmKeysXCD0 + psmKeysXCD1 + psmKeysAID 
    #psmCountKeys = psmCountKeysXCD0 + psmCountKeysXCD1 + psmCountKeysAID
    #psmV = excel.min(psmKeys)
    psmC = excel.min(psmCountKeys)
    #print("XCD", psmC) # min of each row
    print("XCD", min(psmC))
    if not is_dsmLog:
        psmCAid = excel.min(psmCountKeysAID)
        #print("AID0", psmCAid)
        print("AID0", min(psmCAid))

    psmCs = [ min(excel.min([key])) for key in psmCountKeys]
    psmXCC = [ psmCs[i*28:i*28+28] for i in range(len(psmCs)//28)]
    for x in psmXCC: print(x)
    t = min(psmCs)[0]
    tid = 0
    for i in range(0,len(psmCs)):
        if psmCs[i][0] == t :
            tid = i
    AIDOFFSET = 0 if AID0XCD0_exist  else 1
    #print(AID0XCD0_exist)
    print(psmCs)
    print("XCD%d"%(tid), min(psmCs))
    print(min(psmCs)[0])
    if options.save :
        saveKeys = ["idx","System_TimestampLo","System_TimestampHi","System_TimestampLo2","System_TimestampHi2"] + psmCountKeys
        excel.save(saveKeys, options.save+str(min(psmCs)[0])+".csv")

good = 0
try:
  getminpsm()
  good = 1
except Exception as e:
    mystr = str(e)
    if 'decode byte ' in mystr:
        #leftstart = mystr.index('decode byte ') + len('decode byte ')
        #badc = mystr[leftstart:leftstart+4] 
        #badi = int(badc,16)
        #bads = chr(badi)
        #print(badc, badi, bads)
        with open(options.input, encoding='utf-8', errors='ignore') as f:
                data = f.read()
        with open(options.input, "w") as f:
                f.write(data)
if good == 0: getminpsm()
