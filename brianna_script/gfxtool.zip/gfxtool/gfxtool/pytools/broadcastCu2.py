#!/usr/bin/python

import os
import sys
from subprocess import call
from optparse import OptionParser
MSG_USAGE = " -n loops --cs=#cs -e'cmds'"
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-c', '--cu',  dest='thecu', type=int , default=-1, help="cuid")
optParser.add_option('-s', '--cs',  dest='thecs', type="string" , default=-1)
optParser.add_option('-n', '--numOfLoops',  dest='loops', type=int , default=10)
optParser.add_option('-e', '--execute', dest='cmd', type='string' , default="")
optParser.add_option('--cuperse',  dest='num_cu_per_se', type=int , default=16)
optParser.add_option('-D', '--Disable',  dest='disabletest', action='store_true', default=False)
optParser.add_option('-S', '--Screen',  dest='screen', action='store_true', default=False)
optParser.add_option('-b', '--block',  dest='block', type=int, default=-1)
optParser.add_option('-B', '--blocklist',  dest='block_list', type="string", default="")
options, args = optParser.parse_args(sys.argv[1:])

if len(sys.argv) <3:
    print MSG_USAGE
    exit(1)

NUM_SE = 4
NUM_CU_PER_SE = options.num_cu_per_se
if options.thecs == -1:
   print "please specify --cs csselect_index"
   exit()
Cmd = options.cmd
Cmd = "sudo " + Cmd
Blocklist = []

if options.block > -1:
    Blocklist.append(options.block)
if len(options.block_list) > 0:
    blocked_cus = options.block_list.split(",")
    for i in blocked_cus:
        Blocklist.append(int(i))

print "blocked: ", Blocklist

def enableAllCUs():
    if options.thecs == -1:
        cmd = ""
    else:
        cmd = "csselect " + options.thecs + " \n"
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    cmd = cmd + "regw32 89c0 0 \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32.enableallcus", "w")
    f.write(cmd)
    f.close()

    r = os.popen("sudo ./db32 exe db32.enableallcus").read()
    print r
def disableAllCUs():
    if options.thecs == -1:
        cmd = ""
    else:
        cmd = "csselect " + options.thecs + " \n"
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    cmd = cmd + "regw32 89c0 ffffffff \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32.disableallcus", "w")
    f.write(cmd)
    f.close()

    r = os.popen("sudo ./db32 exe db32.disableallcus").read()
    print r
def disableCU(cuid):
    se = cuid // NUM_CU_PER_SE
    lid = cuid % NUM_CU_PER_SE
    lid = lid * 2
    grbm_gfx_index = (se<<16) & 0xffffffff
    grbm_gfx_index_hex = "%X" % grbm_gfx_index
    gc_user_shader_array_config =  ( ((3 << lid)) << 16) & 0xffff0000
    gc_user_shader_array_config_hex = "%X" % gc_user_shader_array_config
    print grbm_gfx_index_hex
    print gc_user_shader_array_config_hex
    if options.thecs == -1:
        cmd = ""
    else:
        cmd = "csselect " + options.thecs + " \n"
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    cmd = cmd + "regw32 89c0 " + gc_user_shader_array_config_hex + "\n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32script", "w")
    f.write(cmd)
    f.close()
    r = os.popen("sudo ./db32 exe db32script").read()
    print cmd
    print r
def enable8CU(cuid):
    se = cuid // NUM_CU_PER_SE
    lid = cuid % NUM_CU_PER_SE
    lid = lid * 2
    grbm_gfx_index = (se<<16) & 0xffffffff
    grbm_gfx_index_hex = "%X" % grbm_gfx_index
    gc_user_shader_array_config =  ( (~(3 << lid)) << 16) & 0xffff0000
    gc_user_shader_array_config_hex = "%X" % gc_user_shader_array_config
    print grbm_gfx_index_hex
    print gc_user_shader_array_config_hex
    if options.thecs == -1:
        cmd = ""
    else:
        cmd = "csselect " + options.thecs + " \n"
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    cmd = cmd + "regw32 89c0 " + gc_user_shader_array_config_hex + "\n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32script", "w")
    f.write(cmd)
    f.close()
    r = os.popen("sudo ./db32 exe db32script").read()
    print cmd
    print r
def run8CU(cuid):
    disableAllCUs()
    enable8CU(cuid)
    passes = 0
    print "............................................."
    print "Running on cu: " , cuid*2 , cuid*2 + 1
    for i in range(0,options.loops):
        print "runing on cu ", cuid, ": at " , i
        r = os.popen(Cmd).read()
        print r
        if "Total Pass: 1" in r:
            passes = passes + 1
    print "on CU ", cuid, " passes: ", passes
    print passes * 100.0 / options.loops, "% pass"
    return passes
def runWithoutCU(cuid):
    disableAllCUs()
    disableCU(cuid)
    passes = 0
    print "Running without cu: " , cuid*2, cuid*2 +1
    for i in range(0,options.loops):
        print "runing without cu ", cuid, ": at " , i
        r = os.popen(Cmd).read()
        print r
        if "Total Pass: 1" in r:
            passes = passes + 1
    print "without CU ", cuid, " passes: ", passes
    print passes * 100.0 / options.loops, "% pass"
    return passes
def testEnable():
    pall = []
    pi = 0
    if options.thecu == -1:
        for i in range(0,NUM_CU_PER_SE/2):
            if i in Blocklist:
                pall.append( 0)
                print i,  " is blocked"
            else:
                pi = run8CU(i)
                pall.append( pi)

        print ""
        print ""
        print ""
        print "In summary:"
        for i in range(0, NUM_CU_PER_SE/2):
            print  'CU{0:2d},{1:2d}  passes:{2:4d} of {3:4d}'.format(i*2, i*2+1, pall[i], options.loops)
        print pall
    else:
        pi = run8CU(options.thecu)
        print "passes:", pi
        print pi * 100.0 / options.loops, "% pass"

    enableAllCUs()

    if options.screen:
        if options.thecu == -1:
            for i in range(0,16):
                if pall[i] != options.loops :
                    disableCU(i)
        else:
            if pi != options.loops:
                disableCU(options.thecu)

def testDisable():
    pall = []
    pi = 0
    if options.thecu == -1:
        for i in range(0,NUM_CU_PER_SE/2):
            if i in Blocklist:
                pall.append( 0)
                print i,  " is blocked"
            else:
                pi = runWithoutCU(i)
                pall.append( pi)

        print ""
        print ""
        print ""
        print "In summary:"
        for i in range(0,NUM_CU_PER_SE/2):
            print  'Without CU{0:2d},{1:2d}  passes:{2:4d} of {3:4d}'.format(i*2, i*2+1, pall[i], options.loops)
    else:
        pi = runWithoutCU(options.thecu)
        print "passes:", pi
        print pi * 100.0 / options.loops, "% pass"

    enableAllCUs()

if options.disabletest :
    testDisable()
else:
    testEnable()


