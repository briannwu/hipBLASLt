#!/usr/bin/python3
import sys
import os
import csv
from excel import Excel
if sys.version_info.major == 2:
    import commands as subprocess
else:
    import subprocess
from optparse import OptionParser
MSG_USAGE = " -i chip_offset.h -o chip_offset.py "
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-i', '--input', dest='input', type='string' , default="pm.log.csv")
optParser.add_option('-o', '--output', dest='output', type='string' , default="")
optParser.add_option('-x', '--prefix', dest='prefix', type='string' , default="")
optParser.add_option('-d', '--device', dest='device', type='string' , default="0")
options, args = optParser.parse_args(sys.argv[1:])

if options.output == "":
    options.output = "_psm." + options.input
options.output = "psm." + options.prefix + options.output

def getKeyIndex(header, keys):
    return [header.index(key) for key in keys]


def getKeys(csvfile, keys, psmKeys, psmCountKeys):
    with open(csvfile) as csf:
        reader = csv.reader(csf)
        header = []
        # print(header)
        row_id = 0
        rows = []
        keyIndex = []
        psmkeyIndex = []
        psmCountkeyIndex = []
        for row in reader:
            if row_id == 0 :
                header = row
                #keyIndex = getKeyIndex(header, keys)
                psmkeyIndex = getKeyIndex(header, psmKeys)
                psmCountkeyIndex = getKeyIndex(header, psmCountKeys)
            else:
                #rows.append(row)
                #item = [float(row[kid]) for kid in keyIndex]
                item = [0]*len(keys)
                psms = [float(row[kid]) for kid in psmkeyIndex]
                psmc = [float(row[kid]) for kid in psmCountkeyIndex]
                item.append(min(psms))
                item.append(min(psmc))
                rows.append(item)
            row_id = row_id + 1
        return rows
def writecsv(csvfile, *datas):
    with open(csvfile, "w") as csf:
        writer = csv.writer(csf)
        for data in datas: writer.writerows(data)

def getdroop():
    keys = [
            'GPU0 SVI2 Set Voltage VDDCR_GFX0',
            'GPU0 SVI2 Telemetry Voltage VDDCR_GFX0',
            'GPU0 GPU0 Frequencies Target Frequency GFXCLK',
            'GPU0 GPU0 Frequencies Actual Frequency GFXCLK',
            'GPU0 SVI2 Telemetry Current VDDCR_GFX0'
            ]
    #GPU = "GPU%s "%options.device
    GPU = ""
    if options.device != "0":
        keys = [
                GPU + 'SVI2 Set Voltage VDDCR_GFX0',
                GPU + 'SVI2 Telemetry Voltage VDDCR_GFX0',
                GPU + 'GPU0 Frequencies Target Frequency GFXCLK',
                GPU + 'GPU0 Frequencies Actual Frequency GFXCLK',
                GPU + 'SVI2 Telemetry Current VDDCR_GFX0'
                ]
    psmKeys = [ GPU + 'Minimum PSM Voltage GFX Min. Voltage#%d GPU0'%i for i in range(0,60)]
    psmCountKeys = [ GPU + 'Minimum PSM Count GFX PSM#%d GPU0'%i for i in range(0,60)]

    excel = Excel(options.input)
    psmV = excel.min(psmKeys)
    psmC = excel.min(psmCountKeys)
    _rows = excel.combine([[0]*(len(keys))]*len(psmC), psmV, psmC)

    item_size = len(keys)+4
    all_min = [10000.0] * item_size
    all_max = [0] * item_size
    all_avg = [0] * item_size
    rows=[]
    for _row in _rows:
        current = _row[4]
        #if current  < 10.0 : continue
        v_set = _row[0]
        v_load= _row[1]
        v_dev = _row[5]
        v_pin = v_set - current * 0.00035
        droop = (v_pin - v_load) * 1000
        psm_droop = (v_dev - v_load) * 1000
        row = _row.copy()
        row.append(droop)
        row.append(psm_droop)
        rows.append(row)
    for row in rows:
        for i in range(len(row)):
            all_avg[i] = all_avg[i]  + row[i]
            all_min[i] = min(all_min[i], row[i])
            all_max[i] = max(all_max[i], row[i])
    header = ["v_set", "v_load", "f_set", "f_load", "current", 'v_minPSM', 'minPSMcnt', "droop", "psm_droop"]
    for i in range(len(all_avg)): all_avg[i] = all_avg[i] / len(rows)

    writecsv(options.output, [header], rows, [[0] * item_size], [all_min], [all_max], [all_avg])
    def tostr(data):
        str0 = ["%s"%str(i)[0:7] for i in data]
        str1 = [ "%10s"%i for i in str0]
        return ",".join(str1)
    def tostr2(data):
        str0 = ["%10s"%str(i) for i in data]
        str1 = [ i for i in str0]
        return ",".join(str1)
    print("   ", tostr(header))
    print("min", tostr(all_min))
    print("max", tostr(all_max))
    print("avg", tostr(all_avg))


getdroop()
