#!/usr/bin/python

import sys
import os
if sys.version_info.major == 2:
    import commands as subprocess
else:
    import subprocess
from optparse import OptionParser
MSG_USAGE = " -i chip_offset.h -o chip_offset.py "
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-i', '--input', dest='input', type='string' , default="chip_registers.h")
optParser.add_option('-t', '--tempfile', dest='tempfile', type='string' , default="chip_registers.i")
optParser.add_option('-o', '--output', dest='output', type='string' , default="")
optParser.add_option('-l', '--list', dest='list', type='string' , default="")
options, args = optParser.parse_args(sys.argv[1:])

codes= []
codes32 = []
codestr = []

def findcode(filename):
    wholef = open(filename, "rb").read()
    pos = []
    wbf810000 = '\x00\x00\x81\xbf'
    w00000000 = '\x00\x00\x00\x00'
    _start = 0
    _pos = wholef.find(wbf810000, _start)
    while  _pos != -1:
        _pos0 = wholef.rfind(w00000000, _start, _pos)
        pos.append((_pos0+4, _pos+4))
        _start = _pos + 4
        _pos = wholef.find(wbf810000, _start)
    for i0,i1 in pos:
        codes.append(wholef[i0:i1])
    for code in codes:
        code32 = []
        for i in range(len(code)//4):
            code32.append( ord(code[4*i]) | (ord(code[4*i+1]) << 8) | (ord(code[4*i+2]) << 16) | (ord(code[4*i+3]) << 24))
        codes32.append(code32)
    for code32 in codes32:
        code32str = ' '.join(["%8x"%i for i in code32])
        codestr.append(code32str)


def disasm(hexstr, i):
    tmp = ".tmps%d.hex"%i
    open(tmp,"w").write(hexstr)
    output = options.output if options.output else options.input
    output = "%s%d.sp3"%(output, i)
    cmd = "./sp3 -hex %s %s"%(tmp, output)
    print cmd
    err,r = subprocess.getstatusoutput(cmd)
    print err, r

def mediazip():
    if os.path.exists('media.zip'): return
    #empty_zip_data = 'PK\x05\x06\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    #with open('media.zip', 'wb') as zip:
    #     zip.write(empty_zip_data)
    import zipfile
    zipf = zipfile.ZipFile('media.zip', 'w', zipfile.ZIP_DEFLATED)
    zipf.writestr('tmp', 'a')
    zipf.close()

findcode(options.input)
mediazip()
for i, s in enumerate(codestr):
    disasm(s, i)
