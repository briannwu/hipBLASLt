#!/usr/bin/python3
import sys
import os
import csv
from excel import Excel
if sys.version_info.major == 2:
    import commands as subprocess
else:
    import subprocess
from optparse import OptionParser
from statistics import mean

MSG_USAGE = " -i chip_offset.h -o chip_offset.py \n \
droop1 is calculated by v_pin - v_load \n \
psm_droop is calculated by v_dev - v_load \n \
droop2 is calculated by v_dev(idle) - v_dev(active)"
optParser = OptionParser(MSG_USAGE)
optParser.add_option('--ll', '--loadline', dest='loadline', type='float' , default=0.00035)
optParser.add_option('-i', '--input', dest='input', type='string' , default="pm.log.csv")
optParser.add_option('-o', '--output', dest='output', type='string' , default="")
optParser.add_option('-x', '--prefix', dest='prefix', type='string' , default="")
optParser.add_option('-d', '--device', dest='device', type='string' , default="0")
optParser.add_option( '--gfx1', dest='gfx1', action="store_true")
optParser.add_option( '--gfx0', dest='gfx0', action="store_true", default=True)
options, args = optParser.parse_args(sys.argv[1:])

if options.output == "":
    options.output = ".droop." + options.input
options.output = "droop." + options.prefix + options.output

def getKeyIndex(header, keys):
    return [header.index(key) for key in keys]


def getKeys(csvfile, keys, psmKeys, psmCountKeys):
    with open(csvfile) as csf:
        reader = csv.reader(csf)
        header = []
        # print(header)
        row_id = 0
        rows = []
        keyIndex = []
        psmkeyIndex = []
        psmCountkeyIndex = []
        for row in reader:
            if row_id == 0 :
                header = row
                keyIndex = getKeyIndex(header, keys)
                psmkeyIndex = getKeyIndex(header, psmKeys)
                psmCountkeyIndex = getKeyIndex(header, psmCountKeys)
            else:
                #rows.append(row)
                item = [float(row[kid]) for kid in keyIndex]
                psms = [float(row[kid]) for kid in psmkeyIndex]
                psmc = [float(row[kid]) for kid in psmCountkeyIndex]
                item.append(min(psms))
                item.append(min(psmc))
                rows.append(item)
            row_id = row_id + 1
        return rows
def writecsv(csvfile, *datas):
    with open(csvfile, "w") as csf:
        writer = csv.writer(csf)
        for data in datas: writer.writerows(data)

def getdroop():
    excel = Excel(options.input)
    GFXID = "GFX1" if options.gfx1 == True else "GFX0"
    GPU = "GPU%s"%options.device
    GPU0_FLAG = " GPU0"
    if not excel.haskey(GPU + ' SVI2 Set Voltage VDDCR_' + GFXID):
        GFXID = "GFX"
        GPU0_FLAG = ""
    keys = [
            'GPU0 SVI2 Set Voltage VDDCR_' + GFXID,
            'GPU0 SVI2 Telemetry Voltage VDDCR_' + GFXID,
            'GPU0 Frequencies Target Frequency GFXCLK',
            'GPU0 Frequencies Actual Frequency GFXCLK',
            'GPU0 SVI2 Telemetry Current VDDCR_'+ GFXID
            ]
    if options.device != "0":
        keys = [
                GPU + ' SVI2 Set Voltage VDDCR_' + GFXID,
                GPU + ' SVI2 Telemetry Voltage VDDCR_'+ GFXID,
                GPU + GPU0_FLAG + ' Frequencies Target Frequency GFXCLK',
                GPU + GPU0_FLAG + ' Frequencies Actual Frequency GFXCLK',
                GPU + ' SVI2 Telemetry Current VDDCR_' + GFXID
                ]
    psmKeys = [ GPU + ' Minimum PSM Voltage  GFX Min. Voltage#%d '%i for i in range(0,60)]
    psmCountKeys = [ GPU + ' Minimum PSM Count  GFX PSM#%d '%i for i in range(0,60)]
    #_rows = getKeys(options.input, keys, psmKeys, psmCountKeys)


    psmV = excel.min(psmKeys)
    psmC = excel.min(psmCountKeys)
    _rows = excel.combine(excel.select(keys), psmV, psmC)
    idle = [item for sublist in psmV[0:2] for item in sublist]
    v_dev_idle = mean(idle)
    print("v_dev in idle status:", idle)

    item_size = len(keys)+5
    all_min = [10000.0] * item_size
    all_max = [0] * item_size
    all_avg = [0] * item_size
    rows=[]
    for _row in _rows:
        current = _row[4]
        #if current  < 10.0 : continue
        v_set = _row[0]
        v_load= _row[1]
        v_dev = _row[5]
        v_pin = v_set - current * options.loadline
        droop1 = (v_pin - v_load) * 1000
        psm_droop = (v_dev - v_load) * 1000
        droop2 = (v_dev_idle - v_dev) * 1000
        row = _row.copy()
        row.append(droop1)
        row.append(psm_droop)
        row.append(droop2)
        rows.append(row)
    for row in rows:
        for i in range(len(row)):
            all_avg[i] = all_avg[i]  + row[i]
            all_min[i] = min(all_min[i], row[i])
            all_max[i] = max(all_max[i], row[i])
    header = ["v_set", "v_load", "f_set", "f_load", "current", 'v_dev', 'minPSMcnt', "droop1", "psm_droop", "droop2"]
    for i in range(len(all_avg)): all_avg[i] = all_avg[i] / len(rows)
    all_result = all_min[0:4] 
    all_result = all_result + [all_max[4]] + all_min[5:7] + all_max[7:9] + [all_max[9]]
    
    writecsv(options.output, [header], rows, [[0] * item_size], [all_min], [all_max], [all_avg], [all_result])
    def tostr(data):
        str0 = ["%s"%str(i)[0:7] for i in data]
        str1 = [ "%10s"%i for i in str0]
        return ",".join(str1)
    def tostr2(data):
        str0 = ["%10s"%str(i) for i in data]
        str1 = [ i for i in str0]
        return ",".join(str1)
    print("Loadline: ", options.loadline)
    print("    ", tostr(header))
    print(" min", tostr(all_min))
    print(" max", tostr(all_max))
    print(" avg", tostr(all_avg))
    print("copy", tostr(all_result))
    min_v_dev = all_min[5]
    if (min_v_dev - 0.6 < 0.0001):
        print("v_dev is too small, capped at 0.6, please calculate v_dev and droop using P2V curve")

getdroop()
