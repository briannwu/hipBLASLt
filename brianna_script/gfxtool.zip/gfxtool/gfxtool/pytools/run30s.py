#!/usr/bin/python

import os
import sys
from subprocess import call
from optparse import OptionParser
MSG_USAGE = " -n loops -e 'cmds'"
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-n', '--numOfLoops',  dest='loops', type=int , default=30)
optParser.add_option('-e', '--execute', dest='cmd', type='string' , default="")
options, args = optParser.parse_args(sys.argv[1:])
cmd = options.cmd
loops = options.loops
def runa():
    passes = 0
    for i in range(0,loops):
        print "running ...: ", i
        r = os.popen(cmd).read()
        print r
        if "Total Pass: 1" in r:
            passes = passes + 1
    return passes
passes = runa()
print "total passes: ", passes, "in ", loops
print passes * 100.0 /loops ,"% pass"
