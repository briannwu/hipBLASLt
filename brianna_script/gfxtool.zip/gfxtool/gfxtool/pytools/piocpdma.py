#!/usr/bin/python

import os
import sys
from subprocess import call
from optparse import OptionParser
MSG_USAGE = " -s src -d dst -l size --cs=#cs "
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-s', '--src',  dest='src', type=int , default=0, help="cpdma source f4...")
optParser.add_option('-d', '--dst',  dest='dst', type=int , default=0x300000, help="cpdma dst f4...")
optParser.add_option('-l', '--length',  dest='size', type=int , default=0x2000, help="cpdma size ...")
optParser.add_option('-c', '--cs',  dest='thecs', type="string" , default=-1)
optParser.add_option('-t', '--type',  dest='', type="string" , default=-1)
options, args = optParser.parse_args(sys.argv[1:])

if len(sys.argv) <3:
    print MSG_USAGE
    exit(1)

def readback():
    cmd = ""
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regr32 3018c \n"
    cmd = cmd + "regr32 30190 \n"
    cmd = cmd + "regr32 30194 \n"
    cmd = cmd + "regr32 30198 \n"
    cmd = cmd + "regr32 3019c \n"
    cmd = cmd + "regr32 303a0 \n"
    cmd = cmd + "dvd " + "%X" % options.dst + "\n"
    f = open("db32.readback", "w")
    f.write(cmd)
    f.close()

    r = os.popen("sudo ./db32 exe db32.readback").read()
    print r



def docpdma():
    if options.thecs == -1:
        cmd = ""
    else:
        cmd = "csselect " + options.thecs + " \n"
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    srcAddrLow = options.src & 0xffffffff
    srcAddrHigh = (options.src & 0xffffffffffffffff) >> 32
    dstAddrLow = options.dst & 0xffffffff
    dstAddrHigh = (options.dst & 0xffffffffffffffff) >> 32
    cmd = cmd + "fv " + "%X" % dstAddrLow + " 1000 cc cc cc cc \n"
    cmd = cmd + "fv " + "%X" % srcAddrLow + " 1000 78 56 34 12 \n"
    cmd = cmd + "regw32 3018c 0  \n"
    cmd = cmd + "regw32 30190 " + "%X" % srcAddrLow + "\n"
    cmd = cmd + "regw32 30194 " + "%X" % srcAddrHigh + "\n"
    cmd = cmd + "regw32 30198 " + "%X" % dstAddrLow + "\n"
    cmd = cmd + "regw32 3019c " + "%X" % dstAddrHigh + "\n"
    cmd = cmd + "regw32 303a0  " + "%X" % options.size + "\n"

    cmd = cmd + "regr32 3018c \n"
    cmd = cmd + "regr32 30190 \n"
    cmd = cmd + "regr32 30194 \n"
    cmd = cmd + "regr32 30198 \n"
    cmd = cmd + "regr32 3019c \n"
    cmd = cmd + "regr32 303a0 \n"
    cmd = cmd + "dvd " + "%X" % dstAddrLow + "\n"

    cmd = cmd + "regw32 303a0  " + "%X" % options.size + "\n"
    cmd = cmd + "regr32 3018c \n"
    cmd = cmd + "regr32 30190 \n"
    cmd = cmd + "regr32 30194 \n"
    cmd = cmd + "regr32 30198 \n"
    cmd = cmd + "regr32 3019c \n"
    cmd = cmd + "regr32 303a0 \n"
    cmd = cmd + "dvd " + "%X" % dstAddrLow + "\n"

    cmd = cmd + "regw32 303a0  " + "%X" % options.size + "\n"
    cmd = cmd + "regr32 3018c \n"
    cmd = cmd + "regr32 30190 \n"
    cmd = cmd + "regr32 30194 \n"
    cmd = cmd + "regr32 30198 \n"
    cmd = cmd + "regr32 3019c \n"
    cmd = cmd + "regr32 303a0 \n"
    cmd = cmd + "dvd " + "%X" % dstAddrLow + "\n"

    f = open("db32.cpdma", "w")
    f.write(cmd)
    f.close()

    r = os.popen("sudo ./db32 exe db32.cpdma").read()
    print r

docpdma()
#readback()
