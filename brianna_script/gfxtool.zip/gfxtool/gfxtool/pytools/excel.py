import sys
import os
import csv
class Excel:
    def __init__(self, csvfile, **kwargs):
        with open(csvfile) as csf:
            reader = csv.reader(csf)
            header = []
            # print(header)
            row_id = 0
            rows = []
            for row in reader:
                if row_id == 0 :
                    self.header = row
                else:
                    rows.append(row)
                row_id = row_id + 1
            self.rows = rows
    def select(self, keys):
        items = []
        keyIndex = Excel.getKeyIndex(self.header, keys)
        for row in self.rows:
            item = [float(row[kid]) for kid in keyIndex]
            items.append(item)
        return items
    def save(self,keys, csvfile):
        keyIndex = Excel.getKeyIndex(self.header, keys)
        with open(csvfile, "w") as csf:
            csf.write(",".join(keys))
            csf.write("\n")
            for row in self.rows:
                item = [row[kid] for kid in keyIndex]
                csf.write(",".join([str(i) for i in item]))
                csf.write("\n")

    def min(self, keys):
        items = []
        keyIndex = Excel.getKeyIndex(self.header, keys)
        for row in self.rows:
            item = [float(row[kid]) for kid in keyIndex]
            items.append([min(item)])
        return items
    def max(self, keys):
        items = []
        keyIndex = Excel.getKeyIndex(self.header, keys)
        for row in self.rows:
            item = [float(row[kid]) for kid in keyIndex]
            itmes.append([max(item)])
        return items
    def haskey(self,key): 
        r = key in self.header
        return r
    @staticmethod
    def getKeyIndex(header, keys):
        return [header.index(key) for key in keys]
    @staticmethod
    def combine(list0, list1, *lists):
        #return [list0[i] + list1[i]  for i in range(len(list0))]
        newlist = []
        for i in range(len(list0)):
            newr = list0[i] + list1[i]
            for j in lists:
                newr.extend(j[i])
            newlist.append(newr)
        return newlist

