#!/usr/bin/python
from ctypes import *

lib = '/home/ddavid/git/tools/bin/libdb32.so'
dll = cdll.LoadLibrary(lib)
#good
#dll._Z12clear_screenv()
#dll.main(1,1)
dll._Z8mem_initv()
dll._Z10PCICS_initb(0)
dll._Z4initPc(0)
cmd = create_string_buffer("regr32 8010")
dll._Z5parsePKcsiPsP8_IO_FILEh(cmd,0,0,0,0,0)
cmd = create_string_buffer("regr32 8008")
dll._Z5parsePKcsiPsP8_IO_FILEh(cmd,0,0,0,0,0)
v = dll._Z9reg_dreadm(0x8010)
print "%08X"%v
