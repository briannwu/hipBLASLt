#!/usr/bin/python

import os
import sys
from subprocess import call
from optparse import OptionParser
MSG_USAGE = " -n loops -e 'cmds'"
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-r', '--rb',  dest='therb', type=int , default=-1)
optParser.add_option('-s', '--cs',  dest='thecs', type="string" , default=-1)
optParser.add_option('-n', '--numOfLoops',  dest='loops', type=int , default=10)
optParser.add_option('-e', '--execute', dest='cmd', type='string' , default="")
options, args = optParser.parse_args(sys.argv[1:])
NUM_RB_PER_SE = 4
if options.thecs == -1:
   print "please specify --cs csselect_index"
   exit()
Cmd = options.cmd
Cmd = "sudo " + Cmd
Blocklist = []
def enableAllRBs():

    if options.thecs == -1:
        cmd = " "
    else:
        cmd = "csselect " + options.thecs + " \n"
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    cmd = cmd + "regw32 9b7c 0 \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32.enableAllRBs", "w")
    f.write(cmd)
    f.close()

    r = os.popen("sudo ./db32 exe db32.enableAllRBs").read()
    print r
def disableAllRBs():

    if options.thecs == -1:
        cmd = " "
    else:
        cmd = "csselect " + options.thecs + " \n"
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    cmd = cmd + "regw32 9b7c 00ff0000\n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32.disableAllRBs", "w")
    f.write(cmd)
    f.close()


    r = os.popen("sudo ./db32 exe db32.disableAllRBs").read()
    print r
def disableRB(rbid):
    se = rbid // NUM_RB_PER_SE
    lid = rbid % NUM_RB_PER_SE
    grbm_gfx_index = (se<<NUM_RB_PER_SE) & 0xffffffff
    grbm_gfx_index_hex = "%X" % grbm_gfx_index
    gc_user_rb_backend_disable =  ( ((1 << lid)) << 16) & 0x00ff0000
    gc_user_rb_backend_disable_hex = "%X" % gc_user_rb_backend_disable
    print grbm_gfx_index_hex
    print gc_user_rb_backend_disable_hex
    if options.thecs == -1:
        cmd = " "
    else:
        cmd = "csselect " + options.thecs + " \n"
    cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 9b7c " + gc_user_rb_backend_disable_hex + "\n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32.rb.script", "w")
    f.write(cmd)
    f.close()
    r = os.popen("sudo ./db32 exe db32.rb.script").read()
    print cmd
    print r
def enableRB(rbid):
    se = rbid // NUM_RB_PER_SE
    lid = rbid % NUM_RB_PER_SE
    grbm_gfx_index = (se<<NUM_RB_PER_SE) & 0xffffffff
    grbm_gfx_index_hex = "%X" % grbm_gfx_index
    gc_user_rb_backend_disable =  ( (~(1 << lid)) << 16) & 0x00ff0000
    gc_user_rb_backend_disable_hex = "%X" % gc_user_rb_backend_disable
    print grbm_gfx_index_hex
    print gc_user_rb_backend_disable_hex
    if options.thecs == -1:
        cmd = " "
    else:
        cmd = "csselect " + options.thecs + " \n"
    #cmd = cmd + "regw32 30800  " + grbm_gfx_index_hex + " \n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    cmd = cmd + "regw32 9b7c " + gc_user_rb_backend_disable_hex + "\n"
    cmd = cmd + "regw32 30800  e0000000 \n"
    f = open("db32.rb.script", "w")
    f.write(cmd)
    f.close()
    r = os.popen("sudo ./db32 exe db32.rb.script").read()
    print cmd
    print r
def runaRB(rbid):
    disableAllRBs()
    enableRB(rbid)
    passes = 0
    print "Running on rb: " , rbid
    for i in range(0,options.loops):
        print "runing on rb: ", rbid, " at " , i
        r = os.popen(Cmd).read()
        print r
        if "Total Pass: 1" in r:
            passes = passes + 1
    print "on rb ", rbid, " passes: ", passes
    print passes * 100.0 / options.loops, "% pass"
    return passes

if options.therb == -1:
    pall = []
    for i in range(0,NUM_RB_PER_SE):
        if i in Blocklist:
            pall.append( 0)
            print i,  " is blocked"
        else:
            pi = runaRB(i)
            pall.append( pi)

    for i in range(0,NUM_RB_PER_SE):
        print  i,   pall[i]
else:
    pi = runaRB(options.therb)
    print "passes:", pi
    print pi * 100.0 / options.loops, "% pass"

enableAllRBs()
