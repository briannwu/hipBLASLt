#!/usr/bin/python
from __future__ import print_function
import os
import io
import sys
import inspect
import math
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
sys.path.append(currentdir+"/asics/default")
sys.path.append(currentdir+"/asics/")
from amd_common import *
from pm4_it_opcodes import *
from chip_offset import *
from chip_registers import *
from gc_features import *
if sys.version_info.major == 2:
    import commands as subprocess
    from cStringIO import StringIO
else:
    import subprocess
    from io import StringIO
import tempfile
from ctypes import *
import threading
import time
import errno
import logging
import types
from functools import wraps
from settings import *
import struct
if os.name == 'nt': from win_util import *
else: from unix_util import *
if False:
  from UserList import *
  from UserDict import *
else:
  class UserDict(dict):
      pass
  class UserList(list):
      pass


logger= logging.getLogger()

def var_exist(var): return var in locals().keys() or var in globals().keys()
if not var_exist('GPU__GC__VARIANT'): GPU__GC__VARIANT = asicNone
if GPU__GC__VARIANT == mi200 or GPU__GC__VARIANT == mi100 or  GPU__GC__VARIANT == mi300 :
    NO_GFX = True
else:
    NO_GFX = False
if sys.version_info.major == 2:
    def isNumber(v): return isinstance(v,(int,long))
else:
    def isNumber(v): return isinstance(v,(int))
def myprint(*a, **ka): print(*a, **ka)

def isIterable(o):
    if type(o) == str: return False
    try:
        _b = iter(o)
        return True
    except TypeError as te:
        return False

def globalLoadVar(defines = False):
   if defines : Settings.loadVar(defines)
   for k, v in Settings.mVars.items():
       globals()[k] = v
globalLoadVar()

mmPCIE_INDEX2 = 0x38 // 4
mmPCIE_INDEX2_HI = 0x44 // 4
mmPCIE_DATA2  = 0x3c // 4
mmPCIE_INDEX = 0x30 // 4
mmPCIE_INDEX_HI = 0x40 // 4
mmPCIE_DATA  = 0x34 // 4
mmRSMU_INDEX = 0x50 // 4
mmRSMU_INDEX_HI = 0x58 // 4
mmRSMU_DATA  = 0x54 // 4
SMN_AID0_BASE = 0
SMN_AID1_BASE = 0x500000000
SMN_AID2_BASE = 0x600000000
SMN_AID3_BASE = 0x700000000
GFX_IP_MAJOR = GC__TCORE_GFXIP_MAJOR_VERSION
if not var_exist('GC__NUM_SH_PER_SE'):
    #GFX_IP_MAJOR = 10
    GC__NUM_SH_PER_SE = GC__NUM_SA_PER_SE
    GC__NUM_TCCS = GC__NUM_GL2C
    GC__NUM_CU_PER_WGP = 2
if not var_exist('GC__NUM_SA_PER_SE'):
    GC__NUM_SA_PER_SE = GC__NUM_SH_PER_SE
    GC__NUM_WGP_PER_SA = GC__NUM_CU_PER_SH
    GC__NUM_WGP_PER_SE = GC__NUM_WGP_PER_SA * GC__NUM_SA_PER_SE
    GC__NUM_GL2C = GC__NUM_TCCS
    GC__NUM_CU_PER_WGP = 1
    #GFX_IP_MAJOR = 9
if not var_exist('GC__NUM_CORE'): GC__NUM_CORE = 1
GC__NUM_SE = GC__NUM_SE*GC__NUM_CORE
RANGE_SA = range(0,GC__NUM_SA_PER_SE)
RANGE_SH = range(0,GC__NUM_SH_PER_SE)
RANGE_SE = range(0,GC__NUM_SE)
GC__NUM_TOTAL_SH = GC__NUM_SH_PER_SE * GC__NUM_SE
RANGE_WGP = list(range(0,GC__NUM_WGP_PER_SA))
if var_exist('GC__NUM_WGP0_PER_SA'):
    RANGE_WGP = list(range(GC__NUM_WGP0_PER_SA)) + [8+i for i in range(GC__NUM_WGP1_PER_SA)]
else:
    RANGE_WGP = list(range(0,GC__NUM_WGP_PER_SA))

class Fmt:
    '''Set Format of printing
    Fmt.setv(0): plain hex format, no color
    Fmt.setv(1): hex format, warn is yellow color
    Fmt.setv(4): hex format, colorful, aaaa_bbbb_cccc
    '''
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    VERBOSE = 1
    VERBOSE_PLAIN = 0
    VERBOSE_NORMAL = 1
    VERBOSE_4 = 4
    NUM_FMTER = "0x%08x"
    @staticmethod
    def warns(s): return ''.join((Fmt.WARNING, s, Fmt.ENDC))
    @staticmethod
    def goods(s): return ''.join((Fmt.OKGREEN, s, Fmt.ENDC))
    @staticmethod
    def bads(s): return ''.join((Fmt.FAIL, s, Fmt.ENDC))
    @staticmethod
    def warn(s): print(''.join((Fmt.WARNING, s, Fmt.ENDC)))
    @staticmethod
    def good(s): print(''.join((Fmt.OKGREEN, s, Fmt.ENDC)))
    @staticmethod
    def bad(s): print(''.join((Fmt.FAIL, s, Fmt.ENDC)))
    @staticmethod
    def error(s): print(''.join((Fmt.FAIL, s, Fmt.ENDC)))

    @classmethod
    def _hex4(cls,v):
       s = Fmt.NUM_FMTER%v
       start = len(s) - int(len(s)//4)*4
       return (s[0:start] + '_' if start !=0 else '')  + '_'.join([s[i:i+4] for i in range(start,len(s),4)])
    @classmethod
    def _hex0(cls,v): return  Fmt.NUM_FMTER%v
    @classmethod
    def hex4(cls,v, *vv):
       if len(vv) == 0 : return Fmt._hex4(v)
       ss = [Fmt._hex4(v)]
       for v in vv: ss.append(Fmt._hex4(v))
       return tuple(ss)
    @classmethod
    def hex0(cls,v, *vv):
       if len(vv) == 0 : return Fmt._hex0(v)
       ss = [Fmt._hex0(v)]
       for v in vv: ss.append(Fmt._hex0(v))
       return tuple(ss)
    @classmethod
    def hex(cls,v, *vv):
        if  Fmt.VERBOSE < Fmt.VERBOSE_4 : return Fmt.hex0(v,*vv)
        else: return Fmt.hex4(v,*vv)
    @staticmethod
    def configlogger(level):
      logging.basicConfig(level=level, format='[%(levelname)-8s] %(message)s')
      #console = logging.StreamHandler()
      #console.setLevel(level)
      #formatter = logging.Formatter('[%(asctime)s  %(filename)s : %(levelname)s]  %(message)s')
      #console.setFormatter(formatter)
      #logger.addHandler(console)
      pass
    @staticmethod
    def setverbose(v):
      Fmt.VERBOSE = v
      Fmt._setcolor()
      if v == Fmt.VERBOSE_PLAIN:
        Fmt.HEADER  = ''
        Fmt.OKBLUE  = ''
        Fmt.OKGREEN = ''
        Fmt.WARNING = ''
        Fmt.FAIL = ''
        Fmt.ENDC = ''
        Fmt.BOLD = ''
        Fmt.UNDERLINE = ''
      elif v < Fmt.VERBOSE_4 :
         Fmt.tos = Fmt.hex0
      else: Fmt.tos=Fmt.hex4
    setv = setverbose
    @staticmethod
    def _setcolor():
      if os.name == 'nt':
        Fmt.HEADER = ''
        Fmt.OKBLUE = ''
        Fmt.OKGREEN = ''
        Fmt.WARNING = ''
        Fmt.FAIL = ''
        Fmt.ENDC = ''
        Fmt.BOLD = ''
        Fmt.UNDERLINE = ''
      else:
        Fmt.HEADER = '\033[95m'
        Fmt.OKBLUE = '\033[94m'
        Fmt.OKGREEN = '\033[92m'
        Fmt.WARNING = '\033[93m'
        Fmt.FAIL = '\033[91m'
        Fmt.ENDC = '\033[0m'
        Fmt.BOLD = '\033[1m'
        Fmt.UNDERLINE = '\033[4m'

    @staticmethod
    def setFmter(i):
      if type(i) == str:Fmt.NUM_FMTER = i

    @staticmethod
    def isShown(v, filter0):
        #toShow = v!=0 or filter0 == False
        hideit = (v==0 and filter0 == True) or( v==0xffffffff and Settings.mOptions.filterf == True)
        return not hideit 
    @staticmethod
    def hexall(i, filter0=3, myfmt=" {0}:{1}"):
      if filter0 == 3: filter0 = Settings.FILTER0
      r = ""
      if isNumber(i): r = Fmt.hex(i)
      #elif isinstance(i, list) or isinstance(i, tuple) or isinstance(i, dict):
      elif isIterable(i):
        a = enumerate(i) if not (isinstance(i, dict) or isinstance(i, UserDict)) else i.items()
        astr = ""
        num_columns = len(i) if Settings.mDumpColumns < 4 else Settings.mDumpColumns
        if num_columns == 0 : num_columns = 1
        num_rows = int(math.ceil(len(i) * 1.0 / num_columns))
        if len(i) == 1: astr = ','.join( (Fmt.WARNING *(v!=0) + " %s" %(Fmt.hexall(v)) +  Fmt.ENDC * (v!=0)) * (Fmt.isShown(v, filter0))  for k,v in a)
        else:
            _allitems = [(Fmt.WARNING *(v!=0) + myfmt.format(str(k), Fmt.hexall(v)) +  Fmt.ENDC * (v!=0)) * (Fmt.isShown(v, filter0))  for k,v in a]
            astr =  "[{}]".format(','.join( _allitems ))
            astr =  "{}]".format('\n'.join([','.join(_allitems[(sliceid*num_columns):(sliceid*num_columns+num_columns)]) for sliceid in range(num_rows)])).replace(" ", "[", 1)
        #r = "[{}]".format(",".join(Fmt.hexall(v) for v in i))
        r = astr
      #elif isinstance(i, tuple):
      #  r = "({})".format(",".join(Fmt.hexall(v) for v in i))
      #elif isinstance(i, dict):
      #  r = "{%s}"%(",".join("%s:%s"%(Fmt.hexall(k), Fmt.hexall(v))  for k, v in i.items()))
      else: r = repr(i)
      return r
    @staticmethod
    def display_as_hex(i):
      if isNumber(i): print(Fmt.hex(i))
      else: print(Fmt.hexall(i))

    @staticmethod
    def flat(*x):
        _xx = []
        if len(x) == 1: x = x[0]
        if not hasattr(x, '__contains__'): return [x]
        for _i in x:
            if hasattr(_i, '__contains__'):
                _xx.extend(Fmt.flat(_i))
            else: _xx.append(_i)
        return _xx

    @staticmethod
    def wgp16():
        global RANGE_WGP
        RANGE_WGP = list(range(0,16))


def hexprint(i):Fmt.display_as_hex(i)

setattr(UserList, 'print', hexprint)
setattr(UserDict, 'print', hexprint)
#setattr(tuple, 'print', hexprint)

Fmt.setv(1)

class logit(object):
    def __init__(self):
        pass
    def __call__(self, func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            if int(logging.root.level) < int(logging.DEBUG):
                _str0 = Fmt.hexall(args, 3, " {1}") if len(args) > 0 else ""
                _str1 = Fmt.hexall(kwargs) if len(kwargs) > 0 else ""
                logger.debug(">>> %s %s %s"%(func.__name__, _str0, _str1))
            ret = func(*args, **kwargs)
            if int(logging.root.level) < int(logging.DEBUG):
                logger.debug("<<< %s ret %s"%(func.__name__, Fmt.hexall(ret)))
            return ret
        return wrapped_function if Settings.mOptions.logit else func

def isGfxReg(mIdx):
    isXCC0gfx = ((mIdx >= 0x2000) and (mIdx < 0x3400)) or ((mIdx >= 0xa000) and (mIdx < 0x10000)) 
    isXCC1gfx =  ((mIdx >= 0x12000) and (mIdx < 0x13400)) or ((mIdx >= 0x1a000) and (mIdx < 0x20000))
    return isXCC0gfx or isXCC1gfx 

def regName(key0):
    keyAID = key0 & 0x1ffff
    if isGfxReg(keyAID):
        key = key0 & 0xffff
    else: key = keyAID
    if key in RegName:
       return RegName[key]
    elif key in range(0xa000,0xc000):
       base_key = (key & 0x3ff) +0xa000
       if base_key in RegName:
         ctxid = (key - 0xa000) // 0x400
         return  "%02d"%ctxid + RegName[base_key][2:]
    return "mm%x"%(key)

def dumparray(array, filter0 = 3):
    if filter0 == 3: filter0 = Settings.FILTER0
    #for key in marray:
    astr = Fmt.hexall(array, filter0)
    #for _i in range(0, len(array)):
    #   if _i & 0x3 == 0 and _i!=0: astr = astr + "\n"
    #   astr = astr + "%s "%Fmt.hex(array[_i])
    print( astr)

def dumpdata(array):
    astr = ' '.join([("\n%3d :: "%si)*(si&7 == 0) + "%08x"%(ss)  for si,ss in enumerate(array)])
    print( astr)

def inforv(r, v):
      logging.log(11, " " + Fmt.tos(v)+ " " + regName(r))
def dumprv(r, v):
      print( " " + Fmt.tos(v)+ " " + regName(r))

def dumpmaparray(marray, filter0 = 3):
    if filter0 == 3: filter0 = Settings.FILTER0
    #for key in marray:
    for key, a in sorted(marray.items()):
        a = marray[key]
        if sum(a) != 0:
            astr = Fmt.WARNING + ("%25s::"%regName(key)) + Fmt.ENDC
        else:
            astr = "%25s::"%regName(key)
            if filter0 == True:  continue
        astr = astr + Fmt.hexall(a, filter0).replace("\n", "\n"+(" "*27))
        print( astr)

class Memory:
   """
   Attribute:
       a:  address
       d:  data, a list
       raw: string of a and d
   """
   def __init__(self, a, d, *raw):
      self.a = a
      self.d = d
      if len(raw) > 0: self._raw = raw[0]
      else: self._raw = ""
   @property
   def raw(self):
      if self._raw == "":
         self.makeraw()
      return self._raw
   @raw.setter
   def raw(self, r):
      self._raw = r
   def makeraw(self):
      a = self.a
      d = self.d
      self._raw = ' ' + ' '.join( ("%08x :: "%(a+n*4))*(n%4==0) + "%08x"%l + "\n" *(n%4 == 3 and n > 0) for n, l in enumerate(d))
   def print(self):
       print(self.raw)

def db32dd2Memory(mm):
    datas = []
    lines = mm.split('\n')
    addr = int(lines[0].split()[0], 16)&0xffffffff
    for line in lines:
      data = line.split()[1:]
      for d in data: datas.append(int(d, 16)&0xffffffff)
    m = Memory(addr, datas, mm)
    return m


class Capturing(list):
    def __enter__(self):
        self._stdout = sys.stdout
        sys.stdout = self._stringio = StringIO()
        return self._stringio
    def __exit__(self, *args):
        self.extend(self._stringio.getvalue().splitlines())
        del self._stringio    # free up some memory
        sys.stdout = self._stdout

class OutputGrabber(object):
    """
    Class used to grab standard output or another stream.
    """
    escape_char = b"\b"
    escape_str = "\b"

    def __init__(self, stream=sys.stdout):
        self.origstream = stream
        self.origstreamfd = self.origstream.fileno()
        self._text = ""
        # Create a pipe so the stream can be captured:
        self.pipe_out, self.pipe_in = os.pipe()
        # Save a copy of the stream:
        self.streamfd = os.dup(self.origstreamfd)

    def __del__(self):
        # Close the pipe:
        os.close(self.pipe_out)
        os.close(self.pipe_in)
        os.close(self.streamfd)
        pass

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, type, value, traceback):
        self.stop()

    def start(self):
        """
        Start capturing the stream data.
        """
        self._text= ""
        # Replace the original stream with our write pipe:
        os.dup2(self.pipe_in, self.origstreamfd)

    def stop(self):
        """
        Stop capturing the stream data and save the text in `_text`.
        """
        # Print the escape character to make the readOutput method stop:
        self.origstream.write(self.escape_str)
        # Flush the stream to make sure all our data goes in before
        # the escape character:
        self.origstream.flush()
        self.readOutput()
        # Restore the original stream:
        os.dup2(self.streamfd, self.origstreamfd)
        #os.closerange(self.pipe_out, self.origstreamfd)
        return self._text

    def readOutput(self):
        """
        Read the stream data (one byte at a time)
        and save the text in `_text`.
        """
        while True:
            char = os.read(self.pipe_out, 1)
            if not char or self.escape_char in char:
                break
            self._text += char.decode('utf-8')

    def text(self): return self._text

def debugInfo():
    if int(logging.root.level) > int(logging.DEBUG): return
    frame = inspect.getouterframes( inspect.currentframe() )[1][0]
    args, _, _, values = inspect.getargvalues(frame)
    if 'self' in values: del values['self']
    hexvalues = {}
    for k,v in values.items():
        if isNumber(v): hexvalues[k] = "0x%0x"%v
        else: hexvalues[k] = v
    logger.debug( " %s %s" % (inspect.getframeinfo(frame)[2], hexvalues))

if GPU__GC__VARIANT == mi300 :
    def g__realIdx(mOffset, idx):
        if mOffset > 0 :
            return idx + mOffset // 4
        elif (gg.XCCID > 0) and isGfxReg(idx):
            return idx + XccOffset(gg.XCCID) // 4
        else:
            return idx
    def g__realOffset(mOffset, offset):
        if mOffset > 0 :
            return offset + mOffset
        elif (gg.XCCID > 0) and isGfxReg(offset // 4):
            return offset + XccOffset(gg.XCCID)
        else:
            return offset
    def g__smnIdx(xccid, idx):
        if xccid > 0 :
            return idx + SmnOffset(xccid) // 4
        elif gg.XCCID > 0:
            return idx + SmnOffset(gg.XCCID) // 4
        else:
            return idx
    def g__smnOffset(xccid, offset):
        if xccid > 0 :
            return offset + SmnOffset(xccid)
        elif gg.XCCID > 0:
            return offset + SmnOffset(gg.XCCID)
        else:
            return offset
else:
    def g__realIdx(xccid, idx):
        return idx
    def g__realOffset(xccid, offset):
        return offset
    def g__smnIdx(xccid, idx):
        return idx
    def g__smnOffset(xccid, offset):
        return offset

class Db32Base(object):
    def __init__(self, **kwargs):
        self.mmioBase = 0
        self.xccid = kwargs['xccid']  if 'xccid' in kwargs else 0
        self.mOffset = XccOffset(self.xccid)
        self.cs = -1
        self.regbase = 0 
    def regValueDb32(self, line):
        '''Read MM Reg 2001 (f6788004): 00000020
        '''
        _si = line.index("(")
        _ei = line.index(")", _si)
        _k = (int(line[_si+1:_ei], 16) - self.mmioBase)//4
        _v = int (line.split(":",1)[1], 16)
        return (_k, _v)
    def rvarray(self, db32output):
        lines=db32output.split("\n")
        v = []
        for line in lines:
            if ":" in line:
                if "Read MM Reg" in line:
                    _k,_v = self.regValueDb32(line)
                    v.append([_k, _v])
        return v

    def rvmap(self, db32output):
        lines=db32output.split("\n")
        v = {}
        for line in lines:
            if ":" in line:
                if "Read MM Reg" in line:
                    _k,_v = self.regValueDb32(line)
                    v[_k] = _v
        return v
    def rvmaparray(self, db32output):
       lines=db32output.split("\n")
       v = {}
       for line in lines:
           if ":" in line:
               if "Read MM Reg" in line:
                   _k,_v = self.regValueDb32(line)
                   if  _k in v :
                       v[_k].append(_v)
                   else:
                       v[_k] = [_v]
       return v

    def smn2w32(self, idx, data, msg=0):
        myoffset = idx #g__smnOffset(self.mOffset, idx)
        self.regw32(mmPCIE_INDEX2*4, myoffset & 0xffffffff)
        self.regw32(mmPCIE_INDEX2_HI*4, (myoffset >> 32) & 0xffffffff)
        self.regw32(mmPCIE_DATA2*4, data)
    @logit()
    def smn2r32(self, idx):
        myoffset = idx #g__smnOffset(self.mOffset, idx)
        self.regw32(mmPCIE_INDEX2*4, myoffset & 0xffffffff)
        self.regw32(mmPCIE_INDEX2_HI*4, (myoffset >> 32) & 0xffffffff)
        return self.regr32(mmPCIE_DATA2*4)# read  mmRSMU_DATA

    def smnw32(self, idx, data, msg=0):
        myoffset = idx #g__smnOffset(self.mOffset, idx)
        self.regw32(mmPCIE_INDEX*4, myoffset & 0xffffffff)
        self.regw32(mmPCIE_INDEX_HI*4, (myoffset >> 32) & 0xffffffff)
        self.regw32(mmPCIE_DATA*4, data)
    @logit()
    def smnr32(self, idx):
        myoffset = idx #g__smnOffset(self.mOffset, idx)
        self.regw32(mmPCIE_INDEX*4, myoffset & 0xffffffff)
        self.regw32(mmPCIE_INDEX_HI*4, (myoffset >> 32) & 0xffffffff)
        return self.regr32(mmPCIE_DATA*4)# read  mmRSMU_DATA
    def rsmuw32(self, idx, data, msg=0):
        myoffset = idx #g__smnOffset(self.mOffset, idx)
        self.regw32(mmRSMU_INDEX*4, myoffset & 0xffffffff)
        self.regw32(mmRSMU_INDEX_HI*4, (myoffset >> 32) & 0xffffffff)
        self.regw32(mmRSMU_DATA*4, data)
    @logit()
    def rsmur32(self, idx):
        myoffset = idx #g__smnOffset(self.mOffset, idx)
        self.regw32(mmRSMU_INDEX*4, myoffset & 0xffffffff)
        self.regw32(mmRSMU_INDEX_HI*4, (myoffset >> 32) & 0xffffffff)
        return self.regr32(mmRSMU_DATA*4)# read  mmRSMU_DATA



class Sdb32(Db32Base):
    """db32 functions from external executable db32 """
    status = False
    def isGood(self):
        return Tdb32.status
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if os.name == 'nt':
          self.db32 =  ".\\db32.exe " if os.path.exists(".\\db32.exe") else  currentdir + "\\bin\win\db32.exe "
          if not os.path.exists(self.db32.strip()): Fmt.bad("\nplease put db32.exe under gfxtool\\tools or gfxtool\\tools\\bin\\win\n")
        else:
          self.db32 =  "./db32 " if os.path.exists("./db32") else  currentdir + "/bin/db32 "
        self.mmioBase = 0
        if(Settings.mOptions.cs != -1):
            self.cs = Settings.mOptions.cs
        if Settings.mOptions.regbase != 0:
               self.regBase(Settings.mOptions.regbase)
        if os.path.exists(self.db32.strip()):
            Sdb32.status = True
            self.getMMIOBase()
    def getMMIOBase(self):
        #Read MM Reg 0 (fe500000): 00756f80
        b = self.cmd('mmr 0')
        _si = b.index(")")
        self.mmioBase = int(b[_si-8:_si], 16)
    def regBase(self, regbase):
        self.regbase = regbase 
    def CS(self, csid):
        self.cs = csid
        if self.regbase != 0:
            self.regBase(self.regbase)
        if Sdb32.status :
            self.getMMIOBase()
    def exe(self, cmd):
        debugInfo()
        cmd = cmd.strip()
        if not cmd.startswith("exe"):
            cmd = "exe " + cmd
        cmd = self.db32 + cmd
        logger.debug(cmd)
        a,b = subprocess.getstatusoutput(cmd)
        logger.debug("ret: " + str(a) + " :: " + b)
        return b
    def cmd(self, cmd):
        cmd = cmd.strip()
        if not cmd.startswith("cmd"):
            prefix = ""
            if self.cs != -1 :
                prefix = "csselect %d;"%(self.cs)
            if self.regbase != 0:
                prefix = prefix + ("regbase=%x;"%self.regbase)
            if prefix != "":
                cmd = 'cmd "%s%s"'%(prefix, cmd)
            else:
                cmd = "cmd " + cmd
        cmd = self.db32 + cmd
        logger.debug( cmd)
        a,b = subprocess.getstatusoutput(cmd)
        logger.debug("ret: " + str(a) + " :: " + b)
        return b

    def mmw(self, idx, data, msg=0):
            myidx = g__realIdx(self.mOffset, idx)
            cmd = "mmw " + "%X" % myidx + " %X" % data
            b = self.cmd(cmd)
            if msg: print( regName(idx) + " " + b)

    def mmr(self, idx):
            myidx = g__realIdx(self.mOffset, idx)
            cmd = "mmr " + "%X" % myidx
            b = self.cmd(cmd)
            v = b.split(":",1)[1]
            return int(v,16) & 0xFFFFFFFF

    def regw32(self, idx, data):
            myoffset = g__realOffset(self.mOffset, idx)
            cmd = "regw32 " + "%X" % myoffset + " %X" % data
            b = self.cmd(cmd)
            #print( RegName[idx/4] + " " + b)

    def regr32(self, idx):
        myoffset = g__realOffset(self.mOffset, idx)
        cmd = "regr32 " + "%X" % myoffset
        b = self.cmd(cmd)
        v = b.split(":",1)[1]
        return int(v,16) & 0xFFFFFFFF
    def dvd(self, start, dwords):
        cmd = "dvd %x %x"%(start, dwords)
        b = self.cmd(cmd)
        d = db32dd2Memory(b)
        return d
    def dd(self, start, dwords):
        cmd = "dd %x %x"%(start, dwords)
        b = self.cmd(cmd)
        d = db32dd2Memory(b)
        return d
    def fvd(self, start, datas, n):
        debugInfo()
        if isNumber(datas):
            cmd = "fvd %x %x %x"%(start, n, datas)
        else:
            cmd = "fvd %x %x "%(start,n) + ' '.join(["%x"%i for i in datas])
        b = self.cmd(cmd)
    def fd(self, start, dwords):
        debugInfo()
        if isNumber(datas):
            cmd = "fd %x %x %x"%(start, n, datas)
        else:
            cmd = "fd %x %x "%(start,n) + ' '.join(["%x"%i for i in datas])
        b = self.cmd(cmd)
    def mem_dwrites(self, addr, datas, n):
        self.fd(addr,datas,n)
    def vid_dwrites(self, addr, datas, n):
        self.fvd(addr,datas,n)
    def run(self, cmd):
        logger.debug("DEBUG:: script: " + cmd)
        temp = tempfile.NamedTemporaryFile(mode='w+t',delete=False)
        if self.cs != -1 :  script = "csselect %d\n"%self.cs + cmd
        temp.write(script)
        temp.flush()
        temp.seek(0)
        temp.close()
        output = self.exe(temp.name)
        #os.remove(temp.name)
        #os.remove(temp.name+".err")
        return output



if sys.version_info.major == 2:
  def my_create_string_buffer(cmd):return create_string_buffer(cmd)
else:
  def my_create_string_buffer(cmd):
    try:
      cmd_cstr = create_string_buffer(cmd)
    except Exception as e:
      cmd_cstr = create_string_buffer(cmd.encode('utf-8'))
    return cmd_cstr

class Tdb32(Db32Base):
    """db32 function from libdb32.so"""
    cs = None
    status = False
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        import tcore
        try:
           Tdb32.gpu = tcore.GetGPU()
           Tdb32.status = True
        except Exception as e:
           print(e)
           Tdb32.status = False
        finally: # !
           #gAperBas = c_ulonglong.in_dll(Cdb32.dll, "gAperBase")
           #print(gAperBas)
           pass
    def isGood(self):
        return Tdb32.status

    def getAperBase(self):
        pass

    def CS(self, csid):
        self.cs = csid

    def exe(self, cmd):
        logger.debug("exe " + cmd )
        b = ""
        return b
    def cmd(self, cmd):
        logger.debug(cmd )
        b = ""
        return b

    #@logit()
    def mmw(self, idx, data, msg=0):
        myidx = g__realIdx(self.mOffset, idx)
        logger.debug("mmw %x %x"%(myidx, data))
        Tdb32.gpu.RegWrite(myidx*4, data)

    #@logit()
    def mmr(self, idx):
        myidx = g__realIdx(self.mOffset, idx)
        logger.debug("mmr %x"%(myidx))
        v = Tdb32.gpu.RegRead(myidx*4)
        return v & 0xFFFFFFFF

    def regw32(self, idx, data, msg=0):
        myoffset = g__realOffset(self.mOffset, idx)
        logger.debug("regw32 %x %x"%(myoffset, data))
        Tdb32.gpu.RegWrite(myoffset, data)
    def regr32(self, idx):
        myoffset = g__realOffset(self.mOffset, idx)
        logger.debug("regr32 %x"%(myoffset))
        v = Tdb32.gpu.RegRead(myoffset)
        return  0xFFFFFFFF & v
    def __dvd_0(self, start, dwords):
        logger.debug("dvd %x %x"%(start, dwords))
        #out = OutputGrabber(sys.stdout, True)
        d = ''
        return d
    def __dvd2(self, start, dwords):
        dvdstr="dvd %x %x"%(start, dwords)
        d = ''
        return d
    def __dd_0(self, start, dwords):
        logger.debug("dd %x %x"%(start, dwords))
        #out = OutputGrabber(sys.stdout, True)
        b = ''
        d = db32dd2Memory(b)
        return d
    def mem_dread(self, addr):
        return ''
    def mem_dwrite(self, addr,data):
        return ''
    def vid_dwrite(self, offset, data):
        return ''
    def mem_dwrites(self, addr, datas, n):
        debugInfo()
        pass
    def vid_dwrites(self, offset, datas, n):
        debugInfo()
        pass
    def mmap(self, phyaddr, length):
        debugInfo()
        return
    def ummap(self, vm):
        pass
    def __dvd_1(self, start, dwords):
        debugInfo()
        addr = self.gAperBase + start
        #vm = self.mmap(addr, dwords)
        datas = []
        for i in range(0, dwords):
          #v = self.mem_dread(addr + i*4)
          datas.append(v)
        #self.ummap(vm)
        m = Memory(addr, datas)
        return m
    def __dd_1(self, start, dwords):
        debugInfo()
        addr = start
        datas = []
        for i in range(0, dwords):
          #v = self.mem_dread(addr + i*4)
          datas.append(v)
        m = Memory(addr, datas)
        return m
    def dvd(self, start, dwords=32):
        #start = start & 0xffffffffff
        if start >= 0x10000000: # >= 256M
            mmHDP_NONSURFACE_BASE      = 0x3d80 //4
            mmHDP_NONSURFACE_BASE_HI   = 0x3d88 //4
            mmHDP_SURFACE0_BASE        = 0x3d98 //4
            mmHDP_SURFACE0_BASE_HI     = 0x3da0 //4
            mmHDP_SURFACE0_INFO        = 0x3d9c //4
            mmHDP_SURFACE0_LOWER_BOUND = 0x3d90 //4
            mmHDP_SURFACE0_UPPER_BOUND = 0x3d94 //4
            vGCMC_VM_FB_LOCATION_BASE = mmr(mmGCMC_VM_FB_LOCATION_BASE) << 24
            vm = start + vGCMC_VM_FB_LOCATION_BASE
            _surface0_base = vm >> 8
            _surface0_off  = vm & 0xff
            _size256b = dwords * 4 // 256 + 1
            self.mmw(mmHDP_SURFACE0_BASE, _surface0_base&0xffffffff)
            self.mmw(mmHDP_SURFACE0_BASE_HI, (_surface0_base >> 32 ) &0xffffffff)
            self.mmw(mmHDP_SURFACE0_LOWER_BOUND, 0)
            self.mmw(mmHDP_SURFACE0_UPPER_BOUND, _size256b)
            _d =  self.__dvd_1(_surface0_off, dwords)
            self.mmw(mmHDP_SURFACE0_BASE, 0)
            self.mmw(mmHDP_SURFACE0_UPPER_BOUND, 0)
            return _d
        # <256M
        start = start & 0xfffffff
        return self.__dvd_1(start, dwords)
    def dd(self, start, dwords=32): return self.__dd_1(start, dwords)
    def csid(self, offset):
        logger.debug("csid %x"%(offset))
        v = 0
        return v & 0xFFFFFFFF
    def isAnA(self):
        pass


class Cdb32(Db32Base):
    """db32 function from libdb32.so"""
    dll = None
    cs = None
    status = False
    gAperBase = 0
    mmaps = {}
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        try:
           if Cdb32.dll != None : return
           currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
           lib =  currentdir + '/bin/libdb32.so'
           if os.name == 'nt': lib = currentdir + '\\bin\win\libdb32.dll'
           if not os.path.exists(lib):
               Cdb32.status = False
               return
           Cdb32.dll = cdll.LoadLibrary(lib)
           Cdb32.dll._Z8mem_initv()
           Cdb32.dll._Z10PCICS_initb(0)
           Cdb32.dll._Z4initPc(0)
           Cdb32.status = True
           Cdb32.cs = -1
           Cdb32.gAperBase = 0x90000000
           self.getAperBase()
           self.out = OutputGrabber()
           self.mmioBase = 0
           self.regbase = 0
           if Settings.mOptions.regbase != 0:
               self.regBase(Settings.mOptions.regbase)
           if Settings.mOptions.cs!= -1:
               self.CS(Settings.mOptions.cs)
           else: self.getMMIOBase()
        except Exception as e:
           print(e)
           Cdb32.status = False
        finally: # !
           #gAperBas = c_ulonglong.in_dll(Cdb32.dll, "gAperBase")
           #print(gAperBas)
           pass

    def fflush(self):
         Cdb32.dll._Z11flushstdoutv()
    def isGood(self):
        if Settings.mExternaldb32 : return False
        return Cdb32.status
    def regBase(self, regbase):
        self.regbase = regbase
        self.cmd("regbase=%x"%regbase)

    def getMMIOBase(self):
        #Read MM Reg 0 (fe500000): 00756f80
        b = self.cmd('mmr 0')
        _si = b.index(")")
        self.mmioBase = int(b[_si-8:_si], 16)

    def getAperBase(self):
        r=c_ulonglong.in_dll(Cdb32.dll,'gAperBase')
        #gAperBase_str = self.cmd("$")
        #gAperBase_str = ''.join(c for c in gAperBase_str[37:] if c.isdigit())
        #self.gAperBase = int(gAperBase_str, 16) << 20
        ##r = c_ulonglong()
        ##Cdb32.dll._Z14get_apper_addrRm(byref(r))
        Cdb32.gAperBase = r.value

    def CS(self, csid):
        Cdb32.cs = csid
        cmd="csselect %d"%csid
        #cmd="csselect "
        r = self.cmd(cmd)
        if len(r) > 4 :
            print ("csselect error:", r)
            use_db32S()
        if self.regbase != 0:
               self.regBase(self.regbase)
        self.getAperBase()
        self.getMMIOBase()

    def exe(self, cmd):
        logger.debug("exe " + cmd )
        cmd = cmd.strip()
        if not cmd.startswith("exe"):
            cmd = "exe " + cmd
        cmd_cstr = my_create_string_buffer(cmd)

        if False:
             out = OutputGrabber(sys.stdout, True)
             outerr = OutputGrabber(sys.stderr)
             with outerr:
                 with out:
                     Cdb32.dll._Z8db_macroPc(cmd_cstr)
                     Cdb32.dll._Z11flushstdoutv()
             b = out.text()
             c = outerr.text()
        else:
             self.out.start()
             Cdb32.dll._Z8db_macroPc(cmd_cstr)
             Cdb32.dll._Z11flushstdoutv()
             b = self.out.stop()
        logger.debug("ret: " + " :: " + b)
        return b
    def cmd(self, cmd):
        logger.debug(cmd )
        cmd = cmd.strip()
        if cmd.startswith("cmd"):
            cmd =  cmd[3:]
        cmd_cstr = my_create_string_buffer(cmd)
        if True:
            with  self.out:
                Cdb32.dll._Z5parsePKcsiPsP8_IO_FILEh(cmd_cstr,0,0,0,0,0)
                Cdb32.dll._Z11flushstdoutv()
            b = self.out.text()
        logger.debug("ret: " + " :: " + b)
        return b

    #@logit()
    def mmw(self, idx, data, msg=0):
        myidx = g__realIdx(self.mOffset, idx)
        logger.debug("mmw %x %x"%(myidx, data))
        Cdb32.dll._Z10reg_dwritejj(myidx*4, data)

    @logit()
    def mmr(self, idx):
        myidx = g__realIdx(self.mOffset, idx)
        logger.debug("mmr %x"%(myidx))
        v = Cdb32.dll._Z9reg_dreadm(myidx * 4)
        return v & 0xFFFFFFFF

    def regw32(self, idx, data, msg=0):
        myoffset = g__realOffset(self.mOffset, idx)
        logger.debug("regw32 %x %x"%(myoffset, data))
        Cdb32.dll._Z10reg_dwritejj(myoffset, data)
    def regr32(self, idx):
        myoffset = g__realOffset(self.mOffset, idx)
        logger.debug("regr32 %x"%(myoffset))
        v = Cdb32.dll._Z9reg_dreadm(myoffset)
        return v & 0xFFFFFFFF

    def __dvd_0(self, start, dwords):
        logger.debug("dvd %x %x"%(start, dwords))
        #out = OutputGrabber(sys.stdout, True)
        out = OutputGrabber()
        dvdstr="dvd %x %x"%(start, dwords)
        cmd_cstr = my_create_string_buffer(dvdstr)
        with out:
            Cdb32.dll._Z3dvdPc(cmd_cstr)
            self.fflush()
        b = out.text()
        del out
        d = db32dd2Memory(b)
        return d
    def __dvd2(self, start, dwords):
        dvdstr="dvd %x %x"%(start, dwords)
        cmd_cstr = my_create_string_buffer(dvdstr)
        with Capturing() as output:
            Cdb32.dll._Z3dvdPc(cmd_cstr)
            self.fflush()
        d = db32dd2Memory(output.getvalue())
        return d
    def __dd_0(self, start, dwords):
        logger.debug("dd %x %x"%(start, dwords))
        #out = OutputGrabber(sys.stdout, True)
        out = OutputGrabber()
        dvdstr="dd %x %x"%(start, dwords)
        cmd_cstr = my_create_string_buffer(dvdstr)
        with out:
            Cdb32.dll._Z6dd_cmdPc(cmd_cstr)
            self.fflush()
        b = out.text()
        del out
        d = db32dd2Memory(b)
        return d
    def mem_dreads(self, addr, n):
        a = c_ulonglong(addr)
        buf = ctypes.create_string_buffer(b"",n * 4)
        b = Cdb32.dll._Z10mem_dreadsmPjj(a, buf, c_uint(n))
        python_bytes_array = buf.raw #ctypes.string_at(buf)
        integer_tuple = struct.unpack("%dI"%n, python_bytes_array)
        return list(integer_tuple)
    def mem_dread(self, addr):
        #debugInfo()
        # must use c_ulonglong, otherwise py will do wrong casting
        a = c_ulonglong(addr)
        r = c_uint()
        b = Cdb32.dll._Z9mem_dreadmRj(a,byref(r))
        #logger.debug("mem_dread %x ->%x"%(addr, r.value))
        return r.value
    def mem_dwrite(self, addr,data):
        #logger.debug("mem_dwrite %x ->%x"%(data, addr))
        a = c_ulonglong(addr)
        b = Cdb32.dll._Z10mem_dwritemj(a,data)
    def vid_dwrite(self, offset, data):
        #logger.debug("mem_dwrite %x ->%x"%(data, addr))
        addr = self.gAperBase + offset
        a = c_ulonglong(addr)
        Cdb32.dll._Z10mem_dwritemj(a,data)
    def mem_dwrites(self, addr, datas, n):
        debugInfo()
        mywrites = Cdb32.dll._Z10mem_dwritemj
        if isNumber(datas):
            if n == 0: n = 1
            for _i in range(0, n):
                a = c_ulonglong(addr + _i*4)
                r = mywrites(a,datas)
        else:
            if n <= 0 or n > len(datas): n = len(datas)
            for _i in range(0, n):
                a = c_ulonglong(addr + _i*4)
                mywrites(a,datas[_i])
    def vid_dwrites(self, offset, datas, n):
        debugInfo()
        addr = self.gAperBase + offset
        self.mem_dwrites(addr, datas, n)
    def mmap(self, phyaddr, length):
        debugInfo()
        a = c_ulonglong(phyaddr)
        vm = Cdb32.dll._Z18DB_allocatelogicalmj(a,length)
        vm = vm &0xffffffffffffffff
        Cdb32.mmaps[vm] = [vm, phyaddr,length]
        logger.debug("mmap %x %x -> %x"%(phyaddr, length, vm))
        return vm
    def ummap(self, vm):
        a = c_ulonglong(vm)
        Cdb32.dll._Z14DB_freelogicalm(a)
        logger.debug("ummap %x"%( vm))
        del Cdb32.mmaps[vm]
    def __dvd_1(self, start, dwords):
        debugInfo()
        addr = self.gAperBase + start
        #vm = self.mmap(addr, dwords)
        if 0:
            datas = []
            for i in range(0, dwords):
              v = self.mem_dread(addr + i*4)
              datas.append(v)
            #self.ummap(vm)
        else:
            datas = self.mem_dreads(addr, dwords)
        m = Memory(addr, datas)
        return m
    def __dd_1(self, start, dwords):
        debugInfo()
        addr = start
        datas = []
        for i in range(0, dwords):
          v = self.mem_dread(addr + i*4)
          datas.append(v)
        m = Memory(addr, datas)
        return m
    def dvd(self, start, dwords=32):
        #start = start & 0xffffffffff
        if start >= 0x10000000: # >= 256M
            mmHDP_NONSURFACE_BASE      = 0x3d80 //4
            mmHDP_NONSURFACE_BASE_HI   = 0x3d88 //4
            mmHDP_SURFACE0_BASE        = 0x3d98 //4
            mmHDP_SURFACE0_BASE_HI     = 0x3da0 //4
            mmHDP_SURFACE0_INFO        = 0x3d9c //4
            mmHDP_SURFACE0_LOWER_BOUND = 0x3d90 //4
            mmHDP_SURFACE0_UPPER_BOUND = 0x3d94 //4
            vGCMC_VM_FB_LOCATION_BASE = mmr(mmGCMC_VM_FB_LOCATION_BASE) << 24
            vm = start + vGCMC_VM_FB_LOCATION_BASE
            _surface0_base = vm >> 8
            _surface0_off  = vm & 0xff
            _size256b = dwords * 4 // 256 + 1
            mmw(mmHDP_SURFACE0_BASE, _surface0_base&0xffffffff)
            mmw(mmHDP_SURFACE0_BASE_HI, (_surface0_base >> 32 ) &0xffffffff)
            mmw(mmHDP_SURFACE0_LOWER_BOUND, 0)
            mmw(mmHDP_SURFACE0_UPPER_BOUND, _size256b)
            _d =  self.__dvd_1(_surface0_off, dwords)
            mmw(mmHDP_SURFACE0_BASE, 0)
            mmw(mmHDP_SURFACE0_UPPER_BOUND, 0)
            return _d
        # <256M
        start = start & 0xfffffff
        return self.__dvd_1(start, dwords)
    def dd(self, start, dwords=32): return self.__dd_1(start, dwords)
    def _fvd(self, start, datas, n):
        debugInfo()
        if isNumber(datas):
            cmd = "fvd %x %x %x"%(start, n, datas)
        else:
            cmd = "fvd %x %x "%(start,n) + ' '.join(["%x"%i for i in datas])
        b = self.cmd(cmd)
    def _fd(self, start, dwords):
        debugInfo()
        if isNumber(datas):
            cmd = "fd %x %x %x"%(start, n, datas)
        else:
            cmd = "fd %x %x "%(start,n) + ' '.join(["%x"%i for i in datas])
        b = self.cmd(cmd)
    def fvd(self, start, dwords):
        self._fvd(start, dwords)
    def fd(self, start, dwords):
        self._fd(start, dwords)
    def csid(self, offset):
        logger.debug("csid %x"%(offset))
        v = Cdb32.dll._Z10PCICS_inpdh(offset)
        return v & 0xFFFFFFFF
    def isAnA(self):
        return Cdb32.gAperBase == 0

if Settings.mDefaultdb32 == 'tcore':
  db32C = None
  db32S = None
  db32T = Tdb32()
  db32I = db32T
elif Settings.mDefaultdb32 == 'external':
  db32C = Cdb32()
  db32S = Sdb32()
  db32T = None
  db32I = db32S
else:
  db32C = Cdb32()
  db32T = None
  db32S = Sdb32() 
  db32I = db32C
  if not db32I.isGood() : 
      db32S = Sdb32()
      db32I = db32S

def use_db32S():
    global db32I
    global db32S
    db32I = db32S
def use_db32T():
    global db32I
    global db32T
    db32I = db32T

def mmw(idx, data, msg=0):
    return db32I.mmw(idx,data,msg)

def mmrq(idx):
    v0 = db32I.mmr(idx)
    v1 = db32I.mmr(idx+1)
    v = v0 + (v1<<32)
    inforv(idx, v)
    return v

def mmr(idx):
    v = db32I.mmr(idx)
    inforv(idx, v)
    return v

def mmrp(idx):
    v = db32I.mmr(idx)
    dumprv(idx, v)
    return v

def regw32(idx, data):
    return db32I.regw32(idx, data)

def regr32(idx):
    v = db32I.regr32(idx)
    inforv(idx//4, v)
    return v
def regr32p(idx):
    v = db32I.regr32(idx)
    dumprv(idx//4, v)
    return v
def dvd(start, dwords=32):
    start = start & 0xffffffffff
    v = db32I.dvd(start, dwords)
    #logger.info("\n%s", v.raw)
    return v
def dvdp(start, dwords=32):
    v = db32I.dvd(start, dwords)
    print(v.raw)
    return v
def dd(start, dwords=32):
    v = db32I.dd(start, dwords)
    #logger.info("\n%s", v.raw)
    return v
def ddp(start, dwords=32):
    v = db32I.dd(start, dwords)
    print(v.raw)
    return v
class smn:
    @staticmethod
    def regr32(idx):
        v = db32I.smnr32(idx)
        inforv(idx//4, v)
        return v
    @staticmethod
    def regr32p(idx):
        v = db32I.smnr32(idx)
        dumprv(idx//4, v)
        return v
    @staticmethod
    def mmr(idx):
        return smn.regr32(idx*4)
    @staticmethod
    def mmrp(idx):
        return smn.regr32p(idx*4)
    @staticmethod
    def regw32(idx, data):
        return db32I.smnw32(idx, data)
    @staticmethod
    def mmw(idx, data):
        return db32I.smnw32(idx*4, data)
class smn2:
    @staticmethod
    def regr32(idx):
        v = db32I.smn2r32(idx)
        inforv(idx//4, v)
        return v
    @staticmethod
    def regr32p(idx):
        v = db32I.smn2r32(idx)
        dumprv(idx//4, v)
        return v
    @staticmethod
    def mmr(idx):
        return smn2.regr32(idx*4)
    @staticmethod
    def mmrp(idx):
        return smn2.regr32p(idx*4)
    @staticmethod
    def regw32(idx, data):
        return db32I.smn2w32(idx, data)
    @staticmethod
    def mmw(idx, data):
        return db32I.smn2w32(idx*4, data)

class rsmu:
    @staticmethod
    def regr32(idx):
        v = db32I.rsmur32(idx)
        inforv(idx//4, v)
        return v
    @staticmethod
    def regr32p(idx):
        v = db32I.rsmur32(idx)
        dumprv(idx//4, v)
        return v
    @staticmethod
    def mmr(idx):
        return rsmu.regr32(idx*4)
    @staticmethod
    def mmrp(idx):
        return rsmu.regr32p(idx*4)
    @staticmethod
    def regw32(idx, data):
        return db32I.rsmuw32(idx, data)
    @staticmethod
    def mmw(idx, data):
        return db32I.rsmuw32(idx*4, data)



class DB32Script(object):
    def __init__(self, with_autoprint = True, **kwargs):
        self.script = ""
        self.last_script = ""
        self.output = ""
        self.last_output = ""
        self.with_autoprint = with_autoprint
        self.xccid = kwargs['xccid']  if 'xccid' in kwargs else 0
        self.mOffset = XccOffset(self.xccid)
        self.db32 =  kwargs['db32'] if 'db32' in kwargs else db32I
    def append(self, cmd):
        self.script = self.script + cmd + "\n"

    def mmw(self, idx, data):
        myidx = g__realIdx(self.mOffset, idx)
        cmd = "mmw " + "%X" % myidx + " %X" % data
        self.append(cmd)
        return cmd

    def mmrp(self, idx): return self.mmr(idx)
    def mmr(self, idx):
        myidx = g__realIdx(self.mOffset, idx)
        cmd = "mmr " + "%X" % myidx
        self.append(cmd)
        return cmd

    def regw32(self, idx, data):
        myoffset = g__realOffset(self.mOffset, idx)
        cmd = "regw32 " + "%X" % myoffset + " %X" % data
        self.append(cmd)
        return cmd

    def regr32p(self, idx): return self.regr32(idx)
    def regr32(self, idx):
        myoffset = g__realOffset(self.mOffset, idx)
        cmd = "regr32 " + "%X" % myoffset
        self.append(cmd)
        return cmd

    def dvd(self, start, dwords=32):
        cmd="dvd %x %x"%(start, dwords)
        b = self.append(cmd)
        return cmd
    def dd(self, start, dwords=32):
        cmd="dd %x %x"%(start, dwords)
        b = self.append(cmd)
        return cmd
    def reset(self):
        self.last_script = self.script
        self.last_output = self.output
        self.script = ""
        self.output = ""
    def dump(self): print(self.script)
    def __enter__(self):
        return self
    def __exit__(self, type, value, traceback):
        r = self.run()
        if self.with_autoprint:
            dumpmaparray(db32I.rvmaparray(r))
        self.reset()

    def internalcmd(self, mycmd, localcmd):
                if(isNumber(mycmd)):
                    self.mmr(mycmd)
                elif "(" in mycmd:
                    exec(localcmd)
                else:
                    self.append(localcmd)

    def persaGFX10(self, mycmd, *value):
        if isNumber(mycmd) and len(value) > 0:
            return self.__allsaGFX10(mycmd, *value)
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for se in RANGE_SE:
            for sa in range(0, GC__NUM_SA_PER_SE):
                    grbm_gfx_index = (se << 16) | (sa << 8)
                    self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                    self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)


    def __allsaGFX10(self, reg, *value):
            __i = 0
            for se in RANGE_SE:
                for sa in RANGE_SA:
                    grbm_gfx_index = (se << 16) | (sa << 8)
                    self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                    self.mmw(reg, value[__i])
                    __i= __i+1
            self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def __allshGFX9(self, reg, *value):
            __i = 0
            for se in RANGE_SE:
                for sh in range(0, GC__NUM_SH_PER_SE):
                    grbm_gfx_index = (se << 16) | (sh << 8)
                    self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                    self.mmw(reg, value[__i])
                    __i= __i+1
            self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def perseGFX9(self, mycmd, *value):
        if isNumber(mycmd) and len(value) > 0:
            return self.__allsaGFX9(mycmd, *value)
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for se in RANGE_SE:
            for sa in range(0, 1):
                    grbm_gfx_index = (se << 16) | (sa << 8)
                    self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                    self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def pershGFX9(self, mycmd):
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for se in RANGE_SE:
            for sh in range(0, GC__NUM_SH_PER_SE):
                    grbm_gfx_index = (se << 16) | (sh << 8)
                    self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                    self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def percuGFX9(self, mycmd):
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for se in RANGE_SE:
            for sh in range(0, GC__NUM_SH_PER_SE):
                for cu in range(0, 16):
                    grbm_gfx_index = (se << 16) | (sh << 8) | cu
                    self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                    self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def persqcGFX9(self, mycmd):
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for se in RANGE_SE:
                    for sh in range(0, GC__NUM_SH_PER_SE):
                        for sqc in range(0, 6):
                            grbm_gfx_index = (se << 16) | (sh << 8) | sqc
                            self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                            self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def pertccGFX9(self, mycmd):
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for tcc in range(0, GC__NUM_TCCS*GC__NUM_CORE):
            grbm_gfx_index = tcc
            self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
            self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def pereaGFX9(self, mycmd):
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for ea in range(0, 32):
            grbm_gfx_index = ea
            self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
            self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def pertcaGFX9(self, mycmd):
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for tca in range(0, 2):
            grbm_gfx_index = tca
            self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
            self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def pertciGFX9(self, mycmd):
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for tci in range(0, 69):
            grbm_gfx_index = tci
            self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
            self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)


    def perutcl2GFX9(self, mycmd):
        v = {0:{}, 1:{}, 2:{}, 3:{}}
        localcmd = self.checkcmd(mycmd)
        for utcl2 in range(0, 2):
            grbm_gfx_index = utcl2
            self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
            self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def perwgpGFX10(self, mycmd):
        localcmd = self.checkcmd(mycmd)
        for se in RANGE_SE:
                    for sa in RANGE_SA:
                        for cu in RANGE_WGP:
                            grbm_gfx_index = (se << 16) | (sa << 8) | cu << 2
                            self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                            self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    def persimdGFX10(self, mycmd):
        localcmd = self.checkcmd(mycmd)
        for se in RANGE_SE:
                    for sa in RANGE_SA:
                        for wgp in RANGE_WGP:
                          for simd in range(0,4):
                            grbm_gfx_index = (se << 16) | (sa << 8) | wgp << 2 | simd
                            self.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                            self.internalcmd(mycmd, localcmd)
        self.mmw(mmGRBM_GFX_INDEX, 0xe0000000)


    def perCtx(self, reg):
        if reg < 0xa000 or reg > 0xbfff :
           print("0x%x Not context register"%reg)
           return
        for i in range(0, 8):
           idx = reg + i * 0x400
           self.mmr(idx)

    def perL2(self, mycmd, indexer, n):
        localcmd = self.checkcmd(mycmd)
        for i in range(n):
            self.mmw(indexer, i)
            self.internalcmd(mycmd, localcmd)
        self.mmw(indexer, 0)

    def run(self):
        logger.debug("DEBUG:: script: " + self.script)
        if len(self.script) == 0 : return ""
        temp = tempfile.NamedTemporaryFile(mode='w+t',delete=False)
        if self.db32.cs != -1 :  self.script = "csselect %d\n"%self.db32.cs + self.script
        temp.write(self.script)
        temp.flush()
        temp.seek(0)
        temp.close()
        #print(temp.name)
        #with open(temp.name, 'r') as f:
        #    print f.read()
        #cmd = "./db32 exe " + temp.name
        #a,b = subprocess.getstatusoutput(cmd)
        self.output = self.db32.exe(temp.name)
        os.remove(temp.name)
        os.remove(temp.name+".err")
        return self.output

    def prun(self):
        r = self.run()
        rv = db32I.rvmaparray(r)
        dumpmaparray(rv)
        return rv

    def formatcmd(self, cmd):
            cmd = cmd.replace("\\n", ";")
            mys = []
            inside = False
            stack = []
            for i,ch in enumerate(cmd):
                if ch == ';':
                    if inside == False:
                        mys.append('\n')
                    else:
                        mys.append(';')
                elif ch == '"' or ch == '\'':
                    if len(stack) == 0:
                        stack.append(ch)
                    else:
                        topch = stack.pop()
                        if topch == ch:
                            pass
                        else:
                            stack.append(ch)
                    if len(stack) == 0:
                        inside = False
                    else:
                        inside = True
                    mys.append(ch)
                else:
                    mys.append(ch)
            cmd = "".join(mys)
            return cmd

    def checkcmd(self,cmd):
            if(isNumber(cmd)):
                cmd = "self.mmr(0x%x)" % cmd
            else:
              func = cmd.split("(",1)[0].strip()
              _has = hasattr(self, func)
              if "per" in cmd:
                   pass
                   cmd = cmd.replace("per", "self.per")
              elif "all" in cmd:
                   pass
                   cmd = cmd.replace("all", "self.all")
              else:
                  if "(" in cmd:
                      #cmd = cmd.replace("mmw", "self.mmw")
                      #cmd = cmd.replace("regw32", "self.regw32")
                      #cmd = cmd.replace("mmr", "self.mmr")
                      #cmd = cmd.replace("regr32", "self.regr32")
                      cmd = re.sub(r'(?:^|([\s\(;]+))mmw\s*\(', r'\1self.mmw(', cmd)
                      cmd = re.sub(r'(?:^|([\s\(;]+))regw32\s*\(', r'\1self.regw32(', cmd)
                      cmd = re.sub(r'(?:^|([\s\(;]+))mmr\s*\(', r'\1self.mmr(', cmd)
                      cmd = re.sub(r'(?:^|([\s\(;]+))regr32\s*\(', r'\1self.regr32(', cmd)
                  cmd = self.formatcmd(cmd)
            return cmd
    def myexec(self, cmd):
            cmd = self.formatcmd(cmd)
            #cmd = cmd.replace("\\n", "\n")
            #cmd = cmd.replace(";", "\n")
            cmds = cmd.split("\n")
            for cmd in  cmds:
                cmd = cmd.strip()
                if not cmd: continue
                localcmd = self.checkcmd(cmd)
                self.internalcmd(cmd, localcmd)


def myexecInt(cmd):
    return mmr(cmd)

def myexecFunc(cmd):
    return cmd()

def myexecStr(cmd):
    cmd = cmd.replace("\\n", "\n")
    #if db32I.isGood() :
    #    exec(cmd)
        #        return
    old_stdout = sys.stdout
    redirected_output = sys.stdout = StringIO()
    try:
       exec(cmd)
    except:
       raise
    finally: # !
        sys.stdout = old_stdout # !
    vstr =  redirected_output.getvalue()
    print(vstr)
    v = db32I.rvmaparray(vstr)
    return v
def myexec(cmd, *args):
    if(isNumber(cmd)):
        return mmr(cmd)
    elif (type(cmd) == str):
        return myexecStr(cmd)
    elif (type(cmd) is types.FunctionType):
        if cmd.__code__.co_argcount > len(args) :
            raise ValueError("%s asks for %d args, but %d is provided"%(cmd.__name__, cmd.__code__.co_argcount, len(args)))
        return cmd(*args[:cmd.__code__.co_argcount])

def itname(pm4packet):
    op = (pm4packet>>8) &0xff
    opname = ""
    if op in PM4_IT_NAME:
        opname = PM4_IT_NAME[op]
    return opname

def dumpon(f, filename='', postf = None, stall_seconds = 0.5):
    '''
       keep doing f until 'q' or esc is pressed.
       if stall_seconds is 0, return after doing f once
    '''
    from datetime import datetime
    outputs = []
    enter_time = datetime.now()
    enter_time = enter_time.strftime('%Y-%m-%d_%H.%M.%S')
    if not filename: filename = "dump.%s.txt"%str(enter_time)
    with mystdin() as stdin :
      print("press q or esc to save and quit")
      while True:
        char = stdin.getch()
        if(char == "q" or char == '\x1b'):break
        if preloop: preloop()
        output = f()
        outputs.append(output)
        if stall_seconds == None: break
        elif stall_seconds != 0 : time.sleep(stall_seconds)
    if postf == None:
       ostr = '\n'.join([str(a) for a in outputs])
    else:
       ostr = postf(outputs)
    with open(filename, 'w') as fo:
       fo.write(ostr)
    print("\nWrite to %s"%filename)

def watchon(f, stall_seconds = 0.5, clear_screen = True, preloop=None):
    '''
       keep doing f until 'q' or esc is pressed.
       if stall_seconds is 0, return after doing f once
    '''
    from datetime import datetime
    with mystdin() as stdin :
      enter_time = datetime.now()
      while True:
        now_time = datetime.now()
        char = stdin.getch()
        if(char == "q" or char == '\x1b'):break
        output = f()
        if clear_screen : os.system('clear')
        print(now_time.strftime('%Y-%m-%d %H:%M:%S'), str(now_time - enter_time))
        print(output)
        if stall_seconds == None: break
        elif stall_seconds != 0 : time.sleep(stall_seconds)

def watchonXCC(f, xccs=[], stall_seconds = 0.5, clear_screen = True, preloop=None):
    '''
       keep doing f until 'q' or esc is pressed.
       if stall_seconds is 0, return after doing f once
    '''
    if len(xccs) == 0:
          mmPARTITION_COMPUTE_CAP = 0x3a04 //4
          xccbits = (mmr(mmPARTITION_COMPUTE_CAP) >> 10) & 0xff
          xccs = [ i for i in range(8) if (1<<i) & xccbits]
    from datetime import datetime
    with mystdin() as stdin :
      enter_time = datetime.now()
      while True:
        now_time = datetime.now()
        char = stdin.getch()
        if(char == "q" or char == '\x1b'):break
        if preloop: preloop()
        oldxccid = gg.XCCID
        output = '\n'.join(["XCC%d:\n%s"%(useXCC(xcc), f(xcc)) for xcc in xccs])
        gg.XCCID = oldxccid 
        if clear_screen : os.system('clear')
        print(now_time.strftime('%Y-%m-%d %H:%M:%S'), str(now_time - enter_time))
        print(output)
        if stall_seconds == None: break
        elif stall_seconds != 0 : time.sleep(stall_seconds)

class CMD:
    cmdlist = ["dvd","dd","mmr","mmw","regr32","regw32"]
    @staticmethod
    def cmd2func(cmd):
        '''convert cmd str to func str
        e.g. "dvd 0 32" -> "dvd(0,32)"
        '''
        var = ""
        if "=" in cmd:
           assigns = cmd.split('=')
           var = assigns[0] + "="
           cmd = assigns[1]
        ss = cmd.split()
        #if ss and ss[0] in CMD.cmdlist  and not "(" in cmd:
        #    func = ss[0] + "(" + ','.join("0x"*(i.startswith("0x") == False)+ i for i in ss[1:]) + ")"
        for i in range(len(ss)):
            if ss[i].isdigit(): ss[i] = '0x'+ss[i]
        if ss and not "(" in cmd:
            func = ss[0] + "(" + ','.join( i for i in ss[1:]) + ")"
        else: func = cmd
        func = var + func
        return func

class EACH:
    ''' iterates on each instance

      EACH().cu : iterator on each cu instance
      EACH().se : iterator on each se instance
      EACH().sh : iterator on each sh instance
      EACH().tcc: iterator on each tcc instance
      e.g.
      EACH().sh(mmGC_USER_SHADER_ARRAY_CONFIG)  #print all instances of mmGC_USER_SHADER_ARRAY_CONFIG
      EACH().sh(mmGC_USER_SHADER_ARRAY_CONFIG, 0x80000)          # mmGC_USER_SHADER_ARRAY_CONFIG[0] = 0x80000
      EACH().sh(mmGC_USER_SHADER_ARRAY_CONFIG, 0x80000, 0x80000) # mmGC_USER_SHADER_ARRAY_CONFIG[0:2] = 0x80000
      EACH().sh(mmGC_USER_SHADER_ARRAY_CONFIG, *[0x80000]*4)     # mmGC_USER_SHADER_ARRAY_CONFIG[0:4] = 0x80000
    '''

    def __init__(self, *index, **kwargs):
        self.db32 = kwargs['db32']  if 'db32' in kwargs else db32I
        self.numse  =kwargs['se']  if 'se' in kwargs else GC__NUM_SE
        self.numsa  =kwargs['sa']  if 'sa' in kwargs else GC__NUM_SH_PER_SE
        self.numinst=kwargs['i']   if 'i' in kwargs   else 1
        self.xccs   =kwargs['xcc']   if 'xcc' in kwargs   else None 
        self.indices = index
    def __myexec(self, cmd, *args):
        if(isNumber(cmd)):
            return self.db32.mmr(cmd)
        else: return myexec(cmd, *args)
    def __index(self, indices, reg, *value):
        value = Fmt.flat(value)
        __i = 0
        _rets = []
        __len = len(value)
        for se,sh,cu in indices:
             if __i >= __len : break
             grbm_gfx_index = (se << 16) | (sh << 8) | cu
             self.db32.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
             self.db32.mmw(reg, value[__i % __len])
             __i= __i+1
        mmw(mmGRBM_GFX_INDEX, 0xe0000000)
        if isinstance(self.db32, DB32Script):
            r = self.db32.run()
            rv = self.db32.rvmaparray(r)
            if len(rv) == 1:
               _rets = rv[list(rv.keys())[0]]
            self.db32.reset()
        return UserList(_rets)
    def index(self, indices, cmd, *value):
        if isNumber(cmd) and len(value) > 0:
            return self.__index(indices, cmd, *value)
        _rets = []
        for se,sh,cu in indices:
             grbm_gfx_index = (se << 16) | (sh << 8) | cu
             self.db32.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
             __ret = self.__myexec(cmd,se,sh,cu)
             _rets.append(__ret)
        self.db32.mmw(mmGRBM_GFX_INDEX, 0xe0000000)
        if isinstance(self.db32, DB32Script):
            r = self.db32.run()
            rv = self.db32.rvmaparray(r)
            self.db32.reset()
            __regkey = list(rv.keys())[0]
            return UserList(rv[__regkey])
        else:
            return UserList(_rets)
    def se(self, cmd, *value):
        __indices = tuple([(se, 0, 0) for se in RANGE_SE])
        return self.index(__indices, cmd, *value)
    def sh(self, cmd, *value):
        __indices = tuple([(se, sh, 0) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE)])
        return self.index(__indices, cmd, *value)
    if GFX_IP_MAJOR <= 9:
        def cu(self, cmd, *value):
            return self.cuslot(cmd, *value)
        def cuslot(self, cmd, *value):
            __indices = tuple([(se, sh, cu) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE) for cu in range(16)])
            return self.index(__indices, cmd, *value)
        def cuexisting(self, cmd, *value):
            __indices = tuple([(se, sh, cu) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE) for cu in RANGE_WGP])
            return self.index(__indices, cmd, *value)
        def wgpexisting(self, cmd, *value):
            return self.cuexisting(cmd, *value)
        def wgpslot(self, cmd, *value):
            return self.cuslot(cmd, *value)
        def tcp(self, cmd, *value):
            return self.cu(cmd, *value)
    elif GFX_IP_MAJOR >= 10:
        def cu(self, cmd, *value):
            return self.cuslot(cmd, *value)
        def cuslot(self, cmd, *value):
            __indices = tuple([(se, sh, (wgp << 2) + cu) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE) for wgp in range(16) for cu in range(2)])
            return self.index(__indices, cmd, *value)
        def cuexisting(self, cmd, *value):
            __indices = tuple([(se, sh, (wgp << 2) + cu) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE) for wgp in RANGE_WGP for cu in range(2)])
            return self.index(__indices, cmd, *value)
        def wgpexisting(self, cmd, *value):
            __indices = tuple([(se, sh, wgp << 2) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE) for wgp in RANGE_WGP])
            return self.index(__indices, cmd, *value)
        def wgpslot(self, cmd, *value):
            __indices = tuple([(se, sh, wgp << 2) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE) for wgp in range(16)])
            return self.index(__indices, cmd, *value)
        def tcp(self, cmd, *value):
            __indices = tuple([(se, sh, (wgp << 2) + cu) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE) for wgp in RANGE_WGP for cu in range(2)])
            return self.index(__indices, cmd, *value)
    def wgp(self, cmd, *value):
            return self.wgpexisting(cmd, *value)
    def i(self, cmd, *value):
        __indices = tuple([(se, sh, inst) for se in range(self.numse) for sh in range(0, self.numsa) for inst in range(self.numinst)])
        return self.index(__indices, cmd, *value)
    def sa(self, cmd, *value): return self.sh(cmd,*value)
    def tcc(self, cmd, *value):
        __indices = tuple([(0, 0, tccid) for tccid in range(GC__NUM_TCCS*GC__NUM_CORE)])
        return self.index(__indices, cmd, *value)
    def simd(self, cmd, *value):
        #__indices = tuple([(se, sh, wgp << 2 | simd) for se in RANGE_SE for sh in range(0, GC__NUM_SH_PER_SE) for wgp in RANGE_WGP for simd in range(0,4)])
        #return self.index(__indices, cmd, *value)
        _rets = []
        if isNumber(cmd) and len(value) > 0:
            return #self.__simd(cmd, *value)
        for se in RANGE_SE:
            for sa in RANGE_SA:
                for wgp in RANGE_WGP:
                  for simd in range(0,4):
                    grbm_gfx_index = (se << 16) | (sa << 8) | wgp << 2 | simd
                    self.db32.mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
                    __ret = self.__myexec(cmd,se,sa,wgp,simd)
                    _rets.append(__ret)
        self.db32.mmw(mmGRBM_GFX_INDEX, 0xe0000000)
        return UserList(_rets)

    def ctx(self, cmd, *value):
        def updatectx(cmd0, *values):
            myvalues = Fmt.flat(values)
            for cid in range(8):
               self.db32.mmw(cmd0 + cid*0x400, myvalues[cid])
        if isNumber(cmd) and len(value) > 0:
            updatectx(cmd, *value)

        _rets = []
        for cid in range(8):
            __ret = self.__myexec(cmd + cid*0x400, cid)
            _rets.append(__ret)
        return UserList(_rets)
    def xcc(self, cmd):
        _rets = []
        if self.xccs == None or len(self.xccs) == 0:
            mmPARTITION_COMPUTE_CAP = 0x3a04 //4
            xccbits = (mmr(mmPARTITION_COMPUTE_CAP) >> 10) & 0xff
            self.xccs = [ i for i in range(8) if (1<<i) & xccbits]
        for xcc in self.xccs:
            useXCC(xcc)
            __ret = self.__myexec(cmd, xcc)
            _rets.append(__ret)
        useXCC(0)
        return UserList(_rets)

each = EACH()

class RegGuard:
    '''To Save and Restore the registers for the scope
    e.g.
      1. with RegGuard(('sa',diag.mmGC_USER_SHADER_ARRAY_CONFIG)):
      2. with RegGuard(mmRSMU_INDEX)
    '''
    def __init__(self, *tosave):
        self.restore = []
        for one in tosave:
            if isNumber(one):
                self.restore.append((one, mmr(one)))
            elif isinstance(one, tuple):
                if one[0] == 'sa': self.restore.append(('sa', one[1], each.sa(one[1])))
                elif one[0] == 'cu': self.restore.append(('cu', one[1], each.cu(one[1])))
                elif one[0] == 'wgp': self.restore.append(('wgp', one[1], each.wgp(one[1])))
                else: raise Exception("Not Implemented")
            else: raise Exception("Not Implemented")
    def __enter__(self):
        return True
    def __exit__(self, *args):
        for one in self.restore:
            if len(one) == 2:
                mmw(one[0], one[1])
            elif len(one) == 3:
                if one[0] == 'sa': each.sa(one[1], *one[2])
                elif one[0] == 'cu': each.cu(one[1], *one[2])
                elif one[0] == 'wgp': each.wgp(one[1], *one[2])
                else:raise Exception("Not Implemented")
            else:raise Exception("Not Implemented")
        pass
regGuard = RegGuard

def currentXCC(): return gg.XCCID
def useXCC(xcc): 
    gg.XCCID=xcc
    return xcc
