#$scriptName= $MyInvocation.MyCommand.Name
$asic = (Get-Item $PSCommandPath ).Basename
python $PSScriptRoot\diag.py -a $asic $args
