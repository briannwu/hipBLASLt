
#!/usr/bin/python
from __future__ import print_function
from db32 import *
import random
import logging
from chip_registers import *
from ip_gds import *
from ip_mm import *
from ip_rb import *
from settings import *


class CReST:
  @staticmethod
  def enable(): 
     v = mmr(mmCP_DFY_CNTL)
     v = v | (1<<31)
     mmw(mmCP_DFY_CNTL, v)
  @staticmethod
  def disable(): 
     v = mmr(mmCP_DFY_CNTL)
     v = v & (0x7fffffff)
     mmw(mmCP_DFY_CNTL, v)
  @staticmethod
  def mode(md): 
     v = mmr(mmCP_DFY_CNTL) & 0x9fffffff
     v = v | ( md << 29)
     mmw(mmCP_DFY_CNTL, v)
  @staticmethod
  def info(): 
     mmrp(mmCP_DFY_CNTL)
     mmrp(mmCP_DFY_STAT)
     mmrp(mmCP_DFY_ADDR_LO)
     mmrp(mmCP_DFY_ADDR_HI)
  @staticmethod
  def address(addr): 
     mmw(mmCP_DFY_ADDR_HI, addr >> 32)
     mmw(mmCP_DFY_ADDR_LO, addr&0xffffffff)
  @staticmethod
  def write(datas): 
    if True:
     if isNumber(datas) : 
         mmw(mmCP_DFY_DATA_0, datas) 
         return
     for data in datas:
         mmw(mmCP_DFY_DATA_0, data)
    else:
     mmw(mmRSMU_INDEX, mmCP_DFY_DATA_0 * 4)
     mmw(mmRSMU_INDEX, 0)
     if isNumber(datas) : 
         mmw(mmRSMU_DATA, datas) 
         return
     for data in datas:
         mmw(mmRSMU_DATA, data)
crest = CReST()
  
