#!/usr/bin/python
from db32 import *
import random
from ip_util import *
from ip_reg import *
from collections import OrderedDict
from settings import *
from ip_debe import *

class CFGCommon:
  '''Common CFGfunction for GFX9/GFX10/GFX11
  '''
  @staticmethod
  @logit()
  def ssid():
      sid=db32I.csid(0x2c)
      logger.log(25, "ssid:%x"%sid)
      return sid
  @staticmethod
  @logit()
  def did():
      did = db32I.csid(0x0) >> 16
      logger.log(25, "device id : 0x%x"%did)
      return did
  @staticmethod
  def hasDisableSA():
      def onesh(seid, shid):
        v0=mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
        v1=mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
        return (v0 | v1) & 0xffff0000
      r = each.sh(onesh)
      return any([v==0xffff0000 for v in r])
  @staticmethod
  def showCUMask():
      mask0 = {}
      mask1 = {}
      rb_mask0 = {}
      rb_mask1 = {}
      wgp_remap= {}
      rb_remap= {}
      WGPs = 0
      def onesh(seid, shid):
        v0=mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
        v1=mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
        mask0["SE%dSH%d"%(seid,shid)] = v0
        mask1["SE%dSH%d"%(seid,shid)] = v1
        if GFX_IP_MAJOR <= 10:
            rb_v0 = mmr(mmCC_RB_BACKEND_DISABLE)
            rb_v1 = mmr(mmGC_USER_RB_BACKEND_DISABLE)
            rb_mask0["SE%dSH%d"%(seid,shid)] = rb_v0
            rb_mask1["SE%dSH%d"%(seid,shid)] = rb_v1
        return v0|v1
      r_wgps = each.sh(onesh)
      if GFX_IP_MAJOR == 11:
            rb_v0 = mmr(mmCC_RB_BACKEND_DISABLE)
            rb_v1 = mmr(mmGC_USER_RB_BACKEND_DISABLE)
            rb_mask0["RB"] = rb_v0
            rb_mask1["RB"] = rb_v1
      if GFX_IP_MAJOR >= 12:
          def onese(seid):
            rb_v0 = mmr(mmCC_RB_BACKEND_DISABLE)
            rb_v1 = mmr(mmGC_USER_RB_BACKEND_DISABLE)
            rb_mask0["SE%d"%(seid)] = rb_v0
            rb_mask1["SE%d"%(seid)] = rb_v1
            wgp_remap["SE%dSA0"%(seid)] = mmr(mmGRBMH_WGP_SA0_REMAP_CNTL)
            wgp_remap["SE%dSA1"%(seid)] = mmr(mmGRBMH_WGP_SA1_REMAP_CNTL)
            rb_remap["SE%dSA0"%(seid)] = mmr(mmGRBMH_RB_SA0_REMAP_CNTL)
            rb_remap["SE%dSA1"%(seid)] = mmr(mmGRBMH_RB_SA1_REMAP_CNTL)
          r = each.se(onese)
          print("mmGRBMH_WGP_SAx_REMAP_CNTL   : %s"%Fmt.hexall(OrderedDict(sorted(wgp_remap.items()))))
      print("mmCC_GC_SHADER_ARRAY_CONFIG  : %s"%Fmt.hexall(OrderedDict(sorted(mask0.items()))))
      print("mmGC_USER_SHADER_ARRAY_CONFIG: %s"%Fmt.hexall(OrderedDict(sorted(mask1.items()))))
      print("mmCC_RB_BACKEND_DISABLE      : %s"%Fmt.hexall(OrderedDict(sorted(rb_mask0.items()))))
      print("mmGC_USER_RB_BACKEND_DISABLE : %s"%Fmt.hexall(OrderedDict(sorted(rb_mask1.items()))))
      if GFX_IP_MAJOR >= 12:
          print("mmGRBMH_RB_SAx_REMAP_CNTL    : %s"%Fmt.hexall(OrderedDict(sorted(rb_remap.items()))))
      if var_exist('mmCC_RB_REDUNDANCY'):
          mmrp(mmCC_RB_REDUNDANCY)
          mmrp(mmGC_USER_RB_REDUNDANCY)
      if var_exist('mmCC_GC_PRIM_CONFIG'):
          mmrp(mmGC_USER_PRIM_CONFIG)
          mmrp(mmCC_GC_PRIM_CONFIG)
      if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
         mmrp(mmGC_USER_SA_UNIT_DISABLE)
         mmrp(mmCC_GC_SA_UNIT_DISABLE)
      if var_exist('mmGRBM_SA_REMAP_CNTL'): mmrp(mmGRBM_SA_REMAP_CNTL)
      if var_exist('mmCGTS_TCC_DISABLE'):
         mmrp(mmCGTS_TCC_DISABLE)
         mmrp(mmCGTS_USER_TCC_DISABLE)
      if var_exist('mmGCUTCL2_HARVEST_BYPASS_GROUPS'):
          mmrp(mmGCUTCL2_HARVEST_BYPASS_GROUPS)
      if var_exist('mmGRBM_SE_REMAP_CNTL'): mmrp(mmGRBM_SE_REMAP_CNTL)
      if var_exist('mmCC_RB_REDUNDANCY'):
          mmrp(mmCC_RB_REDUNDANCY)
          mmrp(mmGC_USER_RB_REDUNDANCY)
      mmrp(mmGB_ADDR_CONFIG)
      if True:
          WPGs = []
          def enablelist(shader_array_lo16, said):
              return [i + said * 16  for i in range(16) if ((shader_array_lo16 >> i) & 1) == 0]
          rs = [ enablelist(v>>16, k) for k, v in enumerate(r_wgps)]
          nnn = sum([len(v) for k, v in enumerate(rs)])
          print("ENABLED_WGP:%d"%nnn, Fmt.warns(str(rs)))
      if Settings.mAsic == mi300:
          mmPARTITION_COMPUTE_CAP = 0x3a04 //4
          mmPARTITION_COMPUTE_STATUS = 0x3a0c //4
          cap = mmr(mmPARTITION_COMPUTE_CAP)
          pat = mmr(mmPARTITION_COMPUTE_STATUS)
          nm = ['SPX', 'DPX', 'TPX', 'QPX', 'CPX']
          print("partition_compute_status 0x%x"%pat)
          print("partition_compute_cap 0x%x"%cap)
          if ((pat&0xf0) >> 4) <= 4:
              print("Partition Mode : %s"%(nm[(pat&0xf0)>>4]))
          mmPARTITION_MEM_STATUS = 0x3a10 // 4
          mmPARTITION_MEM_CAP = 0x3a08 // 4
          mcap = mmr(mmPARTITION_MEM_CAP)
          mpat = mmr(mmPARTITION_MEM_STATUS)
          print("partition_mem_status 0x%x"%mpat)
          print("partition_mem_cap 0x%x"%mcap)
      if var_exist('mmGC_USER_SHADER_RATE_CONFIG'):
          vRatea = mmr(mmGC_USER_SHADER_RATE_CONFIG)
          vRateb = mmr(mmCC_GC_SHADER_RATE_CONFIG)
          vRatea = (vRatea >> 1) & 3
          vRateb = (vRateb >> 1) & 3
          print('GC_USER_SHADER_RATE_CONFIG.dpfp_rate', vRatea)
          print('CC_GC_SHADER_RATE_CONFIG.dpfp_rate', vRateb)

  @staticmethod
  def setPartition(nXCC=0, nXCP=0, **kwargs):
      mmPARTITION_COMPUTE_CAP = 0x3a04 //4
      mmPARTITION_COMPUTE_STATUS = 0x3a0c //4
      conf=[0,0x411, 0xc11, 0x3c13, 0xfc15, 0x3fc1b, 0x3f015]
      if nXCC == 1 :
          mmw(mmPARTITION_COMPUTE_CAP, conf[nXCC])
          mmw(mmPARTITION_COMPUTE_STATUS, 0)
      elif nXCC == 2 :
          mmw(mmPARTITION_COMPUTE_CAP, conf[nXCC])
          if nXCP == 1 : mmw(mmPARTITION_COMPUTE_STATUS, 0)
          else : mmw(mmPARTITION_COMPUTE_STATUS, 0x40)
      elif nXCC == 6 :
          mmw(mmPARTITION_COMPUTE_CAP, conf[nXCC])
          if nXCP == 1 : mmw(mmPARTITION_COMPUTE_STATUS, 0)
          elif nXCP == 6: mmw(mmPARTITION_COMPUTE_STATUS, 0x40)
      if 'cap' in kwargs:
          mmw(mmPARTITION_COMPUTE_CAP, kwargs['cap'])
      if 'status' in kwargs:
          mmw(mmPARTITION_COMPUTE_STATUS, kwargs['status'])
  @staticmethod
  def setMemoryPartition(nps = 0, **kwargs):
      ''' nps: 1,2,3,4,5,6,7,8
      '''
      if not nps in range(1,9):
          if (not 'cap' in kwargs) or  (not 'status' in kwargs):
              print("invalid nps mode: nps must be one of 1,2,3,4,5,6,7,8")
              return
      mmPARTITION_MEM_STATUS = 0x3a10 // 4
      mmPARTITION_MEM_CAP = 0x3a08 // 4
      if nps in range(1,9):
          cap = (1<<(nps-1) )
          status = (1<<(nps+4-1)) | 1
      if 'cap' in kwargs: cap = kwargs['cap']
      if 'status' in kwargs: status = kwargs['status']
      mmw(mmPARTITION_MEM_STATUS, status)
      mmw(mmPARTITION_MEM_CAP, cap)

  @staticmethod
  def showWGPMask():showCUMask()
  @staticmethod
  def info():CFG.showCUMask()

  @staticmethod
  def enableCUExt(*cuids, **kw):
      ''' Enable the *cuids, and disable all the other CUs
          for gfx9:   cuid = seid * 16 + localcuid
          for gfx10:  wgpid = seid * 32 + said *16 + localwgpid
          for gfx10:  the cu is the same to wgp in this API
      '''
      #CFG.clear()
      each.sa(mmGC_USER_SHADER_ARRAY_CONFIG, 0);
      full =  range(0,GC__NUM_TOTAL_SH*16)
      disabledcus = tuple([x for x in full if x not in cuids])
      CFG.disableCU(*disabledcus, **kw)
  @staticmethod
  def disableCUExt(*cuids, **kw):
      ''' Disable the *cuids, and enable all the other CUs
          for gfx9:   cuid = seid * 16 + localcuid
          for gfx10:  wgpid = seid * 32 + said *16 + localwgpid
          for gfx10:  the cu is the same to wgp in this API
      '''
      #CFG.clear()
      each.sa(mmGC_USER_SHADER_ARRAY_CONFIG, 0);
      CFG.disableCU(*cuids, **kw)
  @staticmethod
  def disableCU(*cuids, **kw):
      ''' Disable the *cuids, not change other CUs
          disableCU(0,1)    disable CU0 CU1
          disableCU(16,17)  disable CU0 CU1 in the 2nd SH/SA [GFX9 SE1 // GFX10 SE0SA1]
          disableCU()       enable ALL CUs
          for gfx9:   cuid = seid * 16 + localcuid
          for gfx10:  wgpid = seid * 32 + said *16 + localwgpid
          for gfx10:  the cu is the same to wgp in this API
      '''
      if len(cuids)  == 0:
          return CFG.clear()
      if cuids[0] > GC__NUM_TOTAL_SH*16 - 1: return showCUMask()
      mmREG_SHADER_ARRAY_CONFIG = mmGC_USER_SHADER_ARRAY_CONFIG
      if 'fuse_mode' in kw: mmREG_SHADER_ARRAY_CONFIG=mmCC_GC_SHADER_ARRAY_CONFIG
      for cuid in cuids:
          seshid = int(cuid) // 16
          seid = seshid // GC__NUM_SH_PER_SE
          shid = seshid % GC__NUM_SH_PER_SE
          _cuid = cuid % 16
          mmw(mmGRBM_GFX_INDEX, (seid<<16 ) | (shid << 8))
          v = mmr(mmREG_SHADER_ARRAY_CONFIG)
          v = int(v)
          #print("old %X"%v)
          v = v | ( 1 << (16+_cuid))
          mmw(mmREG_SHADER_ARRAY_CONFIG, v)
          v = mmr(mmREG_SHADER_ARRAY_CONFIG)
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          #print("new %X"%v)
      if not('nosanity' in kw and kw['nosanity']): CFG.sanity()
      CFG.showCUMask()
  @staticmethod
  def enableCU(*cuids, **kw):
      ''' enable the *cuids,  not change other CUs
          enableCU(0,1)    enable CU0 CU1
          enableCU(16,17)  enable CU0 CU1 in the 2nd SH/SA [GFX9 SE1 // GFX10 SE0SA1]
          enableCU()       enable ALL CU
          for gfx9:   cuid = seid * 16 + localcuid
          for gfx10:  wgpid = seid * 32 + said *16 + localwgpid
          for gfx10:  the cu is the same to wgp in this API
      '''
      if len(cuids)  == 0:
          return CFG.clear()
      if cuids[0] > GC__NUM_TOTAL_SH*16 - 1: return showCUMask()

      mmREG_SHADER_ARRAY_CONFIG = mmGC_USER_SHADER_ARRAY_CONFIG
      if 'fuse_mode' in kw: mmREG_SHADER_ARRAY_CONFIG=mmCC_GC_SHADER_ARRAY_CONFIG
      for cuid in cuids:
          seshid = int(cuid) // 16
          seid = seshid // GC__NUM_SH_PER_SE
          shid = seshid % GC__NUM_SH_PER_SE
          _cuid = cuid % 16
          mmw(mmGRBM_GFX_INDEX, (seid<<16 ) | (shid << 8))
          v = mmr(mmREG_SHADER_ARRAY_CONFIG)
          v = int(v)
          #print("old %X"%v)
          v = v & (~( 1 << (16+_cuid))) & 0xffff0000
          mmw(mmREG_SHADER_ARRAY_CONFIG, v)
          v = mmr(mmREG_SHADER_ARRAY_CONFIG)
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          #print("new %X"%v)
      if not('nosanity' in kw and kw['nosanity']): CFG.sanity()
      CFG.showCUMask()

  @staticmethod
  def dpfp_rate(rate, **kw):
      mmDPFP_RATE = mmGC_USER_SHADER_RATE_CONFIG
      if 'fuse_mode' in kw:  mmDPFP_RATE = mmCC_GC_SHADER_RATE_CONFIG
      v = mmr(mmDPFP_RATE)
      v = v & 0xfffffff9
      v = v | (rate & 3)
      mmw(mmDPFP_RATE, v)

  @staticmethod
  def disableWGP(*cuids, **kw):CFG.disableCU(*cuids, **kw)
  @staticmethod
  def enableWGP(*cuids, **kw):CFG.enableCU(*cuids, **kw)
  @staticmethod
  def disableWGPExt(*cuids, **kw):CFG.disableCUExt(*cuids, **kw)
  @staticmethod
  def enableWGPExt(*cuids, **kw):CFG.enableCUExt(*cuids, **kw)

  @staticmethod
  def enableOneSE(seid=None):
      ''' Enable seid and disable all the other SEs
      '''
      mask0 = [0]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
      mask = [0xfffe0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
      if seid is None:
          CFG.clear()
          showCUMask()
          return
      if seid > 3: return showCUMask()
      #
      for i in RANGE_SE:
          for j in RANGE_SA:
            mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
            mask0[i*GC__NUM_SA_PER_SE+j] = mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
      mmw(mmGRBM_GFX_INDEX, 0xe0000000)
      # The disabled SE, must have one active CU
      for i in range(0, GC__NUM_SE):
          if (mask[0] & 0xFFFF0000) == 0 :
              mask[i] = 0xfffe0000
          else:
              _dmsk = 16
              while ((_dmsk < 32) and ((( mask0[i] >> _dmsk ) & 1) == 1)) : _dmsk = _dmsk +1
              _dmsk = 1 << _dmsk
              _dmsk = (~ _dmsk) & 0xFFFF0000
              mask[i] = _dmsk
      #
      for said in RANGE_SA:
          mask[seid*GC__NUM_SA_PER_SE+said] = 0
      for i in RANGE_SE:
          for j in RANGE_SA:
              mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
              mmw(mmGC_USER_SHADER_ARRAY_CONFIG, mask[i*GC__NUM_SA_PER_SE+j])
      mmw(mmGRBM_GFX_INDEX, 0xe0000000)
      if GFX_IP_MAJOR == 9:
          iaID = seid // 2     #active ia
          iaID = 1 << iaID
          iaID = (~iaID) & 3  #inacitve ia
          vgtID = seid
          vgtID = 1 << seid
          vgtID = (~vgtID) & 15 #inactive vgt
          vGC_USER_PRIM_CONFIG = (iaID << 16) | (vgtID << 24)
          mmw(mmGC_USER_PRIM_CONFIG, vGC_USER_PRIM_CONFIG)
      showCUMask()

  @staticmethod
  def clear():
      ''' clear mmGC_USER_SHADER_ARRAY_CONFIG and mmGC_USER_PRIM_CONFIG
      '''
      each.sh(lambda seid:mmw(mmGC_USER_SHADER_ARRAY_CONFIG, 0))
      each.sh(lambda seid:mmw(mmGC_USER_RB_BACKEND_DISABLE, 0))
      if var_exist("mmGC_USER_PRIM_CONFIG"):      mmw(mmGC_USER_PRIM_CONFIG, 0)
      if var_exist("mmGC_USER_RB_REDUNDANCY"): mmw(mmGC_USER_RB_REDUNDANCY,0)
      if var_exist('mmGC_USER_SA_UNIT_DISABLE'): mmw(mmGC_USER_SA_UNIT_DISABLE,0)
      if var_exist('mmGCUTCL2_HARVEST_BYPASS_GROUPS'): mmw(mmGCUTCL2_HARVEST_BYPASS_GROUPS,0)
      if var_exist('mmGRBM_SE_REMAP_CNTL'): mmw(mmGRBM_SE_REMAP_CNTL,0xeca86420)

  @staticmethod
  def __checkGRBM( cmd = 'softreset1()'):
      s = mmr(mmGRBM_STATUS)
      if not "(" in cmd: cmd = cmd + "()"
      if s != 0x3028: exec(cmd)

  @staticmethod
  def __reduceBadCUCandidates(cmd, candidates, bads, goods, loops = 0, useDisable = True, allbads = [], saharv = False, resetcmd='softreset1()'):
      '''return list of bad cu candidates'''
      L = len(candidates)
      #if L < 2: return [candidates]
      left = candidates[0:L//2]
      right = candidates[L//2:]
      logging.log(25, "left:%s  right:%s",   repr(left), repr(right))
      CFG.clear()
      if useDisable == True:  CFG.disableCU(*tuple(left+bads))
      else:
          #allenables = [i for i in  range(0,GC__NUM_TOTAL_SH*16) if i not in allbads] + list(left)
          allenables = goods + list(left)
          CFG.enableCUExt(*tuple(allenables))
      errLeft = 0
      if saharv or CFG.hasDisableSA() == False:
          for i in range(0, max(1,loops)):
            CFG.__checkGRBM(resetcmd)
            logging.info(cmd)
            errLeft0,bL = subprocess.getstatusoutput(cmd)
            errLeft = errLeft0 + errLeft
            errStr = "errLeft %s"%(repr(errLeft))
            errStr = Fmt.goods(errStr) if errLeft == 0 else Fmt.bads(errStr)
            logging.info(errStr)
            logging.log(19, "logLeft %s ", str(bL))
      else:
          logging.error( Fmt.bad("There is disabled SA"))
          errLeft = 1
          return [candidates]
      CFG.clear()
      if loops > 0 or len(right) == 1:
        if useDisable == True:  CFG.disableCU(*tuple(right+bads))
        else:
            #allenables = [i for i in  range(0,GC__NUM_TOTAL_SH*16) if i not in allbads] + list(right)
            allenables = goods + list(right)
            CFG.enableCUExt(*tuple(allenables))
        errRight = 0
        if saharv or CFG.hasDisableSA() == False:
            for i in range(0, max(1,loops)):
              CFG.__checkGRBM(resetcmd)
              logging.info(cmd)
              errRight0,bR = subprocess.getstatusoutput(cmd)
              errRight = errRight0 + errRight
              errStr = "errRight %s"%(repr(errRight))
              errStr = Fmt.goods(errStr) if errRight == 0 else Fmt.bads(errStr)
              logging.info(errStr)
              logging.log(19, "logRight %s ", str(bR))
        else:
            logging.error( Fmt.bad("There is disabled SA"))
            errRight = 1
            return [candidates]
        CFG.clear()
      else:
        errRight = 0 if errLeft != 0 else 1
        bR=""
      newcandidates = []
      if useDisable == True:
          if errLeft == 0 and errRight == 0:#no failing
              pass
          elif errLeft != 0 and errRight != 0:
              newcandidates = [left, right]
              # both left and right have bad CU
          elif errLeft == 0: #bad is in left
              newcandidates = [left]
          else:              #bad is in right
              newcandidates = [right]
      else: #useEnable == True
          if errLeft == 0 and errRight == 0:#no failing
              pass
          elif errLeft != 0 and errRight != 0:
              newcandidates = [left, right]
          elif errLeft == 0: #good is in left
              newcandidates = [right]
          else:              #good is in right
              newcandidates = [left]
      return newcandidates
  @staticmethod
  def findBadCUGfx10(cmd, loops=1, **dic): CFG.findBadCUGfx9(cmd, loops, **dic)
  @staticmethod
  def findBadWGPGfx10(cmd, loops=1, **dic): CFG.findBadCUGfx9(cmd, loops, **dic)
  @staticmethod
  def debug00(*badcus):
          mask0 =[]
          each.sh(lambda seid,shid:mask0.append(mmr(mmCC_GC_SHADER_ARRAY_CONFIG) | mmr(mmGC_USER_SHADER_ARRAY_CONFIG)))
          allmask = 0
          for i, key in enumerate(mask0): allmask = allmask |  (((key & 0xffff0000) >> 16) << (i*16))
          mymask = 0
          for i in badcus: mymask = mymask | ( 1 << i)
          if (mymask | allmask ) == allmask:
              exit(0)
          else:
              exit(1)

  @staticmethod
  def findGood(cmd, currentBadCandidatesList, extra = 1, saharv = False, resetcmd='softreset1()'):
      if not isNumber(extra):extra = 1
      print(GC__NUM_SA_PER_SE, GC__NUM_SE)
      #_predef = [ [wi+16*ai for ai in range(0,GC__NUM_SA_PER_SE*GC__NUM_SE)]  for wi in RANGE_WGP]
      _predef = [ [wi+16*ai for ai in range(0,GC__NUM_SA_PER_SE*GC__NUM_SE)]  for wi in range(0, GC__NUM_WGP_PER_SA)]
      if extra > 0:
          allsa = [[] for i in range(GC__NUM_TOTAL_SH)]
          for wgp in currentBadCandidatesList:
              sa = wgp // 16
              allsa[sa].append(wgp)
          if True:
              if all([len(i) for i in allsa]): # make sure allsa[i] is not empty
                for i in range(0, extra):
                  for sa in allsa: random.shuffle(sa)
                  _predef.append([allsa[i][0] for i in range(0, GC__NUM_TOTAL_SH)])
          else:
              for i in range(0, extra):
                  _predef.append([i*16+random.randint(0,GC__NUM_WGP_PER_SA) for i in range(0, GC__NUM_TOTAL_SH)])

      logging.log(25, "----------------- search good WGP -------------")
      print(_predef)
      for s in _predef:
         CFG.clear()
         CFG.enableCUExt(*tuple(s))
         CFG.__checkGRBM(resetcmd)
         CFG.info()
         logging.info(cmd)
         if saharv or CFG.hasDisableSA() == False:
            err,bR = subprocess.getstatusoutput(cmd)
            logging.log(19, str(err) + str(bR))
            if err == 0:
               logging.log(25, "goods:       " + str(s))
               logging.log(25, "----------------- search good WGP done ---------")
               return s
      logging.log(25, "goods:[]       ")
      logging.log(25, "----------------- search good WGP done ---------")
      return []

  @staticmethod
  def searchGoodPattern(cmd, **kwargs):
      resetcmd = kwargs['resetcmd'] if 'reset' in kwargs else 'softreset1()'
      gfx_minor = kwargs['gfx_minor_version'] if 'gfx_minor_version' in kwargs  else 3
      if 'searchlist' in kwargs:
        searchlist = kwargs['searchlist']
        for stringtocheck in searchlist:
            CFG.clear()
            CFG.disableWGP(*tuple(stringtocheck))
            CFG.__checkGRBM(resetcmd)
            CFG.info()
            logging.log(25, "Disabled CU: %s ", repr(stringtocheck))
            errVerify,bL = subprocess.getstatusoutput(cmd)
            logging.info("errVerify %s %s", repr(errVerify), str(bL))

            __wgpAse= GC__NUM_SA_PER_SE*16
            custr = ' '.join(["SE%dSA%dCU%d"%(wid//__wgpAse, (wid%__wgpAse)//16, wid%16) for wid in stringtocheck])
            Fmt.warn("Checked Bad CUs:"+ repr(stringtocheck) + " " + custr)
            if errVerify == 0:
                Fmt.good("Verify: Test passes after disable " + repr(stringtocheck))
                if GFX_IP_MAJOR == 10:CFG.debeGfx10(0,gfx_minor)
                else: CFG.debeGfx9()
                break
            else: Fmt.bad("Verify: Test falis after disable " + repr(stringtocheck))
      else:
        logging.error("Please provide searchlist, e.g, searchlist=[[18,19]]")
        return 1

  @staticmethod
  def searchGoodPatternRobin(cmd, **kwargs):
      searchlist = [[51, 52, 35, 36, 19, 20, 3, 4], [50, 51, 34, 35, 18, 19, 2, 3], [49, 50, 33, 34, 17, 18, 1, 2], [49, 52, 33, 36, 17, 20, 1, 4], [48, 52, 32, 36, 16, 20, 0, 4]]
      if 'searchlist' in kwargs:
          kwargs['searchlist'] = searchlist + kwargs['searchlist']
      else:
          kwargs['searchlist'] = searchlist
      CFG.searchGoodPattern(cmd, **kwargs)

  @staticmethod
  def findBadCUGfx9(cmd, loops=1, **dic):
      def shuffle(wgplist):
          random.shuffle(wgplist)
          allsa = [[] for i in range(GC__NUM_TOTAL_SH)]
          left = []
          right = []
          for wgp in wgplist:
              sa = wgp // 16
              allsa[sa].append(wgp)
          for sa in range(GC__NUM_TOTAL_SH):
              if len(allsa[sa]) > 0:
                  mid = len(allsa[sa]) // 2
                  left = left + allsa[sa][:mid]
                  right = right + allsa[sa][mid:]
          newlist = left + right
          for i in range(len(wgplist)):
              wgplist[i] = newlist[i]
      def workaroundOneWGPinSA(currentBadCandidatesList, good):
          ''' For those SA that has only 1 WGP, if it doesn't
              support sa harvest, we cannot disable it
          '''
          allsa = [[] for i in range(GC__NUM_TOTAL_SH)]
          for wgp in currentBadCandidatesList:
              sa = wgp // 16
              allsa[sa].append(wgp)
          for sa in allsa:
              if len(sa) == 1 :
                  good.append(sa[0])
                  currentBadCandidatesList.remove(sa[0])

      bads=[]
      goods=[]
      maxbads = 0
      maxloops = 100
      resetcmd = 'softreset1()'
      currentBadCandidatesLists = [list(range(0,GC__NUM_TOTAL_SH*16))]
      doOneWGPWorkaround = False
      saharv = dic['saharv'] if 'saharv' in dic  else False
      gfx_minor = dic['gfx_minor_version'] if 'gfx_minor_version' in dic  else 3
      if 'se' in dic:
        _seid = dic['se']
        currentBadCandidatesLists = [range(_seid*16, _seid*16+16)]
      elif 'cu' in dic:
        currentBadCandidatesLists = [dic['cu']]
      if 'cwd' in dic:
          cmd = 'cd ' + dic['cwd'] + ";" + cmd

      if True:
          ''' remove the disabled CU/wgp from currentBadCandidatesLists
          '''
          mask0 =[]
          each.sh(lambda seid,shid:mask0.append(mmr(mmCC_GC_SHADER_ARRAY_CONFIG) | mmr(mmGC_USER_SHADER_ARRAY_CONFIG)))
          allmask = 0
          for i, key in enumerate(mask0): allmask = allmask |  (((key & 0xffff0000) >> 16) << (i*16))
          currentBadCandidatesLists[0] = [k for k in currentBadCandidatesLists[0] if ((allmask >> k)&1) ==0]
          bads = [k for k in range(0,GC__NUM_TOTAL_SH*16) if ((allmask >> k)&1) ==1]
          mask00 =[]
          allmask00 = 0
          each.sh(lambda seid,shid:mask00.append(mmr(mmCC_GC_SHADER_ARRAY_CONFIG)))
          for i, key in enumerate(mask00): allmask00 = allmask00 |  (((key & 0xffff0000) >> 16) << (i*16))
      if len(dic) > 0:
         if 'bad' in dic:
           bads = bads + dic['bad']
         if 'good' in dic:
           goods = dic['good']
         if 'goodstart' in dic and dic['goodstart']:
           goods += CFG.findGood(cmd, currentBadCandidatesLists[0], dic['goodstart'], saharv)
         if len(goods) > 0:
           currentBadCandidatesLists[0] = [k for k in currentBadCandidatesLists[0] if k not in goods]
         if 'maxbads' in dic: maxbads = dic['maxbads']
         if 'maxloops' in dic: maxloops = dic['maxloops']
         if 'reset' in dic: resetcmd = dic['reset']
         if 'onewgpwa' in dic : doOneWGPWorkaround = dic['onewgpwa']
         if (not saharv) and (doOneWGPWorkaround) : workaroundOneWGPinSA(currentBadCandidatesLists[0], goods)

      useDisable = True # when there is only 1 bad CU, use Disable
      shuffle(currentBadCandidatesLists[0])
      def safeshuffle(_lrlist):
          L = len(_lrlist)
          while True:
              shuffle(_lrlist)
              left = _lrlist[0:L//2]
              right = _lrlist[L//2:]
              break;

      loopid = 0
      while len(currentBadCandidatesLists) > 0:
        logging.log(25, "-----------------------------------------------")
        logging.log(25, "candidates: " + repr(currentBadCandidatesLists))
        logging.log(25, "bads:       " + repr(bads))
        logging.log(25, "goods:      " + repr(goods))
        if loopid > maxloops:
            logging.error("The number of loop > %d" % maxloops)
            return 1
        if maxbads > 0 and len(currentBadCandidatesLists) > maxbads:
            logging.error("The number of bad WGPs > %d" % maxbads)
            return 1
        newLists = []
        allbads = bads
        for badCandidatesList in currentBadCandidatesLists: allbads = allbads + badCandidatesList
        for badCandidatesList in currentBadCandidatesLists:
            _newlist = CFG.__reduceBadCUCandidates(cmd, badCandidatesList, bads, goods, loops, useDisable, allbads, saharv, resetcmd)
            if len(_newlist) == 0: # update Goods
                goods.extend(badCandidatesList)
            if len(_newlist) == 1: # update Goods
                goods.extend([gi for gi in  badCandidatesList if gi not in _newlist[0]])
            if len(_newlist) == 2: useDisable = False
            for lr in _newlist :
                if len(lr) == 1:  #get the bad CU
                    bads.append(lr[0])
                else:
                    shuffle(lr)
                    newLists.append(lr)
        currentBadCandidatesLists = newLists
        loopid = loopid + 1

      logging.log(25, "---------------  search done  -----------------")
      bads = [k for k in bads if ((allmask00 >> k)&1) ==0] # remove the fused CU
      logging.info("\nverify " + repr(bads))
      errVerify = 0
      if True:
          CFG.clear()
          CFG.disableCU(*tuple(bads))
          for i in range(0, max(1,loops)):
            CFG.__checkGRBM(resetcmd)
            errVerify0,bL = subprocess.getstatusoutput(cmd)
            errVerify= errVerify+ errVerify0
            logging.info("errVerify %s %s", repr(errVerify), str(bL))

      __wgpAse= GC__NUM_SA_PER_SE*16
      custr = ' '.join(["SE%dSA%dCU%d"%(wid//__wgpAse, (wid%__wgpAse)//16, wid%16) for wid in bads])
      Fmt.warn("Bad CUs:"+ repr(bads) + " " + custr)
      if errVerify0 == 0:
         Fmt.good("Verify: Test passes after disable " + repr(bads))
         if GFX_IP_MAJOR == 10:CFG.debeGfx10(0,gfx_minor)
         else: CFG.debeGfx9()
      else: Fmt.bad("Verify: Test falis after disable " + repr(bads))
  @staticmethod
  def checkCUHarvestable(nativeCU=80, balancedCU=72, useDEBE=False, **kwargs):
      '''
      param:
          nativeCU        int : #CU of Full configure
          balancedCU      int : #CU of down configure
          symsa(optional) bool: balanced(symmetric) in SA level
          symse(optional) bool: balanced(symmetric) in SE level
      return value:
         0      :  nativeCU count observed
         -1(255):  Insufficient CU for balancedCU config
         1      :  less than nativeCU count found, but down-config available to balancedCU
      '''
      cuNumOfFullConfig = 2 * GC__NUM_WGP_PER_SA * GC__NUM_SE * GC__NUM_SA_PER_SE
      #if (nativeCU != cuNumOfFullConfig):
      #   print("invalid param: nativeCU should be %d" %(cuNumOfFullConfig))
      #   return -2
      if 0 != (balancedCU > nativeCU):
         print("invalid param: balancedCU %d is bigger than nativeCU" %(balancedCU))
         return -2
      if 0 != ((balancedCU // 2) % GC__NUM_SE):
         print("invalid config: config's balancedWGP %d should be multiple of SE number %d" %(balancedCU//2, GC__NUM_SE))
         return -2
      maxBadWGPPerSE = ((nativeCU // 2) - (balancedCU // 2)) // GC__NUM_SE
      maxBadWGPPerSA = (maxBadWGPPerSE + GC__NUM_SA_PER_SE - 1) // GC__NUM_SA_PER_SE
      w, h = GC__NUM_SA_PER_SE, GC__NUM_SE
      maskwgp = [[0 for x in range(w)] for y in range(h)]
      maskrb  = [[0 for x in range(w)] for y in range(h)]
      if (useDEBE == False):
        def onesh(seid, shid):
          v0=mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
          v1=mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
          v = v0 | v1
          maskwgp[seid][shid] = ((v >> 16) & 0xFFFF)
        each.sh(onesh)
        #def oneshrb(seid, shid):
        #  v0=mmr(mmCC_RB_BACKEND_DISABLE)
        #  v1=mmr(mmGC_USER_RB_BACKEND_DISABLE)
        #  v = v0 | v1
        #  maskrb[seid][shid] = ((v >> 16) & 0xFFFF)
        #each.sh(oneshrb)
        maskrb = CFG.getRenderBackendPerSA()
      else:
        line = ""
        if 'debe' in kwargs : line = kwargs['debe']
        else:
             try:
                 f = open('DEBE.txt', 'r')
             except IOError:
                 print("DEBE.txt not found")
             else:
                 with f:
                     line = f.readline()
                     line = line.rstrip()

        cnt = len(line)
        for seid in range(0, GC__NUM_SE):
            for shid in range(0, GC__NUM_SA_PER_SE):
                for wgpid in range(0, 8):
                    if ('1' == line[cnt - 1 - ((seid * 2 + shid) * 8 + wgpid)]):
                        maskwgp[seid][shid] |= 1 << wgpid
        _rbStartI = GC__NUM_SE * GC__NUM_SA_PER_SE * 8
        _MAXRBPERSA = 8
        if GFX_IP_MAJOR == 11 : _MAXRBPERSA = 4
        for seid in range(0, GC__NUM_SE):
            for shid in range(0, GC__NUM_SA_PER_SE):
                for rbid in range(0, 8):
                    if ('1' == line[cnt - 1 - _rbStartI - ((seid * 2 + shid) * _MAXRBPERSA + rbid)]):
                        maskrb[seid][shid] |= 1 << rbid
      if 'symsa' in kwargs and  kwargs['symsa']:
          def xory(x,y): return x|y
          saor = reduce(xory, [reduce(xory, se) for se in maskwgp])
          maskwgp = [[saor]*GC__NUM_SA_PER_SE]*GC__NUM_SE
      if 'symse' in kwargs and  kwargs['symse']:
          mask00 = [0]*GC__NUM_SA_PER_SE
          for se in maskwgp:
              for shid in range(GC__NUM_SA_PER_SE):
                  mask00[shid] |= se[shid]
          maskwgp = [mask00] * GC__NUM_SE
      totalActiveWGPs = 0
      for se in maskwgp:
          for sh in se:
              if (useDEBE != True):
                  totalActiveWGPs += min(GC__NUM_WGP_PER_SA, 16 - bitCount(sh))
              else:
                  sh = sh & ((1 << GC__NUM_WGP_PER_SA) - 1)
                  totalActiveWGPs += (GC__NUM_WGP_PER_SA - bitCount(sh))
      isFullConfigOK = 1
      isDownConfigOK = 1
      for se in maskwgp:
          if (useDEBE != True):
              badWGPNumInSA0 = GC__NUM_WGP_PER_SA - (16 - bitCount(se[0]))
              badWGPNumInSA1 = GC__NUM_WGP_PER_SA - (16 - bitCount(se[1]))
          else:
              badWGPNumInSA0 = bitCount(se[0] & ((1 << GC__NUM_WGP_PER_SA) - 1))
              badWGPNumInSA1 = bitCount(se[1] & ((1 << GC__NUM_WGP_PER_SA) - 1))
          if ((0 != badWGPNumInSA0) or (0 != badWGPNumInSA1)):
              isFullConfigOK = 0
          if (((badWGPNumInSA0 + badWGPNumInSA1) > maxBadWGPPerSE) or
               (badWGPNumInSA0 > maxBadWGPPerSA) or
               (badWGPNumInSA1 and (badWGPNumInSA1 > maxBadWGPPerSA))):
              isDownConfigOK = 0
      for se in maskrb:
          badRBNumInSA0 = bitCount(se[0])
          badRBNumInSA1 = bitCount(se[1])
          if ((0 != badRBNumInSA0) or (0 != badRBNumInSA1)):
              isFullConfigOK = 0
              isDownConfigOK = 0
      logging.log(25, " Total Active (WGP %d === CU %d)"%(totalActiveWGPs, totalActiveWGPs*2))
      if 1 == isFullConfigOK:
          logging.log(25, " FullConfig")
          return 0
      if 1 == isDownConfigOK:
          logging.log(25, " DownConfig")
          return 1
      return -1
  @staticmethod
  def checkSEHarvestable(nativeSE=4, downconfigSE=3, useDEBE=False, **kwargs):
      '''
      e.g. checkSEHarvestable(6, 5)    # check if 5SE (without any bad CU on the 5 SE) is avaliable
      e.g. checkSEHarvestable(6, 5, balancedCU=80)    # check if 5SE with 80CU  is avaliable
      e.g. checkSEHarvestable(6, 5, balancedCU=70)    # check if 5SE with 70CU  is avaliable
      e.g. checkSEHarvestable(6, 4, balancedCU=60)    # check if 4SE with 60CU  is avaliable
      return value:
         0      :  nativeSE count observed
         -1(255):  Insufficient SE/CU for downconfigSE/balancedCU config
         1      :  less than nativeSE/nativeCU count found, but down-config available to downconfigSE/balancedCU
      '''
      #if (nativeSE != GC__NUM_SE):
      #   print("invalid param: nativeSE %d should be %d" %(nativeSE, GC__NUM_SE))
      #   return -2
      if (downconfigSE > nativeSE):
         print("invalid param: downconfigSE %d is bigger than nativeSE %d" %(downconfigSE, nativeSE))
         return -2
      maxBadWGPPerSE = 0
      if 'balancedCU' in kwargs and kwargs['balancedCU'] > 0:
          balancedCU = kwargs['balancedCU']
          maxBadWGPPerSE =  GC__NUM_WGP_PER_SE - ((balancedCU // 2) // downconfigSE)
      w, h = GC__NUM_SA_PER_SE * 2, GC__NUM_SE
      mask0 = [[0 for x in range(w)] for y in range(h)]
      if (useDEBE != True):
        maskrb = CFG.getRenderBackendPerSA()
        def onesh(seid, shid):
          v0=mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
          v1=mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
          v = v0 | v1
          mask0[seid][shid] = ((v >> 16) & 0xFFFF)
          #v0=mmr(mmCC_RB_BACKEND_DISABLE)
          #v1=mmr(mmGC_USER_RB_BACKEND_DISABLE)
          #v = v0 | v1
          mask0[seid][shid + 2] = maskrb[seid][shid]
        each.sh(onesh)
      else:
        line = ""
        if 'debe' in kwargs : line = kwargs['debe']
        else:
             try:
                 f = open('DEBE.txt', 'r')
             except IOError:
                 print("DEBE.txt not found")
             else:
                 with f:
                     line = f.readline()
                     line = line.rstrip()

        cnt = len(line)
        _rbStartI = GC__NUM_SE * GC__NUM_SA_PER_SE * 8
        for seid in range(0, GC__NUM_SE):
            for shid in range(0, GC__NUM_SA_PER_SE):
                for wgpid in range(0, 8):
                    if ('1' == line[cnt - 1 - ((seid * 2 + shid) * 8 + wgpid)]):
                        mask0[seid][shid] |= 1 << wgpid
        _MAXRBPERSA = 8
        if GFX_IP_MAJOR == 11 : _MAXRBPERSA = 4
        for seid in range(0, GC__NUM_SE):
            for shid in range(0, GC__NUM_SA_PER_SE):
                for rbid in range(0, 8):
                    if ('1' == line[cnt - 1 - _rbStartI - ((seid * 2 + shid) * _MAXRBPERSA + rbid)]):
                        mask0[seid][shid + 2] |= 1 << rbid
      goodSE = 0
      for se in mask0:
        if (useDEBE != True):
            badWGPNumInSA0 = GC__NUM_WGP_PER_SA - (16 - bitCount(se[0]))
            badWGPNumInSA1 = GC__NUM_WGP_PER_SA - (16 - bitCount(se[1]))
        else:
            badWGPNumInSA0 = bitCount(se[0] & ((1 << GC__NUM_WGP_PER_SA) - 1))
            badWGPNumInSA1 = bitCount(se[1] & ((1 << GC__NUM_WGP_PER_SA) - 1))
        badRBNumInSA0 = bitCount(se[2])
        badRBNumInSA1 = bitCount(se[3])
        if 0 == maxBadWGPPerSE:
            if ((0 == badWGPNumInSA0) and (0 == badWGPNumInSA1) and (0 == badRBNumInSA0) and (0 == badRBNumInSA1)):
                goodSE = goodSE + 1
        else:
            if (( maxBadWGPPerSE >= (badWGPNumInSA0+ badWGPNumInSA1)) and (0 == badRBNumInSA0) and (0 == badRBNumInSA1)):
                goodSE = goodSE + 1
      if nativeSE == goodSE: return 0
      if downconfigSE == goodSE: return 1
      return -1
  @staticmethod
  def repairRB(*rbid):
      if GC__NUM_SE == 2:pass
      elif GC__NUM_SE == 4:pass
      else: pass
      rb_redundent = 0
      if len(rbid) == 0 :
          pass
      else:
          if len(rbid) == 1:
              rb_redundent = (1<<12) | (rbid[0] << 8)
          elif len(rbid) == 2:
              rb_redundent = (1<<12) | (rbid[0] << 8) | (1<<20) | (rbid[1] << 16)
          mmw(mmGC_USER_RB_REDUNDANCY, rb_redundent)
      mmrp(mmCC_RB_REDUNDANCY)
      mmrp(mmGC_USER_RB_REDUNDANCY)

  @staticmethod
  def devices(did = 0):
    if did == 0:
        b0 = db32I.cmd('cslist').split('\n')
        gpulist = [i for i in b0 if 'Disp' in i or 'VGA' in i or 'Accelerator' in i or 'Accelarator' in i]
        print ('\n'.join(gpulist))
        def getDevicesMap(devicelist):
             devicemap = {}
             for i in gpulist:
                 fields = i[1:].strip().split()
                 deviceid = fields[4]
                 csid = int(fields[0])
                 if deviceid in devicemap:
                     devicemap[deviceid].append(csid)
                 else:
                     devicemap[deviceid]= [csid]
             return devicemap
        def onedevice(fields): return [fields[0], fields[4]]
        devicelist = [onedevice(i[1:].strip().split())  for i in gpulist]
        return devicelist
    b0 = db32I.cmd('cslist').split('\n')
    b1 = [int(i[1:].strip().split(' ')[0]) for i in b0 if "%x"%did in i]
    b = tuple(b1)
    return b
  @staticmethod
  def getRenderBackendPerSA():
      w, h = GC__NUM_SA_PER_SE, GC__NUM_SE
      maskrb = [[0 for x in range(w)] for y in range(h)]
      def oneshrb(seid, shid):
        v0=mmr(mmCC_RB_BACKEND_DISABLE)
        v1=mmr(mmGC_USER_RB_BACKEND_DISABLE)
        v = v0 | v1
        maskrb[seid][shid] = ((v >> 16) & 0xFFFF)
      each.sh(oneshrb)
      return maskrb


'''---------------------------------------------------------'''
'''---------------------  GFX9 -----------------------------'''
'''---------------------------------------------------------'''
if GFX_IP_MAJOR == 9:
    class CFG(CFGCommon):
        class TCC:
            @staticmethod
            def info():
                mmrp(mmTCP_CHAN_STEER_0)
                mmrp(mmTCP_CHAN_STEER_1)
                mmrp(mmTCP_CHAN_STEER_2)
                mmrp(mmTCP_CHAN_STEER_3)
                mmrp(mmTCP_CHAN_STEER_4)
            @staticmethod
            def tcp_steer(*v):
                l = len(v)
                steer_reg = (mmTCP_CHAN_STEER_0, mmTCP_CHAN_STEER_1, mmTCP_CHAN_STEER_2, mmTCP_CHAN_STEER_3, mmTCP_CHAN_STEER_4)
                for i in range(5): mmw(steer_reg[i], v[i % l])
        @staticmethod
        def sanity():
          '''Make sure there is at least one active CU in each SE'''
          seids = []
          def onesh(seid, shid):
              v0 = mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
              v1 = mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
              v = (v0 | v1) & 0xFFFF0000
              if v == 0xFFFF0000:
                  #let's enable 1st available CU
                  _dmsk = 0x10000
                  while (_dmsk < 0x100000000) and (( v1 &  _dmsk ) != 0) : _dmsk = _dmsk << 1
                  v0 = v0 & (~_dmsk) & 0xFFFF0000
                  mmw(mmGC_USER_SHADER_ARRAY_CONFIG, v0)
              else: seids.append(seid)
          each.sh(onesh)

          if GFX_IP_MAJOR == 9:
              iaID = 0
              for seid in seids:
                 iaID = iaID | (1<<(seid // 2)) #active ia
              iaID = (~iaID) & 3  #inacitve ia

              vgtID = 0
              for seid in seids:vgtID = vgtID | (1 << seid)
              vgtID = (~vgtID) & 15 #inactive vgt

              vGC_USER_PRIM_CONFIG = (iaID << 16) | (vgtID << 24)
              mmw(mmGC_USER_PRIM_CONFIG, vGC_USER_PRIM_CONFIG)

        @staticmethod
        def enableOneCU(cuid=None):
            """      The 1st CU in a SE must be active
            """
            mask0 = [0,0,0,0]
            mask = [0xfffe0000, 0xfffe0000,0xfffe0000,0xfffe0000]
            if cuid is None:
                CFG.clear()
                return
            seid = cuid // 16
            if seid > 3: return showCUMask()
            #
            each.sh(lambda se,sh:mask0.append(mmr(mmCC_GC_SHADER_ARRAY_CONFIG)))
            # The disabled SE, must have one active CU
            def checksh(se,sh):
                i = se * GC__NUM_SH_PER_SE + sh
                if (mask0[0] & 0xFFFF0000) == 0 :
                    mask[i] = 0xfffe0000
                else:
                    _dmsk = 16
                    while ((_dmsk < 32) and ((( mask0[i] >> _dmsk ) & 1) == 1)) : _dmsk = _dmsk +1
                    _dmsk = 1 << _dmsk
                    _dmsk = (~ _dmsk) & 0xFFFF0000
                    mask[i] = _dmsk
            each.sh(checksh)
            #
            local_cuid = cuid % 16
            mask[seid] = mask[seid] & (~((1 << local_cuid) << 16)) &0xffff0000
            each.sh(mmGC_USER_SHADER_ARRAY_CONFIG, *tuple(mask))
            if GFX_IP_MAJOR == 9:
                iaID = seid // 2     #active ia
                iaID = 1 << iaID
                iaID = (~iaID) & 3  #inacitve ia
                vgtID = seid
                vgtID = 1 << seid
                vgtID = (~vgtID) & 15 #inactive vgt
                vGC_USER_PRIM_CONFIG = (iaID << 16) | (vgtID << 24)
                mmw(mmGC_USER_PRIM_CONFIG, vGC_USER_PRIM_CONFIG)
        @staticmethod
        def enableSE(*seids, **kwargs):
          ''' enable the *seids,  and disable all the other SEs
              enableSE(0,2) Enable SE0 and SE2
              enableSE(0) Enable SE0
              enableSE() Enable All SE
          '''
          user_mode = True
          if 'fuse_mode' in kwargs : user_mode = not kwargs['fuse_mode']
          if user_mode :
              REG_SHADER_ARRAY = mmGC_USER_SHADER_ARRAY_CONFIG
              REG_PRIM_CONFIG = mmGC_USER_PRIM_CONFIG
          else:
              REG_SHADER_ARRAY = mmCC_GC_SHADER_ARRAY_CONFIG
              REG_PRIM_CONFIG = mmCC_GC_PRIM_CONFIG
          mask0 = [0]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          if GFX_IP_MAJOR == 9:
              mask = [0xfffe0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          else:
              mask = [0xffff0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          if len(seids) == 0:
              CFG.clear()
              return
          #
          for i in RANGE_SE:
              for j in RANGE_SA:
                mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                mask0[i*GC__NUM_SA_PER_SE+j] = mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          # The disabled SE, must have one active CU
          if GFX_IP_MAJOR == 9:
            for i in range(0, GC__NUM_SE*GC__NUM_SA_PER_SE):
              if (mask[0] & 0xFFFF0000) == 0 :
                  mask[i] = 0xfffe0000
              else:
                  _dmsk = 16
                  while ((_dmsk < 32) and ((( mask0[i] >> _dmsk ) & 1) == 1)) : _dmsk = _dmsk +1
                  _dmsk = 1 << _dmsk
                  _dmsk = (~ _dmsk) & 0xFFFF0000
                  mask[i] = _dmsk
          #Enable CUs in seids
          for seid in seids:
              for said in RANGE_SA:
                  mask[seid*GC__NUM_SA_PER_SE+said] = 0
          for i in RANGE_SE:
              for j in RANGE_SA:
                  mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                  mmw(REG_SHADER_ARRAY, mask[i*GC__NUM_SA_PER_SE+j])
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)


          if GFX_IP_MAJOR == 9:
              iaID = 0
              for seid in seids:
                 iaID = iaID | (1<<(seid // 2)) #active ia
              iaID = (~iaID) & 3  #inacitve ia

              vgtID = 0
              for seid in seids:vgtID = vgtID | (1 << seid)
              vgtID = (~vgtID) & 15 #inactive vgt

              vGC_USER_PRIM_CONFIG = (iaID << 16) | (vgtID << 24)
              mmw(REG_PRIM_CONFIG, vGC_USER_PRIM_CONFIG)
          showCUMask()

        @staticmethod
        def enableSA(*saids):
          ''' Enable *saids and disable all the other SAs
              enableSA(0,2) Enable SE0SA0 and SE1SA0
              enableSA(0) Enable SE0SA0
              enableSA() Enable All SA
          '''
          mask0 = [0]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          if GFX_IP_MAJOR == 9:
              mask = [0xfffe0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          else:
              mask = [0xffff0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          if len(saids) == 0:
              CFG.clear()
              return
          #
          for i in RANGE_SE:
              for j in RANGE_SA:
                mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                mask0[i*GC__NUM_SA_PER_SE+j] = mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          # The disabled SE, must have one active CU
          if GFX_IP_MAJOR == 9:
            for i in range(0, GC__NUM_SE*GC__NUM_SA_PER_SE):
              if (mask[0] & 0xFFFF0000) == 0 :
                  mask[i] = 0xfffe0000
              else:
                  _dmsk = 16
                  while ((_dmsk < 32) and ((( mask0[i] >> _dmsk ) & 1) == 1)) : _dmsk = _dmsk +1
                  _dmsk = 1 << _dmsk
                  _dmsk = (~ _dmsk) & 0xFFFF0000
                  mask[i] = _dmsk
          #Enable CUs in seids
          for said in saids: mask[said] = 0
          for i in RANGE_SE:
              for j in RANGE_SA:
                  mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                  mmw(mmGC_USER_SHADER_ARRAY_CONFIG, mask[i*GC__NUM_SA_PER_SE+j])
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)

          if GFX_IP_MAJOR == 9:
              seids = [said // GC__NUM_SA_PER_SE  for said in saids]
              iaID = 0
              for seid in seids:
                 iaID = iaID | (1<<(seid // 2)) #active ia
              iaID = (~iaID) & 3  #inacitve ia

              vgtID = 0
              for seid in seids:vgtID = vgtID | (1 << seid)
              vgtID = (~vgtID) & 15 #inactive vgt

              vGC_USER_PRIM_CONFIG = (iaID << 16) | (vgtID << 24)
              mmw(mmGC_USER_PRIM_CONFIG, vGC_USER_PRIM_CONFIG)
          showCUMask()
        @staticmethod
        def debeGfx9(readable = 0):
            cus = [0]*GC__NUM_TOTAL_SH
            rbs = [0]*GC__NUM_TOTAL_SH
            sec = Debe()
            for i in range(0, GC__NUM_SE):
              mmw(mmGRBM_GFX_INDEX, i<<16)
              v0 = mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
              v1 = mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
              v = (v0 | v1) & 0xFFFF0000
              cus[i] = v >> 16
              v0 = mmr(mmCC_RB_BACKEND_DISABLE)
              v1 = mmr(mmGC_USER_RB_BACKEND_DISABLE)
              v = (v0 | v1) & 0xFFFF0000
              rbs[i] = v >> 16
            mmw(mmGRBM_GFX_INDEX, 0xe0000000);
            #ACP
            #VCE
            #UVD
            __cc_uvd_harvesting = regr32(0x1fb1c) #mmr(mmCC_UVD_HARVESTING)  # bit0 is WRITE_DIS; 1 UVD_DISABLE
            #DCE
            __cc_dc_pipe_dis = regr32(0xd680)#mmr(mmCC_DC_PIPE_DIS)        # bit0 is WRITE_DIS; 6:1 DC_PIPE_DIS; 21:16 DC_UNDERLAY_PIPE_DIS
            #RB
            __cc_rb_redundancy  = mmr(mmCC_RB_REDUNDANCY)   # bit0 is WRITE_DIS;
            __cc_rb_redundancy_2bit = ((__cc_rb_redundancy >> 12) & 1)| ((__cc_rb_redundancy >> 19) & 0x2)
            if (__cc_rb_redundancy >> 12) & 1 :
                badrb = (__cc_rb_redundancy >> 8 ) & 0xf
                rbs[badrb // 4] |= 1 << (badrb &3)
            if (__cc_rb_redundancy >> 20) & 1 :
                badrb = (__cc_rb_redundancy >> 16 ) & 0xf
                rbs[badrb // 4 + 2] |= 1 << (badrb &3)
            #TCC
            __cgts_tcc_disable  = mmr(mmCGTS_TCC_DISABLE)   # bit0 is WRITE_DIS; 31:16 TCC_DISABLE
            #PRIM
            __cc_GC_PRIM_CONFIG = mmr(mmCC_GC_PRIM_CONFIG)    # bit0 is WRITE_DIS; 17:16 INACTIVE_IA  27:24 INACTIVE_VGT_PA
            __gc_user_prim_config = mmr(mmGC_USER_PRIM_CONFIG)

            sec["UVD"] = __cc_uvd_harvesting >> 1
            sec["DCE"] = __cc_dc_pipe_dis >> 1
            if sec.has_key("SPARERB"): sec["SPARERB"] = __cc_rb_redundancy_2bit
            if sec.has_key("SE3SH0RB"): sec["SE3SH0RB"] = rbs[3]
            if sec.has_key("SE2SH0RB"): sec["SE2SH0RB"] = rbs[2]
            if sec.has_key("SE1SH0RB"): sec["SE1SH0RB"] = rbs[1]
            if sec.has_key("SE0SH0RB"): sec["SE0SH0RB"] = rbs[0]
            sec["TCC"] = __cgts_tcc_disable >> 16
            if GC__NUM_CORE == 2:
                sec["SE7SH0CU"] = cus[7]
                sec["SE6SH0CU"] = cus[6]
                sec["SE5SH0CU"] = cus[5]
                sec["SE4SH0CU"] = cus[4]
            sec["SE3SH0CU"] = cus[3]
            sec["SE2SH0CU"] = cus[2]
            sec["SE1SH0CU"] = cus[1]
            sec["SE0SH0CU"] = cus[0]
            debestr = sec.readable() if readable > 0 else str(sec)
            print(debestr)
            with open("DEBE.txt", "w") as text_file:
               text_file.write(str(sec))
            return debestr
        @staticmethod
        def debeMI300(readable = 0):
            CPX_AVAILABILITY = mmr(0x3a04//4) >> 10
            sec = Debe()
            for xcc in range(8):
                cus = [0]*GC__NUM_TOTAL_SH
                if CPX_AVAILABILITY & ( 1 << xcc) == 0 : continue
                mydb = Cdb32(xccid = xcc)
                __cgts_tcc_disable  = mydb.mmr(mmCGTS_TCC_DISABLE)   # bit0 is WRITE_DIS; 31:16 TCC_DISABLE
                __cgts_tcc_disable  = __cgts_tcc_disable | mydb.mmr(mmCGTS_USER_TCC_DISABLE)
                __cgts_tcc_disable = __cgts_tcc_disable >> 16
                for i in range(0, GC__NUM_SE):
                    mydb.mmw(mmGRBM_GFX_INDEX, i<<16)
                    v0 = mydb.mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
                    v1 = mydb.mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
                    v = (v0 | v1) & 0xFFFF0000
                    cus[i] = v >> 16
                mydb.mmw(mmGRBM_GFX_INDEX, 0xE0000000)
                sec["XCC%dTCC"     %xcc] = __cgts_tcc_disable
                sec["XCC%dSE3SH0CU"%xcc] = cus[3]
                sec["XCC%dSE2SH0CU"%xcc] = cus[2]
                sec["XCC%dSE1SH0CU"%xcc] = cus[1]
                sec["XCC%dSE0SH0CU"%xcc] = cus[0]
            debestr = sec.readable() if readable > 0 else str(sec)
            print(debestr)
            with open("DEBE.txt", "w") as text_file:
               text_file.write(str(sec))
            return debestr
        @staticmethod
        def debe(readable = 0):
           if GPU__GC__VARIANT == mi300: return CFG.debeMI300(readable)
           return CFG.debeGfx9(readable)
        @staticmethod
        def flushcache():
           mmw(mmTCC_WBINVL2, 1)

    if GPU__GC__VARIANT == mi300:
      class RM:
       #RSMU_GC:RSMU_MEM_POWER_CTRL_GC
       myregs = [0x36002018, 0x38002018,
               SmnAid(1) + 0x36002018, SmnAid(1) + 0x38002018,
               SmnAid(2) + 0x36002018, SmnAid(2) + 0x38002018,
               SmnAid(3) + 0x36002018, SmnAid(3) + 0x38002018]
       @staticmethod
       def read():
           for xcc in range(0,8): print("XCC%d:%x"%(xcc, smn.regr32(RM.myregs[xcc])))
       @staticmethod
       def info():RM.read()

       @staticmethod
       def set(mux4=0, mux2=0, **kw):
           if not 'gc' in kw:
               print('please run with RM.set(gc=values)')
               return
           myrm = kw['gc']
           for xcc in range(0,8): smn.regw32(RM.myregs[xcc],myrm)
    else:
      class RM:
       @staticmethod
       def read():
           pass
       @staticmethod
       def set(mux4, mux2, **kw):
           pass
elif GFX_IP_MAJOR == 10:
    '''---------------------------------------------------------'''
    '''---------------------  GFX10 ----------------------------'''
    '''---------------------------------------------------------'''

    class RM:
       @staticmethod
       def read():
         v = smn.mmr(mmRSMU_MEM_POWER_CTRL_GC)
         mux2 = (v >> 13) & 0x3f
         mux4 = (v >> 20) & 0x3f
         logger.log(25, "mmRSMU_MEM_POWER_CTRL_CG: 0x%x"%v)
         logger.log(25, "MUX2_RME                : 0x%x"%mux2);
         logger.log(25, "MUX4_RME                : 0x%x"%mux4);
         return UserList([mux2, mux4])
       @staticmethod
       def set(mux4, mux2, **kw):
         if 'mux4' in kw: mux4 = kw['mux4']
         if 'mux2' in kw: mux2 = kw['mux2']
         v = smn.mmr(mmRSMU_MEM_POWER_CTRL_GC) & 0xfc000fff
         newv = v | (1 << 12) | ((mux2 & 0x3f) << 13) | (1 << 19) | ((mux4 & 0x3f) << 20)
         smn.mmw(mmRSMU_MEM_POWER_CTRL_GC, newv)
         cv = mmr(mmRLC_GFX_RM_CNTL) & 0xfffffffe
         cv = cv | 0x1
         mmw(mmRLC_GFX_RM_CNTL, cv)
         time.sleep(0.05)
         mmw(mmRLC_GFX_RM_CNTL, cv & 0xfffffffe)

    class CFG(CFGCommon):
        @staticmethod
        def sanity():
          if Settings.mMinorVersion == 1: return
          def onesh(seid, shid):
            v0=mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
            v1=mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
            return (v0 | v1) & 0xffff0000
          r = each.sh(onesh)
          saids_disable = [k for k,v in enumerate(r) if v == 0xffff0000]
          seids_disable = [ i for i in RANGE_SE if 2*i in saids_disable and 2*i+1 in saids_disable]
          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for said in saids_disable: sa_disable = sa_disable | (1<<said)
              sa_disable = sa_disable << 8
              mmw(mmGC_USER_SA_UNIT_DISABLE, sa_disable)
              mmrp(mmGC_USER_SA_UNIT_DISABLE)
          each.sa(mmGC_USER_RB_BACKEND_DISABLE, 0)
          for sa_id in saids_disable:
                  se_id = sa_id // 2
                  mmw(mmGRBM_GFX_INDEX, (se_id << 16) | ((sa_id & 1) << 8))
                  mmw(mmGC_USER_RB_BACKEND_DISABLE, 0xff0000)
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          if len(seids_disable) > 0:
              pa_disable = 0
              for seid in seids_disable:
                  #for paid in ragne(GC__NUM_PA_PER_SE):
                  for paid in range(2):
                      pa_disable = pa_disable | (1<<(seid * 2 + paid))
              pa_disable = pa_disable << 4
              mmw(mmGC_USER_PRIM_CONFIG, pa_disable)
              mmrp(mmGC_USER_PRIM_CONFIG)
          #GCUTCL2_HARVEST_BYPASS_GROUPS
          if var_exist('mmGCUTCL2_HARVEST_BYPASS_GROUPS'):
              utcl2_bypass = 0
              for said in saids_disable:
                  utcl2_bypass = utcl2_bypass | (1 <<(said))
                  mmw(mmGCUTCL2_HARVEST_BYPASS_GROUPS, utcl2_bypass)

          pass
        @staticmethod
        def debe(readable = 0, gfxver = 3):
           return CFG.debeGfx10(readable, gfxver)
        @staticmethod
        def enableOneWGP(cuid=None):CFG.enableCUExt(cuid, nosanity=1)
        @staticmethod
        def enableSE(*seids):
          ''' enable the *seids,  and disable all the other SEs
              enableSE(0,2) Enable SE0 and SE2
              enableSE(0) Enable SE0
              enableSE() Enable All SE
          '''
          CFG.clear()
          mask = [0xffff0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          seids_disable = [ i for i in RANGE_SE if i not in seids]
          #print(seids_disable)
          if len(seids) == 0:
              CFG.clear()
              showCUMask()
              return
          #
          #Enable CUs in seids
          for seid in seids:
              for said in RANGE_SA:
                  mask[seid*GC__NUM_SA_PER_SE+said] = 0
          for i in RANGE_SE:
              for j in RANGE_SA:
                  mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                  mmw(mmGC_USER_SHADER_ARRAY_CONFIG, mask[i*GC__NUM_SA_PER_SE+j])
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)

          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for seid in seids_disable: sa_disable = sa_disable | (1<<(seid*2)) | (1<<(seid*2+1))
              sa_disable = sa_disable << 8
              mmw(mmGC_USER_SA_UNIT_DISABLE, sa_disable)
              #print("sa %X" % sa_disable)

              pa_disable = 0
              for seid in seids_disable:
                  #for paid in ragne(GC__NUM_PA_PER_SE):
                  for paid in range(2):
                      pa_disable = pa_disable | (1<<(seid * 2 + paid))
              pa_disable = pa_disable << 4
              mmw(mmGC_USER_PRIM_CONFIG, pa_disable)
              mmrp(mmGC_USER_PRIM_CONFIG)
          #Disable RB
          for seid in seids_disable:
              for sa_id in RANGE_SA:
                  mmw(mmGRBM_GFX_INDEX, (seid << 16) | (sa_id << 8))
                  mmw(mmGC_USER_RB_BACKEND_DISABLE, 0xff0000)
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          #GCUTCL2_HARVEST_BYPASS_GROUPS
          if var_exist('mmGCUTCL2_HARVEST_BYPASS_GROUPS'):
              utcl2_bypass = 0
              for seid in seids_disable:
                  utcl2_bypass = utcl2_bypass | (3 <<(seid*2))
                  mmw(mmGCUTCL2_HARVEST_BYPASS_GROUPS, utcl2_bypass)
              #print("L2 %X"%utcl2_bypass)

          showCUMask()
          softreset1()

        @staticmethod
        def enableSA(*saids):
          ''' Enable *saids and disable all the other SAs
              enableSA(0,2) Enable SE0SA0 and SE1SA0
              enableSA(0) Enable SE0SA0
              enableSA() Enable All SA
          '''
          mask = [0xffff0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          saids_disable = [ i for i in range(GC__NUM_SE*GC__NUM_SA_PER_SE) if i not in saids]
          if len(saids) == 0:
              CFG.clear()
              showCUMask()
              return
          #Enable CUs in seids
          for said in saids: mask[said] = 0
          for i in RANGE_SE:
              for j in RANGE_SA:
                  mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                  mmw(mmGC_USER_SHADER_ARRAY_CONFIG, mask[i*GC__NUM_SA_PER_SE+j])
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for said in saids_disable: sa_disable = sa_disable | (1<<said)
              sa_disable = sa_disable << 8
              mmw(mmGC_USER_SA_UNIT_DISABLE, sa_disable)

          CFG.sanity()
          showCUMask()
          softreset1()
        @staticmethod
        def debeGfx10(readable=False, gfxversion=3):
          '''
             print debe string according to current status
          '''
          #RB repair
          #TCC
          sec = Debe()
          #if gfxversion == 0: gfxversion = Settings.mMinorVersion
          gfxversion  = 3 if sec.has_key('PA') else 1
          __cgts_tcc_disable0  = mmr(mmCGTS_TCC_DISABLE)   # bit0 is WRITE_DIS; 31:16 TCC_DISABLE 15:8 HI
          __cgts_tcc_disable = (__cgts_tcc_disable0 >> 16)  | ((__cgts_tcc_disable0 & 0xff00)<< 8)
          rbs = [0,0,0,0,0,0,0,0]
          wgps = [0,0,0,0,0,0,0,0]
          def onesa(seid, said):
            v0 = mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
            v1 = mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
            v = (v0 | v1) & 0xFFFF0000
            wgps[seid*2+said] = v >> 16
            v0 = mmr(mmCC_RB_BACKEND_DISABLE)
            v1 = mmr(mmGC_USER_RB_BACKEND_DISABLE)
            v = (v0 | v1) & 0xFFFF0000
            rbs[seid*2+said] = v >> 16
          each.sa(onesa)

          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = (mmr(mmGC_USER_SA_UNIT_DISABLE) | mmr(mmCC_GC_SA_UNIT_DISABLE)) >> 8
              for said in range(0, GC__NUM_SE*GC__NUM_SA_PER_SE):
                  if((sa_disable >> said) & 1) == 1 :
                      wgps[said] = 0xffff
                      rbs [said] = (1 << GC__NUM_RB_PER_SA)-1

          if gfxversion <= 1:
              pass
          elif sec.has_key('PA'):
              prim_config = mmr(mmCC_GC_PRIM_CONFIG) | mmr(mmGC_USER_PRIM_CONFIG)
              prim_config_mask = 0xFF
              if (GC__NUM_PA_PER_SE == 1):
                  prim_config_mask = 0x55
              prim_config = (prim_config >> 4) & prim_config_mask
              if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
                  sa_unit = mmr(mmCC_GC_SA_UNIT_DISABLE) | mmr(mmGC_USER_SA_UNIT_DISABLE)
                  sa_unit = (sa_unit >> 8) & 0xff
              else: sa_unit = 0xff
              rb_redundancy0 =  mmr(mmCC_RB_REDUNDANCY) | mmr(mmGC_USER_RB_REDUNDANCY)
              rb_redundancy  = ((rb_redundancy0 >> 8) & 0x1f) | ((rb_redundancy0 >> 11) & 0x3E0)
              sec["PA"] = prim_config
              sec["SA_UNIT"] = sa_unit
              sec["RBr3REPAIR"] = (rb_redundancy >> 15) & 0x1f
              sec["RBr2REPAIR"] = (rb_redundancy >> 10) & 0x1f
              sec["RBr1REPAIR"] = (rb_redundancy >> 5) & 0x1f
              sec["RBr0REPAIR"] = (rb_redundancy >> 0)& 0x1f

          sec["GL2C"] = __cgts_tcc_disable

          sec["SE3SA1RB"] =rbs[7]
          sec["SE3SA0RB"] =rbs[6]
          sec["SE2SA1RB"] =rbs[5]
          sec["SE2SA0RB"] =rbs[4]
          sec["SE1SA1RB"] =rbs[3]
          sec["SE1SA0RB"] =rbs[2]
          sec["SE0SA1RB"] =rbs[1]
          sec["SE0SA0RB"] =rbs[0]
          wgp_mask = (1 << GC__NUM_WGP_PER_SA) - 1
          sec["SE3SA1WGP"] = (wgps[7] & wgp_mask)
          sec["SE3SA0WGP"] = (wgps[6] & wgp_mask)
          sec["SE2SA1WGP"] = (wgps[5] & wgp_mask)
          sec["SE2SA0WGP"] = (wgps[4] & wgp_mask)
          sec["SE1SA1WGP"] = (wgps[3] & wgp_mask)
          sec["SE1SA0WGP"] = (wgps[2] & wgp_mask)
          sec["SE0SA1WGP"] = (wgps[1] & wgp_mask)
          sec["SE0SA0WGP"] = (wgps[0] & wgp_mask)
          debestr = sec.readable() if readable > 0 else str(sec)
          print(debestr)
          with open("DEBE.txt", "w") as text_file:
             text_file.write(str(sec))
          return debestr
        @staticmethod
        def enableRBCrest(sa_select=0xff, rbid=0xff):
            ''' Set PA:PA_SC_TILE_STEERING_CREST_OVERRIDE
                enableRBCrest() set the reg to 0 which is the defualt value
                enableRBCrest(sa_select, rbid) route all the traffic to RB(sa_select, rbid)
            '''
            #rbids=[0x1, 0x21, 0x41, 0x61, 0x101, 0x121, 0x141, 0x161, 0x201, 0x221, 0x241, 0x261, 0x301, 0x321, 0x341, 0x361] #nv21
            #regvalue=rbids[rbid] if rbid < GC__NUM_RB_PER_SA * GC__NUM_SA_PER_SE * GC__NUM_SE else 0
            regvalue = 0
            if sa_select < GC__NUM_SE * GC__NUM_SA_PER_SE  and rbid < GC__NUM_RB_PER_SA * GC__NUM_SA_PER_SE:
                regvalue = 1 | (sa_select << 8) | (rbid << 5)
            mmw(mmPA_SC_TILE_STEERING_CREST_OVERRIDE, regvalue)
            mmrp(mmPA_SC_TILE_STEERING_CREST_OVERRIDE)
        @staticmethod
        def enableOneRB(sa_select=0xff, rbid=0xff):CFG.enableRBCrest(sa_select,rbid)

        @staticmethod
        def flushcache():
           mmw(mmGL2C_WBINVL2, 1)

elif GFX_IP_MAJOR == 11:
    '''---------------------------------------------------------'''
    '''---------------------  GFX11 ----------------------------'''
    '''---------------------------------------------------------'''
    class RM:
       @staticmethod
       def read():
         mmRSMU_MEM_POWER_CTRL_1_GC = 0x900b018 // 4
         v = smn.mmr(mmRSMU_MEM_POWER_CTRL_1_GC)
         mux2 = (v >> 17) & 0x3f
         #mux4 = (v >> 20) & 0x3f
         logger.log(25, "mmRSMU_MEM_POWER_CTRL_1_GC: 0x%x"%v)
         logger.log(25, "MUX2_RME                : 0x%x"%mux2);
         return UserList([mux2])
       @staticmethod
       def set(mux4, mux2, **kw):
         mmRSMU_MEM_POWER_CTRL_1_GC = 0x900b018 // 4
         if 'mux4' in kw: mux4 = kw['mux4']
         if 'mux2' in kw: mux2 = kw['mux2']
         v = smn.mmr(mmRSMU_MEM_POWER_CTRL_GC) & 0xfc000fff
         newv = v | (1 << 16) | ((mux2 & 0x3f) << 17)
         smn.mmw(mmRSMU_MEM_POWER_CTRL_GC, newv)
         cv = mmr(mmRLC_GFX_RM_CNTL) & 0xfffffffe
         cv = cv | 0x1
         mmw(mmRLC_GFX_RM_CNTL, cv)
         time.sleep(0.05)
         mmw(mmRLC_GFX_RM_CNTL, cv & 0xfffffffe)

    class CFG(CFGCommon):
        class GL2C:
             @staticmethod
             def info():
                 mmrp(mmGB_ADDR_CONFIG)
                 mmrp(mmCGTS_TCC_DISABLE)
                 mmrp(mmCGTS_USER_TCC_DISABLE)
                 mmrp(mmCGTS_TCC_DISABLE)
                 mmrp(mmGL2_PIPE_STEER_0)
                 mmrp(mmGL2_PIPE_STEER_1)
                 mmrp(mmGL2_PIPE_STEER_2)
                 mmrp(mmGL2_PIPE_STEER_3)
                 mmrp(mmGL1_PIPE_STEER)
             @staticmethod
             def steer(*v):
                 l = len(v)
                 i = 0
                 mmw(mmGL2_PIPE_STEER_0, v[i % l])
                 i = i + 1
                 mmw(mmGL2_PIPE_STEER_1, v[i % l])
                 i = i + 1
                 mmw(mmGL2_PIPE_STEER_2, v[i % l])
                 i = i + 1
                 mmw(mmGL2_PIPE_STEER_3, v[i % l])
                 i = i + 1
        @staticmethod
        def sanity():
          def onesh(seid, shid):
            v0=mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
            v1=mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
            return (v0 | v1) & 0xffff0000
          r = each.sh(onesh)
          saids_disable = [k for k,v in enumerate(r) if v == 0xffff0000]
          seids_disable = [ i for i in RANGE_SE if 2*i in saids_disable and 2*i+1 in saids_disable]
          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for said in saids_disable: sa_disable = sa_disable | (1<<said)
              sa_disable = sa_disable << 8
              mmw(mmGC_USER_SA_UNIT_DISABLE, sa_disable)
              mmrp(mmGC_USER_SA_UNIT_DISABLE)
          each.sa(mmGC_USER_RB_BACKEND_DISABLE, 0)
          for sa_id in saids_disable:
                  se_id = sa_id // 2
                  mmw(mmGRBM_GFX_INDEX, (se_id << 16) | ((sa_id & 1) << 8))
                  mmw(mmGC_USER_RB_BACKEND_DISABLE, 0xff0000)
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          if len(seids_disable) > 0:
              pa_disable = 0
              for seid in seids_disable:
                  #for paid in ragne(GC__NUM_PA_PER_SE):
                  for paid in range(2):
                      pa_disable = pa_disable | (1<<(seid * 2 + paid))
              pa_disable = pa_disable << 4
              mmw(mmGC_USER_PRIM_CONFIG, pa_disable)
              mmrp(mmGC_USER_PRIM_CONFIG)
          #GCUTCL2_HARVEST_BYPASS_GROUPS
          if var_exist('mmGCUTCL2_HARVEST_BYPASS_GROUPS'):
              utcl2_bypass = 0
              for said in saids_disable:
                  utcl2_bypass = utcl2_bypass | (1 <<(said))
                  mmw(mmGCUTCL2_HARVEST_BYPASS_GROUPS, utcl2_bypass)

          pass
        @staticmethod
        def debe(readable = 0, gfxver = 1):
           if GFX_IP_MAJOR >= 12:
               CFG.debeGfx12(readable, gfxver)
           if GFX_IP_MAJOR == 11:
               CFG.debeGfx11(readable, gfxver)
        @staticmethod
        def enableOneWGP(cuid=None):CFG.enableCUExt(cuid, nosanity=1)
        @staticmethod
        def enableSE(*seids, **kwargs):
          ''' enable the *seids,  and disable all the other SEs
              enableSE(0,2) Enable SE0 and SE2
              enableSE(0) Enable SE0
              enableSE() Enable All SE
          '''
          CFG.clear()
          WGP0WA = False # WGP0 in each SA must be enabled
          if WGP0WA:
              mask = [0xfffe0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          else:
              mask = [0xffff0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          seids_disable = [ i for i in RANGE_SE if i not in seids]
          #print(seids_disable)
          if len(seids) == 0:
              CFG.clear()
              showCUMask()
              return
          user_mode = True
          if 'fuse_mode' in kwargs : user_mode = not kwargs['fuse_mode']
          if user_mode :
              REG_SHADER_ARRAY = mmGC_USER_SHADER_ARRAY_CONFIG
              REG_RB_DISABLE = mmGC_USER_RB_BACKEND_DISABLE
              REG_SA_UNIT_DISABLE = mmGC_USER_SA_UNIT_DISABLE
              REG_PRIM_CONFIG = mmGC_USER_PRIM_CONFIG if var_exist("mmGC_USER_PRIM_CONFIG") else 0
          else:
              REG_SHADER_ARRAY = mmCC_GC_SHADER_ARRAY_CONFIG
              REG_RB_DISABLE = mmCC_RB_BACKEND_DISABLE
              REG_SA_UNIT_DISABLE = mmCC_GC_SA_UNIT_DISABLE
              REG_PRIM_CONFIG = mmCC_GC_PRIM_CONFIG if var_exist("mmCC_GC_PRIM_CONFIG") else 0
          #
          #Enable CUs in seids
          for seid in seids:
              for said in RANGE_SA:
                  mask[seid*GC__NUM_SA_PER_SE+said] = 0

          if var_exist('mmGC_USER_PRIM_CONFIG'):
              pa_disable = 0xfaaa
              print('dis se', seids_disable)
              for seid in seids_disable:
                  #for paid in ragne(GC__NUM_PA_PER_SE):
                  for paid in range(2):
                      pa_disable = pa_disable | (1<<(seid * 2 + paid))
              pa_disable = pa_disable << 4
              mmw(REG_PRIM_CONFIG, pa_disable)

          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for seid in seids_disable: sa_disable = sa_disable | (1<<(seid*2)) | (1<<(seid*2+1))
              sa_disable = sa_disable << 8
              mmw(REG_SA_UNIT_DISABLE, sa_disable)
              #print("sa %X" % sa_disable)
          #Disable RB
          if var_exist('mmCC_RB_BACKEND_DISABLE'):
              if GFX_IP_MAJOR >= 12:
                  rb_masks = [0] * GC__NUM_SE
                  for seid in seids_disable: rb_masks[seid] = 0xF0
                  each.se(REG_RB_DISABLE, rb_masks)
              elif GFX_IP_MAJOR >= 11:
                  vGC_USER_RB_BACKEND_DISABLE = 0
                  for seid in seids_disable:
                          vGC_USER_RB_BACKEND_DISABLE = vGC_USER_RB_BACKEND_DISABLE | (0xf << (4 + seid * 4) )
                  mmw(REG_RB_DISABLE, vGC_USER_RB_BACKEND_DISABLE)

          if var_exist('mmGC_USER_SHADER_ARRAY_CONFIG'):
               for i in RANGE_SE:
                   for j in RANGE_SA:
                       mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                       mmw(REG_SHADER_ARRAY, mask[i*GC__NUM_SA_PER_SE+j])
               mmw(mmGRBM_GFX_INDEX, 0xe0000000)


          #GCUTCL2_HARVEST_BYPASS_GROUPS
          if var_exist('mmGCUTCL2_HARVEST_BYPASS_GROUPS'):
              utcl2_bypass = 0
              for seid in seids_disable:
                  utcl2_bypass = utcl2_bypass | (3 <<(seid*2))
                  #mmw(mmGCUTCL2_HARVEST_BYPASS_GROUPS, utcl2_bypass)
              #print("L2 %X"%utcl2_bypass)
          if var_exist('mmGRBM_SE_REMAP_CNTL'):
              vGRBM_SE_REMAP_CNTL = mmr(mmGRBM_SE_REMAP_CNTL)
              vGRBM_SE_REMAP_CNTL = 0xeca86420
              for seid in seids_disable:
                  vGRBM_SE_REMAP_CNTL = vGRBM_SE_REMAP_CNTL & (~(0xf << (seid *4)))
                  vGRBM_SE_REMAP_CNTL = vGRBM_SE_REMAP_CNTL | (1 << (seid * 4))
                  vGRBM_SE_REMAP_CNTL = vGRBM_SE_REMAP_CNTL | (seids[0] << (seid * 4 + 1))
              mmw(mmGRBM_SE_REMAP_CNTL, vGRBM_SE_REMAP_CNTL)

          showCUMask()
          do_reset = True
          if 'noreset' in kwargs : do_reset = not kwargs['noreset']
          if do_reset: softreset1()

        @staticmethod
        def enableSA(*saids):
          ''' Enable *saids and disable all the other SAs
              enableSA(0,2) Enable SE0SA0 and SE1SA0
              enableSA(0) Enable SE0SA0
              enableSA() Enable All SA
          '''
          mask = [0xffff0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          saids_disable = [ i for i in range(GC__NUM_SE*GC__NUM_SA_PER_SE) if i not in saids]
          if len(saids) == 0:
              CFG.clear()
              showCUMask()
              return
          #Enable CUs in seids
          for said in saids: mask[said] = 0
          for i in RANGE_SE:
              for j in RANGE_SA:
                  mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                  mmw(mmGC_USER_SHADER_ARRAY_CONFIG, mask[i*GC__NUM_SA_PER_SE+j])
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for said in saids_disable: sa_disable = sa_disable | (1<<said)
              sa_disable = sa_disable << 8
              mmw(mmGC_USER_SA_UNIT_DISABLE, sa_disable)

          CFG.sanity()
          showCUMask()
          softreset1()
        @staticmethod
        def debeGfx12(readable=False, gfxversion=1):
            print("not implemented")
        @staticmethod
        def debeGfx11(readable=False, gfxversion=1):
          '''
             print debe string according to current status
          '''
          #RB repair
          #TCC
          if gfxversion == 0: gfxversion = Settings.mMinorVersion
          __cgts_tcc_disable0  = mmr(mmCGTS_TCC_DISABLE)   # bit0 is WRITE_DIS; 31:16 TCC_DISABLE 15:8 HI
          __cgts_tcc_disable = (__cgts_tcc_disable0 >> 16)  | ((__cgts_tcc_disable0 & 0xff00)<< 8)
          wgps = [0] *(GC__NUM_SE*GC__NUM_SA_PER_SE)
          sec = Debe()
          def onesa(seid, said):
            v0 = mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
            v1 = mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
            v = (v0 | v1) & 0xFFFF0000
            wgps[seid*2+said] = v >> 16
          each.sa(onesa)

          rbs = Fmt.flat(CFG.getRenderBackendPerSA())

          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = (mmr(mmGC_USER_SA_UNIT_DISABLE) | mmr(mmCC_GC_SA_UNIT_DISABLE)) >> 8
              for said in range(0, GC__NUM_SE*GC__NUM_SA_PER_SE):
                  if((sa_disable >> said) & 1) == 1 :
                      wgps[said] = 0xffff
                      rbs [said] = (1 << GC__NUM_RB_PER_SA)-1

          if True:
              prim_config = mmr(mmCC_GC_PRIM_CONFIG) | mmr(mmGC_USER_PRIM_CONFIG)
              prim_config_mask = 0xFF
              if (GC__NUM_PA_PER_SE == 1):
                  prim_config_mask = 0x55
              prim_config = (prim_config >> 4) & prim_config_mask
              if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
                  sa_unit = mmr(mmCC_GC_SA_UNIT_DISABLE) | mmr(mmGC_USER_SA_UNIT_DISABLE)
                  sa_unit = (sa_unit >> 8) & 0xffff
              else: sa_unit = 0xff
              sec["SE7SA"] = (sa_unit >> 14) & 3
              sec["SE6SA"] = (sa_unit >> 12) & 3
              sec["SE5SA"] = (sa_unit >> 10) & 3
              sec["SE4SA"] = (sa_unit >> 8) & 3
              sec["SE3SA"] = (sa_unit >> 6) & 3
              sec["SE2SA"] = (sa_unit >> 4) & 3
              sec["SE1SA"] = (sa_unit >> 2) & 3
              sec["SE0SA"] = sa_unit & 3
              #rb_redundancy0 =  mmr(mmCC_RB_REDUNDANCY) | mmr(mmGC_USER_RB_REDUNDANCY)
              #rb_redundancy  = ((rb_redundancy0 >> 8) & 0x1f) | ((rb_redundancy0 >> 11) & 0x3E0)
              #sec["RBr3REPAIR"] = (rb_redundancy >> 15) & 0x1f
              #sec["RBr2REPAIR"] = (rb_redundancy >> 10) & 0x1f
              #sec["RBr1REPAIR"] = (rb_redundancy >> 5) & 0x1f
              #sec["RBr0REPAIR"] = (rb_redundancy >> 0)& 0x1f

          sec["GL2C"] = __cgts_tcc_disable

          sec["SE5SA1RB"] =rbs[11]
          sec["SE5SA0RB"] =rbs[10]
          sec["SE4SA1RB"] =rbs[9]
          sec["SE4SA0RB"] =rbs[8]
          sec["SE3SA1RB"] =rbs[7]
          sec["SE3SA0RB"] =rbs[6]
          sec["SE2SA1RB"] =rbs[5]
          sec["SE2SA0RB"] =rbs[4]
          sec["SE1SA1RB"] =rbs[3]
          sec["SE1SA0RB"] =rbs[2]
          sec["SE0SA1RB"] =rbs[1]
          sec["SE0SA0RB"] =rbs[0]
          wgp_mask = (1 << GC__NUM_WGP_PER_SA) - 1
          sec["SE5SA1WGP"] = (wgps[11] & wgp_mask)
          sec["SE5SA0WGP"] = (wgps[10] & wgp_mask)
          sec["SE4SA1WGP"] = (wgps[9] & wgp_mask)
          sec["SE4SA0WGP"] = (wgps[8] & wgp_mask)
          sec["SE3SA1WGP"] = (wgps[7] & wgp_mask)
          sec["SE3SA0WGP"] = (wgps[6] & wgp_mask)
          sec["SE2SA1WGP"] = (wgps[5] & wgp_mask)
          sec["SE2SA0WGP"] = (wgps[4] & wgp_mask)
          sec["SE1SA1WGP"] = (wgps[3] & wgp_mask)
          sec["SE1SA0WGP"] = (wgps[2] & wgp_mask)
          sec["SE0SA1WGP"] = (wgps[1] & wgp_mask)
          sec["SE0SA0WGP"] = (wgps[0] & wgp_mask)
          debestr = sec.readable() if readable > 0 else str(sec)
          print(debestr)
          with open("DEBE.txt", "w") as text_file:
             text_file.write(str(sec))
        @staticmethod
        def enableRBCrest(sa_select=0xff, rbid=0xff):
            ''' Set PA:PA_SC_TILE_STEERING_CREST_OVERRIDE
                enableRBCrest() set the reg to 0 which is the defualt value
                enableRBCrest(sa_select, rbid) route all the traffic to RB(sa_select, rbid)
            '''
            #rbids=[0x1, 0x21, 0x41, 0x61, 0x101, 0x121, 0x141, 0x161, 0x201, 0x221, 0x241, 0x261, 0x301, 0x321, 0x341, 0x361] #nv21
            #regvalue=rbids[rbid] if rbid < GC__NUM_RB_PER_SA * GC__NUM_SA_PER_SE * GC__NUM_SE else 0
            regvalue = 0
            if sa_select < GC__NUM_SE * GC__NUM_SA_PER_SE  and rbid < GC__NUM_RB_PER_SA * GC__NUM_SA_PER_SE:
                regvalue = 1 | (sa_select << 8) | (rbid << 5)
            mmw(mmPA_SC_TILE_STEERING_CREST_OVERRIDE, regvalue)
            mmrp(mmPA_SC_TILE_STEERING_CREST_OVERRIDE)
        @staticmethod
        def enableOneRB(sa_select=0xff, rbid=0xff):CFG.enableRBCrest(sa_select,rbid)
        @staticmethod
        def getRenderBackendPerSA():
            w, h = GC__NUM_SA_PER_SE, GC__NUM_SE
            maskrb = [[0 for x in range(w)] for y in range(h)]
            v0=mmr(mmCC_RB_BACKEND_DISABLE)
            v1=mmr(mmGC_USER_RB_BACKEND_DISABLE)
            v = v0 | v1
            v = v >> 4
            for se in range(GC__NUM_SE):
                for sh in range(GC__NUM_SA_PER_SE):
                    maskrb[se][sh] = v & 3
                    v = v >> 2
            return maskrb
        @staticmethod
        def flushcache():
           mmw(mmGL2C_WBINVL2, 1)



elif GFX_IP_MAJOR >= 12:
    '''---------------------------------------------------------'''
    '''---------------------  GFX11 ----------------------------'''
    '''---------------------------------------------------------'''
    class RM:
       @staticmethod
       def read():
         mmRSMU_MEM_POWER_CTRL_1_GC = 0x900b018 // 4
         v = smn.mmr(mmRSMU_MEM_POWER_CTRL_1_GC)
         mux2 = (v >> 17) & 0x3f
         #mux4 = (v >> 20) & 0x3f
         logger.log(25, "mmRSMU_MEM_POWER_CTRL_1_GC: 0x%x"%v)
         logger.log(25, "MUX2_RME                : 0x%x"%mux2);
         return UserList([mux2])
       @staticmethod
       def set(mux4, mux2, **kw):
         mmRSMU_MEM_POWER_CTRL_1_GC = 0x900b018 // 4
         if 'mux4' in kw: mux4 = kw['mux4']
         if 'mux2' in kw: mux2 = kw['mux2']
         v = smn.mmr(mmRSMU_MEM_POWER_CTRL_GC) & 0xfc000fff
         newv = v | (1 << 16) | ((mux2 & 0x3f) << 17)
         smn.mmw(mmRSMU_MEM_POWER_CTRL_GC, newv)
         cv = mmr(mmRLC_GFX_RM_CNTL) & 0xfffffffe
         cv = cv | 0x1
         mmw(mmRLC_GFX_RM_CNTL, cv)
         time.sleep(0.05)
         mmw(mmRLC_GFX_RM_CNTL, cv & 0xfffffffe)

    class CFG(CFGCommon):
        class GL2C:
             @staticmethod
             def info():
                 mmrp(mmGB_ADDR_CONFIG)
                 mmrp(mmCGTS_TCC_DISABLE)
                 mmrp(mmCGTS_USER_TCC_DISABLE)
                 mmrp(mmCGTS_TCC_DISABLE)
                 mmrp(mmGL2_PIPE_STEER_0)
                 mmrp(mmGL2_PIPE_STEER_1)
                 mmrp(mmGL2_PIPE_STEER_2)
                 mmrp(mmGL2_PIPE_STEER_3)
                 mmrp(mmGL1_PIPE_STEER)
             @staticmethod
             def steer(*v):
                 l = len(v)
                 i = 0
                 mmw(mmGL2_PIPE_STEER_0, v[i % l])
                 i = i + 1
                 mmw(mmGL2_PIPE_STEER_1, v[i % l])
                 i = i + 1
                 mmw(mmGL2_PIPE_STEER_2, v[i % l])
                 i = i + 1
                 mmw(mmGL2_PIPE_STEER_3, v[i % l])
                 i = i + 1
        @staticmethod
        def sanity():
          def onesh(seid, shid):
            v0=mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
            v1=mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
            return (v0 | v1) & 0xffff0000
          r = each.sh(onesh)
          saids_disable = [k for k,v in enumerate(r) if v == 0xffff0000]
          seids_disable = [ i for i in RANGE_SE if 2*i in saids_disable and 2*i+1 in saids_disable]
          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for said in saids_disable: sa_disable = sa_disable | (1<<said)
              sa_disable = sa_disable << 8
              mmw(mmGC_USER_SA_UNIT_DISABLE, sa_disable)
              mmrp(mmGC_USER_SA_UNIT_DISABLE)
          each.sa(mmGC_USER_RB_BACKEND_DISABLE, 0)
          for sa_id in saids_disable:
                  se_id = sa_id // 2
                  mmw(mmGRBM_GFX_INDEX, (se_id << 16) | ((sa_id & 1) << 8))
                  mmw(mmGC_USER_RB_BACKEND_DISABLE, 0xff0000)
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          if len(seids_disable) > 0:
              pa_disable = 0
              for seid in seids_disable:
                  #for paid in ragne(GC__NUM_PA_PER_SE):
                  for paid in range(2):
                      pa_disable = pa_disable | (1<<(seid * 2 + paid))
              pa_disable = pa_disable << 4
              mmw(mmGC_USER_PRIM_CONFIG, pa_disable)
              mmrp(mmGC_USER_PRIM_CONFIG)
          #GCUTCL2_HARVEST_BYPASS_GROUPS
          if var_exist('mmGCUTCL2_HARVEST_BYPASS_GROUPS'):
              utcl2_bypass = 0
              for said in saids_disable:
                  utcl2_bypass = utcl2_bypass | (1 <<(said))
                  mmw(mmGCUTCL2_HARVEST_BYPASS_GROUPS, utcl2_bypass)

          pass
        @staticmethod
        def debe(readable = 0, gfxver = 1):
           if GFX_IP_MAJOR >= 12:
               CFG.debeGfx12(readable, gfxver)
           if GFX_IP_MAJOR == 11:
               CFG.debeGfx11(readable, gfxver)
        @staticmethod
        def enableOneWGP(cuid=None):CFG.enableCUExt(cuid, nosanity=1)
        @staticmethod
        def enableSE(*seids, **kwargs):
          ''' enable the *seids,  and disable all the other SEs
              enableSE(0,2) Enable SE0 and SE2
              enableSE(0) Enable SE0
              enableSE() Enable All SE
          '''
          CFG.clear()
          WGP0WA = False # WGP0 in each SA must be enabled
          if WGP0WA:
              mask = [0xfffe0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          else:
              mask = [0xffff0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          seids_disable = [ i for i in RANGE_SE if i not in seids]
          #print(seids_disable)
          if len(seids) == 0:
              CFG.clear()
              showCUMask()
              return
          user_mode = True
          if 'fuse_mode' in kwargs : user_mode = not kwargs['fuse_mode']
          if user_mode :
              REG_SHADER_ARRAY = mmGC_USER_SHADER_ARRAY_CONFIG
              REG_RB_DISABLE = mmGC_USER_RB_BACKEND_DISABLE
              REG_SA_UNIT_DISABLE = mmGC_USER_SA_UNIT_DISABLE
              REG_PRIM_CONFIG = mmGC_USER_PRIM_CONFIG if var_exist("mmGC_USER_PRIM_CONFIG") else 0
          else:
              REG_SHADER_ARRAY = mmCC_GC_SHADER_ARRAY_CONFIG
              REG_RB_DISABLE = mmCC_RB_BACKEND_DISABLE
              REG_SA_UNIT_DISABLE = mmCC_GC_SA_UNIT_DISABLE
              REG_PRIM_CONFIG = mmCC_GC_PRIM_CONFIG if var_exist("mmCC_GC_PRIM_CONFIG") else 0
          #
          #Enable CUs in seids
          for seid in seids:
              for said in RANGE_SA:
                  mask[seid*GC__NUM_SA_PER_SE+said] = 0

          if var_exist('mmGC_USER_PRIM_CONFIG'):
              pa_disable = 0xfaaa
              print('dis se', seids_disable)
              for seid in seids_disable:
                  #for paid in ragne(GC__NUM_PA_PER_SE):
                  for paid in range(2):
                      pa_disable = pa_disable | (1<<(seid * 2 + paid))
              pa_disable = pa_disable << 4
              mmw(REG_PRIM_CONFIG, pa_disable)

          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for seid in seids_disable: sa_disable = sa_disable | (1<<(seid*2)) | (1<<(seid*2+1))
              sa_disable = sa_disable << 8
              mmw(REG_SA_UNIT_DISABLE, sa_disable)
              #print("sa %X" % sa_disable)
          #Disable RB
          if var_exist('mmCC_RB_BACKEND_DISABLE'):
              if GFX_IP_MAJOR >= 12:
                  rb_masks = [0] * GC__NUM_SE
                  for seid in seids_disable: rb_masks[seid] = 0xF0
                  each.se(REG_RB_DISABLE, rb_masks)
              elif GFX_IP_MAJOR >= 11:
                  vGC_USER_RB_BACKEND_DISABLE = 0
                  for seid in seids_disable:
                          vGC_USER_RB_BACKEND_DISABLE = vGC_USER_RB_BACKEND_DISABLE | (0xf << (4 + seid * 4) )
                  mmw(REG_RB_DISABLE, vGC_USER_RB_BACKEND_DISABLE)

          if var_exist('mmGC_USER_SHADER_ARRAY_CONFIG'):
               for i in RANGE_SE:
                   for j in RANGE_SA:
                       mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                       mmw(REG_SHADER_ARRAY, mask[i*GC__NUM_SA_PER_SE+j])
               mmw(mmGRBM_GFX_INDEX, 0xe0000000)


          #GCUTCL2_HARVEST_BYPASS_GROUPS
          if var_exist('mmGCUTCL2_HARVEST_BYPASS_GROUPS'):
              utcl2_bypass = 0
              for seid in seids_disable:
                  utcl2_bypass = utcl2_bypass | (3 <<(seid*2))
                  #mmw(mmGCUTCL2_HARVEST_BYPASS_GROUPS, utcl2_bypass)
              #print("L2 %X"%utcl2_bypass)
          if var_exist('mmGRBM_SE_REMAP_CNTL'):
              vGRBM_SE_REMAP_CNTL = mmr(mmGRBM_SE_REMAP_CNTL)
              vGRBM_SE_REMAP_CNTL = 0xeca86420
              for seid in seids_disable:
                  vGRBM_SE_REMAP_CNTL = vGRBM_SE_REMAP_CNTL & (~(0xf << (seid *4)))
                  vGRBM_SE_REMAP_CNTL = vGRBM_SE_REMAP_CNTL | (1 << (seid * 4))
                  vGRBM_SE_REMAP_CNTL = vGRBM_SE_REMAP_CNTL | (seids[0] << (seid * 4 + 1))
              mmw(mmGRBM_SE_REMAP_CNTL, vGRBM_SE_REMAP_CNTL)

          showCUMask()
          do_reset = True
          if 'noreset' in kwargs : do_reset = not kwargs['noreset']
          if do_reset: softreset1()

        @staticmethod
        def enableSA(*saids):
          ''' Enable *saids and disable all the other SAs
              enableSA(0,2) Enable SE0SA0 and SE1SA0
              enableSA(0) Enable SE0SA0
              enableSA() Enable All SA
          '''
          mask = [0xffff0000]*(GC__NUM_SE*GC__NUM_SA_PER_SE)
          saids_disable = [ i for i in range(GC__NUM_SE*GC__NUM_SA_PER_SE) if i not in saids]
          if len(saids) == 0:
              CFG.clear()
              showCUMask()
              return
          #Enable CUs in seids
          for said in saids: mask[said] = 0
          for i in RANGE_SE:
              for j in RANGE_SA:
                  mmw(mmGRBM_GFX_INDEX, (i<<16)|(j<<8))
                  mmw(mmGC_USER_SHADER_ARRAY_CONFIG, mask[i*GC__NUM_SA_PER_SE+j])
          mmw(mmGRBM_GFX_INDEX, 0xe0000000)
          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = 0
              for said in saids_disable: sa_disable = sa_disable | (1<<said)
              sa_disable = sa_disable << 8
              mmw(mmGC_USER_SA_UNIT_DISABLE, sa_disable)

          CFG.sanity()
          showCUMask()
          softreset1()
        @staticmethod
        def debeGfx12(readable=False, gfxversion=1):
            print("not implemented")
        @staticmethod
        def debeGfx11(readable=False, gfxversion=1):
          '''
             print debe string according to current status
          '''
          #RB repair
          #TCC
          if gfxversion == 0: gfxversion = Settings.mMinorVersion
          __cgts_tcc_disable0  = mmr(mmCGTS_TCC_DISABLE)   # bit0 is WRITE_DIS; 31:16 TCC_DISABLE 15:8 HI
          __cgts_tcc_disable = (__cgts_tcc_disable0 >> 16)  | ((__cgts_tcc_disable0 & 0xff00)<< 8)
          wgps = [0] *(GC__NUM_SE*GC__NUM_SA_PER_SE)
          sec = Debe()
          def onesa(seid, said):
            v0 = mmr(mmGC_USER_SHADER_ARRAY_CONFIG)
            v1 = mmr(mmCC_GC_SHADER_ARRAY_CONFIG)
            v = (v0 | v1) & 0xFFFF0000
            wgps[seid*2+said] = v >> 16
          each.sa(onesa)

          rbs = Fmt.flat(CFG.getRenderBackendPerSA())

          if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
              sa_disable = (mmr(mmGC_USER_SA_UNIT_DISABLE) | mmr(mmCC_GC_SA_UNIT_DISABLE)) >> 8
              for said in range(0, GC__NUM_SE*GC__NUM_SA_PER_SE):
                  if((sa_disable >> said) & 1) == 1 :
                      wgps[said] = 0xffff
                      rbs [said] = (1 << GC__NUM_RB_PER_SA)-1

          if True:
              prim_config = mmr(mmCC_GC_PRIM_CONFIG) | mmr(mmGC_USER_PRIM_CONFIG)
              prim_config_mask = 0xFF
              if (GC__NUM_PA_PER_SE == 1):
                  prim_config_mask = 0x55
              prim_config = (prim_config >> 4) & prim_config_mask
              if var_exist('mmGC_USER_SA_UNIT_DISABLE'):
                  sa_unit = mmr(mmCC_GC_SA_UNIT_DISABLE) | mmr(mmGC_USER_SA_UNIT_DISABLE)
                  sa_unit = (sa_unit >> 8) & 0xffff
              else: sa_unit = 0xff
              sec["SE7SA"] = (sa_unit >> 14) & 3
              sec["SE6SA"] = (sa_unit >> 12) & 3
              sec["SE5SA"] = (sa_unit >> 10) & 3
              sec["SE4SA"] = (sa_unit >> 8) & 3
              sec["SE3SA"] = (sa_unit >> 6) & 3
              sec["SE2SA"] = (sa_unit >> 4) & 3
              sec["SE1SA"] = (sa_unit >> 2) & 3
              sec["SE0SA"] = sa_unit & 3
              #rb_redundancy0 =  mmr(mmCC_RB_REDUNDANCY) | mmr(mmGC_USER_RB_REDUNDANCY)
              #rb_redundancy  = ((rb_redundancy0 >> 8) & 0x1f) | ((rb_redundancy0 >> 11) & 0x3E0)
              #sec["RBr3REPAIR"] = (rb_redundancy >> 15) & 0x1f
              #sec["RBr2REPAIR"] = (rb_redundancy >> 10) & 0x1f
              #sec["RBr1REPAIR"] = (rb_redundancy >> 5) & 0x1f
              #sec["RBr0REPAIR"] = (rb_redundancy >> 0)& 0x1f

          sec["GL2C"] = __cgts_tcc_disable

          sec["SE5SA1RB"] =rbs[11]
          sec["SE5SA0RB"] =rbs[10]
          sec["SE4SA1RB"] =rbs[9]
          sec["SE4SA0RB"] =rbs[8]
          sec["SE3SA1RB"] =rbs[7]
          sec["SE3SA0RB"] =rbs[6]
          sec["SE2SA1RB"] =rbs[5]
          sec["SE2SA0RB"] =rbs[4]
          sec["SE1SA1RB"] =rbs[3]
          sec["SE1SA0RB"] =rbs[2]
          sec["SE0SA1RB"] =rbs[1]
          sec["SE0SA0RB"] =rbs[0]
          wgp_mask = (1 << GC__NUM_WGP_PER_SA) - 1
          sec["SE5SA1WGP"] = (wgps[11] & wgp_mask)
          sec["SE5SA0WGP"] = (wgps[10] & wgp_mask)
          sec["SE4SA1WGP"] = (wgps[9] & wgp_mask)
          sec["SE4SA0WGP"] = (wgps[8] & wgp_mask)
          sec["SE3SA1WGP"] = (wgps[7] & wgp_mask)
          sec["SE3SA0WGP"] = (wgps[6] & wgp_mask)
          sec["SE2SA1WGP"] = (wgps[5] & wgp_mask)
          sec["SE2SA0WGP"] = (wgps[4] & wgp_mask)
          sec["SE1SA1WGP"] = (wgps[3] & wgp_mask)
          sec["SE1SA0WGP"] = (wgps[2] & wgp_mask)
          sec["SE0SA1WGP"] = (wgps[1] & wgp_mask)
          sec["SE0SA0WGP"] = (wgps[0] & wgp_mask)
          debestr = sec.readable() if readable > 0 else str(sec)
          print(debestr)
          with open("DEBE.txt", "w") as text_file:
             text_file.write(str(sec))
        @staticmethod
        def enableRBCrest(sa_select=0xff, rbid=0xff):
            ''' Set PA:PA_SC_TILE_STEERING_CREST_OVERRIDE
                enableRBCrest() set the reg to 0 which is the defualt value
                enableRBCrest(sa_select, rbid) route all the traffic to RB(sa_select, rbid)
            '''
            #rbids=[0x1, 0x21, 0x41, 0x61, 0x101, 0x121, 0x141, 0x161, 0x201, 0x221, 0x241, 0x261, 0x301, 0x321, 0x341, 0x361] #nv21
            #regvalue=rbids[rbid] if rbid < GC__NUM_RB_PER_SA * GC__NUM_SA_PER_SE * GC__NUM_SE else 0
            regvalue = 0
            if sa_select < GC__NUM_SE * GC__NUM_SA_PER_SE  and rbid < GC__NUM_RB_PER_SA * GC__NUM_SA_PER_SE:
                regvalue = 1 | (sa_select << 8) | (rbid << 5)
            mmw(mmPA_SC_TILE_STEERING_CREST_OVERRIDE, regvalue)
            mmrp(mmPA_SC_TILE_STEERING_CREST_OVERRIDE)
        @staticmethod
        def enableOneRB(sa_select=0xff, rbid=0xff):CFG.enableRBCrest(sa_select,rbid)
        @staticmethod
        def getRenderBackendPerSA():
            w, h = GC__NUM_SA_PER_SE, GC__NUM_SE
            maskrb = [[0 for x in range(w)] for y in range(h)]
            v0=mmr(mmCC_RB_BACKEND_DISABLE)
            v1=mmr(mmGC_USER_RB_BACKEND_DISABLE)
            v = v0 | v1
            v = v >> 4
            for se in range(GC__NUM_SE):
                for sh in range(GC__NUM_SA_PER_SE):
                    maskrb[se][sh] = v & 3
                    v = v >> 2
            return maskrb
        @staticmethod
        def flushcache():
           mmw(mmGL2C_WBINVL2, 1)




cfg = CFG()
# deprecated, use CFG.enableSE
def enableSE(*seids): return CFG.enableSE(*seids)
# deprecated, use CFG.enableOneSE
def enableOneSE(seid=None): return CFG.enableOneSE(seid)
# deprecated, use CFG.disableCU
def disableCU(*cuids): return CFG.disableCU(*cuids)
# deprecated, use CFG.showCUMask
def showCUMask(): return CFG.showCUMask()
# deprecated, use CFG.enableOneCU
def enableOneCU(cuid=None): return CFG.enableOneCU(cuid)
# deprecated, use CFG.enableOneWGP
def enableOneWGP(cuid=None): return CFG.enableOneCU(cuid)
# deprecated, use CFG.disableWGP
def disableWGP(*cuids): return CFG.disableCU(*cuids)
# deprecated, use CFG.showWGPMask
def showWGPMask(): return CFG.showCUMask()

rm=RM()

class PRMT:
  @staticmethod
  def info():
    reg.dump(mmGRBM_RRMT_CNTL)
    a = UserList()
    mmw(mmGRBM_RRMT_LUT_INDEX , 0)
    for i in range(30):
        r = mmr(mmGRBM_RRMT_LUT_DATA)
        a.append(r)
    print(Fmt.hexall(a))
    mmw(mmGRBM_RRMT_LUT_INDEX , 0)
