#!/usr/bin/python

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)
from db32 import *
from ip_gds import *
from ip_mm import *
from ip_reg import *
from ip_cpdma import *

class Q:
    def __init__(self, me=0,pipe=0,queue=0,vmid=0):
       if not isNumber(me) : return self.fromstr(me)
       self.__init(me,pipe,queue,vmid)
       self.select()
    def __enter__(self):
        self.select()
        return self
    def __exit__(self, type, value, traceback):
       self.done()
    def __del__(self):
       self.done()
    def __init(self, me, pipe, queue, vmid):
       self.me = me
       self.pipe = pipe
       self.q = queue
       # get correct vmid
       self.vmid = vmid
       self.grbm_gfx_cntl = ((pipe&3)<<0) | ((me&3)<<2) | ((vmid&0xf)<<4) | ((queue&7)<<8)
    def fromstr(self, qstr):
       qstrs = qstr.split(",")
       t = [0,0,0,0]
       for i in range(0,4):
         if len(qstrs) > i :
           if len(qstrs[i].strip()) > 0:
             t[i] = int(qstrs[i].strip())
       me, pipe, queue, vmid = tuple(t)
       self.__init(me,pipe,queue,vmid)
    def select(self):
       mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
    def done(self): mmw(mmGRBM_GFX_CNTL, 0)

class CP:
    @staticmethod
    def info():
       reg.dumpCPheader()
cp = CP()

class RB:
    IT_PM4_MAPS = {
    IT_DRAW_INDEX_INDIRECT: ['DATA_OFFSET', '[31:16]START_INDX_LOC, [15:0]BASE_CTX_LOC', '[28]START_INDEX_ENABLE,[15:0]START_INST_LOC', 'DRAW_INITIATOR'],
    IT_DRAW_INDEX_2:['MAX_SIZE', 'INDEX_BASE_LO', 'INDEX_BASE_HI', 'INDEX_COUNT', 'DRAW_INITIATOR'],
    IT_RELEASE_MEM:['[11:8]EVENT_INDEX : [5:0]EVENT_TYPE', '', 'ADDR_LO', 'ADDR_HI', 'DATA_LO', 'DATA_HI', 'INT_CTID'],
    IT_DISPATCH_DIRECT:['ThreadGroup_DIM_X', 'ThreadGroup_DIM_Y', 'ThreadGroup_DIM_Z', 'DISPATCH_INITIATOR'],
    IT_DMA_DATA:['CONTROL', 'SRC_LO', 'SRC_HI', 'DST_LO', 'DST_HI', '[25:0]BYTE_COUNT']
    }
    def __init__(self, me=0,pipe=0,queue=0,vmid=0):
       self.q = Q(me,pipe,queue,vmid)
       self.rptr= 0
       self.wptr= 0
       self.base= 0
    def info(self):
       "Dump Ring Info for self.q"
       self.q.select()
       if self.q.me == 0 : self.infoGFXRB(self.q.pipe)
       else: self.infoCS()
    def update(self):
       self.q.select()
       if self.q.me == 0 : return self.updateGfx(self.q.pipe)
       else: return self.infoCS()
    def infoGFX(self):
       """Dump GFX PIPE Ring Info"""
       return self.infoGFXRB(self.q.pipe)
    def infoGFXRB(self, rbi):
       if rbi == 0 :
         _mmRB_BASE, _mmRB_BASE_HI, _mmRPTR, _mmRPTR_REPORT_ADDR, _mmRPTR_REPORT_ADDR_HI , _mmWPTR, _mmWPTR_HI, _mmWPTR_POLLING_ADDR, _mmWPTR_POLLING_ADDR_HI = (mmCP_RB0_BASE, mmCP_RB0_BASE_HI, mmCP_RB0_RPTR, mmCP_RB0_RPTR_ADDR, mmCP_RB0_RPTR_ADDR_HI, mmCP_RB0_WPTR, mmCP_RB0_WPTR_HI, mmCP_RB_WPTR_POLL_ADDR_LO, mmCP_RB_WPTR_POLL_ADDR_HI)
       else :
         _mmRB_BASE, _mmRB_BASE_HI, _mmRPTR, _mmRPTR_REPORT_ADDR, _mmRPTR_REPORT_ADDR_HI , _mmWPTR, _mmWPTR_HI, _mmWPTR_POLLING_ADDR, _mmWPTR_POLLING_ADDR_HI = (mmCP_RB1_BASE, mmCP_RB1_BASE_HI, mmCP_RB1_RPTR, mmCP_RB1_RPTR_ADDR, mmCP_RB1_RPTR_ADDR_HI, mmCP_RB1_WPTR, mmCP_RB1_WPTR_HI, mmCP_RB_WPTR_POLL_ADDR_LO, mmCP_RB_WPTR_POLL_ADDR_HI)
       _mmDOORBELL_CONTTROL = mmCP_RB_DOORBELL_CONTROL
       _control = mmrp(_mmDOORBELL_CONTTROL)
       _doorbell_offset = (_control &0x0ffffffc)>> 2
       _doorbell_en = (_control &0x40000000) >> 30
       print("DOORBELL:%X"% _doorbell_offset)
       _base = mmrp(_mmRB_BASE) + (mmrp(_mmRB_BASE_HI) << 32)
       _base = _base << 8
       _raddr = mmrp(_mmRPTR_REPORT_ADDR) +  (mmrp(_mmRPTR_REPORT_ADDR_HI) << 32)
       _rptr = mmrp(_mmRPTR)
       _wptr = mmrp(_mmWPTR)
       mmrp(_mmWPTR_HI)
       _waddr = mmrp(_mmWPTR_POLLING_ADDR) +  (mmrp(_mmWPTR_POLLING_ADDR_HI) << 32)
       mmrp(mmCP_IB1_BASE_LO)
       mmrp(mmCP_IB1_BASE_HI)
       mmrp(mmCP_IB1_OFFSET)
       mmrp(mmCP_IB1_BUFSZ)
       mmrp(mmCP_IB1_CMD_BUFSZ)
       mmrp(mmCP_ROQ_IB1_STAT)
       print("RPTR_ADDR:")
       _rptr2 = mm.readp(_raddr,8, 0)[0]
       if _rptr == 0 : _rptr = _rptr2
       print("WPTR_POLL_ADDR:")
       _wptr2 = mm.readp(_waddr,8, 0)[0]
       if _wptr == 0 : _wptr = _wptr2
       print("RB_BASE:")
       ring0 = mm.readp(_base, 8)
       self.parsePM4(ring0)
       print("RB_BASE + WPTR - 8:")
       ring000 = mm.readp(_base+_wptr*4 - 32, 8)
       self.parsePM4(ring000)
       print("WPTR %X"%(_wptr))
       print("RPTR %X"%(_rptr))
       print("BASE %X"%(_base))
       self.rptr= _wptr
       self.wptr= _rptr
       self.base= _base
       self.doorbell = _doorbell_offset
       print("To parse pm4 in the ring: -e'RB.parsePM4(0x%x, ndwords)'"%_base)
    def updateGfx(self, rbi):
       if rbi == 0 :
         _mmRB_BASE, _mmRB_BASE_HI, _mmRPTR, _mmRPTR_REPORT_ADDR, _mmRPTR_REPORT_ADDR_HI , _mmWPTR, _mmWPTR_HI, _mmWPTR_POLLING_ADDR, _mmWPTR_POLLING_ADDR_HI = (mmCP_RB0_BASE, mmCP_RB0_BASE_HI, mmCP_RB0_RPTR, mmCP_RB0_RPTR_ADDR, mmCP_RB0_RPTR_ADDR_HI, mmCP_RB0_WPTR, mmCP_RB0_WPTR_HI, mmCP_RB_WPTR_POLL_ADDR_LO, mmCP_RB_WPTR_POLL_ADDR_HI)
       else :
         _mmRB_BASE, _mmRB_BASE_HI, _mmRPTR, _mmRPTR_REPORT_ADDR, _mmRPTR_REPORT_ADDR_HI , _mmWPTR, _mmWPTR_HI, _mmWPTR_POLLING_ADDR, _mmWPTR_POLLING_ADDR_HI = (mmCP_RB1_BASE, mmCP_RB1_BASE_HI, mmCP_RB1_RPTR, mmCP_RB1_RPTR_ADDR, mmCP_RB1_RPTR_ADDR_HI, mmCP_RB1_WPTR, mmCP_RB1_WPTR_HI, mmCP_RB_WPTR_POLL_ADDR_LO, mmCP_RB_WPTR_POLL_ADDR_HI)
       _mmDOORBELL_CONTTROL = mmCP_RB_DOORBELL_CONTROL
       _control = mmrp(_mmDOORBELL_CONTTROL)
       _doorbell_offset = (_control &0x0ffffffc)>> 2
       _doorbell_en = (_control &0x40000000) >> 30
       print("DOORBELL:%X"% _doorbell_offset)
       _base = mmrp(_mmRB_BASE) + (mmrp(_mmRB_BASE_HI) << 32)
       _base = _base << 8
       _raddr = mmrp(_mmRPTR_REPORT_ADDR) +  (mmrp(_mmRPTR_REPORT_ADDR_HI) << 32)
       _rptr = mmrp(_mmRPTR)
       _wptr = mmrp(_mmWPTR)
       mmrp(_mmWPTR_HI)
       _waddr = mmrp(_mmWPTR_POLLING_ADDR) +  (mmrp(_mmWPTR_POLLING_ADDR_HI) << 32)
       mmrp(mmCP_IB1_BASE_LO)
       mmrp(mmCP_IB1_BASE_HI)
       mmrp(mmCP_IB1_OFFSET)
       mmrp(mmCP_IB1_BUFSZ)
       mmrp(mmCP_IB1_CMD_BUFSZ)
       mmrp(mmCP_ROQ_IB1_STAT)
       print("RPTR_ADDR:")
       _rptr2 = mm.read(_raddr,8, 0)[0]
       if _rptr == 0 : _rptr = _rptr2
       print("WPTR_POLL_ADDR:")
       _wptr2 = mm.read(_waddr,8, 0)[0]
       if _wptr == 0 : _wptr = _wptr2
       print("WPTR %X"%(_wptr))
       print("RPTR %X"%(_rptr))
       print("BASE %X"%(_base))
       self.rptr= _wptr
       self.wptr= _rptr
       self.base= _base
       self.doorbell_offset = _doorbell_offset

    def infoCS(self, hqd = True):
       """Dump HQD Ring Info"""
       _mmDOORBELL_CONTTROL = mmCP_HQD_PQ_DOORBELL_CONTROL
       _control = mmrp(_mmDOORBELL_CONTTROL)
       _doorbell_offset = (_control &0x0ffffffc)>> 2
       _doorbell_en = (_control &0x40000000) >> 30
       print("DOORBELL:%X"% _doorbell_offset)
       mmrp(mmCP_HQD_PQ_CONTROL)
       mmrp(mmCP_HQD_AQL_CONTROL)
       _vmid = mmrp(mmCP_HQD_VMID)
       _base = mmrp(mmCP_HQD_PQ_BASE) + (mmrp(mmCP_HQD_PQ_BASE_HI) << 32)
       _base = _base << 8
       _raddr = mmrp(mmCP_HQD_PQ_RPTR_REPORT_ADDR) +  (mmrp(mmCP_HQD_PQ_RPTR_REPORT_ADDR_HI) << 32)
       _rptr = mmrp(mmCP_HQD_PQ_RPTR)
       _wptr = mmrp(mmCP_HQD_PQ_WPTR_LO)
       mmrp(mmCP_HQD_ACTIVE)
       mmrp(mmCP_HQD_PQ_WPTR_HI)
       _waddr = mmrp(mmCP_HQD_PQ_WPTR_POLL_ADDR) +  (mmrp(mmCP_HQD_PQ_WPTR_POLL_ADDR_HI) << 32)
       print("CP_GFX_HQD_PQ_RPTR_ADDR:")
       _rptr2 = mm.readp(_raddr,16, 0)[0]
       #if _rptr == 0 : _rptr = _rptr2
       print("CP_HQD_PQ_WPTR_POLL_ADDR:")
       _wptr2 = mm.readp(_waddr,16, 0)[0]
       #if _wptr == 0 : _wptr = _wptr2
       mmw(mmGRBM_GFX_CNTL, 0)
       print("RB_BASE:")
       mm.readp(_base)
       print("RB_BASE + WPTR - 8:")
       mm.readp(_base+_wptr*4 - 32)
       print("WPTR        %X"%(_wptr))
       print("WPTR_POLL   %X"%(_wptr2))
       print("RPTR        %X"%(_rptr))
       print("RPTR_REPORT %X"%(_rptr))
       print("BASE %X"%(_base))
       self.rptr= _wptr
       self.wptr= _rptr
       self.base= _base
       print("To parse pm4 in the ring: -e'RB.parsePM4(0x%x, ndwords)'"%_base)
    @staticmethod
    def parsePM4fromAddr(addr, n):
       return RB.parsePM4fromList(mm.read(addr, n))

    @staticmethod
    def parsePM4fromList(m, n =0):
       i = 0
       while i < len(m):
         header = m[i]
         if (header & 0xc0000000) == 0xc0000000 and ( (header & 0xff) == 2 or (header & 0xff) == 0):#get a packet
            op = (header & 0xff00) >> 8
            pl = (header & 0x3fff0000) >> 16
            standard_forward = True
            if op == IT_SET_CONFIG_REG or op == IT_SET_SH_REG or op == IT_SET_CONTEXT_REG or op == IT_SET_UCONFIG_REG :
              RB.parseSET_X_REG(m, i)
            elif op == IT_COND_INDIRECT_BUFFER:
              RB.parseINDIRECT_BUFFER(m,i)
            elif op in RB.IT_PM4_MAPS:
              RB.parseByMap(m, i)
            elif op == IT_NOP  and  pl == 0x3FFF :
              print("  0x%X [opcode = %s count = %d] @%x"%(header, itname(header),pl, i))
              standard_forward = False
              i = i + 1
            else:
              print("  0x%X [opcode = %s count = %d] @%x"%(header, itname(header),pl, i))
              for j in range(1, pl+2):
                if(i+j < len(m)):print("    0x%8x"%m[i+j])
            if standard_forward : i = i + pl + 2
         else:
            print("    0x%08x"%m[i])
            i = i + 1

    @staticmethod
    def parseINDIRECT_BUFFER(m, i):
      header = m[i]
      op = (header & 0xff00) >> 8
      pl = (header & 0x3fff0000) >> 16
      print("  0x%X [opcode = %s count = %d] @%x"%(header, itname(header),pl, i))
      for j in range(1, pl+2):
          if(i+j < len(m)):print("    0x%8x"%m[i+j])
      if len(m) <= i + 3:
          print("Error in this packet")
          return
      _ib_base = m[i+1]  + (m[i+2] << 32)
      _ib_size = m[i+3] & 0xfffff
      print(">>>>>>>>>>>INDIRECT BUFFER START %x %x>>>>>>>>>>"%(_ib_base, _ib_size))
      RB.parsePM4fromAddr(_ib_base, _ib_size)
      print("<<<<<<<<<<<INDIRECT  BUFFER  END<<<<<<<<<<")

    @staticmethod
    def parseByMap(m, i):
      header = m[i]
      op = (header & 0xff00) >> 8
      pl = (header & 0x3fff0000) >> 16
      print("  0x%X [opcode = %s count = %d] @%x"%(header, itname(header),pl, i))
      f = RB.IT_PM4_MAPS[op]
      for j in range(1, pl+2):
        if(i+j < len(m)):print("    0x%8x    %s"%(m[i+j], f[j-1]))
      return i + pl + 2
    @staticmethod
    def parseSET_X_REG(m, i):
      _base = 0
      header = m[i]
      op = (header & 0xff00) >> 8
      pl = (header & 0x3fff0000) >> 16
      mlen = len(m)
      if op == IT_SET_CONFIG_REG : _base = 0x2000
      elif op == IT_SET_SH_REG : _base = 0x2C00
      elif op == IT_SET_CONTEXT_REG : _base = 0xA000
      elif op == IT_SET_UCONFIG_REG : _base = 0xC000
      else: _base = 0x2000
      print("  0x%X [opcode = %s count = %d] @%x"%(header, itname(header),pl, i))

      if(i+1 < mlen):print("    0x%8x"%m[i+1])
      for j in range(2, pl+2):
        if(i+j < mlen):print("    0x%8x    %s"%(m[i+j], regName(_base + j -2 + m[i+1])))
      return i + pl + 2

    @staticmethod
    def parsePM4(m, n = 0):
      """Parse PM4 Packet from m. m is ringbuffer address,  or dword list from ringbuffer"""
      if isNumber(m):return RB.parsePM4fromAddr(m, n)
      else: RB.parsePM4fromList(m)

if  GFX_IP_MAJOR == 9:
  from gfx9.ip_rb_gfx import *
else:
  from gfx10.ip_rb_gfx import *

