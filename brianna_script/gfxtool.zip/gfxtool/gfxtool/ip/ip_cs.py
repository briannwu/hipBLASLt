#!/usr/bin/python

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)
from db32 import *
from ip_mm import *
from ip_crest import *


class ComputeShaderBase:
    def __init__(self, shaderFile, **kwarg):
        self.args = ()
        self.localWorkSize = ()
        self.globalWorkSize = ()
        self.cs_rsrc1 = 0
        self.cs_rsrc2 = 0
        self.cs_rsrc3 = 0
        fb_location        = mmr(mmGCMC_VM_FB_LOCATION_BASE)
        self.fb_size       = mmr(mmGCMC_VM_FB_LOCATION_TOP)
        self.fb_location   = (fb_location << 24)
        self.fb_off        = 0x100000
        self.vmid          = 0x00000
        self.cs_limits     = 0
        self.grbm_gfx_cntl = 0
        self.pipelinestat = 0
        self.perf         = 0
        self.threadtrace  = 0
        self.initiator    = 0x61 # USE_THREAD_DIMENSIONS=1 ORDER_MODE=1 COMPUTE_SHADER_EN=1
        self.w32mode      = 0
        if GFX_IP_MAJOR >= 10:
            if 'wave32' in kwarg: self.w32mode = kwarg['wave32']
            if self.w32mode : self.initiator    = 0x8061
        if 'fb_offset' in kwarg: self.fb_off = kwarg['fb_offset']
        if 'fb_location' in kwarg: self.fb_location = kwarg['fb_location']
        self.fb_off0 = self.fb_off
        self.cs_addr = self.fb_location  +  self.fb_off
        if 'cs_addr' in kwarg: self.cs_addr = kwarg['cs_addr']
        self.crest_mode = 0
        if 'crest' in kwarg: self.crest_mode = kwarg['crest']
    def write(self, addr, datas):
         if self.crest_mode:
             crest.address(addr)
             crest.write(datas)
             if (len(datas) & 0x7) != 0 :
                   ri = 8 - (len(datas) & 0x7)
                   crest.write([0] * ri)
         else:
             for i in range(len(datas)):
                mm.write(addr+i*4, datas[i])
             #mm.write(self.cs_addr, shaderdata) #why it doesn't work
    def loadShader(self, shaderFile):
        if not shaderFile : return 0
        with open(shaderFile, 'r') as f:
             data = f.read()
             dataI = data.find('data')
             enddataI = data.find('enddata')
             regs = data[dataI+4:enddataI].split('\n')
             regs = [i for i in regs if len(i) > 10]
             if "GRBM_SH_reg 1 1 2e12" in  regs[2]: self.cs_rsrc1 = int(regs[2][23:31], 16)
             if "GRBM_SH_reg 1 1 2e13" in  regs[3]: self.cs_rsrc2 = int(regs[3][23:31], 16)
             if "GRBM_SH_reg 1 1 2e2d" in  regs[4]: self.cs_rsrc3 = int(regs[4][23:31], 16)
             shaderhex = data[enddataI + 7:].split(',')
             shaderdata = [int(i.strip(), 16) for i in shaderhex if len(i.strip()) > 2 ]
             #for i in range(len(shaderdata)):
             #   self.write(self.cs_addr+i*4, shaderdata[i])
             self.write(self.cs_addr, shaderdata) 
             return len(shaderdata) * 4

    def setSize(self, globalsize, localsize):
        _localsize  = [1, 1, 1]
        _globalsize = [1, 1, 1]
        if isNumber(localsize) : _localsize[0] = localsize
        else:
           for i in range(len(localsize)) : _localsize[i] = localsize[i]

        if isNumber(globalsize) : _globalsize[0] = globalsize
        else:
            for i in range(len(globalsize)) : _globalsize[i] = globalsize[i]
        self.localWorkSize  = tuple(_localsize)
        self.globalWorkSize = tuple(_globalsize)
        if self.localWorkSize[0] > self.globalWorkSize[0]:
            raise Exception("wrong size")
        return self
    def setArgs(self, *arg):
        _args = [self.localWorkSize[0], self.localWorkSize[1], self.localWorkSize[2], 0]
        for  i in range(len(arg)):
            _m = arg[i]
            _m0 = _m & 0xffffffff
            _m1 = (_m >> 32)& 0xffffffff
            _args.append(_m0)
            _args.append(_m1)

        self.args = tuple(_args)
        return self

    def info(self):
        print('mmCOMPUTE_PIPELINESTAT_ENABLE     ->%x'%self.pipelinestat );
        print('mmCOMPUTE_PERFCOUNT_ENABLE        ->%x'%self.perf         );
        print('mmCOMPUTE_THREAD_TRACE_ENABLE     ->%x'%self.threadtrace  );
        print('mmCOMPUTE_DIM_X                   ->%x'%self.globalWorkSize[0]);
        print('mmCOMPUTE_DIM_Y                   ->%x'%self.globalWorkSize[1]);
        print('mmCOMPUTE_DIM_Z                   ->%x'%self.globalWorkSize[2]);
        print('mmCOMPUTE_NUM_THREAD_X            ->%x'%self.localWorkSize[0]);
        print('mmCOMPUTE_NUM_THREAD_Y            ->%x'%self.localWorkSize[1]);
        print('mmCOMPUTE_NUM_THREAD_Z            ->%x'%self.localWorkSize[2]);
        print('mmCOMPUTE_PGM_LO                  ->%x'%((self.cs_addr >> 8 )&0xffffffff));
        print('mmCOMPUTE_PGM_HI                  ->%x'%((self.cs_addr >> 40)&0xffffffff));
        print('mmCOMPUTE_PGM_RSRC1               ->%x'%self.cs_rsrc1);
        print('mmCOMPUTE_PGM_RSRC2               ->%x'%self.cs_rsrc2);
        print('mmCOMPUTE_PGM_RSRC3               ->%x'%self.cs_rsrc3);
        print('mmCOMPUTE_RESOURCE_LIMITS         ->%x'%self.cs_limits);
        for i in range(len(self.args)):
            print('mmCOMPUTE_USER_DATA_0 + i     ->%x'%self.args[i]);

        print('mmCOMPUTE_DISPATCH_INITIATOR      ->%x'%self.initiator);
        print('mmCOMPUTE_DISPATCH_END            ->%x'%0x0);

        mmrp(mmCOMPUTE_PIPELINESTAT_ENABLE);
        mmrp(mmCOMPUTE_PERFCOUNT_ENABLE   );
        mmrp(mmCOMPUTE_THREAD_TRACE_ENABLE);
        mmrp(mmCOMPUTE_DIM_X              );
        mmrp(mmCOMPUTE_DIM_Y              );
        mmrp(mmCOMPUTE_DIM_Z              );
        mmrp(mmCOMPUTE_NUM_THREAD_X       );
        mmrp(mmCOMPUTE_NUM_THREAD_Y       );
        mmrp(mmCOMPUTE_NUM_THREAD_Z       );
        mmrp(mmCOMPUTE_PGM_LO             );
        mmrp(mmCOMPUTE_PGM_HI             );
        mmrp(mmCOMPUTE_PGM_RSRC1          );
        mmrp(mmCOMPUTE_PGM_RSRC2          );
        mmrp(mmCOMPUTE_PGM_RSRC3          );
        mmrp(mmCOMPUTE_RESOURCE_LIMITS    );
        for i in range(len(self.args)):
            mmrp(mmCOMPUTE_USER_DATA_0 + i);

        mmrp(mmCOMPUTE_DISPATCH_INITIATOR );
        mmrp(mmCOMPUTE_DISPATCH_END       );
        return self


'''
GFX ADC        : GRBM used to fully request a dispatch.
Multi-queue ADC: MEC used to fully request a dispatch.
currently, this class only support compute in GFX pipe
The shader is submitted by register,  no CP FW involved
'''
class ComputeShaderCpg(ComputeShaderBase):
    def __init__(self, shaderFile, **kwarg):
        super().__init__(shaderFile, **kwarg)
        if 'grbm_gfx_cntl' in kwarg: self.grbm_gfx_cntl = kwarg['grbm_gfx_cntl']
        self.fb_off = self.fb_off + self.loadShader(shaderFile)
    def run(self, globalsize, localsize, *args):
        self.setSize(globalsize, localsize)
        if(len(args)): self.setArgs(*args)
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        self.Init()
        mmw(mmCOMPUTE_PIPELINESTAT_ENABLE      ,self.pipelinestat );
        mmw(mmCOMPUTE_PERFCOUNT_ENABLE         ,self.perf         );
        mmw(mmCOMPUTE_THREAD_TRACE_ENABLE      ,self.threadtrace  );
        mmw(mmCOMPUTE_DIM_X                    ,self.globalWorkSize[0]);
        mmw(mmCOMPUTE_DIM_Y                    ,self.globalWorkSize[1]);
        mmw(mmCOMPUTE_DIM_Z                    ,self.globalWorkSize[2]);
        mmw(mmCOMPUTE_NUM_THREAD_X             ,self.localWorkSize[0]);
        mmw(mmCOMPUTE_NUM_THREAD_Y             ,self.localWorkSize[1]);
        mmw(mmCOMPUTE_NUM_THREAD_Z             ,self.localWorkSize[2]);
        mmw(mmCOMPUTE_PGM_LO                   ,(self.cs_addr >> 8 )&0xffffffff);
        mmw(mmCOMPUTE_PGM_HI                   ,(self.cs_addr >> 40)&0xffffffff);
        mmw(mmCOMPUTE_PGM_RSRC1                ,self.cs_rsrc1);
        mmw(mmCOMPUTE_PGM_RSRC2                ,self.cs_rsrc2);
        mmw(mmCOMPUTE_PGM_RSRC3                ,self.cs_rsrc3);
        mmw(mmCOMPUTE_RESOURCE_LIMITS          ,self.cs_limits);
        for i in range(len(self.args)):
            mmw(mmCOMPUTE_USER_DATA_0 + i      ,self.args[i]);

        mmw(mmCOMPUTE_DISPATCH_INITIATOR       ,self.initiator);
        mmw(mmCOMPUTE_DISPATCH_END             ,0x0);

        mmw(mmGRBM_GFX_CNTL, 0x0)
        return self

    def Init(self):
        mmw(mmCOMPUTE_START_X,                     0x0);
        mmw(mmCOMPUTE_START_Y,                     0x0);
        mmw(mmCOMPUTE_START_Z,                     0x0);
        mmw(mmCOMPUTE_PIPELINESTAT_ENABLE,         0x0);
        mmw(mmCOMPUTE_PERFCOUNT_ENABLE,            0x0);
        mmw(mmCOMPUTE_THREAD_TRACE_ENABLE,         0x0);
        mmw(mmCOMPUTE_VMID,                        0x0);
        mmw(mmCOMPUTE_TMPRING_SIZE,                0x0);
        mmw(mmCOMPUTE_STATIC_THREAD_MGMT_SE0,      0xFFFFFFFF);
        mmw(mmCOMPUTE_STATIC_THREAD_MGMT_SE1,      0xFFFFFFFF);
        mmw(mmCOMPUTE_STATIC_THREAD_MGMT_SE2,      0xFFFFFFFF);
        mmw(mmCOMPUTE_STATIC_THREAD_MGMT_SE3,      0xFFFFFFFF);
        if var_exist('mmCOMPUTE_STATIC_THREAD_MGMT_SE4'):
            mmw(mmCOMPUTE_STATIC_THREAD_MGMT_SE4,      0xFFFFFFFF);
            mmw(mmCOMPUTE_STATIC_THREAD_MGMT_SE5,      0xFFFFFFFF);
            mmw(mmCOMPUTE_STATIC_THREAD_MGMT_SE6,      0xFFFFFFFF);
            mmw(mmCOMPUTE_STATIC_THREAD_MGMT_SE7,      0xFFFFFFFF);
        if var_exist('mmCOMPUTE_REQ_CTRL'):mmw(mmCOMPUTE_REQ_CTRL, 0x0);
    def tearDown(self):
        pass

'''
MEC queue with MQD, need MEC FW
'''
class ComputeQueue(ComputeShaderBase):
    def __init__(self, shaderFile, **kwarg):
        super().__init__(shaderFile, **kwarg)
        self.grbm_gfx_cntl = 0x4
        (meid, pipeid, queueid) = (1, 0, 0)
        if 'grbm_gfx_cntl' in kwarg: self.grbm_gfx_cntl = kwarg['grbm_gfx_cntl']
        if 'me' in kwarg: meid = kwarg['me']
        if 'pipe' in kwarg: pipeid = kwarg['pipe']
        if 'queue' in kwarg: queueid = kwarg['queue']
        self.grbm_gfx_cntl = (meid << 2) | pipeid | (queueid << 8)
        self.me    = (self.grbm_gfx_cntl >> 2 ) & 3
        self.pipe  = (self.grbm_gfx_cntl >> 0 ) & 3
        self.queue = (self.grbm_gfx_cntl >> 8 ) & 7
        self.use_newsettings = True 
        if 'use_newsettings' in kwarg: self.use_newsettings = kwarg['use_newsettings']
        if not self.isNewSettings():
            # check if existing settings are good
            mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
            isActive = mmrp(mmCP_HQD_ACTIVE);
            if not isActive: self.use_newsettings = True 

        self.mqd_base  = 0
        self.rb_base   = 0
        self.wptr_poll_addr   = 0
        self.rptr_report_addr = 0
        self.cs_addr   = 0
        self.wptr      = 0

        self.kmd_queue = 1
        if self.isNewSettings():
            self._newSettings()
        else:
            self._loadSettings()

        self.fb_off = self.fb_off + self.loadShader(shaderFile)
    def isNewSettings(self): return self.use_newsettings == True
    def isExistingSettings(self): return self.use_newsettings == False 
    def _newSettings(self):
        # MQD buffer    : 512 DWORDS
        # RB            : 5 DWORDS
        # WPTR_POLL_ADDR: 2 DWORDS
        self.mqd_base = self.fb_location + self.fb_off
        self.fb_off = self.fb_off + 512 * 4
        self.rb_base  = self.fb_location + self.fb_off
        self.fb_off = self.fb_off + 256
        self.wptr_poll_addr  = self.fb_location + self.fb_off
        self.rptr_report_addr = self.wptr_poll_addr + 16 
        self.fb_off = self.fb_off + 256
        self.cs_addr = self.fb_location + self.fb_off
        #
        self.kmd_queue = 1
        self.wptr = 0

        self.write(self.wptr_poll_addr, [0, 0])
        self.write(self.rptr_report_addr, [0, 0])
        self.createMQDnRB()

    def _loadSettings(self):
        self.mqd_base = mmr(mmCP_MQD_BASE_ADDR) +  (mmr(mmCP_MQD_BASE_ADDR_HI)<<32)
        self.rb_base  =  mmr(mmCP_HQD_PQ_BASE) + ( mmr(mmCP_HQD_PQ_BASE_HI)<<32)
        self.wptr_poll_addr   = mmr(mmCP_HQD_PQ_WPTR_POLL_ADDR) + (mmr(mmCP_HQD_PQ_WPTR_POLL_ADDR_HI) << 32)
        self.rptr_report_addr = mmr(mmCP_HQD_PQ_RPTR_ADDR) + ( mmr(mmCP_HQD_PQ_RPTR_ADDR_HI) << 32)
        self.wptr =  mmr(mmCP_HQD_PQ_WPTR_LO) + (mmr(mmCP_HQD_PQ_WPTR_HI) << 32)
        self.fb_off  += 512*5  
        self.cp_hqd_pq_control = mmr(mmCP_HQD_PQ_CONTROL)

    def updateWPTR(self, wptr):
        self.write(self.wptr_poll_addr, [wptr, 0])
        self.wptr = wptr
    def enqueuePM4IntoRB(self, packets):
        self.write(self.rb_base + self.wptr, packets)
        self.updateWPTR(self.wptr + len(packets))
    def enqueueDispatchIntoRB(self):
        dispatchPackets = [
           0xc0031502, # IT_DISPATCH_DIRECT
           self.globalWorkSize[0], # DIM_X
           self.globalWorkSize[1], # DIM_Y
           self.globalWorkSize[2], # DIM_Y
           self.initiator #0x61 #DISPATCH_INITIATOR
        ]
        if GFX_IP_MAJOR <= 9:
             acquireMem = [
                 0xc0055800,  # [TYPE 3: OpCode=IT_ACQUIRE_MEM(88) Count=7]
                 0x68c40000,  # COHER_CNTL
                 0xffffffff,  # size
                 0x00ffffff,  # size
                 0x00000000,  # base_lo
                 0x00000000,  # base_hi
                 0x00000008,  # poll interval
             ]
        elif GFX_IP_MAJOR == 10:
             acquireMem = [
                 0xc0065802,  # [TYPE 3: OpCode=IT_ACQUIRE_MEM(88) Count=7]
                 0xe8c40000,  # COHER_CNTL
                 0xffffffff,  # size
                 0x00ffffff,  # size
                 0x00000000,  # base_lo
                 0x00000000,  # base_hi
                 0x00000004,  # poll interval
                 0x0000c3c1   # GCR_CNTL
             ]
        elif GFX_IP_MAJOR >= 11:
             acquireMem = [
                 0xc0065802,  # [TYPE 3: OpCode=IT_ACQUIRE_MEM(88) Count=7]
                 0x00000000,  # COHER_CNTL
                 0xffffffff,  # size
                 0x00ffffff,  # size
                 0x00000000,  # base_lo
                 0x00000000,  # base_hi
                 0x00000008,  # poll interval
                 0x0001c3c1   # GCR_CNTL
             ]
        pm4Packets = []
        pm4Packets.extend(acquireMem)
        pm4Packets.extend(dispatchPackets)
        self.write(self.rb_base + self.wptr, pm4Packets)
        self.updateWPTR(self.wptr + len(pm4Packets))
    def fillMQD(self, mqd = None):
        if mqd == None : mqd = [0] * 512
        mqd[13]  = self.cs_addr >> 8                  #/ COMPUTE_PGM_LO
        mqd[14]  = self.cs_addr >> 40                 #/ COMPUTE_PGM_HI
        mqd[19]  = self.cs_rsrc1                      #/ COMPUTE_PGM_RSRC1
        mqd[20]  = self.cs_rsrc2                      #/ COMPUTE_PGM_RSRC2
        if GFX_IP_MAJOR <= 9:
            mqd[46]  = self.cs_rsrc3                      #/ COMPUTE_PGM_RSRC3
        else:
            mqd[41]  = self.cs_rsrc3                      #/ COMPUTE_PGM_RSRC3
        mqd[23]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE0
        mqd[24]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE1
        mqd[26]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE2
        mqd[27]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE3
        if GFX_IP_MAJOR <= 9 and GC__VARIANT == mi200:
            mqd[39]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE4
            mqd[40]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE5
            mqd[41]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE6
            mqd[42]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE7
        elif GFX_IP_MAJOR == 11:
            mqd[44]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE4
            mqd[45]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE5
            mqd[46]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE6
            mqd[47]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE7
        mqd[8]   = self.localWorkSize[0]              #/ COMPUTE_NUM_THREAD_X
        mqd[9]   = self.localWorkSize[1]              #/ COMPUTE_NUM_THREAD_Y
        mqd[10]  = self.localWorkSize[2]              #/ COMPUTE_NUM_THREAD_Z
        mqd[22]  = self.cs_limits                     #/ COMPUTE_RESOURCE_LIMITS
        for i in range(len(self.args)):  mqd[65+i] = self.args[i]
        mqd[128] = self.mqd_base & 0xFFFFFFFF         #/ CP_MQD_BASE_ADDR
        mqd[129] = self.mqd_base >> 32                #/ CP_MQD_BASE_ADDR_HI
        mqd[136] = (self.rb_base >> 8 ) & 0xFFFFFFFF  #/ CP_HQD_PQ_BASE_LO
        mqd[137] = (self.rb_base >> 40) & 0xFFFFFFFF  #/ CP_HQD_PQ_BASE_HI
        mqd[139] = self.rptr_report_addr  & 0xFFFFFFFF #/ CP_HQD_PQ_RPTR_REPORT_ADDR
        mqd[140] = self.rptr_report_addr >> 32         #/ CP_HQD_PQ_RPTR_REPORT_ADDR_HI
        mqd[141] = self.wptr_poll_addr  & 0xFFFFFFFF  #/ CP_HQD_PQ_WPTR_POLL_ADDR
        mqd[142] = self.wptr_poll_addr >> 32          #/ CP_HQD_PQ_WPTR_POLL_ADDR_HI
        mqd[145] = self.cp_hqd_pq_control             #/ CP_HQD_PQ_CONTROL

        self.write(self.mqd_base, mqd)

    def createMQDnRB(self):
        no_udpdate_rptr = 0  # must be 1 for CReST
        priv_state = 1
        self.cp_hqd_pq_control = 7 | (no_udpdate_rptr<<27) | (priv_state<<30) | (self.kmd_queue<<31)
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmw(mmCP_HQD_ACTIVE,        0x0)
        mmw(mmCP_MQD_BASE_ADDR,             self.mqd_base & 0xFFFFFFFF)
        mmw(mmCP_MQD_BASE_ADDR_HI,          self.mqd_base >> 32)
        mmw(mmCP_HQD_PQ_BASE,               (self.rb_base >> 8) & 0xFFFFFFFF)
        mmw(mmCP_HQD_PQ_BASE_HI,            self.rb_base >> 40)
        mmw(mmCP_HQD_PQ_WPTR_POLL_ADDR,     self.wptr_poll_addr & 0xFFFFFFFF)
        mmw(mmCP_HQD_PQ_WPTR_POLL_ADDR_HI,  self.wptr_poll_addr>> 32)
        mmw(mmCP_HQD_PQ_RPTR_REPORT_ADDR,     self.rptr_report_addr & 0xFFFFFFFF)
        mmw(mmCP_HQD_PQ_RPTR_REPORT_ADDR_HI,  self.rptr_report_addr>> 32)
        mmw(mmCP_HQD_VMID,                  self.vmid)
        mmw(mmCP_HQD_PQ_CONTROL,            self.cp_hqd_pq_control)
        if(var_exist('mmCP_HQD_AQL_CONTROL')) : mmw(mmCP_HQD_AQL_CONTROL,           0)
        if(var_exist('mmCP_HQD_AQL_CONTROL_1')) : mmw(mmCP_HQD_AQL_CONTROL_1,         0)
        mmw(mmGRBM_GFX_CNTL, 0)


    def enableQueue(self):
        if not self.isNewSettings(): return
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmw(mmCP_HQD_ACTIVE,        0x0)
        mmw(mmCP_HQD_PQ_RPTR,       0x0)
        mmw(mmCP_HQD_PQ_WPTR_LO,    0x0)
        mmw(mmCP_HQD_PQ_WPTR_HI,    0x0)
        mmw(mmCP_HQD_ACTIVE,        0x1)
    def kickoffQueue(self):
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        enabledQueues = 1 << ( self.pipe * 8 + self.queue)
        print(mmCP_PQ_WPTR_POLL_CNTL1, enabledQueues);
        mmw(mmCP_PQ_WPTR_POLL_CNTL1, enabledQueues);
        mmw(mmGRBM_GFX_CNTL, 0)

    def run(self, globalsize, localsize, *args):
        self.setSize(globalsize, localsize)
        if(len(args)): self.setArgs(*args)
        self.fillMQD()
        self.enqueueDispatchIntoRB()
        self.enableQueue()
        self.kickoffQueue()
        return self

    def runPM4(self, packets, *args):
        self.setSize(1,1)
        self.fillMQD()
        self.enqueuePM4IntoRB(packets)
        self.enableQueue()
        self.kickoffQueue()
        return self

    def tearDown(self):
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmw(mmCP_HQD_ACTIVE,        0x0)
        mmw(mmCP_HQD_PQ_RPTR,       0x0)
        mmw(mmCP_HQD_PQ_WPTR_LO,    0x0)
        mmw(mmCP_HQD_PQ_WPTR_HI,    0x0)
        mmw(mmCP_MQD_BASE_ADDR,             0x0)
        mmw(mmCP_MQD_BASE_ADDR_HI,          0x0)
        mmw(mmCP_HQD_PQ_BASE,               0x0)
        mmw(mmCP_HQD_PQ_BASE_HI,            0x0)
        mmw(mmCP_HQD_PQ_WPTR_POLL_ADDR,     0x0)
        mmw(mmCP_HQD_PQ_WPTR_POLL_ADDR_HI,  0x0)
        mmw(mmCP_HQD_VMID,                  0x0)
        mmw(mmCP_HQD_PQ_CONTROL,            0x0)
        mmw(mmGRBM_GFX_CNTL, 0)
    def info(self):
        super().info()
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmrp(mmCP_HQD_ACTIVE);
        mmrp(mmCP_HQD_PQ_RPTR);
        mmrp(mmCP_HQD_PQ_WPTR_LO);
        mmrp(mmCP_HQD_PQ_WPTR_HI);
        mmrp(mmCP_HQD_ACTIVE);
        mmrp(mmCP_MQD_BASE_ADDR)
        mmrp(mmCP_MQD_BASE_ADDR_HI)
        mmrp(mmCP_HQD_PQ_BASE)
        mmrp(mmCP_HQD_PQ_BASE_HI)
        mmrp(mmCP_HQD_PQ_WPTR_POLL_ADDR)
        mmrp(mmCP_HQD_PQ_WPTR_POLL_ADDR_HI)
        mmrp(mmCP_HQD_VMID)
        mmrp(mmCP_HQD_PQ_CONTROL)
        mmw(mmGRBM_GFX_CNTL, 0)
        print("Total Resource Size : %x" % (self.fb_off - self.fb_off0))
        print("     MQD_BASE:%x"%self.mqd_base)
        print("      RB_BASE:%x"%self.rb_base)
        print("WPTR_POOLADDR:%x"%self.wptr_poll_addr)
        print("  SHADER_BASE:%x"%self.cs_addr)
        return self
'''
Async GFX queue with MQD, need ME FW and PFP FW
'''
class GfxQueue(ComputeShaderBase):
    def __init__(self, shaderFile, **kwarg):
        super().__init__(shaderFile, **kwarg)
        self.grbm_gfx_cntl = 0x4
        (meid, pipeid, queueid) = (0, 0, 0)
        if 'grbm_gfx_cntl' in kwarg: self.grbm_gfx_cntl = kwarg['grbm_gfx_cntl']
        if 'me' in kwarg: meid = kwarg['me']
        if 'pipe' in kwarg: pipeid = kwarg['pipe']
        if 'queue' in kwarg: queueid = kwarg['queue']
        self.grbm_gfx_cntl = (meid << 2) | pipeid | (queueid << 8)
        self.me    = (self.grbm_gfx_cntl >> 2 ) & 3
        self.pipe  = (self.grbm_gfx_cntl >> 0 ) & 3
        self.queue = (self.grbm_gfx_cntl >> 8 ) & 7
        self.use_newsettings = True 
        if 'use_newsettings' in kwarg: self.use_newsettings = kwarg['use_newsettings']
        if not self.isNewSettings():
            # check if existing settings are good
            mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
            isActive = mmrp(mmCP_GFX_HQD_ACTIVE);
            if not isActive: self.use_newsettings = True 

        self.mqd_base  = 0
        self.rb_base   = 0
        self.wptr_poll_addr   = 0
        self.rptr_report_addr = 0
        self.cs_addr   = 0
        self.wptr      = 0

        self.kmd_queue = 1
        if self.isNewSettings():
            self._newSettings()
        else:
            self._loadSettings()

        self.fb_off = self.fb_off + self.loadShader(shaderFile)
    def isNewSettings(self): return self.use_newsettings == True
    def isExistingSettings(self): return self.use_newsettings == False 
    def _newSettings(self):
        # MQD buffer    : 512 DWORDS
        # RB            : 5 DWORDS
        # WPTR_POLL_ADDR: 2 DWORDS
        self.mqd_base = self.fb_location + self.fb_off
        self.fb_off = self.fb_off + 512 * 4
        self.rb_base  = self.fb_location + self.fb_off
        self.fb_off = self.fb_off + 256
        self.wptr_poll_addr  = self.fb_location + self.fb_off
        self.rptr_report_addr = self.wptr_poll_addr + 16 
        self.fb_off = self.fb_off + 256
        self.cs_addr = self.fb_location + self.fb_off
        #
        self.kmd_queue = 1
        self.wptr = 0

        self.write(self.wptr_poll_addr, [0, 0])
        self.write(self.rptr_report_addr, [0, 0])
        self.createMQDnRB()

    def _loadSettings(self):
        self.mqd_base = mmr(mmCP_GFX_MQD_BASE_ADDR) +  (mmr(mmCP_GFX_MQD_BASE_ADDR_HI)<<32)
        self.rb_base  =  mmr(mmCP_GFX_HQD_BASE) + ( mmr(mmCP_GFX_HQD_BASE_HI)<<32)
        self.wptr_poll_addr   = mmr(mmCP_RB_WPTR_POLL_ADDR_LO) + (mmr(mmCP_GFX_HQD_WPTR_POLL_ADDR_HI) << 32)
        self.rptr_report_addr = mmr(mmCP_GFX_HQD_RPTR_REPORT_ADDR) + ( mmr(mmCP_GFX_HQD_RPTR_REPORT_ADDR_HI) << 32)
        self.wptr =  mmr(mmCP_GFX_HQD_WPTR) + (mmr(mmCP_GFX_HQD_WPTR_HI) << 32)
        self.fb_off  += 512*5  
        self.cp_hqd_pq_control = mmr(mmCP_GFX_HQD_CNTL)

    def updateWPTR(self, wptr):
        self.write(self.wptr_poll_addr, [wptr, 0])
        self.wptr = wptr
    def enqueuePM4IntoRB(self, packets):
        self.write(self.rb_base + self.wptr, packets)
        self.updateWPTR(self.wptr + len(packets))
    def enqueueDispatchIntoRB(self):
        dispatchPackets = [
           0xc0031502, # IT_DISPATCH_DIRECT
           self.globalWorkSize[0], # DIM_X
           self.globalWorkSize[1], # DIM_Y
           self.globalWorkSize[2], # DIM_Y
           self.initiator #0x61 #DISPATCH_INITIATOR  bit15 CS_W32_EN
        ]
        if GFX_IP_MAJOR <= 9:
             acquireMem = [
                 0xc0055800,  # [TYPE 3: OpCode=IT_ACQUIRE_MEM(88) Count=7]
                 0x68c40000,  # COHER_CNTL
                 0xffffffff,  # size
                 0x00ffffff,  # size
                 0x00000000,  # base_lo
                 0x00000000,  # base_hi
                 0x00000008,  # poll interval
             ]
        elif GFX_IP_MAJOR == 10:
             acquireMem = [
                 0xc0065802,  # [TYPE 3: OpCode=IT_ACQUIRE_MEM(88) Count=7]
                 0xe8c40000,  # COHER_CNTL
                 0xffffffff,  # size
                 0x00ffffff,  # size
                 0x00000000,  # base_lo
                 0x00000000,  # base_hi
                 0x00000004,  # poll interval
                 0x0000c3c1   # GCR_CNTL
             ]
        elif GFX_IP_MAJOR >= 11:
             acquireMem = [
                 0xc0065802,  # [TYPE 3: OpCode=IT_ACQUIRE_MEM(88) Count=7]
                 0x00000000,  # COHER_CNTL
                 0xffffffff,  # size
                 0x00ffffff,  # size
                 0x00000000,  # base_lo
                 0x00000000,  # base_hi
                 0x00000008,  # poll interval
                 0x0001c3c1   # GCR_CNTL
             ]
        pm4Packets = []
        pm4Packets.extend(acquireMem)
        pm4Packets.extend(dispatchPackets)
        self.write(self.rb_base + self.wptr, pm4Packets)
        self.updateWPTR(self.wptr + len(pm4Packets))
    def fillMQD(self, mqd = None):
        if mqd == None : mqd = [0] * 512
        mqd[13]  = self.cs_addr >> 8                  #/ COMPUTE_PGM_LO
        mqd[14]  = self.cs_addr >> 40                 #/ COMPUTE_PGM_HI
        mqd[19]  = self.cs_rsrc1                      #/ COMPUTE_PGM_RSRC1
        mqd[20]  = self.cs_rsrc2                      #/ COMPUTE_PGM_RSRC2
        if GFX_IP_MAJOR <= 9:
            mqd[46]  = self.cs_rsrc3                      #/ COMPUTE_PGM_RSRC3
        else:
            mqd[41]  = self.cs_rsrc3                      #/ COMPUTE_PGM_RSRC3
        mqd[23]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE0
        mqd[24]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE1
        mqd[26]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE2
        mqd[27]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE3
        if GFX_IP_MAJOR <= 9 and GC__VARIANT == mi200:
            mqd[39]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE4
            mqd[40]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE5
            mqd[41]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE6
            mqd[42]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE7
        elif GFX_IP_MAJOR == 11:
            mqd[44]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE4
            mqd[45]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE5
            mqd[46]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE6
            mqd[47]  = 0xffffffff                         #/ COMPUTE_STATIC_THREAD_MGMT_SE7
        mqd[8]   = self.localWorkSize[0]              #/ COMPUTE_NUM_THREAD_X
        mqd[9]   = self.localWorkSize[1]              #/ COMPUTE_NUM_THREAD_Y
        mqd[10]  = self.localWorkSize[2]              #/ COMPUTE_NUM_THREAD_Z
        mqd[22]  = self.cs_limits                     #/ COMPUTE_RESOURCE_LIMITS
        for i in range(len(self.args)):  mqd[65+i] = self.args[i]
        mqd[128] = self.mqd_base & 0xFFFFFFFF         #/ CP_MQD_BASE_ADDR
        mqd[129] = self.mqd_base >> 32                #/ CP_MQD_BASE_ADDR_HI
        mqd[136] = (self.rb_base >> 8 ) & 0xFFFFFFFF  #/ CP_HQD_PQ_BASE_LO
        mqd[137] = (self.rb_base >> 40) & 0xFFFFFFFF  #/ CP_HQD_PQ_BASE_HI
        mqd[139] = self.rptr_report_addr  & 0xFFFFFFFF #/ CP_HQD_PQ_RPTR_REPORT_ADDR
        mqd[140] = self.rptr_report_addr >> 32         #/ CP_HQD_PQ_RPTR_REPORT_ADDR_HI
        mqd[141] = self.wptr_poll_addr  & 0xFFFFFFFF  #/ CP_HQD_PQ_WPTR_POLL_ADDR
        mqd[142] = self.wptr_poll_addr >> 32          #/ CP_HQD_PQ_WPTR_POLL_ADDR_HI
        mqd[145] = self.cp_hqd_pq_control             #/ CP_HQD_PQ_CONTROL

        self.write(self.mqd_base, mqd)

    def createMQDnRB(self):
        no_udpdate_rptr = 0  # must be 1 for CReST
        priv_state = 1
        self.cp_hqd_pq_control = 7 | (no_udpdate_rptr<<27) | (priv_state<<30) | (self.kmd_queue<<31)
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmw(mmCP_GFX_HQD_ACTIVE,        0x0)
        mmw(mmCP_GFX_MQD_BASE_ADDR,             self.mqd_base & 0xFFFFFFFF)
        mmw(mmCP_GFX_MQD_BASE_ADDR_HI,          self.mqd_base >> 32)
        mmw(mmCP_GFX_HQD_BASE,               (self.rb_base >> 8) & 0xFFFFFFFF)
        mmw(mmCP_GFX_HQD_BASE_HI,            self.rb_base >> 40)
        mmw(mmCP_RB_WPTR_POLL_ADDR_LO,     self.wptr_poll_addr & 0xFFFFFFFF)
        mmw(mmCP_RB_WPTR_POLL_ADDR_HI,  self.wptr_poll_addr>> 32)
        mmw(mmCP_GFX_HQD_RPTR_ADDR,     self.rptr_report_addr & 0xFFFFFFFF)
        mmw(mmCP_GFX_HQD_RPTR_ADDR_HI,  self.rptr_report_addr>> 32)
        mmw(mmCP_GFX_HQD_VMID,                  self.vmid)
        mmw(mmCP_GFX_HQD_CNTL,            self.cp_hqd_pq_control)
        if(var_exist('mmCP_GFX_HQD_AQL_CONTROL')) : mmw(mmCP_GFX_HQD_AQL_CONTROL,           0)
        if(var_exist('mmCP_GFX_HQD_AQL_CONTROL_1')) : mmw(mmCP_GFX_HQD_AQL_CONTROL_1,         0)
        mmw(mmGRBM_GFX_CNTL, 0)


    def enableQueue(self):
        if not self.isNewSettings(): return
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmw(mmCP_GFX_HQD_ACTIVE,        0x0)
        mmw(mmCP_GFX_HQD_RPTR,       0x0)
        mmw(mmCP_GFX_HQD_WPTR,    0x0)
        mmw(mmCP_GFX_HQD_WPTR_HI,    0x0)
        mmw(mmCP_GFX_HQD_ACTIVE,        0x1)
    def kickoffQueue(self):
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmw(mmCP_GFX_HQD_WPTR, self.wptr)
        mmw(mmCP_GFX_HQD_WPTR_HI, 0)
        mmw(mmGRBM_GFX_CNTL, 0)

    def run(self, globalsize, localsize, *args):
        self.setSize(globalsize, localsize)
        if(len(args)): self.setArgs(*args)
        self.fillMQD()
        self.enqueueDispatchIntoRB()
        self.enableQueue()
        self.kickoffQueue()
        return self

    def runPM4(self, packets, *args):
        self.setSize(1,1)
        self.fillMQD()
        self.enqueuePM4IntoRB(packets)
        self.enableQueue()
        self.kickoffQueue()
        return self

    def tearDown(self):
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmw(mmCP_GFX_HQD_ACTIVE,        0x0)
        mmw(mmCP_GFX_HQD_RPTR,       0x0)
        mmw(mmCP_GFX_HQD_WPTR,    0x0)
        mmw(mmCP_GFX_HQD_WPTR_HI,    0x0)
        mmw(mmCP_GFX_MQD_BASE_ADDR,             0x0)
        mmw(mmCP_GFX_MQD_BASE_ADDR_HI,          0x0)
        mmw(mmCP_GFX_HQD_BASE,               0x0)
        mmw(mmCP_GFX_HQD_BASE_HI,            0x0)
        mmw(mmCP_RB_WPTR_POLL_ADDR_LO,     0x0)
        mmw(mmCP_RB_WPTR_POLL_ADDR_HI,  0x0)
        mmw(mmCP_GFX_HQD_VMID,                  0x0)
        mmw(mmCP_GFX_HQD_CNTL,            0x0)
        mmw(mmGRBM_GFX_CNTL, 0)
    def info(self):
        super().info()
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmrp(mmCP_GFX_HQD_ACTIVE);
        mmrp(mmCP_GFX_HQD_RPTR);
        mmrp(mmCP_GFX_HQD_WPTR);
        mmrp(mmCP_GFX_HQD_WPTR_HI);
        mmrp(mmCP_GFX_HQD_ACTIVE);
        mmrp(mmCP_GFX_MQD_BASE_ADDR)
        mmrp(mmCP_GFX_MQD_BASE_ADDR_HI)
        mmrp(mmCP_GFX_HQD_BASE)
        mmrp(mmCP_GFX_HQD_BASE_HI)
        mmrp(mmCP_RB_WPTR_POLL_ADDR_LO)
        mmrp(mmCP_RB_WPTR_POLL_ADDR_HI)
        mmrp(mmCP_GFX_HQD_VMID)
        mmrp(mmCP_GFX_HQD_CNTL)
        mmw(mmGRBM_GFX_CNTL, 0)
        print("Total Resource Size : %x" % (self.fb_off - self.fb_off0))
        print("     MQD_BASE:%x"%self.mqd_base)
        print("      RB_BASE:%x"%self.rb_base)
        print("WPTR_POOLADDR:%x"%self.wptr_poll_addr)
        print("  SHADER_BASE:%x"%self.cs_addr)
        return self
