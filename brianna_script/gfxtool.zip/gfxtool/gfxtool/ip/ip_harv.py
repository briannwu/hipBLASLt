#!/usr/bin/python3
from db32 import *

import itertools
from functools import cmp_to_key

class HarvestConfig:
    def __init__(self, name, se_threshold, wgp_threshold):
        self.name = name
        self.se_threshold = se_threshold
        self.wgp_threshold = wgp_threshold
        self.fail = 0
        self.reset()

    def reset(self):
        # It's important to know what SEs and WGPs fail
        self.known_badSEs = []
        self.known_badWGPs = [[] for _ in range(GPU__GC__NUM_SE)]
        # It's only important to know the count of potential SE and WGP fails
            # These are only used to test for invalid configurations
        self.potential_badSEs = 0
        self.potential_badWGPs = [0 for _ in range(GPU__GC__NUM_SE)]

    def addPotentialWGP(self, se_index):
        self.potential_badWGPs[se_index] += 1
        if ((self.potential_badWGPs[se_index] + len(self.known_badWGPs[se_index])) > self.wgp_threshold):
            if (not se_index in self.known_badSEs):
                self.known_badSEs.append(se_index)
            self.known_badWGPs[se_index] = []
            if ((self.potential_badSEs + len(self.known_badSEs)) > self.se_threshold):
                self.fail = 1

    def addBadWGP(self, wgp_index):
        se_index = wgp_index // GPU__GC__NUM_WGP_PER_SE
        self.known_badWGPs[se_index].append(wgp_index)
        if ((self.potential_badWGPs[se_index] + len(self.known_badWGPs[se_index])) > self.wgp_threshold):
            if (not se_index in self.known_badSEs):
                self.known_badSEs.append(se_index)
            self.known_badWGPs[se_index] = []
            if ((self.potential_badSEs + len(self.known_badSEs)) > self.se_threshold):
                self.fail = 1

    def addPotentialSE(self):
        #if the rest of the program is behaving correctly, there should be no WGPs under us yet.
            #if there is any WGP room for this config, this won't fail us.
        if (self.wgp_threshold == 0):
            self.potential_badSEs += 1
            if ((self.potential_badSEs + len(self.known_badSEs)) > self.se_threshold):
                self.fail = 1

class HardwareGroup:
    def __init__(self, base, count, creation_id, parent):
        self.base = base
        self.count = count
        self.creation_id = creation_id
        self.parent = parent
        self.priority = 99

    def split(self, potential_list, new_creation_id):
        pass

    def test(self, test_cmd):
        pass

    def getUnderlyingWGPs(self):
        pass

    def getUnderlyingSE(self):
        pass

    def addFailToConfig(self, config):
        pass

class SEGroup(HardwareGroup):
    def __init__(self, base, count, creation_id, parent):
        super().__init__(base, count, creation_id, parent)
        self.priority = 0

    def split(self, potential_list, new_creation_id):
        if (self.count > 1):
            first_half_count = -(self.count // -2)
            second_half_count = self.count - first_half_count
            potential_list.append(SEGroup(self.base, first_half_count, new_creation_id, self.creation_id))
            potential_list.append(SEGroup(self.base + first_half_count, second_half_count, new_creation_id, self.creation_id))
        else:
            sa_base = self.base * GPU__GC__NUM_SA_PER_SE
            first_half_count = -(GPU__GC__NUM_SA_PER_SE // -2)
            second_half_count = GPU__GC__NUM_SA_PER_SE - first_half_count
            potential_list.append(SAGroup(sa_base, first_half_count, new_creation_id, self.creation_id))
            if (second_half_count != 0):
                potential_list.append(SAGroup(sa_base + first_half_count, second_half_count, new_creation_id, self.creation_id))
        return 0

    def test(self, test_cmd):
        _disable_other_WGPs(self.getUnderlyingWGPs())
        return _test_hardware(test_cmd)

    def getUnderlyingWGPs(self):
        wgp_base = self.base * GPU__GC__NUM_WGP_PER_SE
        wgp_count = self.count * GPU__GC__NUM_WGP_PER_SE
        return range(wgp_base, wgp_base + wgp_count)

    def getUnderlyingSE(self):
        if (self.count == 1):
            return -1
        else:
            return self.base

    def addFailToConfig(self, config):
        if (self.count == 1):
            config.addPotentialWGP(self.base)
        else:
            config.addPotentialSE()

class SAGroup(HardwareGroup):
    def __init__(self, base, count, creation_id, parent):
        super().__init__(base, count, creation_id, parent)
        self.priority = 1

    def split(self, potential_list, new_creation_id):
        if (self.count > 1):
            first_half_count = -(self.count // -2)
            second_half_count = self.count - first_half_count
            potential_list.append(SAGroup(self.base, first_half_count, new_creation_id, self.creation_id))
            potential_list.append(SAGroup(self.base + first_half_count, second_half_count, new_creation_id, self.creation_id))
        else:
            wgp_base = self.base * GPU__GC__NUM_WGP_PER_SA
            first_half_count = -(GPU__GC__NUM_WGP_PER_SA // -2)
            second_half_count = GPU__GC__NUM_WGP_PER_SA - first_half_count
            potential_list.append(WGPGroup(wgp_base, first_half_count, new_creation_id, self.creation_id))
            if (second_half_count != 0):
                potential_list.append(WGPGroup(wgp_base + first_half_count, second_half_count, new_creation_id, self.creation_id))
        return 0

    def test(self, test_cmd):
        _disable_other_WGPs(self.getUnderlyingWGPs())
        return _test_hardware(test_cmd)

    def getUnderlyingWGPs(self):
        wgp_base = self.base * GPU__GC__NUM_WGP_PER_SA
        wgp_count = self.count * GPU__GC__NUM_WGP_PER_SA
        return range(wgp_base, wgp_base + wgp_count)

    def getUnderlyingSE(self):
        return self.base // GPU__GC__NUM_SA_PER_SE

    def addFailToConfig(self, config):
        config.addPotentialWGP(self.getUnderlyingSE())

class WGPGroup(HardwareGroup):
    def __init__(self, base, count, creation_id, parent):
        super().__init__(base, count, creation_id, parent)
        self.priority = 2

    def split(self, potential_list, new_creation_id):
        if (self.count > 1):
            first_half_count = -(self.count // -2)
            second_half_count = self.count - first_half_count
            potential_list.append(WGPGroup(self.base, first_half_count, new_creation_id, self.creation_id))
            potential_list.append(WGPGroup(self.base + first_half_count, second_half_count, new_creation_id, self.creation_id))
            return 0
        else:
            # Cannot split a 1 WGP group, return 1 to signal final failure
            return 1

    def test(self, test_cmd):
        _disable_other_WGPs(self.getUnderlyingWGPs())
        return _test_hardware(test_cmd)

    def getUnderlyingWGPs(self):
        return range(self.base, self.base + self.count)

    def getUnderlyingSE(self):
        return self.base // GPU__GC__NUM_WGP_PER_SE

    def addFailToConfig(self, config):
        if (self.count == 1):
            config.addBadWGP(self.base)
        else:
            config.addPotentialWGP(self.getUnderlyingSE())

def _disable_other_WGPs(wgp_list):
    print("Enabled WGPs: ", wgp_list)
    # start with everything disabled
    WGP_masks = [[0xffff0000 for _ in range(GPU__GC__NUM_SA_PER_SE)] for _ in range (GPU__GC__NUM_SE)]
    RB_disable = [[0x00ff0000 for _ in range(GPU__GC__NUM_SA_PER_SE)] for _ in range (GPU__GC__NUM_SE)]
    SA_disable = 0x0000ff00
    PA_disable = 0x00000ff0
    UTCL2_bypass = 0x000000ff
    # enable each element as we come to it
    for wgp_total_index in wgp_list:
        se_index = wgp_total_index // GPU__GC__NUM_WGP_PER_SE
        sa_total_index = wgp_total_index // GPU__GC__NUM_WGP_PER_SA
        sa_index = sa_total_index % GPU__GC__NUM_SA_PER_SE
        wgp_index = wgp_total_index % GPU__GC__NUM_WGP_PER_SA
        WGP_masks[se_index][sa_index] &= ~(0x1 << (16 + wgp_index))
        RB_disable[se_index][sa_index] = 0x0
        SA_disable &= ~(0x1 << (8 + sa_total_index))
        PA_disable &= ~(0x3 << ((se_index * 2) + 4))
        UTCL2_bypass &= ~(0x3 << (se_index * 2))

    # write values out to hardware
    for se_index in range(GPU__GC__NUM_SE):
        for sa_index in range(GPU__GC__NUM_SA_PER_SE):
            mmw(mmGRBM_GFX_INDEX, (se_index<<16 ) | (sa_index << 8))
            mmw(mmGC_USER_SHADER_ARRAY_CONFIG, WGP_masks[se_index][sa_index])
            mmw(mmGC_USER_RB_BACKEND_DISABLE, RB_disable[se_index][sa_index])

    mmw(mmGRBM_GFX_INDEX, 0xe0000000)

    mmw(mmGC_USER_SA_UNIT_DISABLE, SA_disable)
    mmw(mmGC_USER_PRIM_CONFIG, PA_disable)
    mmw(mmGCUTCL2_HARVEST_BYPASS_GROUPS, UTCL2_bypass)

def _test_hardware(test_cmd):
    # soft reset before testing the hardware
    mmw(mmCP_SOFT_RESET_CNTL, 0x7c)
    mmw(mmGRBM_SOFT_RESET, 0x10001)
    mmw(mmCP_SOFT_RESET_CNTL, 0)
    mmw(mmGRBM_SOFT_RESET, 0x0)

    test_result = subprocess.getstatusoutput(test_cmd)
    if(test_result[0] == 0):
        print("PASS")
    else:
        print("FAIL")
    return test_result[0]

# Old-school sorting; based first on priority, then on count.
def _compare_hardware_groups(a, b):
    if a.priority < b.priority:
        return -1
    elif a.priority == b.priority:
        if a.count > b.count:
            return -1
        elif a.count == b.count:
            return 0
        else:
            return 1
    else:
        return 1

def _harvest_main(test_cmd):

    # Convert the old-school method to Python's newfangled stuff
    sort_key = cmp_to_key(_compare_hardware_groups)

    config_list = [
        HarvestConfig('60CU', 1, 0),
        HarvestConfig('72CU', 0, 1)
    ]

    curr_creation_id = 0
    potential_list = []
    fail_list = []
    pass_list = []
    creation_ids_seen = []
    num_tests = 0
    full_chip = SEGroup(0, GPU__GC__NUM_SE, curr_creation_id, curr_creation_id)
    # Start by splitting the chip in half, as we assume that the chip has some sort of failure already
        # the split function implicitly adds to the global potential list, so this will start the chain
    curr_creation_id += 1
    full_chip.split(potential_list, curr_creation_id)
    while potential_list:
        if not config_list:
            break
        # pull the head of the list off and test it
        curr_group = potential_list.pop(0)
        #before we test, let's check if any config will be possibly changed by the result
        skip_this = 1
        for config in config_list:
            se_index = curr_group.getUnderlyingSE()
            if (not se_index in config.known_badSEs):
                skip_this = 0
        if (skip_this == 1):
            continue
        num_tests += 1
        if (curr_group.test(test_cmd) != 0):
            # if the test fails, we split into the smaller elements to continue searching
            curr_creation_id += 1
            if (curr_group.split(potential_list, curr_creation_id) == 1):
                # if we can't split any more, then this is a single WGP so we add it to the definitely-failed list.
                fail_list.append(curr_group)
        else:
            pass_list.append(curr_group)

        #once we've added new elements to the list, we need to keep it sorted so we check the largest elements first
        potential_list.sort(key=sort_key)

        # make sure to reset the configs so we don't double count anything
        for config in config_list:
            config.reset()

        # Now let's check the fail list for any invalid configurations
        for hardware_group in fail_list:
            if not config_list:
                break
            #add the hardware_group's creation id to the list
            creation_ids_seen.append(hardware_group.creation_id)
            #no need to check the creation ids for failing WGPs
            for config in config_list:
                hardware_group.addFailToConfig(config)
            #remove failing configs
            config_list = [config for config in config_list if (config.fail == 0)]

        # Now let's check the potential list for any invalid configurations
        for hardware_group in potential_list:
            if not config_list:
                break
            #we need to check if we've seen this creation_id before so we don't double count anything.
            if (not ((hardware_group.creation_id in creation_ids_seen) or (hardware_group.parent in creation_ids_seen))):
                for config in config_list:
                    hardware_group.addFailToConfig(config)
                #remove failing configs
                config_list = [config for config in config_list if (config.fail == 0)]
                creation_ids_seen.append(hardware_group.creation_id)

        # reset creation_ids_seen so we can count everything again next loop
        creation_ids_seen = []

    for config in config_list:
        print("Allowed config: ",config.name)
    print("Num tests: ", num_tests)

    if not config_list:
        return 1

    #final check!
    wgps_to_enable = []
    for hardware_group in pass_list:
        for wgp_index in hardware_group.getUnderlyingWGPs():
            wgps_to_enable.append(wgp_index)
    wgps_to_enable.sort()
    print("")
    print("Final check!")
    _disable_other_WGPs(wgps_to_enable)
    final_result = _test_hardware(test_cmd)
    return(final_result != 0)

class harv:
    @staticmethod
    def harvest_main(test_cmd):
        return _harvest_main(test_cmd)