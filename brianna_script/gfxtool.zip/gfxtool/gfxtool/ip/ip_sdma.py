#!/usr/bin/python

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)
from db32 import *
from ip_cpdma import *

class SDMA:
    def __init__(self, instance = 0):
        if instance == 0:
             self.mmSDMA_PIO_COMMAND     =mmSDMA0_PIO_COMMAND
             self.mmSDMA_PIO_CONTROL     =mmSDMA0_PIO_CONTROL
             self.mmSDMA_PIO_SRC_ADDR_LO =mmSDMA0_PIO_SRC_ADDR_LO
             self.mmSDMA_PIO_SRC_ADDR_HI =mmSDMA0_PIO_SRC_ADDR_HI
             self.mmSDMA_PIO_DST_ADDR_LO =mmSDMA0_PIO_DST_ADDR_LO
             self.mmSDMA_PIO_DST_ADDR_HI =mmSDMA0_PIO_DST_ADDR_HI
             self.mmSDMA_PIO_STATUS      =mmSDMA0_PIO_STATUS
        elif var_exist('mmSDMA1_PIO_COMMAND'):
             self.mmSDMA_PIO_COMMAND     =mmSDMA1_PIO_COMMAND
             self.mmSDMA_PIO_CONTROL     =mmSDMA1_PIO_CONTROL
             self.mmSDMA_PIO_SRC_ADDR_LO =mmSDMA1_PIO_SRC_ADDR_LO
             self.mmSDMA_PIO_SRC_ADDR_HI =mmSDMA1_PIO_SRC_ADDR_HI
             self.mmSDMA_PIO_DST_ADDR_LO =mmSDMA1_PIO_DST_ADDR_LO
             self.mmSDMA_PIO_DST_ADDR_HI =mmSDMA1_PIO_DST_ADDR_HI
             self.mmSDMA_PIO_STATUS      =mmSDMA1_PIO_STATUS
    def info(self):
        """dump mmCP_DMA_PIO_*"""
        mmrp(self.mmSDMA_PIO_COMMAND)
        mmrp(self.mmSDMA_PIO_CONTROL)
        mmrp(self.mmSDMA_PIO_SRC_ADDR_LO)
        mmrp(self.mmSDMA_PIO_SRC_ADDR_HI)
        mmrp(self.mmSDMA_PIO_DST_ADDR_LO)
        mmrp(self.mmSDMA_PIO_DST_ADDR_HI)
        mmrp(self.mmSDMA_PIO_STATUS )

    def do(self, src, dst, byte_count, **kw):
        """kw could be(in any order): sas = x, das=x, """
        _k = {"sas":0, "das": 0, "overlap_disable":0, "src_l2_policy":2, "dst_l2_policy":3}
        for key in kw: _k[key] = kw[key]
        if 'src_reuse_hint' in _k : _k["src_l2_policy"] = _k['src_reuse_hint']
        if 'dst_reuse_hint' in _k : _k["dst_l2_policy"] = _k['dst_reuse_hint']
        _command =  byte_count & 0x3ffffff
        _control = 0
        _command = _command | ((_k['overlap_disable']&1)<<30)
        _control = _control | ((_k["src_l2_policy"]&0x3)<<13) | ((_k["dst_l2_policy"]&3)<<25)
        if 'src_comp_en' in kw:
            _control = _control |  (kw['src_comp_en'] << 10)
        if 'dst_comp_en' in kw:
            _control = _control |  (kw['dst_comp_en'] << 24)
        if 'bycp' in kw and kw['bycp'] :
             CPDMA.d2r(_control              , self.mmSDMA_PIO_CONTROL     *4,  4)
             CPDMA.d2r(src & 0xffffffff      , self.mmSDMA_PIO_SRC_ADDR_LO *4,  4)
             CPDMA.d2r((src>>32) & 0xffffffff, self.mmSDMA_PIO_SRC_ADDR_HI *4,  4)
             CPDMA.d2r(dst & 0xffffffff      , self.mmSDMA_PIO_DST_ADDR_LO *4,  4)
             CPDMA.d2r((dst>>32) & 0xffffffff, self.mmSDMA_PIO_DST_ADDR_HI *4,  4)
             CPDMA.d2r( _command             , self.mmSDMA_PIO_COMMAND     *4,  4)
        else:
             db32s = DB32Script()
             db32s.mmw(self.mmSDMA_PIO_CONTROL, _control)
             db32s.mmw(self.mmSDMA_PIO_SRC_ADDR_LO , src & 0xffffffff)
             db32s.mmw(self.mmSDMA_PIO_SRC_ADDR_HI , (src>>32) & 0xffffffff)
             db32s.mmw(self.mmSDMA_PIO_DST_ADDR_LO , dst & 0xffffffff)
             db32s.mmw(self.mmSDMA_PIO_DST_ADDR_HI , (dst>>32) & 0xffffffff)
             db32s.mmw(self.mmSDMA_PIO_COMMAND,  _command)
             db32s.mmr(self.mmSDMA_PIO_COMMAND)
             db32s.run()

    def m2m_bycp(self, src, dst, byte_count, **kw):
        _k = {'sas':0, 'das':0, 'bycp':1}
        for key in kw: _k[key] = kw[key]
        return self.do(src, dst, byte_count, **_k)
    def m2m(self, src, dst, byte_count, **kw):
        _k = {'sas':0, 'das':0}
        for key in kw: _k[key] = kw[key]
        return self.do(src, dst, byte_count, **_k)

    def do1(self, src, dst,
        byte_count, sas = 0, das=0, saic=0, daic=0, raw_wait=0, dis_wc=0,
        memlog_clear=0, src_cache_policy=0, src_volatle=0, dst_sel=0, dst_cache_policy=0, dst_volatle=0, src_sel=0):
        pass

sdma0 = SDMA(0)
SDMA0 = sdma0

if var_exist('mmSDMA1_PIO_COMMAND'):
  sdma1 = SDMA(1)
  SDMA1 = sdma1
