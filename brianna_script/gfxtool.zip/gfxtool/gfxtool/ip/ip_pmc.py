#!/usr/bin/python3
from db32 import *
from ip_reg import *

class PMC:
    ''' param counters : list of counter
        counter can be tuple(slot, counter, name), or counter's id
    '''
    def __init__(self, *counters):
        self.counters = [] # counter: [slot, counter, mmPERFCOUNTER_SELECT, mmLO]
        self.mmPERFCOUNTER0_SELECT = self.mmBase[0]
        self.mmPERFCOUNTER0_LO = self.mmBase[1]
        self.names = {}
        curSlot = 0
        for counter in counters:
            myName = "PMC"
            if isNumber(counter):
                myCounter = counter
            else: # must be tuple or array
                curSlot = counter[0]
                myCounter = counter[1]
                if len(counter) > 2 :myName = counter[2]
            mySELECT = self.mmPERFCOUNTER0_SELECT + curSlot
            myLO = self.mmPERFCOUNTER0_LO + curSlot * 2
            self.counters.append([curSlot, myCounter, mySELECT, myLO, myName])
            curSlot = curSlot + 1
        self.updateName(self.__class__.__name__)
    def read_all(self, mmreg):
        Fmt.bad("Error")
    @staticmethod
    def enablePMC():
        if var_exist('mmRLC_RLCS_PERFMON_CLK_CNTL_UCODE'): mmw(mmRLC_RLCS_PERFMON_CLK_CNTL_UCODE, 1)
        if var_exist('mmRLC_PERFMON_CLK_CNTL'):
            mmw(mmRLC_PERFMON_CLK_CNTL, 1)
        else:
            r = mmr(mmRLC_CGTT_MGCG_OVERRIDE)
            r = r | (1<<10)
            mmw(mmRLC_CGTT_MGCG_OVERRIDE, r)

        mmw(mmCOMPUTE_PERFCOUNT_ENABLE, 1)

    def get(self, doPrint = True, **kw):
        ret = {}
        detail = kw['detail'] if 'detail' in kw else False
        for counter in self.counters:
            slot = counter[0]
            counterid = counter[1]
            myLO = counter[3]
            myHI = myLO + 1
            lo = self.read_all(myLO)
            hi = self.read_all(myHI)
            v = UserList([x[0] + (x[1] << 32) for x in zip(lo, hi)])
            if doPrint:
                print("Counter %d : %d"%(counterid, sum(v)))
                if detail: hexprint(v)
            ret[counterid] = v
        return ret
    def disable(self):
        if var_exist('mmRLC_PERFMON_CLK_CNTL'): mmw(mmRLC_PERFMON_CLK_CNTL, 0)
        if var_exist('mmRLC_RLCS_PERFMON_CLK_CNTL_UCODE'): mmw(mmRLC_RLCS_PERFMON_CLK_CNTL_UCODE, 0)
        mmw(mmCP_PERFMON_CNTL, 2) # stop
        for counter in self.counters:
            counterid = counter[1]
            myPERFCOUNTER_SELECT = counter[2]
            mmw(myPERFCOUNTER_SELECT, 0) # remove from PERFCOUNTER_SELECT
    def enable(self):
        mmw(mmGRBM_GFX_INDEX, 0xE0000000)
        v = mmr(mmSQ_PERFCOUNTER_CTRL)
        v = v | 0x7F  #All Shader stages
        mmw(mmSQ_PERFCOUNTER_CTRL, v)
        mmw(mmSQ_PERFCOUNTER_CTRL2, 0x1ffff) # FORCE_EN=1
        for counter in self.counters:
            counterid = counter[1]
            myPERFCOUNTER_SELECT = counter[2]
            mmw(myPERFCOUNTER_SELECT, counterid)
    def run(self, cmd, **kwargs):
        if 'reset' in kwargs and  kwargs['reset'] : self.reset()
        self.enable()
        PMC.start()
        errLeft0,bL = subprocess.getstatusoutput(cmd)
        print(str(bL))
        PMC.stop()
        ret = self.get()
        return ret

    if var_exist('mmWGS_PERFMON_CNTL'):
        @staticmethod
        def sample_and_start():
              mmw(mmCP_PERFMON_CNTL, 0x401) #sample and sart
              mmw(mmWGS_PERFMON_CNTL, 0x401) #sample and sart
        @staticmethod
        def start():
            PMC.enablePMC()
            mmw(mmCP_PERFMON_CNTL, 1)
            mmw(mmWGS_PERFMON_CNTL, 1)
        @staticmethod
        def stop():
            v = mmr(mmCP_PERFMON_CNTL)
            if v != 1 : Fmt.bad("mmCP_PERFMON_CNTL is not starting, is it cleared by someone?")
            PMC.sample()
            mmw(mmCP_PERFMON_CNTL, 0x2)
            mmw(mmWGS_PERFMON_CNTL, 0x2)
        @staticmethod
        def sample(self):
            mmw(mmCP_PERFMON_CNTL, 0x402)
            mmw(mmWGS_PERFMON_CNTL, 0x402)
        @staticmethod
        def reset(self):
            mmw(mmCP_PERFMON_CNTL, 0)
            mmw(mmWGS_PERFMON_CNTL, 0)
            mmw(mmGCEA_PERFCOUNTER_RSLT_CNTL, 0x3000000)

    else:
        @staticmethod
        def sample_and_start():
              mmw(mmCP_PERFMON_CNTL, 0x401) #sample and sart
        @staticmethod
        def start(self):
            PMC.enablePMC()
            mmw(mmCP_PERFMON_CNTL, 1)
        @staticmethod
        def stop(self):
            v = mmr(mmCP_PERFMON_CNTL)
            if v != 1 : Fmt.bad("mmCP_PERFMON_CNTL is not starting, is it cleared by someone?")
            self.sample()
            mmw(mmCP_PERFMON_CNTL, 0x2)
        @staticmethod
        def sample(self):
            mmw(mmCP_PERFMON_CNTL, 0x402)
        @staticmethod
        def reset(self):
            mmw(mmCP_PERFMON_CNTL, 0)
            mmw(mmGCEA_PERFCOUNTER_RSLT_CNTL, 0x3000000)


    def watch(self, **kw):
      watch(self, **kw)
      return

    def dump(self, *rs, **kw):
      dump(self, *rs, **kw)
      return
    def updateName(self, blkname):
        for counter in self.counters:
            name = "%s:%s(pmc%d)"%(blkname, counter[4], counter[1])
            counter[4] = name
            self.names[counter[1]] = name

    def run_and_watch(self, cmd,  **kw):
        detail = kw['detail'] if 'detail' in kw else False
        self.enable()
        PMC.start()
        cmds = cmd.split()
        if cmds[0] == 'sudo': cmds = cmds[1:]
        p = subprocess.Popen(cmds, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        os.set_blocking(p.stdout.fileno(), False)
        pout = []
        def one():
          PMC.sample_and_start()
          d = self.get(False)
          s = ""
          for k,v in d.items():
              details = '' if not detail else Fmt.hexall(v)
              s = s + ("%8s : "%self.name(k)) + Fmt.hexall(sum(v)) + details + "\n"
          #s = s + Fmt.hexall(self.counters)
          for i in range(0,16):
              line = p.stdout.readline().decode("utf-8")
              if line == "": break
              pout.append(line)
          return s + '\n-----------------------------\n' + "".join(pout[-16:])
        stall_seconds = kw['sleep'] if 'sleep' in kw else 0.5
        watchon(one, stall_seconds)
        self.disable()
    def name(self, i): return self.names[i] #"SQ_%d"%i

class SQ(PMC):
    def __init__(self, *cnts):
       self.mmBase = [mmSQ_PERFCOUNTER0_SELECT, mmSQ_PERFCOUNTER0_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
          counter[2] = self.mmPERFCOUNTER0_SELECT + slot
          counter[3] = self.mmPERFCOUNTER0_LO + slot * 2
    def read_all(self, mmreg):
        lo = EACH().se(mmreg)
        return lo
    def enable(self):
        if len(self.counters) > 16: Fmt.bad("SQ has 16 counters")
        mmw(mmGRBM_GFX_INDEX, 0xE0000000)
        v = mmr(mmSQ_PERFCOUNTER_CTRL)
        v = v | 0x7F  #All Shader stages
        mmw(mmSQ_PERFCOUNTER_CTRL, v)
        mmw(mmSQ_PERFCOUNTER_CTRL2, 0x1ffff) # FORCE_EN=1
        for counter in self.counters:
            slot = counter[0]
            counterid = counter[1]
            myPERFCOUNTER_SELECT = counter[2]
            # 0:8 counter;  12:15 SQC_BANk_MASK  16:19 SQC_CLIENT_MASK
            # 20:23 SPM_MODE 24:27 SIMD_MASK 28:31 PERF_MODE
            v = counterid | (0xff << 12) |  (0xf << 24)
            mmw(myPERFCOUNTER_SELECT, v)

class SPI(PMC):
    def __init__(self, *cnts):
       self.mmBase = [mmSPI_PERFCOUNTER0_SELECT, mmSPI_PERFCOUNTER0_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
          counter[2] = self.mmPERFCOUNTER0_SELECT + slot
          counter[3] = self.mmPERFCOUNTER0_LO + slot * 2
    def read_all(self, mmreg):
        lo = EACH().se(mmreg)
        return lo

class CB(PMC):
    def __init__(self, *cnts):
       self.mmBase = [mmCB_PERFCOUNTER0_SELECT, mmCB_PERFCOUNTER0_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
          myPERFCOUNTER_SELECT = self.mmPERFCOUNTER0_SELECT + slot
          if slot > 0: myPERFCOUNTER_SELECT = myPERFCOUNTER_SELECT + 1
          counter[2] = myPERFCOUNTER_SELECT
          counter[3] = self.mmPERFCOUNTER0_LO + slot * 2
       if len(self.counters) > 4: Fmt.bad("CB has 4 counters")
    def read_all(self, mmreg):
        lo = EACH(i=2).i(mmreg)
        return lo


class DB(PMC):
    def __init__(self, *cnts):
       self.mmBase = [mmDB_PERFCOUNTER0_SELECT, mmDB_PERFCOUNTER0_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
          myPERFCOUNTER_SELECT = self.mmPERFCOUNTER0_SELECT + slot
          if slot > 0: myPERFCOUNTER_SELECT = myPERFCOUNTER_SELECT + 1
          counter[2] = myPERFCOUNTER_SELECT
          counter[3] = self.mmPERFCOUNTER0_LO + slot * 2
       if len(self.counters) > 4: Fmt.bad("CB has 4 counters")
    def read_all(self, mmreg):
        lo = EACH(i=2).i(mmreg)
        return lo

class GL2C(PMC):
    def __init__(self, *cnts):
       if GFX_IP_MAJOR == 9:
          self.mmBase = [mmTCC_PERFCOUNTER0_SELECT, mmTCC_PERFCOUNTER0_LO]
          mmSelects = [mmTCC_PERFCOUNTER0_SELECT, mmTCC_PERFCOUNTER1_SELECT, mmTCC_PERFCOUNTER2_SELECT, mmTCC_PERFCOUNTER3_SELECT]
       else:
          self.mmBase = [mmGL2C_PERFCOUNTER0_SELECT, mmGL2C_PERFCOUNTER0_LO]
          mmSelects = [mmGL2C_PERFCOUNTER0_SELECT, mmGL2C_PERFCOUNTER1_SELECT, mmGL2C_PERFCOUNTER2_SELECT, mmGL2C_PERFCOUNTER3_SELECT]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
          myPERFCOUNTER_SELECT = mmSelects[slot]
          counter[2] = myPERFCOUNTER_SELECT
          counter[3] = self.mmPERFCOUNTER0_LO + slot * 2
       if len(self.counters) > 4: Fmt.bad("GL2C(TCC) has 4 counters")
    def read_all(self, mmreg):
        lo = EACH().tcc(mmreg)
        return lo
TCC=GL2C

class GL1C(PMC):
    def __init__(self, *cnts):
       self.mmBase = [mmGL1C_PERFCOUNTER0_SELECT, mmGL1C_PERFCOUNTER0_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
          myPERFCOUNTER_SELECT = self.mmPERFCOUNTER0_SELECT + slot
          if slot > 0: myPERFCOUNTER_SELECT = myPERFCOUNTER_SELECT + 1
          counter[2] = myPERFCOUNTER_SELECT
          counter[3] = self.mmPERFCOUNTER0_LO + slot * 2
       if len(self.counters) > 4: Fmt.bad("CB has 4 counters")
    def read_all(self, mmreg):
        lo = EACH(i=GC__NUM_GL1C_PER_SA).i(mmreg)
        return lo


class TCP(PMC):
    def __init__(self, *cnts):
       self.mmBase = [mmTCP_PERFCOUNTER0_SELECT, mmTCP_PERFCOUNTER0_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
          myPERFCOUNTER_SELECT = self.mmPERFCOUNTER0_SELECT + slot
          if slot > 0: myPERFCOUNTER_SELECT = myPERFCOUNTER_SELECT + 1
          if slot > 1: myPERFCOUNTER_SELECT = myPERFCOUNTER_SELECT + 1
          counter[2] = myPERFCOUNTER_SELECT
          counter[3] = self.mmPERFCOUNTER0_LO + slot * 2
       if len(self.counters) > 4: Fmt.bad("CB has 4 counters")
    def read_all(self, mmreg):
        lo = EACH().tcp(mmreg)
        return lo

class EA(PMC):
    def __init__(self, *cnts):
       self.mmBase = [mmGCEA_PERFCOUNTER0_CFG, mmGCEA_PERFCOUNTER_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
          myPERFCOUNTER_SELECT = self.mmPERFCOUNTER0_SELECT + slot
          counter[2] = myPERFCOUNTER_SELECT
          counter[3] = self.mmPERFCOUNTER0_LO + slot * 2 # hack: there is GC_EA:GCEA_PERFCOUNTER_LO only for pmc

       if len(self.counters) > 2: Fmt.bad("EA has 1 counters")
       mmw(mmGCEA_PERFCOUNTER_RSLT_CNTL, 0x1000000)
    def enable(self):
        mmw(mmGRBM_GFX_INDEX, 0xE0000000)
        for counter in self.counters:
            counterid = counter[1]
            myPERFCOUNTER_SELECT = counter[2]
            mmw(myPERFCOUNTER_SELECT, counterid | (1<<28))
            #print("%x"%myPERFCOUNTER_SELECT, "%x"%(counterid | (1<<28)) , "%x"%(counter[3]))
    def read_all(self, mmreg):
        if (mmreg == mmGCEA_PERFCOUNTER_LO) or (mmreg == mmGCEA_PERFCOUNTER_HI) :
           mmw(mmGCEA_PERFCOUNTER_RSLT_CNTL, 0x1000000)
           lo = EACH().tcc(mmreg)
        else:
           mmw(mmGCEA_PERFCOUNTER_RSLT_CNTL, 0x1000001)
           lo = EACH().tcc(mmreg-2)
        return lo

class UTCL1(PMC):
    def __init__(self, *cnts):
       self.mmBase = [mmUTCL1_PERFCOUNTER0_SELECT, mmUTCL1_PERFCOUNTER0_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
       if len(self.counters) > 4: Fmt.bad("UTCL1 has 4 counters")
    def read_all(self, mmreg):
        lo = EACH().se(mmreg)
        return lo
if var_exist('mmWGS_PERFMON_CNTL'):
  class WGS(PMC):
    def __init__(self, *cnts):
       # WGS_PERFCOUNTER1_SELECT:0x376cc//4  WGS_PERFCOUNTER0_SELECT:376c0//4
       # WGS_PERFCOUNTER1_LO:0x356c8//4      WGS_PERFCOUNTER0_LO::456c00//4
       self.mmBase = [mmWGS_PERFCOUNTER1_SELECT, mmWGS_PERFCOUNTER1_LO]
       super().__init__(*cnts)
       for counter in self.counters:
          slot = counter[0]
       if len(self.counters) > 2: Fmt.bad("UTCL1 has 4 counters")
    def read_all(self, mmreg):
        lo = EACH().se(mmreg)
        return lo

def watch(*rs, **kw):
      has_wgs = var_exist('mmWGS_PERFMON_CNTL')
      for block in rs: block.enable()
      PMC.enablePMC()
      detail = kw['detail'] if 'detail' in kw else False
      def one():
          PMC.sample_and_start()
          if has_wgs: mmw(mmWGS_PERFMON_CNTL, 0x401)
          mmw(mmCOMPUTE_PERFCOUNT_ENABLE, 1)
          s = ""
          for block in rs:
             d = block.get(False)
             for k,v in d.items():
                details = '' if not detail else Fmt.hexall(v)
                s = s + ("%8s : "%block.name(k)) + Fmt.hexall(sum(v)) + details + "\n"
          return s
      stall_seconds = kw['sleep'] if 'sleep' in kw else 0.5
      watchon(one, stall_seconds)
      for block in rs: block.disable()

def watchxcc(*rs, **kw):
      def init(xccid):
          for block in rs: block.enable()
          PMC.enablePMC()
      each.xcc(init)
      detail = kw['detail'] if 'detail' in kw else False
      def one(xcc):
          PMC.sample_and_start()
          mmw(mmCOMPUTE_PERFCOUNT_ENABLE, 1)
          s = ""
          for block in rs:
             d = block.get(False)
             for k,v in d.items():
                details = '' if not detail else Fmt.hexall(v)
                s = s + ("%8s : "%block.name(k)) + Fmt.hexall(sum(v)) + details + "\n"
          return s
      stall_seconds = kw['sleep'] if 'sleep' in kw else 0.5
      watchonXCC(one, [], stall_seconds)
      def deinit(xccid):
          for block in rs: block.disable()
      each.xcc(deinit)


def dump(*rs, **kw):
      for block in rs: block.enable()
      PMC.enablePMC()
      detail = kw['detail'] if 'detail' in kw else False
      if sys.version_info.major >= 3 and sys.version_info.minor >= 7:
          def gettime(): return time.time_ns()
      else:
          def gettime(): return int(time.time() * 1000000)

      if detail:
          def one():
              PMC.sample_and_start()
              mmw(mmCOMPUTE_PERFCOUNT_ENABLE, 1)
              s = [gettime()]
              for block in rs:
                 d = block.get(False)
                 for k,v in d.items():
                     s.append(sum(v))
                     s.extend(v)
              return s
          def tostr(outarray):
              s = ['              ns']
              for block in rs:
                 d = block.get(False)
                 for k,v in d.items():
                     nm = block.name(k)
                     s.append("%16s"%block.name(k))
                     for _i in range(len(v)):s.append("%16s"%("%s:%d"%(nm,_i)))
              ostr = '\n'.join([','.join(["%16d"%b for b in a]) for a in outarray])
              return ','.join(s) + '\n' +  ostr
      else:
          def one():
              PMC.sample_and_start()
              s = [gettime()]
              for block in rs:
                 d = block.get(False)
                 for k,v in d.items():
                     s.append(sum(v))
              return s
          def tostr(outarray):
              s = ['              ns']
              for block in rs:
                 d = block.get(False)
                 for k,v in d.items():
                     s.append("%16s"%block.name(k))
              ostr = '\n'.join([','.join(["%16d"%b for b in a]) for a in outarray])
              return ','.join(s) + '\n' +  ostr
      stall_seconds = kw['sleep'] if 'sleep' in kw else 0.5
      dumpon(one, "pmc.dump.txt", tostr, stall_seconds)
      for block in rs: block.disable()


def info():
        mmrp(mmCP_PERFMON_CNTL)
        if var_exist('mmRLC_PERFMON_CLK_CNTL'):mmrp(mmRLC_PERFMON_CLK_CNTL)
        mmrp(mmRLC_CGTT_MGCG_OVERRIDE)
        mmrp(mmSQ_PERFCOUNTER_CTRL)
        mmrp(mmCOMPUTE_PERFCOUNT_ENABLE)
