#!/usr/bin/python
from db32 import *
if GFX_IP_MAJOR == 9:
    from sqind_offset_gfx9 import *
elif GFX_IP_MAJOR == 10:
    from sqind_offset_gfx10 import *
elif GFX_IP_MAJOR == 11:
    from sqind_offset_gfx11 import *
else:
    from sqind_offset_gfx12 import *

ixSQ_WAVE_NULL                   = 0x0000
SQ_IND_CMD_CMD_NULL              = 0x0000
SQ_IND_CMD_CMD_SETHALT           = 0x0001
SQ_IND_CMD_CMD_SAVECTX           = 0x0002
SQ_IND_CMD_CMD_KILL              = 0x0003
SQ_IND_CMD_CMD_DEBUG             = 0x0004
SQ_IND_CMD_CMD_TRAP              = 0x0005
SQ_IND_CMD_CMD_SET_SPI_PRIO      = 0x0006
SQ_IND_CMD_CMD_SETFATALHALT      = 0x0007
SQ_IND_CMD_CMD_SINGLE_STEP       = 0x0008
SQ_IND_CMD_MODE_SINGLE           = 0x0000
SQ_IND_CMD_MODE_BROADCAST        = 0x0001
SQ_IND_CMD_MODE_BROADCAST_QUEUE  = 0x0002
SQ_IND_CMD_MODE_BROADCAST_PIPE   = 0x0003
SQ_IND_CMD_MODE_BROADCAST_ME     = 0x0004

class SQ:
  allwaves = 'all'
  allsimds = 'all'
  if GFX_IP_MAJOR == 9:
      @staticmethod
      def select(index, waveid=0, threadid=0, simdid=0):
          mmw(mmSQ_IND_INDEX, (waveid << 0) | (simdid << 4) | (threadid << 6) | (index << 16))
  else:
      @staticmethod
      def select(index, waveid=0, threadid=0, simdid=0):
          mmw(mmSQ_IND_INDEX, (waveid << 0) | (threadid << 5) | (index << 16))
  @staticmethod
  def dumpSQINDGFX9(index, waveid=0, threadid=0, simdid=0, **kw):
      waveid_range = range(waveid,waveid+1) if waveid != 'all' else range(0,GC__NUM_WAVES_PER_SIMD)
      simdid_range = range(simdid,simdid+1) if simdid != 'all' else range(0,4)
      threadid_range = range(threadid, threadid+1) if threadid != 'all' else range(0,64)
      use_db32S = False
      if 'db32script' in kw and kw['db32script']: use_db32S = True
      if db32S != None and use_db32S:
          db32s = DB32Script()
          def onecu():
              for simdid in simdid_range:
                  for threadid in threadid_range:
                      for waveid in waveid_range:
                          sq_ind_index = (waveid << 0) | (simdid << 4) | (threadid << 6) | (index << 16)
                          cmd = "mmw(mmSQ_IND_INDEX, 0x%X);mmr(mmSQ_IND_DATA)" % sq_ind_index
                          localcmd = db32s.checkcmd(cmd)
                          db32s.internalcmd(cmd, localcmd)
          ret = EACH(db32=db32s).cuexisting(onecu)
          #r = db32s.last_output
          #rv = rvmaparray(r)
          #dumpmaparray(rv)
          #ret = rv[mmSQ_IND_DATA] if mmSQ_IND_DATA in rv else []
          return ret
      else:
          ret = []
          def onecu():
              for simdid in simdid_range:
                  for threadid in threadid_range:
                      for waveid in waveid_range:
                          sq_ind_index = (waveid << 0) | (simdid << 4) | (threadid << 6) | (index << 16)
                          mmw(mmSQ_IND_INDEX, sq_ind_index)
                          v = mmr(mmSQ_IND_DATA)
                          ret.append(v)
          each.cuexisting(onecu)
          return ret

  @staticmethod
  def dumpSQINDGFX10(index, waveid=0, threadid=0, obseleted=0, **kw):
      waveid_range = range(waveid,waveid+1) if waveid != 'all' else range(0,GC__NUM_WAVES_PER_SIMD)
      threadid_range = range(threadid, threadid+1) if threadid != 'all' else range(0,64)
      db32s = DB32Script()
      def onesimd():
          for waveid in waveid_range:
              for threadid in threadid_range:
                      sq_ind_index = (waveid << 0) | (threadid << 5) | (index << 16)
                      cmd = "mmw(mmSQ_IND_INDEX, 0x%X);mmr(mmSQ_IND_DATA)" % sq_ind_index
                      db32s.myexec(cmd)
      ret = EACH(db32=db32s).simd(onesimd)
      #r = db32s.last_output
      #rv = rvmaparray(r)
      #dumpmaparray(rv)
      #ret = rv[mmSQ_IND_DATA]
      return ret

  if GFX_IP_MAJOR == 9:
     @staticmethod
     def dumpSQIND(index, waveid=0, threadid=0, simdid=0, **kw): return SQ.dumpSQINDGFX9(index,waveid,threadid,simdid, **kw)
  else:
     @staticmethod
     def dumpSQIND(index, waveid=0, threadid=0, obseleted=0, **kw): return SQ.dumpSQINDGFX10(index,waveid,threadid,obseleted, **kw)

  @staticmethod
  def cmd(cmd, mode = 1, **kwargs):
      _cmd = cmd | (mode<<4)
      if GFX_IP_MAJOR >= 10:
          if 'wave'  in kwargs: _cmd = _cmd | ((kwargs['wave'] & 0x1f) << 16)
          if 'queue' in kwargs: _cmd = _cmd | ((kwargs['queue']& 0x3) << 24)
          if 'vmid'  in kwargs: _cmd = _cmd | ((kwargs['vmid'] & 0xf) << 28)
          if 'data'  in kwargs: _cmd = _cmd | ((kwargs['data'] & 0xf) << 8)
      else:
          if 'wave'  in kwargs: _cmd = _cmd | ((kwargs['wave'] & 0xf) << 16)
          if 'queue' in kwargs: _cmd = _cmd | ((kwargs['queue']& 0x3) << 24)
          if 'vmid'  in kwargs: _cmd = _cmd | ((kwargs['vmid'] & 0xf) << 28)
          if 'data'  in kwargs: _cmd = _cmd | ((kwargs['data'] & 0xf) << 8)
          if 'simd'  in kwargs: _cmd = _cmd | ((kwargs['simd'] & 0x3) << 20)
      if 'se'  in kwargs or 'cu' in kwargs or 'wgp' in kwargs:
          if GFX_IP_MAJOR == 9:
              mmw(mmGRBM_GFX_INDEX, ((kwargs['se'] << 16) | (kwargs['cu'])))
          else:
              mmw(mmGRBM_GFX_INDEX, ((kwargs['se'] << 16) | (kwargs['cu'] << 2)))
          print("SQ_CMD 0x%x"%_cmd)
          mmw(mmSQ_CMD, _cmd)
          mmw(mmGRBM_GFX_INDEX, 0xE0000000)
      else:
          print("SQ_CMD 0x%x"%_cmd)
          mmw(mmSQ_CMD, _cmd)
  @staticmethod
  def kill(mode = 1  , **kwargs): SQ.cmd(3, mode, **kwargs)
  @staticmethod
  def halt(mode = 1  , **kwargs): SQ.cmd(1, mode, data = 1, **kwargs)
  @staticmethod
  def resume(mode = 1, **kwargs): SQ.cmd(1, mode, data = 0, **kwargs)
  @staticmethod
  def save(mode = 1  , **kwargs): SQ.cmd(2, mode, **kwargs)
  @staticmethod
  def trap(mode = 1  , **kwargs):
      if not 'data' in kwargs : kwargs['data'] = 1
      SQ.cmd(5, mode, **kwargs)
  @staticmethod
  def debug(mode = 1 , **kwargs):
      if not 'data' in kwargs : kwargs['data'] = 1
      SQ.cmd(4, mode, **kwargs)
  @staticmethod
  def next(mode = 1  , **kwargs):
      if not 'data' in kwargs : kwargs['data'] = 1
      SQ.cmd(8, mode, **kwargs)

  @staticmethod
  def dumpVGPR():
      dumpSQIND(0x15,1,0x13 , 2)
      dumpSQIND(0x400 + 29,1,0x13, 2)
      dumpSQIND(0x400 + 65,1,0x13, 2)
  @staticmethod
  def dumpVGPR33():
      dumpSQIND(0x15,0,0x16, 1)
      dumpSQIND(0x400 + 33,0,0x16,1)
      dumpSQIND(0x400 + 69,0,0x16,1)

  @staticmethod
  def vgpr_location(vgpr, hw_id, sq_wave_gpr_alloc, threadid):
      banktable = [[0,2,1,3], [1,3,2,0],[2,0,3,1],[3,1,0,2]]
      location_in_row_bank = vgpr + (sq_wave_gpr_alloc & 0xff)*4
      location_in_row_bank = location_in_row_bank & 0xff
      row = threadid // 16
      bank = banktable[location_in_row_bank&0x3][(threadid & 0xf)//4]
      logic_in_tile  = location_in_row_bank * 4 + (threadid &0x3)
      logic_addr = (row*4+bank)*1024 + logic_in_tile
      return row,bank,location_in_row_bank,logic_addr

