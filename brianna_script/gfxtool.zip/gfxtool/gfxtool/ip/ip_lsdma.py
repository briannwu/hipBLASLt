#!/usr/bin/python

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)
from db32 import *

mmLSDMA_PIO_COMMAND = 0x451b4 // 4
mmLSDMA_PIO_CONTROL = 0x451bc // 4
mmLSDMA_PIO_CONSTFILL_DATA = 0x451b8 // 4
mmLSDMA_PIO_SRC_ADDR_LO = 0x451a4 // 4
mmLSDMA_PIO_SRC_ADDR_HI = 0x451a8 // 4
mmLSDMA_PIO_DST_ADDR_LO = 0x451ac // 4
mmLSDMA_PIO_DST_ADDR_HI = 0x451b0 // 4
mmLSDMA_PIO_STATUS      = 0x450c8 // 4

class LSDMA:
    @staticmethod
    def info():
        """dump mmCP_DMA_PIO_*"""
        mmrp(mmLSDMA_PIO_COMMAND)
        mmrp(mmLSDMA_PIO_CONTROL)
        mmrp(mmLSDMA_PIO_CONSTFILL_DATA)
        mmrp(mmLSDMA_PIO_SRC_ADDR_LO)
        mmrp(mmLSDMA_PIO_SRC_ADDR_HI)
        mmrp(mmLSDMA_PIO_DST_ADDR_LO)
        mmrp(mmLSDMA_PIO_DST_ADDR_HI)
        mmrp(mmLSDMA_PIO_STATUS )

    @staticmethod
    def do(src, dst, byte_count, **kw):
        """kw could be(in any order): sas = x, das=x, """
        _k = {"sas":0, "das": 0, "overlap_disable":0, "constant_fill":0, "vmid":0, "gpa":0, "sys":0, "gcc":0, "snoop":0}
        for key in kw: _k[key] = kw[key]
        _command =  byte_count & 0x3ffffff
        _control = 0
        _command = _command | ((_k['overlap_disable']&1)<<30) | ((_k['constant_fill']&1)<<31)
        _control = _control | ((_k["vmid"]&0xf)<<0) | ((_k["gpa"]&1)<<4) | ((_k['sys']&1)<<5)
        _control = _control | ((_k['gcc']&1)<<6) | ((_k['snoop']&1)<<7)
        db32s = DB32Script()

        db32s.mmw(mmLSDMA_PIO_CONTROL, _control)
        if (_k['constant_fill']&1) : db32s.mmw(mmLSDMA_PIO_CONSTFILL_DATA, src & 0xffffffff)
        db32s.mmw(mmLSDMA_PIO_SRC_ADDR_LO , src & 0xffffffff)
        db32s.mmw(mmLSDMA_PIO_SRC_ADDR_HI , (src>>32) & 0xffffffff)
        db32s.mmw(mmLSDMA_PIO_DST_ADDR_LO , dst & 0xffffffff)
        db32s.mmw(mmLSDMA_PIO_DST_ADDR_HI , (dst>>32) & 0xffffffff)
        db32s.mmw(mmLSDMA_PIO_COMMAND,  _command)
        db32s.mmr(mmLSDMA_PIO_COMMAND)
        db32s.run()

    @staticmethod
    def d2m(src, dst, byte_count, **kw):
        _k = {'constant_fill':1}
        for key in kw: _k[key] = kw[key]
        return LSDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def m2m(src, dst, byte_count, **kw):
        _k = {'sas':0, 'das':0}
        for key in kw: _k[key] = kw[key]
        return LSDMA.do(src, dst, byte_count, **_k)

    @staticmethod
    def do1(src, dst,
        byte_count, sas = 0, das=0, saic=0, daic=0, raw_wait=0, dis_wc=0,
        memlog_clear=0, src_cache_policy=0, src_volatle=0, dst_sel=0, dst_cache_policy=0, dst_volatle=0, src_sel=0):
        pass

lsdma = LSDMA()
