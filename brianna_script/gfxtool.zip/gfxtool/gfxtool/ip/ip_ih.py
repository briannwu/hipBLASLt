#!/usr/bin/python
from __future__ import print_function
from db32 import *
import random
import logging
from chip_registers import *
from ip_gds import *
from ip_mm import *
from ip_rb import *
from ip_reg import *
from settings import *

class IH:
    '''
    e.g.
    '''
    def __init__(self):
        pass

    def info(self):
        mmrp(mmIH_INT_FLAGS)
        mmrp(mmIH_FIRST_INT_INFO0)
        mmrp(mmIH_LAST_INT_INFO0)
        mmrp(mmIH_RB_BASE)
        mmrp(mmIH_RB_BASE_HI)
        mmrp(mmIH_RB_WPTR)
        mmrp(mmIH_RB_RPTR)
        mmrp(mmIH_RB_BASE_RING1)
        mmrp(mmIH_RB_BASE_HI_RING1)
        mmrp(mmIH_RB_WPTR_RING1)
        mmrp(mmIH_RB_RPTR_RING1)
        self.RB = (mmr(mmIH_RB_BASE) +  (mmr(mmIH_RB_BASE_HI) <<32 ) ) << 8 
        self.wptr = (mmr(mmIH_RB_WPTR) >> 2) &0xffff
        if self.RB >0 and self.wptr > 0:
            allints = mm.readp(self.RB, self.wptr)
            self.parseall(allints)
    def parseone(self, myint):
        '''
            uint32_t ClientId : 8;
            uint32_t IntSrcId : 8;
            uint32_t RingId : 8;
            uint32_t Vmid : 4;
            uint32_t Reserved1 : 3;
            uint32_t VmidType : 1;
            uint32_t Timestamp1;
            uint32_t Timestamp2 : 16;
            uint32_t Reserved2 : 15;
            uint32_t TimestampSrc : 1;
            uint32_t Pasid : 16;
            uint32_t Reserved3 : 16;
            uint32_t SrcData[4];
        '''
        clientid = myint[0] & 0xf
        srctid   = (myint[0]>>8) & 0xff
        ringid   = (myint[0]>>16)& 0xff 
        vimid    = (myint[0]>>24)& 0xf 
        return (clientid, srctid, ringid, vimid)
    def parseall(self, myints):
        nint = len(myints)
        n = nint // 8
        for i in range(0, n):
           oneint = self.parseone(myints[i*8:i*8+1])
           print("ClientId:%02x IntSrcId:%02x RingId:%02x Vmid:%02x"%oneint)
