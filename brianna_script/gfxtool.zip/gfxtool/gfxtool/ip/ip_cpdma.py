#!/usr/bin/python

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)
from db32 import *

"""
m  : memory  (src_sel:0 sas:0) (dst_sel:0 das:0)
r  : register(src_sel:0 sas:1) (dst_sel:0 das:1)
l2 or nowhere :                (dst_sel:2  dst_nowhere)
l2m: addr_using_l2 (src_sel:3) (dst_sel:3)
gds:         (src_sel:1)       (dst_sel:1)
"""
class CPDMA:
    @staticmethod
    def info():
        """dump mmCP_DMA_PIO_*"""
        mmrp(mmCP_DMA_PIO_CONTROL)
        mmrp(mmCP_DMA_PIO_SRC_ADDR)
        mmrp(mmCP_DMA_PIO_SRC_ADDR_HI)
        mmrp(mmCP_DMA_PIO_DST_ADDR)
        mmrp(mmCP_DMA_PIO_DST_ADDR_HI)
        mmrp(mmCP_DMA_PIO_COMMAND)
    @staticmethod
    def finish():
        while (mmr(mmCP_STAT) & 0x400000) : mmr(mmCP_STAT)
    @staticmethod
    def do(src, dst, byte_count, **kw):
        """kw could be(in any order): sas = x, das=x, saic=x, daic=x, raw_wait=x, dis_wc=x, memlog_clear=x, src_cache_policy=x, src_volatle=x, dst_sel=x, dst_cache_policy=x, dst_volatle=x, src_sel=x"""
        _k = {"sas":0, "das": 0 , "saic":0, "daic":0, "raw_wait":0, "dis_wc":0,
        "memlog_clear":0, "src_cache_policy":0, "src_volatle":0, "dst_sel":0, "dst_cache_policy":0, "dst_volatle":0, "src_sel":0}
        for key in kw: _k[key] = kw[key]
        _command =  byte_count & 0x3ffffff
        _control = 0
        _command = _command | ((_k["sas"]&1)<<26) | ((_k["das"]&1)<<27) | ((_k['saic']&1)<<28) | ((_k['daic']&1)<<29) | ((_k['raw_wait']&1)<<30) | ((_k['dis_wc']&1)<<31)
        _control = _control | ((_k["memlog_clear"]&1)<<10) | ((_k["src_cache_policy"]&3)<<13) | ((_k['src_volatle']&1)<<15)
        _control = _control | ((_k['dst_sel']&3)<<20) | ((_k['dst_cache_policy']&3)<<25) | ((_k['dst_volatle']&1)<<27)| ((_k['src_sel']&3)<<29)
        db32s = DB32Script()
        if False:
             db32s.mmw(mmCP_DMA_PIO_CONTROL, 0)
             db32s.mmw(mmCP_DMA_PIO_SRC_ADDR , 0)
             db32s.mmw(mmCP_DMA_PIO_SRC_ADDR_HI ,0)
             db32s.mmw(mmCP_DMA_PIO_DST_ADDR , 0)
             db32s.mmw(mmCP_DMA_PIO_DST_ADDR_HI ,0)
             db32s.run()
             db32s.reset()

        db32s.mmw(mmCP_DMA_PIO_CONTROL, _control)
        db32s.mmw(mmCP_DMA_PIO_SRC_ADDR , src & 0xffffffff)
        db32s.mmw(mmCP_DMA_PIO_SRC_ADDR_HI , (src>>32) & 0xffffffff)
        db32s.mmw(mmCP_DMA_PIO_DST_ADDR , dst & 0xffffffff)
        db32s.mmw(mmCP_DMA_PIO_DST_ADDR_HI , (dst>>32) & 0xffffffff)
        db32s.mmw(mmCP_DMA_PIO_COMMAND,  _command)
        db32s.mmr(mmCP_DMA_PIO_COMMAND)
        db32s.run()
    @staticmethod
    def m2gds(src, dst, byte_count, **kw):
        _k = {'src_sel':0, 'dst_sel':1}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def d2gds(src, dst, byte_count, **kw):
        _k = {'src_sel':2, 'dst_sel':1}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def r2gds(src, dst, byte_count, **kw):
        _k = {'src_sel':0, 'dst_sel':1, 'sas':1}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def r2m(src, dst, byte_count, **kw):
        _k = {'src_sel':0, 'dst_sel':0, 'sas':1}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def d2m(src, dst, byte_count, **kw):
        _k = {'src_sel':2, 'dst_sel':0}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def d2l2m(src, dst, byte_count, **kw):
        _k = {'src_sel':2, 'dst_sel':3}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def m2m(src, dst, byte_count, **kw):
        _k = {'src_sel':0, 'dst_sel':0}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def l2m2l2m(src, dst, byte_count, **kw):
        _k = {'src_sel':3, 'dst_sel':3}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def l2m2m(src, dst, byte_count, **kw):
        _k = {'src_sel':3, 'dst_sel':0}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def l2m2gds(src, dst, byte_count, **kw):
        _k = {'src_sel':3, 'dst_sel':1}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def gds2m(src, dst, byte_count, **kw):
        _k = {'src_sel':1, 'dst_sel':0}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def m2l2(src, dst, byte_count, **kw):
        _k = {'src_sel':0, 'dst_sel':2}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def l2m2nowhere(src, dst, byte_count, **kw):
        _k = {'src_sel':3, 'dst_sel':2}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def m2r(src, dst, byte_count, **kw):
        _k = {'src_sel':0, 'dst_sel':0, 'das':1}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def d2r(src, dst, byte_count, **kw):
        _k = {'src_sel':2, 'dst_sel':0, 'das':1}
        for key in kw: _k[key] = kw[key]
        return CPDMA.do(src, dst, byte_count, **_k)
    @staticmethod
    def do1(src, dst,
        byte_count, sas = 0, das=0, saic=0, daic=0, raw_wait=0, dis_wc=0,
        memlog_clear=0, src_cache_policy=0, src_volatle=0, dst_sel=0, dst_cache_policy=0, dst_volatle=0, src_sel=0):
        pass
cpdma = CPDMA()
