#!/usr/bin/python

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)
from db32 import *
from ip_gds import *
from ip_cpdma import *

mmHDP_NONSURFACE_BASE      = 0x3d80 //4
mmHDP_NONSURFACE_BASE_HI   = 0x3d88 //4
mmHDP_SURFACE0_BASE        = 0x3d98 //4
mmHDP_SURFACE0_BASE_HI     = 0x3da0 //4
mmHDP_SURFACE0_INFO        = 0x3d9c //4
mmHDP_SURFACE0_LOWER_BOUND = 0x3d90 //4
mmHDP_SURFACE0_UPPER_BOUND = 0x3d94 //4

class MM:
    ''' Memory operations

    GFX9:
    typedef union {
        TC_uint64 data64;
        struct {
        TC_uint64 valid         V: 1;    // [   0] 1 = PTE contains a valid mapping
        TC_uint64 system        S: 1;    // [   1] 1 = page lives in system memory
        TC_uint64 cached        C: 1;    // [   2] 1 = cache probe for coherency
        TC_uint64 tmz           Z: 1;    // [   3] 1 = trusted memory zone
        TC_uint64 exe           X: 1;    // [   4] 1 = executable
        TC_uint64 readable      R: 1;    // [   5] 1 = page can be read
        TC_uint64 writable      W: 1;    // [   6] 1 = page may be written
        TC_uint64 fragment      F: 5;    /* [11:7] fragment size =
                                                   2^(12 + BlockFragmentSize + fragment) */
        TC_uint64 addr          P: 36;   // [47:12] GPA addr
        TC_uint64                : 3;    // unused
        TC_uint64 tile          T: 1;    // [   51] 1 = tiled( UserVM )
        TC_uint64 sw           SW: 2;    // [53:52] reserved for software
        TC_uint64 asPte         : 1;    /* [   54] for PDE masquerads
                                           as PTE */
        TC_uint64 log           L: 1;    // [   55] 1 = enable log
        TC_uint64 further       F: 1;    /* [   56] 1 = translater
                                           further. applies only to
                                           what is normally the leaf
                                           pte. It is expected to be
                                           used in cases where the
                                           native page size is greater
                                           than 4kb. */
        TC_uint64 mtype         M: 2;    // [58:57] MTYPE( NC, UC, CC )
        TC_uint64               : 5;    // [63:59] unused
        };
    } PTE64;


    GFX10:
     typedef union {
        TC_uint64 data64;
        struct {
        TC_uint64 valid         V: 1;    // [   0] 1 = PTE contains a valid mapping
        TC_uint64 system        S: 1;    // [   1] 1 = page lives in system memory
        TC_uint64 cached        C: 1;    // [   2] 1 = cache probe for coherency
        TC_uint64 tmz           Z: 1;    // [   3] 1 = trusted memory zone
        TC_uint64 exe           X: 1;    // [   4] 1 = executable
        TC_uint64 readable      R: 1;    // [   5] 1 = page can be read
        TC_uint64 writable      W: 1;    // [   6] 1 = page may be written
        TC_uint64 fragment      F: 5;    /* [11:7] fragment size =
                                                   2^(12 + fragment) */
        TC_uint64 addr          P: 36;   // [47:12] GPA addr
        TC_uint64 mtype         M: 3;    // [50:48] MTYPE
        TC_uint64 tile          T: 1;    // [   51] 1 = tiled( UserVM )
        TC_uint64 hor           : 1;    // [   52] halt on read
        TC_uint64 how           : 1;    // [   53] halt on write
        TC_uint64 asPte         : 1;    /* [   54] for PDE masquerads
                                           as PTE */
        TC_uint64 log           L: 1;    // [   55] 1 = enable log
        TC_uint64 further       F: 1;    /* [   56] 1 = translater
                                           further. applies only to
                                           what is normally the leaf
                                           pte. It is expected to be
                                           used in cases where the
                                           native page size is greater
                                           than 4kb. */
        TC_uint64 gcr           : 1;    // [57] GCR
        TC_uint64 noAlloc       : 1;    // [58] NoAlloc
        TC_uint64               : 5;    // [63:59] unused
        };
    } PTE64;

    GFX12:
        struct PTE64{
        TC_uint64 valid         : 1;  // [0] 1 = PTE contains a valid mapping
        TC_uint64 system        : 1;  // [1] 1 = page lives in system memory
        TC_uint64 cached        : 1;  // [2] 1 = cache probe for coherency
        TC_uint64 tmz           : 1;  // [3] 1 = trusted memory zone
        TC_uint64 exe           : 1;  // [4] 1 = executable
        TC_uint64 readable      : 1;  // [5] 1 = page can be read
        TC_uint64 writable      : 1;  // [6] 1 = page may be written
        TC_uint64 fragment      : 5;  // [11:7] fragment size =
                                      //        2^(12 + fragment)
        TC_uint64 addr          : 36; // [47:12] GPA addr
        TC_uint64               : 4;  // [51:48] unused
        TC_uint64 hor           : 1;  // [52] halt on read
        TC_uint64 how           : 1;  // [53] halt on write
        TC_uint64 mtype         : 2;  // [55:54] MTYPE
        TC_uint64 tile          : 1;  // [56] 1 = tiled(UserVM)
        TC_uint64 gcr           : 1;  // [57] GCR
        TC_uint64 dcc           : 1;  // [58] Compression Enable
        TC_uint64               : 4;  // [62:59] unused
        TC_uint64 isPte         : 1;  // [63] Is a PTE
        };

    '''

    fb_location = 0
    fb_size = 0
    vm_start = 0
    vm_end = 0

    @staticmethod
    def fbinfo():
        if MM.fb_location == 0:
            fb_location = mmr(mmGCMC_VM_FB_LOCATION_BASE)
            fb_size = mmr(mmGCMC_VM_FB_LOCATION_TOP)
            fb_location = fb_location << 24
            fb_size = ((fb_size << 24) | 0xffffff) + 1 - fb_location
            print("%x"%fb_size)
    @staticmethod
    def parsePTE(pte):
        dcc = 0
        _vld, _sys, _cac, _tmz, _exe, _rd, _wr, _frg, _aspte, _fur = ((pte>>0)&1, (pte>>1)&1, (pte>>2)&1, (pte>>3)&1, (pte>>4)&1, (pte>>5)&1, (pte>>6)&1, (pte>>7)&0x1f, (pte>>54)&1, (pte>>56)&1)
        if  GFX_IP_MAJOR <= 9:
            _mtype, _hor, _how, _gcr, _noalloc = ((pte >> 57)&3 , 0, 0,0,0)
            _pte = (_vld, _sys, _cac, _tmz, _exe, _rd, _wr, _frg,  _mtype, _hor, _how, _fur, _aspte,  _gcr, _noalloc)
            print("Vld=%d Sys=%d Cac=%d Tmz=%d Exe=%d Rd=%d Wr=%d Frg=%d Mtype=%d HoR=%d HoW=%d TranslateFurther=%d AsPte=%d Gcr=%d NoAlloc=%d" % _pte)
        elif GFX_IP_MAJOR <= 11:
            _mtype, _hor, _how, _gcr, _noalloc = ((pte >> 48)&3, (pte >> 52)&1 , (pte >> 53)&1, (pte >> 57)&1 , (pte >> 58)&1)
            _pte = (_vld, _sys, _cac, _tmz, _exe, _rd, _wr, _frg,  _mtype, _hor, _how, _fur, _aspte,  _gcr, _noalloc)
            print("Vld=%d Sys=%d Cac=%d Tmz=%d Exe=%d Rd=%d Wr=%d Frg=%d Mtype=%d HoR=%d HoW=%d TranslateFurther=%d AsPte=%d Gcr=%d NoAlloc=%d" % _pte)
        else:
            _mtype, _hor, _how, _gcr, _dcc = ((pte >> 54)&3, (pte >> 52)&1 , (pte >> 53)&1, (pte >> 57)&1 , (pte >> 58)&1)
            _pte = (_vld, _sys, _cac, _tmz, _exe, _rd, _wr, _frg,  _mtype, _hor, _how, _fur, _aspte,  _gcr, _dcc)
            print("Vld=%d Sys=%d Cac=%d Tmz=%d Exe=%d Rd=%d Wr=%d Frg=%d Mtype=%d HoR=%d HoW=%d TranslateFurther=%d AsPte=%d Gcr=%d dcc=%d" % _pte)
        return _pte

    if  GFX_IP_MAJOR <= 9:
        @staticmethod
        def invl2():
            mmw(mmTCC_WBINVL2, 0)
            time.sleep(1.0)
            mmrp(mmTCC_WBINVL2)
    else:
        @staticmethod
        def invl2():
            mmw(mmGL2C_WBINVL2, 0)
            time.sleep(1.0)
            mmrp(mmGL2C_WBINVL2)
    @staticmethod
    def vminfo():
      _vmctx = []
      for i in range(16):
          bl = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_BASE_ADDR_LO32 + i * 2)
          bh = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_BASE_ADDR_HI32 + i * 2)
          sl = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_LO32 + i * 2)
          sh = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_HI32 + i * 2)
          el = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_LO32 + i * 2)
          eh = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_HI32 + i * 2)
          cntl = mmr(mmGCVM_CONTEXT0_CNTL + i)
          _vmctx.append((((bh<<32)+bl), ((sh<<32)+sl)<<12, ((eh<<32)+el)<<12, cntl))
      s = '\n'.join(["(vm%2d: %016x %016x %016x %8x)"%(i, v[0], v[1], v[2], v[3]) for i,v in enumerate(_vmctx)])
      s0 = "vmid   PT_BASE          START           END              CONTROL\n"
      print(s0+s)
    @staticmethod
    def info():
      fbBase = mmrp(mmGCMC_VM_FB_LOCATION_BASE)
      mmrp(mmGCMC_VM_FB_LOCATION_TOP)
      fb_offset = mmrp(mmGCMC_VM_FB_OFFSET)
      if var_exist('mmGCMC_VM_LOCAL_HBM_ADDRESS_START'): mmrp(mmGCMC_VM_LOCAL_HBM_ADDRESS_START)
      if var_exist('mmGCMC_VM_LOCAL_HBM_ADDRESS_END'):mmrp(mmGCMC_VM_LOCAL_HBM_ADDRESS_END)
      if Settings.mAsic == mi300:
           mmHDP_XDP_MC_VM_FB_LOCATION_BASE = 0x4194 //4
           print(" " + Fmt.tos(regr32(mmHDP_XDP_MC_VM_FB_LOCATION_BASE)) + " " + "HDP_XDP_MC_VM_FB_LOCATION_BASE")
      print("  GCMC_VM_FB_OFFSET :%s"%Fmt.tos(fb_offset << 24))
      print("  FB BASE: %s"%Fmt.tos(fbBase<< 24))
      print(" " + Fmt.tos(regr32(0x3d80)) + " " + "HDP_NONSURFACE_BASE")
      print(" " + Fmt.tos(regr32(0x3d88)) + " " + "HDP_NONSURFACE_BASE_HI")
      print(" " + Fmt.tos(regr32(0x3d98)) + " " + "HDP_SURFACE0_BASE")
      print(" " + Fmt.tos(regr32(0x3da0)) + " " + "HDP_SURFACE0_BASE_HI")
      print(" " + Fmt.tos(regr32(0x3d9c)) + " " + "HDP_SURFACE0_INFO")
      print(" " + Fmt.tos(regr32(0x3d90)) + " " + "HDP_SURFACE0_LOWER_BOUND")
      print(" " + Fmt.tos(regr32(0x3d94)) + " " + "HDP_SURFACE0_UPPER_BOUND")
      print(" " + Fmt.tos(regr32(0x3db8)) + " " + "HDP_SURFACE1_BASE")
      mmrp(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_LO32)
      mmrp(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_HI32)
      if var_exist("mmGCMC_VM_XGMI_LFB_SIZE"):mmrp(mmGCMC_VM_XGMI_LFB_SIZE)
      if var_exist("mmGCMC_VM_XGMI_LFB_SIZE_alt_1"):smn.mmrp(mmGCMC_VM_XGMI_LFB_SIZE_alt_1)
      if var_exist("mmnbif_gpu_RCC_CONFIG_MEMSIZE"):mmrp(mmnbif_gpu_RCC_CONFIG_MEMSIZE)
      if var_exist("mmnbif_gpu_RCC_CONFIG_MEMSIZE_alt_1"):mmrp(mmnbif_gpu_RCC_CONFIG_MEMSIZE_alt_1)
      if var_exist("mmGCMC_VM_XGMI_LFB_CNTL"):mmrp(mmGCMC_VM_XGMI_LFB_CNTL)
      if var_exist("mmGCMC_VM_NB_LOWER_TOP_OF_DRAM2"):
          tom2 = mmrp(mmGCMC_VM_NB_LOWER_TOP_OF_DRAM2)
          tom2 = tom2 + (mmrp(mmGCMC_VM_NB_UPPER_TOP_OF_DRAM2) << 32)
          print("  TOM2: %s" % Fmt.tos(tom2))
      if var_exist("mmGCMC_VM_APT_CNTL"): mmrp(mmGCMC_VM_APT_CNTL)

    @staticmethod
    def gva2gpa(gva):
        """gva-> gpa,  e.g. 0xf4_0000_1000   -> 0x4_5000_1000 """
        vGCMC_VM_FB_LOCATION_BASE = mmr(mmGCMC_VM_FB_LOCATION_BASE) << 24
        vGCMC_VM_FB_OFFSET= mmr(mmGCMC_VM_FB_OFFSET) << 24
        gpa = gva - vGCMC_VM_FB_LOCATION_BASE + vGCMC_VM_FB_OFFSET
        print("gpa:%x = gva:%x - (GCMC_VM_FB_LOCATION_BASE<<24):%x + (GCMC_VM_FB_OFFSET<<24):%x" % (gpa, gva, vGCMC_VM_FB_LOCATION_BASE, vGCMC_VM_FB_OFFSET))
        return gpa

    @staticmethod
    def gva2sys(gva):
        """gva-> sys,  e.g. 0x80_0000_1000   -> 0x4_5000_1000 """
        return MM.gva2gpa(gva)

    @staticmethod
    def isvm(addr):
        _vm_start = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_LO32) << 12
        _vm_end = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_LO32) << 12
        if _vm_start == 0:
            _vm_start = 0xf40000000
            _vm_end = 0xf5ffff000
        _isvm = True if addr >= _vm_start and addr <= _vm_end else False
    @staticmethod
    def readp(vm, n = 32, vmid=0):
        """read and print
           vm: address
           n : num of dwords to read
           vmid: vmid
        """
        print("%X:"%vm)
        r = mm.read(vm,n,vmid)
        dumpdata(r)
        return r

    @staticmethod
    def address_type(vm):
        pass

    @staticmethod
    def read_000(vm, n = 32, vmid=0):
        """read and print
           vm: address
           n : num of dwords to read
           vmid: vmid
        """
        _vm_startL = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_LO32 + vmid*2)
        _vm_startH = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_HI32 + vmid*2)
        _vm_start = _vm_startL + (_vm_startH << 32)
        _vm_start = _vm_start << 12

        _vm_endL = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_LO32 + vmid*2)
        _vm_endH = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_HI32 + vmid*2)
        _vm_end = _vm_endL + (_vm_endH << 32)
        _vm_end = _vm_end << 12

        if _vm_start == 0:
            _vm_start = 0xf40000000
            _vm_end = 0xf5ffff000
        if vm >= _vm_start and vm <= _vm_end : #vm addr
          _phy, _issys, _off = mm.va2pa(vm,vmid)
          if _issys: return dd(_phy,n).d
          else: return dvd(_off,n).d
        else:
            fb_location = mmr(mmGCMC_VM_FB_LOCATION_BASE) << 24
            fb_top = mmr(mmGCMC_VM_FB_LOCATION_TOP) << 24
            if vm >= fb_location and vm < fb_top: #phy vid
              vHDP_NONSURFACE_BASE = ((mmr(mmHDP_NONSURFACE_BASE) << 32 ) | mmr(mmHDP_NONSURFACE_BASE)) << 8
              if( vm >= vHDP_NONSURFACE_BASE and vm < vHDP_NONSURFACE_BASE + 0x10000000):
                  return dvd(vm - fb_location, n).d # fb_location == HDP_NONSURFACE_BASE
              else:
                  # Aper with HDP_SURFACE0
                  _surface0_base = vm >> 8
                  _surface0_off  = vm & 0xff
                  _size256b = n * 4 // 256 + 1
                  mmw(mmHDP_SURFACE0_BASE, _surface0_base&0xffffffff)
                  mmw(mmHDP_SURFACE0_BASE_HI, (_surface0_base >> 32 ) &0xffffffff)
                  mmw(mmHDP_SURFACE0_LOWER_BOUND, 0)
                  mmw(mmHDP_SURFACE0_UPPER_BOUND, _size256b)
                  _d = dvd(_surface0_off, n)
                  mmw(mmHDP_SURFACE0_BASE, 0)
                  mmw(mmHDP_SURFACE0_BASE_HI, 0)
                  mmw(mmHDP_SURFACE0_LOWER_BOUND, 0)
                  mmw(mmHDP_SURFACE0_UPPER_BOUND, 0)
                  return _d.d
            else: #sys??
              _d = dd(vm,n)
              return _d.d

    @staticmethod
    def writes_000(vm, data, n = 0, vmid=0):
        """read and print
           vm: address
           n : num of dwords to read
           vmid: vmid
        """
        _vm_startL = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_LO32 + vmid*2)
        _vm_startH = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_HI32 + vmid*2)
        _vm_start = _vm_startL + (_vm_startH << 32)
        _vm_start = _vm_start << 12

        _vm_endL = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_LO32 + vmid*2)
        _vm_endH = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_HI32 + vmid*2)
        _vm_end = _vm_endL + (_vm_endH << 32)
        _vm_end = _vm_end << 12

        if _vm_start == 0:
            _vm_start = 0xf40000000
            _vm_end = 0xf5ffff000
        if vm >= _vm_start and vm <= _vm_end : #vm addr
          _phy, _issys, _off = mm.va2pa(vm,vmid)
          if _issys: db32I.mem_dwrites(_phy, data, n)
          else: db32I.vid_dwrites(_off, data, n)
        else:
            fb_location = mmr(mmGCMC_VM_FB_LOCATION_BASE) << 24
            fb_top = mmr(mmGCMC_VM_FB_LOCATION_TOP) << 24
            if vm >= fb_location and vm < fb_top: #phy vid
              vHDP_NONSURFACE_BASE = ((mmr(mmHDP_NONSURFACE_BASE) << 32 ) | mmr(mmHDP_NONSURFACE_BASE)) << 8
              if( vm >= vHDP_NONSURFACE_BASE and vm < vHDP_NONSURFACE_BASE + 0x10000000):
                  db32I.vid_dwrites(vm - fb_location, data, n) # fb_location == HDP_NONSURFACE_BASE
              else:
                  # Aper with HDP_SURFACE0
                  _surface0_base = vm >> 8
                  _surface0_off  = vm & 0xff
                  _size256b = n * 4 // 256 + 1
                  mmw(mmHDP_SURFACE0_BASE, _surface0_base&0xffffffff)
                  mmw(mmHDP_SURFACE0_BASE_HI, (_surface0_base >> 32 ) &0xffffffff)
                  mmw(mmHDP_SURFACE0_LOWER_BOUND, 0)
                  mmw(mmHDP_SURFACE0_UPPER_BOUND, _size256b)
                  db32I.vid_dwrites(_surface0_off, data,n)
                  mmw(mmHDP_SURFACE0_BASE, 0)
                  mmw(mmHDP_SURFACE0_UPPER_BOUND, 0)
            else: #sys??
              db32I.mem_dwrites(vm, data, n)

    @staticmethod
    def write(vm, data, n = 0, vmid=0):
        MM.writes_000(vm, data, n, vmid)

    if NO_GFX :
       @staticmethod
       def read_bycpdma(vm, n = 32, vmid=0):
           """read n dwords from address vm through memory. CPDMA vm->vm[16384B:]
              vm: address
              n : num of dwords to read
              vmid: vmid
           """
           VM_ADDR = 0x10000000
           CPDMA.m2m(vm, VM_ADDR, n*4)
           time.sleep(0.05)
           return mm.read_000(VM_ADDR, n, vmid)

    else:
        @staticmethod
        def read_bycpdma(vm, n = 32, vmid=0):
            """read n dwords from address vm through GDS. CPDMA vm->gds[16384B:]
               vm: address
               n : num of dwords to read
               vmid: vmid
            """
            CPDMA.m2gds(vm, 16384, n*4)
            time.sleep(0.05)
            datas = gds.r(16384//4, n, False)
            return datas[mmGDS_RD_DATA]
    @staticmethod
    def read(vm, n = 32, vmid=0):
        """read 32 dwords from address vm.
           vm: address
           n : num of dwords to read
           vmid: vmid
        """
        if Settings.mByCPDMA : return mm.read_bycpdma(vm, n, vmid)
        else    : return mm.read_000(vm,n,vmid)
    @staticmethod
    def va2pa(vm, vmid, verbose=None):
        """convert virtual address to physical address

        Returns:
          return phyAddr,isSys,offset
          if isSys == True:  dd(offset) can read out the memory
          if isSys == False: dvd(offset) can read out the memory
        """
        if verbose == None: verbose = Fmt.VERBOSE
        _vm_startL = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_LO32 + vmid*2)
        _vm_startH = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_START_ADDR_HI32 + vmid*2)
        _vm_start = _vm_startL + (_vm_startH << 32)
        _vm_start = _vm_start << 12

        _vm_endL = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_LO32 + vmid*2)
        _vm_endH = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_END_ADDR_HI32 + vmid*2)
        _vm_end = _vm_endL + (_vm_endH << 32)
        _vm_end = _vm_end << 12

        # the PTE index
        idx = ((vm - _vm_start) >> 12 ) << 3

        _vm_baseL = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_BASE_ADDR_LO32 + vmid*2)
        _vm_baseH = mmr(mmGCVM_CONTEXT0_PAGE_TABLE_BASE_ADDR_HI32 + vmid*2)
        _vm_base0 =  _vm_baseL + (_vm_baseH << 32)
        _pt_insys = _vm_base0 & 0x2
        _pt_infb = _pt_insys == 0
        _vm_base_pte = (_vm_base0 >> 48 ) & 3
        _vm_base0 = _vm_base0 & 0x0000FFFFFFFFF000 # bit12-47

        _fb_offset = mmr(mmGCMC_VM_FB_OFFSET) << 24
        _pte_base = _vm_base0 - _fb_offset if _pt_infb else _vm_base0
        #if db32I.csid(0x10) & 0xffffff00 == 0:
        if db32I.isAnA():
            _pte_base = _vm_base0 # A+A mode
        pte_addr = _pte_base + idx

        #ptes = db32I.cmd("dvd %X"%pte_addr)
        #line0 = ptes.split('\n')[0]
        #line0 = ' '.join(line0.split())
        #datas = line0.split()
        #phyaddr_str = "0x" + datas[2] + datas[1]
        #_pte = int(phyaddr_str, 16)

        ptes = db32I.dvd(pte_addr,32) if _pt_infb else db32I.dd(pte_addr,32)
        _pte = (ptes.d[1] << 32) + ptes.d[0]

        phyaddr = _pte & 0x00000FFFFFFFFF000
        phyaddr = phyaddr + (vm &0xfff)
        _insys = _pte & 0x2
        _offset = phyaddr
        datas = ""
        readable = Fmt.hex
        if verbose > 2: readable = Fmt.hex4
        if verbose > 0 :
          print ("Virtual:%s Physical:%s PDE:%s offset:%s"%readable(vm, phyaddr, _pte, _offset))
          mm.parsePTE(_pte)
        if verbose > 1 :
          print("VM_CONTEXT%d_PAGE_TABLE_START_ADDR %s (%s__%s << 12)"%((vmid,) + readable(_vm_start, _vm_startH, _vm_startL)))
          print("VM_CONTEXT%d_PAGE_TABLE_END_ADDR %s (%s__%s << 12)"%((vmid,) +readable(_vm_end, _vm_endH, _vm_endL)))
          print("VM_CONTEXT%d_PAGE_TABLE_BASE_ADDR %s(%s__%s - fbOffset 0x%s) insys:%s"%((vmid,) +readable(_pte_base, _vm_baseH, _vm_baseL,_fb_offset, _pt_insys)))
          if _pt_infb :print("PTE: dvd %s"%(readable(pte_addr)))
          else:print("PTE: dd %s"%(readable(pte_addr)))
          print(ptes.raw)
          if _insys == 0:
              _offset = phyaddr - _fb_offset
              datas = db32I.dvd(_offset, 32)
              print("%X:: dvd %s"%(vm, readable(_offset)))
              print(datas.raw)
          else: # sysmem
              if False: # dd
                pass
              else:
                print("%X:: dd %X:"%(vm, phyaddr))
                #mm.readp(vm)
                datas = db32I.dd(phyaddr, 32)
                print(datas.raw)

        return phyaddr, _insys, _offset

    class UTCL2:
        @staticmethod
        def translate(vm, vmid=0, gpa=0):
           '''gpa:
           0: GPUVA
           1: SYSMEM_GPA
           2: FB_GPA
           3: *SPA -> IO/SPA=0/0
           '''
           if  GFX_IP_MAJOR < 12:
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_CNTL, 1)
                lo = (vm >> 12) &0xffffffff
                hi = (vm >> 44) &0xf
                (vfid, vf, rd, wr, exe, clientid, req) = (0, 0, 1, 1, 1, 1, 1)

                attr = (vmid<<4) | (vfid <<8) |(vf<<12) | (gpa<<13) | (rd<<15) |(wr<<16)|(exe<<17)|(clientid<<18) | (req << 30)
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_LO, lo)
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_HI, hi |attr| (1<<30))
                time.sleep(0.01)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_LO)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_HI)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_RESPONSE_LO)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_RESPONSE_HI)
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_CNTL, 0)
           else:
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_CNTL, 1)
                lo = (vm >> 12) &0xffffffff
                hi = (vm >> 44) &0xf
                (vfid, vf, rd, wr, exe, clientid, req) = (0, 0, 1, 1, 1, 1, 1)

                attr = (vmid) | (vfid <<4) |(vf<<9) | (gpa<<10) | (rd<<12) |(wr<<13)|(exe<<14)|(clientid<<15) | (req << 31)
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_ADDR_LO32, lo)
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_ADDR_HI32, hi)
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_ATTR, attr)
                time.sleep(0.01)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_ADDR_LO32)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_REQUEST_ADDR_HI32)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_RESPONSE_ADDR_LO32)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_RESPONSE_ADDR_HI32)
                mmrp(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_RESPONSE_ATTR)
                mmw(mmGCUTC_GPUVA_VMID_TRANSLATION_ASSIST_CNTL, 0)

    utcl2 = UTCL2()

mm = MM()
