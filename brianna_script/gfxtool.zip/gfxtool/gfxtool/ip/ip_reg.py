#!/usr/bin/python
from __future__ import print_function
from db32 import *
import random
import logging
from chip_registers import *
from ip_gds import *
from ip_mm import *
from ip_rb import *
from settings import *

#if Settings.mLoadFullRegisters == True: from chip_registers_full import *
class REG:
  if GFX_IP_MAJOR == 9:
      @staticmethod
      def select(seid=0, said=0, i=0, simd=0):
          mmw(mmGRBM_GFX_INDEX, (seid << 16) | (said << 8) | (i))
  else:
      @staticmethod
      def select(seid=0, said=0, i=0, simd=0):
          mmw(mmGRBM_GFX_INDEX, (seid << 16) | (said << 8) | (i<<2) | simd)
  @staticmethod
  def unselect():
      mmw(mmGRBM_GFX_INDEX, 0xE0000000)
  @staticmethod
  def dumpCPheader(header = 0):
      if header == 0:
          REG.dumpCPheader(mmCP_MEC_ME1_HEADER_DUMP)
          if var_exist('mmCP_MEC_ME2_HEADER_DUMP'):REG.dumpCPheader(mmCP_MEC_ME2_HEADER_DUMP)
          if (not NO_GFX) and var_exist('mmCP_CE_HEADER_DUMP'):REG.dumpCPheader(mmCP_CE_HEADER_DUMP)
          if (not NO_GFX) : REG.dumpCPheader(mmCP_PFP_HEADER_DUMP)
          if (not NO_GFX) : REG.dumpCPheader(mmCP_ME_HEADER_DUMP)
          if var_exist('mmCP_MES_HEADER_DUMP'): REG.dumpCPheader(mmCP_MES_HEADER_DUMP)
          return
      print(regName(header))
      db32s = DB32Script()
      for i in range(0,8):
          db32s.mmr(header)
      r = db32s.run()
      _rv = db32s.db32.rvarray(r)
      __s0 = ', '.join(["%8x"%(regV[1]) for idx, regV in enumerate(_rv)]) 
      __s1 = ', '.join(["%s"%(itname(regV[1])) for idx, regV in enumerate(_rv)]) 
      print(__s0 + '\n' + __s1 + '\n')
  @staticmethod
  def dumpCEheader():
      REG.dumpCPheader(mmCP_CE_HEADER_DUMP)

  @staticmethod
  def dumpMEheader():
      REG.dumpCPheader(mmCP_ME_HEADER_DUMP)

  @staticmethod
  def dumpPFPheader():
      REG.dumpCPheader(mmCP_PFP_HEADER_DUMP)

  @staticmethod
  def dumpME1header():
      REG.dumpCPheader(mmCP_MEC_ME1_HEADER_DUMP)

  @staticmethod
  def dumpME2header():
      REG.dumpCPheader(mmCP_MEC_ME2_HEADER_DUMP)

  @staticmethod
  def downloadRegisters():
        __asicpath = Settings.mAsicPath
        __chip_reg_full_path =  __asicpath +  "/chip_registers_full.py"
        if not os.path.exists(__chip_reg_full_path):
           if os.name == 'nt':
               import wget
               wget.download("http://ddavid-diag-mk.amd.com:8080/public/git/asics/%s/chip_registers.py"%Settings.mAsicName, __chip_reg_full_path)
           else:
               __fetchcmd = __asicpath + "/fetch.py"
               err,r = subprocess.getstatusoutput(__fetchcmd)
               print(err,r)

  @staticmethod
  def dumpMatch(mmstr, expected = 0):
      import re
      regs = []
      mmstr = mmstr.replace("*", ".*")
      pat = re.compile(mmstr)
      for k,v in RegName.items():
          #if v.startswith(mmstr): regs.append(k)
          if pat.match(v): regs.append(k)
      for r in regs:
          REG.dumpRegister(r,expected)
          print("")

  @staticmethod
  def dump(r, expected = 0, v = None):
      if type(r) == str: return REG.dumpMatch(r, expected)
      return REG.dumpRegister(r,expected, v)

  @staticmethod
  def dumpGfx(space = 0xf):

      if space == "config": space = REG.CONFIG_SPACE_ENUM
      if space == "uconfig": space = REG.UCONFIG_SPACE_ENUM
      if space == "persistent": space = REG.PERSISTENT_SPACE_ENUM
      if space == "context": space = REG.CONTEXT_SPACE_ENUM
      for r in RegName:
          s =  REG.space(r,False)
          if not (space == s or space == 0xf):continue
          if s == REG.CONTEXT_SPACE_ENUM:
              for i in range(0,8):
                  REG.dump(r+0x400*i)
                  #print(regName(r+0x400*i))
          elif s > 0:
              #print(regName(r))
              REG.dump(r);

  @staticmethod
  def dumpRegister(v, expected = 0, vv = None):
      if isNumber(v):
          u32All = vv if vv!=None else mmr(v)
          try:
              if REG.loadRegStruct(regName(v)[2:]):
                  reg0 = globals()[regName(v)[2:]]()
                  reg0.u32All = u32All
                  REG.dumpRegister(reg0, expected)
              else:
                  print("%s:%x"%(regName(v), u32All))
          except:
              print("%s:%x"%(regName(v), u32All))
              pass
          finally:
              pass
      elif v.u32All == expected:
          Fmt.good("%s:%x" %( v.__class__.__name__, expected))
      else:
          Fmt.warn("%s:%x" %( v.__class__.__name__, v.u32All))
          maxl = 24
          for t in v.bits._fields_ :
              maxl = max(maxl, len(t[0]))
          fmter = "%%%ds %%X"% maxl
          index = 0
          for t in v.bits._fields_ :
              seperator = '\n' if (index % Settings.mDumpColumns) == 0 else '\t'
              if index == len(v.bits._fields_) -1 : seperator = '\n'
              s = getattr(v.bits, t[0])
              str = fmter%(t[0], s)
              if s != 0:
                  Fmt.bad(fmter%(t[0], s))
              elif Settings.FILTER0 == False:
                  print(fmter%(t[0], s), end=seperator)
              index = index + 1
          #print()
  @staticmethod
  def tostr(v, expected = 0, vv = None):
       if isNumber(v):
          u32All = vv if vv!=None else mmr(v)
          try:
              if REG.loadRegStruct(regName(v)[2:]):
                  reg0 = globals()[regName(v)[2:]]()
                  reg0.u32All = u32All
                  return REG.tostr(reg0, expected)
              else: return "%s:%x"%(regName(v), u32All)
          except e:
              return "%s:%x"%(regName(v), u32All)
       s = "%s:%x" %( v.__class__.__name__, v.u32All)
       maxl = 24
       for t in v.bits._fields_ :
           maxl = max(maxl, len(t[0]))
       fmter = "%%%ds %%X"% maxl
       s = ''.join((s, '\n',
          '\n'.join( fmter%(t[0], getattr(v.bits, t[0])) for t in v.bits._fields_ )))
       return s

  CONFIG_SPACE_ENUM      =  1
  UCONFIG_SPACE_ENUM     =  2
  PERSISTENT_SPACE_ENUM  =  3
  CONTEXT_SPACE_ENUM     =  4
  CONFIG_SPACE_START     =  0x00002000
  CONFIG_SPACE_END       =  0x00009fff
  UCONFIG_SPACE_START    =  0x0000c000
  UCONFIG_SPACE_END      =  0x0000ffff
  PERSISTENT_SPACE_START =  0x00002c00
  PERSISTENT_SPACE_END   =  0x00002fff
  CONTEXT_SPACE_START    =  0x0000a000
  CONTEXT_SPACE_END      =  0x0000bfff
  @staticmethod
  def space(r, returnstr = False):
    if r in range(REG.PERSISTENT_SPACE_START, REG.PERSISTENT_SPACE_END+1):
        return REG.PERSISTENT_SPACE_ENUM if returnstr == False else (REG.PERSISTENT_SPACE_ENUM, "PERSISTENT_SPACE")
    elif r in range(REG.CONFIG_SPACE_START, REG.CONFIG_SPACE_END+1) :
        return REG.CONFIG_SPACE_ENUM if returnstr == False else (REG.CONFIG_SPACE_ENUM, "CONFIG_SPACE")
    elif r in range(REG.UCONFIG_SPACE_START, REG.UCONFIG_SPACE_END+1):
        return REG.UCONFIG_SPACE_ENUM if returnstr == False else (REG.UCONFIG_SPACE_ENUM, "UCONFIG_SPACE")
    elif r in range(REG.CONTEXT_SPACE_START, REG.CONTEXT_SPACE_END+1):
        return REG.CONTEXT_SPACE_ENUM if returnstr == False else (REG.CONTEXT_SPACE_ENUM, "CONTEXT_SPACE")
    else: return 0 if returnstr == False else (0,"ERROR")
  @staticmethod
  def inCONTEX_SPACE(r):
    return  r in range(REG.CONTEXT_SPACE_START, REG.CONTEXT_SPACE_END+1)

  @staticmethod
  def dumpmaparray2(marray, filter0 = 3):
    if filter0 == 3: filter0 = Fmt.FILTER0
    if type(marray) == str: return REG.dumpmaparray2(rvmaparray(marray), filter0)
    if filter0 == False:
        astr = '\n'.join("{}".format('\n'.join("Instance %d :: "%idx + REG.tostr(key,0, v) for idx,v in enumerate(marray[key]))) for key, a in sorted(marray.items()))
    else:
        astr = '\n'.join("{}".format('\n'.join("Instance %d :: "%idx + REG.tostr(key,0, v) for idx,v in enumerate(marray[key]) if v!=0)) for key, a in sorted(marray.items()) if sum(a) != 0)
    print(astr)

  @staticmethod
  def test():
       with DB32Script() as s:
          EACH(db32=s).sa(mmCC_GC_SHADER_ARRAY_CONFIG)
       REG.dumpmaparray2(rvmaparray(s.last_output))
       with s as s:
          s.percuGFX9(mmSQ_EDC_CNT)
       REG.dumpmaparray2(s.last_output)

  @staticmethod
  def dumpCS(wgs=1):
    for i in range(0, 1):
        v = mmrp(mmCOMPUTE_DIM_X + i * 0x400)
        v = mmrp(mmCOMPUTE_DIM_Y+ i * 0x400)
        v = mmrp(mmCOMPUTE_DIM_Z+ i * 0x400)
        v = mmrp(mmCOMPUTE_NUM_THREAD_X+ i * 0x400)
        v = mmrp(mmCOMPUTE_NUM_THREAD_Y+ i * 0x400)
        v = mmrp(mmCOMPUTE_NUM_THREAD_Z+ i * 0x400)
        v = mmrp(mmCOMPUTE_PGM_HI+ i * 0x400)
        v = mmrp(mmCOMPUTE_PGM_LO+ i * 0x400)
        v = mmrp(mmCOMPUTE_PGM_RSRC1+ i * 0x400)
        v = mmrp(mmCOMPUTE_PGM_RSRC2+ i * 0x400)
        if var_exist('mmCOMPUTE_PGM_RSRC3'):v = mmrp(mmCOMPUTE_PGM_RSRC3+ i * 0x400)
        v = mmrp(mmSQ_SHADER_TMA_LO)
        v = mmrp(mmSQ_SHADER_TMA_HI)


    if wgs == 1 and var_exist('mmWGS_COMPUTE_PGM_HI'):
      print("WGS")
      for i in range(0, 1):
        v = mmrp(mmWGS_COMPUTE_DIM_X + i * 0x400)
        v = mmrp(mmWGS_COMPUTE_DIM_Y+ i * 0x400)
        v = mmrp(mmWGS_COMPUTE_DIM_Z+ i * 0x400)
        v = mmrp(mmWGS_COMPUTE_NUM_THREAD_X+ i * 0x400)
        v = mmrp(mmWGS_COMPUTE_NUM_THREAD_Y+ i * 0x400)
        v = mmrp(mmWGS_COMPUTE_NUM_THREAD_Z+ i * 0x400)
        v = mmrp(mmWGS_COMPUTE_PGM_HI+ i * 0x400)
        v = mmrp(mmWGS_COMPUTE_PGM_LO+ i * 0x400)
        v = mmrp(mmWGS_COMPUTE_PGM_RSRC1+ i * 0x400)
        v = mmrp(mmWGS_COMPUTE_PGM_RSRC2+ i * 0x400)
        if var_exist('mmWGS_COMPUTE_PGM_RSRC3'):v = mmrp(mmWGS_COMPUTE_PGM_RSRC3+ i * 0x400)

  @staticmethod
  def dumpBC():
    v = mmrp(mmGFX_COMPAT_PIPE0)
    v = mmrp(mmGFX_COMPAT_PIPE1)
    for i in range(0,8):
        v = mmrp(mmACE_COMPAT_ME1PIPE0 + i)
  @staticmethod
  def loadRegStruct(regname):
    if regname in globals(): return True
    try:
        REG.downloadRegisters()
        with open(Settings.mAsicPath + "/chip_registers_full.py", 'r') as f:
            data = f.read()
        si = data.index("class " + regname + " ")
        ei = data.index("\nclass ", si + len(regname) + 20)
        regdef = data[si:ei]
        loc = {}
        exec(regdef, None, loc)
        for k, v in loc.items():
            globals()[k] = v
    except:
        return False
    return True

  @staticmethod
  def dumpStatus(blocks = ''):
    '''blocks can be :
       all,cp,spi,ge,sx,cb,db
    '''
    blocks = blocks.upper()
    grbm_st = GRBM_STATUS()
    grbm_st.u32All = mmr(mmGRBM_STATUS)
    grbm_st2 = GRBM_STATUS2()
    grbm_st2.u32All = mmr(mmGRBM_STATUS2)
    if  'all' in blocks:
        blocks += 'CP SPI SX DB CB'
    elif blocks == '' :
        blocks = blocks.upper() +  ' '.join([t[0] for t in grbm_st.bits._fields_ if  getattr(grbm_st.bits, t[0]) != 0 and 'BUSY' in t[0]])
        blocks = blocks.upper() +  ' '.join([t[0] for t in grbm_st2.bits._fields_ if  getattr(grbm_st2.bits, t[0]) != 0 and 'BUSY' in t[0]])
        if GFX_IP_MAJOR >= 10 :
            grbm_st3 = GRBM_STATUS3()
            grbm_st3.u32All = mmr(mmGRBM_STATUS3)
            blocks = blocks.upper() +  ' '.join([t[0] for t in grbm_st3.bits._fields_ if  getattr(grbm_st3.bits, t[0]) != 0 and 'BUSY' in t[0]])
    if 'CP' in blocks: REG.dumpCPheader()
    REG.dump(mmGRBM_STATUS, 0x3028)
    REG.dump(mmGRBM_STATUS2,0x8)
    if GFX_IP_MAJOR >= 10 :     REG.dump(mmGRBM_STATUS3)
    if 'CP' in blocks:
        REG.dump(mmCP_STAT)
        REG.dump(mmCP_BUSY_STAT)
        REG.dump(mmCP_STALLED_STAT1, 0x0 if GFX_IP_MAJOR>=0 else 0xc00)
        REG.dump(mmCP_STALLED_STAT2)
        REG.dump(mmCP_STALLED_STAT3)
        REG.dump(mmCP_CPF_STATUS)
        REG.dump(mmCP_CPF_BUSY_STAT)
        if GFX_IP_MAJOR >= 10 : REG.dump(mmCP_CPF_BUSY_STAT2)
        REG.dump(mmCP_CPC_STATUS)
        REG.dump(mmCP_CPC_BUSY_STAT)
        if GFX_IP_MAJOR >= 10 : REG.dump(mmCP_CPC_BUSY_STAT2)
        REG.dump(mmCP_CPC_STALLED_STAT1)
        REG.dump(mmCP_GFX_ERROR)
        REG.dump(mmCP_HQD_ERROR)
    if 'SPI' in blocks:
        REG.dump(mmSPI_DEBUG_BUSY)
    if 'SX' in blocks:
        REG.dump(mmSX_DEBUG_BUSY)
    if 'DB' in blocks:
        REG.dump(0x21d5c//4)
    if 'CB' in blocks:
        for i in range(16,22):REG.dump(mmCB_DEBUG_BUS_1 + i)
    if 'PH' in blocks:
        pass
    if 'GE' in blocks:
        pass
    if 'PA' in blocks:
        pass
    if 'UTCL1' in blocks:
        pass
    if 'GL2CC' in blocks:
        pass
    if 'GL1CC' in blocks:
        pass
    if 'GUS' in blocks:
        pass

  @staticmethod
  def watch(*rs, **kw):
    ''' watch(mmGRBR_STATUS, mmGRBR_STATUS2)
        watch(mmGRBR_STATUS, mmGRBR_STATUS2, delay=0.2)
        watch() # same to watch(mmGRBR_STATUS, delay=0.1)
    '''
    from datetime import datetime
    regs = rs if len(rs) > 0  else (mmGRBM_STATUS,)
    delay=0.1
    doclear = True
    if 'delay' in kw: delay = kw['delay']
    if 'noclear' in kw: doclear = not kw['noclear']
    with mystdin() as stdin :
      cmd=""
      last_cmd=""
      cmds=["softreset0()", "softreset1()", "hardreset()", "warmreset()", "softreset()"]
      err=""
      cursor = "_"
      lasttime = datetime.now()
      while True:
        char = stdin.getch()
        if(char == "q" or char == '\x1b'):
            break
        if(char == '\b' or char == '\x7f'):
            cmd = cmd[:-1]
        elif(char == '\n'):
            err=""
            try:
                if len(cmd) > 1 and cmd[0] == 'c':
                    i = int(cmd[1:])
                    cmd = cmds[i]
            except: pass
            try:
                exec(cmd.strip())
                lasttime=datetime.now()
            except:
                last_cmd=cmd
                err =  sys.exc_info()[0]
                print("Unexpected error:", err)
            cmd = ""
        elif(char != False): cmd = cmd + char
        else:pass
        time.sleep(delay);
        if doclear:
            if os.name == 'nt': os.system('cls')
            else: os.system('clear')
        nowtime = datetime.now()
        usedtime=str(nowtime-lasttime)[:8]
        print(nowtime.strftime('%Y-%m-%d %H:%M:%S'), usedtime)
        for r in regs:
            if isinstance(r, str):
                myexecStr(r)
            elif (type(r) is types.FunctionType):
                myexec(r,delay)
            else:REG.dump(r)
        if doclear:
             print("options")
             cmd_str = ' | '.join(["c%d: %s"%(i,c) for i, c in enumerate(cmds)])
             print(cmd_str)
             cursor = "_" if cursor == "" else ""
             print("CMD: %s%s"%(cmd,cursor))
             if err : print("%s:%s"%(last_cmd,err))

  @staticmethod
  def watch2(*rs, **kw): reg.watch(mmGRBM_STATUS, mmGRBM_STATUS2)

  @staticmethod
  def watch3(*rs, **kw): reg.watch(mmGRBM_STATUS, mmGRBM_STATUS2, mmGRBM_STATUS3)

  @staticmethod
  def watch4(*rs, **kw):
      rs = []
      for se in RANGE_SE:
          if se ==0 : rs.append(mmGRBM_STATUS_SE0)
          if se ==1 : rs.append(mmGRBM_STATUS_SE1)
          if se ==2 : rs.append(mmGRBM_STATUS_SE2)
          if se ==3 : rs.append(mmGRBM_STATUS_SE3)
      reg.watch(*rs)


reg = REG()

def smureset():
    mmPCIE_INDEX2 = 0x38 // 4
    mmPCIE_DATA2  = 0x3c // 4
    mmRSMU_INDEX = 0x50 // 4
    mmRSMU_DATA  = 0x54 // 4
    if GFX_IP_MAJOR == 9:
        mmw(mmPCIE_INDEX2, 0x100b008) #PCIE_INDEX2 = RSMU_GC:RSMU_HARD_RESETB_GC
    else:
        mmw(mmPCIE_INDEX2, 0x900b008) #PCIE_INDEX2 = RSMU_GC:RSMU_HARD_RESETB_GC
    mmw(mmPCIE_DATA2, 0)          #RSMU_GC:RSMU_HARD_RESETB_GC  = 0 through PCIE_DATA2
    time.sleep(0.2)                     # Wait more than 2000 clks
    mmw(mmPCIE_DATA2, 1)          #RSMU_GC:RSMU_HARD_RESETB_GC  = 1
    time.sleep(0.2)                     # Wait more than 2000 clks
def hardreset():smureset()
def warmreset():
    if GFX_IP_MAJOR == 9 and Settings.mAsic < mi200:
        mmRSMU_HARD_RESETB_GC = 0x100b008 // 4
        mmRSMU_HARD_RESETB_COMING_GC = 0x100b224 // 4
    else:
        mmRSMU_HARD_RESETB_GC = 0x900b008 // 4
        mmRSMU_HARD_RESETB_COMING_GC = 0x900b224 // 4
    smn.mmw(mmRSMU_HARD_RESETB_COMING_GC, 0)
    time.sleep(0.2)
    smn.mmw(mmRSMU_HARD_RESETB_GC, 0)
    time.sleep(0.2)
    smn.mmw(mmRSMU_HARD_RESETB_COMING_GC, 1)
    time.sleep(0.2)
    smn.mmw(mmRSMU_HARD_RESETB_GC, 1)
    time.sleep(0.2)

def softreset0():
    db32S.mmw(mmGRBM_SOFT_RESET, 0x10001)
    db32S.mmw(mmGRBM_SOFT_RESET, 0x0)
def softreset1(cntl = 0x34, vRESET = 0x10001, **kwargs):
    '''
    Default softreset1():  soft reset CP and GFX
    Reset EA:   softreset1(0, 0, EA=1)
    Reset RLC:  softreset1(0, 0, RLC=1)
    Reset CP:  softreset1(0, 0, CP=1)
    '''
    if 'RLC' in kwargs and  kwargs['RLC'] : vRESET = vRESET | (1 << 2)
    if 'CP' in kwargs and  kwargs['CP'] : vRESET = vRESET | (1)
    if 'CPF' in kwargs and  kwargs['CPF'] : vRESET = vRESET | (1<<17)
    if 'CPC' in kwargs and  kwargs['CPC'] : vRESET = vRESET | (1<<18)
    if 'CPG' in kwargs and  kwargs['CPG'] : vRESET = vRESET | (1<<19)
    if 'CAC' in kwargs and  kwargs['CAC'] : vRESET = vRESET | (1<<20)
    if 'CANE' in kwargs and  kwargs['CANE'] : vRESET = vRESET | (1<<21)
    if 'EA' in kwargs and  kwargs['EA'] : vRESET = vRESET | (1 << 22)
    if GFX_IP_MAJOR == 11:
       if 'UTCL2' in kwargs and  kwargs['UTCL2'] : vRESET = vRESET | (1<<15)
    else:
       if 'UTCL2' in kwargs and  kwargs['UTCL2'] : vRESET = vRESET | (1<<23)
    if 'SDMA0' in kwargs and  kwargs['SDMA0'] : vRESET = vRESET | (1 << 23) #GFX11
    if 'SDMA1' in kwargs and  kwargs['SDMA1'] : vRESET = vRESET | (1 << 24) #GFX11
    mmw(mmCP_SOFT_RESET_CNTL, cntl)
    mmw(mmGRBM_SOFT_RESET, vRESET)
    time.sleep(0.2)
    mmw(mmCP_SOFT_RESET_CNTL, 0)
    mmw(mmGRBM_SOFT_RESET, 0x0)
    mmrp(mmGRBM_STATUS)
    mmrp(mmGRBM_STATUS2)
def softresetgrbmh(vRESET=0, **kwargs):
    if 'GFX' in kwargs and  kwargs['GFX'] : vRESET = vRESET | (1 << 0)
    if 'SX' in kwargs and  kwargs['SX'] : vRESET = vRESET | (1 <<1)
    if 'EA' in kwargs and  kwargs['EA'] : vRESET = vRESET | (1 << 2)
    if 'WGS' in kwargs and  kwargs['WGS'] : vRESET = vRESET | (1 << 4)
    mmw(mmGRBMH_SOFT_RESET, vRESET)
    time.sleep(0.2)
    mmw(mmGRBMH_SOFT_RESET, 0x0)
def softreset(**kwargs):
    '''
    Following //gfxip/gfx10/doc/architecture/Reset/gfxip-soft-reset-requirements.docx
    //gfxip/gfx10/doc/architecture/Reset/gfxip-reset-confirmation-plan.docx
    '''
    mmPCIE_INDEX2 = 0x38 // 4
    mmPCIE_DATA2  = 0x3c // 4
    vRESET = 0x10001
    vCNTL = 0x34
    do_rsmu_reset = False
    norlc = False
    if 'CP_SOFT_RESET_CNTL' in kwargs : vCNTL = kwargs['CP_SOFT_RESET_CNTL']
    if 'GRBM_SOFT_RESET' in kwargs : vRESET = kwargs['GRBM_SOFT_RESET']
    if 'EA' in kwargs and  kwargs['EA'] : vRESET = vRESET | (1 << 22)
    if 'SDMA0' in kwargs and  kwargs['SDMA0'] : vRESET = vRESET | (1 << 23)
    if 'SDMA1' in kwargs and  kwargs['SDMA1'] : vRESET = vRESET | (1 << 24)
    if 'ACV' in kwargs and  kwargs['ACV'] : vRESET = vRESET | (1 << 25)
    if 'RSMU' in kwargs and  kwargs['RSMU'] : do_rsmu_reset = True
    if 'norlc' in kwargs and  kwargs['norlc'] : norlc = True
    if 'RLC' in kwargs and  kwargs['RLC'] : vRESET = vRESET | (1 << 2)

    mmw(mmCP_SOFT_RESET_CNTL, vCNTL)# Out of spec
    # Following gfxip-soft-reset-requirements.docx
    mmw(mmRLC_SAFE_MODE, 0x3)       # Enter Safe mode
    #wait until RLC_SAFE_MODE == 2  # SPEC says it must be 3, but acutally it is 2
    if not norlc:
        while (mmr(mmRLC_SAFE_MODE) & 0x1) == 1 : time.sleep(0.1)
    if vRESET:
        mmw(mmGRBM_SOFT_RESET, vRESET)  # SOFT_RESET_GFX and SOFT_RESET_CP (0x10001) by default
    time.sleep(0.2)                 #
    if do_rsmu_reset:
       mmw(mmPCIE_INDEX2, mmRSMU_SOFT_RESETB_GC*4)
       mmw(mmPCIE_DATA2,0)             # RSMU_SOFT_RESETB_GC = 0 IP specific reset, triggered by software for clearing a specific portion of IP or entire IP.
       time.sleep(0.2)                 #
       #clear all queues if you want
       #...
       #restore RSMU_SOFT_RESETB_GC
       mmw(mmPCIE_INDEX2, mmRSMU_SOFT_RESETB_GC*4)
       mmw(mmPCIE_DATA2,3)             # mmRSMU_SOFT_RESETB_GC = 3
       time.sleep(0.2)                 #
    mmw(mmGRBM_SOFT_RESET,0)        # Clear GRBM_SOFT_RESET
    time.sleep(0.1)                 #
    mmw(mmRLC_SAFE_MODE, 0x1)       # Exit Safe mode
    #wait until RLC_SAFE_MODE == 0
    if not norlc:
        while (mmr(mmRLC_SAFE_MODE) & 0x1) != 0 : time.sleep(0.1)
    mmw(mmCP_ME_CNTL, 0)            # Unhalt ME
    mmw(mmCP_MEC_CNTL, 0)           # Unhalt MEC
    # End of Following gfxip-soft-reset-requirements.docx
    mmw(mmCP_SOFT_RESET_CNTL, 0)    # Out of spec
def vmidreset(*vmids, **kwargs):
    '''
    RESET_REQUEST   15:0    Mask indicating which of the 16 VMIDs to reset. bit[0]=VMID0, bit[1]=VMID1, etc.
    PIPE0_QUEUES    23:16   Mask indicating which of the 8 queues in pipe0 to reset. bit[0]=QUEUE0, bit[1]=QUEUE1, etc.
    PIPE1_QUEUES    31:24   Mask indicating which of the 8 queues in pipe1 to reset. bit[0]=QUEUE0, bit[1]=QUEUE1, etc.
    example:
        vmidreset(1,4)  reset vmid 1 and 4
        vmidreset(1,4, pipe0=(0), pipe1=(1))  reset vmid 1 and 4, pipe0queue0 pipe1queue1
        vmidreset(mask=0xfffe)  reset with CP_VMID_RESET = 0xfffe
    '''
    _reset_request = 0
    _pipe0_queues = 0
    _pipe1_queues = 0
    for vmid in vmids:
        _reset_request = _reset_request | (1 << vmid)
    def getqueues(queues):
        if isNumber(queues): return 1<<queues
        _qs = 0
        for q in queues: _qs = _qs | (1<<q)
        return _qs & 0xff

    if 'pipe0' in kwargs: _pipe0_queues = getqueues(kwargs['pipe0'])
    if 'pipe1' in kwargs: _pipe1_queues = getqueues(kwargs['pipe1'])
    _cp_vmid_reset = (_reset_request & 0xFFFF) | (_pipe0_queues << 16) | (_pipe1_queues<<24)
    if 'mask' in kwargs: _cp_vmid_reset = kwargs['mask']
    mmw(mmCP_VMID_RESET, _cp_vmid_reset)
    time.sleep(0.2)                 #
    print("CP_VMID_RESET: 0x%x"%_cp_vmid_reset)
    mmw(mmCP_VMID_RESET, 0)
    vCPG_UTCL1_CNTL = mmr(mmCPG_UTCL1_CNTL) & 0xffffffff
    vCPG_UTCL1_CNTL = vCPG_UTCL1_CNTL | (1<<26)
    vCPF_UTCL1_CNTL = mmr(mmCPF_UTCL1_CNTL) & 0xffffffff
    vCPF_UTCL1_CNTL = vCPF_UTCL1_CNTL | (1<<26)
    mmw(mmCPG_UTCL1_CNTL, vCPG_UTCL1_CNTL)
    mmw(mmCPF_UTCL1_CNTL, vCPF_UTCL1_CNTL)
def pipelinereset(*vmids, **kwargs):
    vmidreset(*vmids, **kwargs)
def acereset(meid, pipeid, queueid, vmid):
      grbm_gfx_cntl = ((pipeid&3)<<0) | ((meid&3)<<2) | ((vmid&0xf)<<4) | ((queueid&7)<<8)
      mmw(mmGRBM_GFX_CNTL, grbm_gfx_cntl)
      mmw(mmSPI_COMPUTE_QUEUE_RESET, 1)
      time.sleep(1.2)                 #
      mmw(mmSPI_COMPUTE_QUEUE_RESET, 0)
      mmw(mmGRBM_GFX_CNTL, 0)

##############################################################################
class UCODE:
      @staticmethod
      def checksum():
          mmrp(mmCP_HYP_MEC_ME1_UCODE_CHKSUM)
          if var_exist('mmCP_HYP_MEC_ME2_UCODE_CHKSUM'):mmrp(mmCP_HYP_MEC_ME2_UCODE_CHKSUM)
          mmrp(mmCP_HYP_PFP_UCODE_CHKSUM)
          mmrp(mmCP_HYP_ME_UCODE_CHKSUM)
          if var_exist("mmCP_HYP_CE_UCODE_CHKSUM"):mmrp(mmCP_HYP_CE_UCODE_CHKSUM)
          if var_exist('mmSDMA0_UCODE_CHECKSUM'):mmrp(mmSDMA0_UCODE_CHECKSUM)
          if var_exist('mmSDMA1_UCODE_CHECKSUM'):mmrp(mmSDMA1_UCODE_CHECKSUM)
          mmrp(mmCP_CPC_IC_BASE_LO)
          mmrp(mmCP_CPC_IC_BASE_HI)
          if var_exist('mmCP_ME_IC_BASE_LO'):
              mmrp(mmCP_ME_IC_BASE_LO)
              mmrp(mmCP_ME_IC_BASE_HI)
              mmrp(mmCP_PFP_IC_BASE_LO)
              mmrp(mmCP_PFP_IC_BASE_HI)
          if var_exist('mmCP_MES_IC_BASE_LO'):
              mmw(mmGRBM_GFX_CNTL, 0xc)
              mmrp(mmCP_MES_IC_BASE_LO)
              mmrp(mmCP_MES_IC_BASE_HI)
              mmw(mmGRBM_GFX_CNTL, 0xd)
              mmrp(mmCP_MES_IC_BASE_LO)
              mmrp(mmCP_MES_IC_BASE_HI)
          if var_exist('mmWGS_IC_BASE_LO'):
              mmrp(mmWGS_IC_BASE_LO)
              mmrp(mmWGS_IC_BASE_HI)
          mmrp(mmCPC_PSP_DEBUG)
          mmrp(mmCPG_PSP_DEBUG)

      @staticmethod
      def info():
          UCODE.checksum()
ucode = UCODE()
##############################################################################
class GDB:
      @staticmethod
      def tool_load(gdb_list):
          for row in gdb_list:
              mmIndex = row[0]
              v = mmr(mmIndex)
              andMask = row[2]
              orMask = row[3]
              newv = v & (~ andMask)
              newv = v | ( andMask & orMask)
              mmw(mmIndex, newv)
      @staticmethod
      def tcore_load(gdb_list):
          for row in gdb_list:
              #/ Indirect register
              #/ item0 : register byte offset  (or offset inside indirect space)
              #/ item1 : data to write
              #/ item2 : Is indirect register
              #/ item3 : IND register
              #/ item4 : DATA register
              if row[2] :
                  regw32(row[3], row[0])
                  regw32(row[4], row[1])
              else:
                  regw32(row[0], row[1])

      @staticmethod
      def load(gdb_list):
          if len(gdb_list[0]) != 4:
              GDB.tcore_load(gdb_list)
          else:
              GDB.tool_load(gdb_list)
      @staticmethod
      def print(gdb_list):
          for row in gdb_list:
              if len(row) !=4 :
                  regr32p(row[0])
              else:
                  mmrp(row[0])

##############################################################################
class CP:
  @staticmethod
  def info():
      reg.dumpCPheader()
      UCODE.info()
  @staticmethod
  def info2():
      if GPU__GC__VARIANT == mi300:
          v0 = mmrp(mmCP_PSP_XCP_CTL)
          v1 = mmrp(mmCP_HYP_XCP_CTL)
          mmrp(mmCOMPUTE_CURRENT_LOGICAL_XCC_ID)
          mmrp(mmCP_MEC1_PIPE_XCP_FW_CTL)
          mmrp(mmCP_XCP_SYNC_REQUEST)
          mmrp(mmCP_HYP_XCP_PHY2DIE_MAP)
          print("VIRTUAL_XCC_ID:%d PHYSICAL_XCC_ID:%d XCC_DIE_ID:%d NUM_XCC_IN_XCP:%d"%(v1&7, v0&7, (v0>>3)&7, (v1>>3)&7 ))
  @staticmethod
  def sync_counter(xcc=0, mec=1, pipe=0, queue=0, i=0):
      '''
      READ_EN   0
      MEC_ID    2:1
      PIPE_ID   5:3
      QUEUE_ID  9:6
      SET_INDEX 11:10
      XCC_ID    14:12
      VALUE     22:15
      '''
      mmw(mmCP_XCP_SYNC_COUNTER_INDEX, (xcc<<12) | (i<<10) |(mec<<1) |(queue<<6) |(pipe<<3) | 1)
      mmrp(mmCP_XCP_SYNC_COUNTER_READ)

##############################################################################
##############################################################################
class GRBM:
  @staticmethod
  def info():
      mmrp(mmGRBM_STATUS)
      mmrp(mmGRBM_STATUS2)
  @staticmethod
  def softreset1(cntl = 0x34, vRESET = 0x10001, **kwargs):
      softreset1(cntl, vRESET, **kwargs)
  @staticmethod
  def debug():
      reg.dumpStatus()
grbm=GRBM()
