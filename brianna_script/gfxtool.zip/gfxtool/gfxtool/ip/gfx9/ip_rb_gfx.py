from db32 import *
from ip_gc import *
class RBA(RB):
    def __init__(self, me=0,pipe=0,queue=0,vmid=0):
       RB.__init__(self, me,pipe,queue,vmid)
    def infoGFX(self):
       pass
