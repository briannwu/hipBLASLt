#!/usr/bin/python

import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)
from db32 import *
class GDS:
    @staticmethod
    def clear():
      gds.w(0,16384,0)

    @staticmethod
    def w(start, dws, v=0):
        db32I.mmw(mmGDS_WR_ADDR, start)
        if(isNumber(v)):
          for ii in range(0, dws):
            db32I.mmw(mmGDS_WR_DATA, v)
        else:
          _len = len(v)
          for ii in range(0, dws):
            db32I.mmw(mmGDS_WR_DATA, v[ii%_len])

    @staticmethod
    def r0(start, dws):
        '''print all values include 0'''
        db32I.mmw(mmGDS_RD_ADDR, start)
        for ii in range(0, dws):
            v = db32I.mmr(mmGDS_RD_DATA)
            print("[%d 0x%X] "%(start+ii, v&0xffffffff))
    @staticmethod
    def r(start, dws, p = True):
        '''print all values except 0'''
        if p == True:
          db32I.mmw(mmGDS_RD_ADDR, start)
          for ii in range(0, dws):
            v = db32I.mmr(mmGDS_RD_DATA)
            if v != 0 and p : print("[%d 0x%X] "%(start+ii, v&0xffffffff))
          return {}
        else:
           db32s = DB32Script()
           db32s.mmw(mmGDS_RD_ADDR, start)
           for ii in range(0, dws):
               db32s.mmr(mmGDS_RD_DATA)
           r = db32s.run()
           rv = rvmaparray(r)
           return rv
    @staticmethod
    def enable(size=0x1000):
        for i in range(0,16): mmw(mmGDS_VMID0_SIZE + 2 * i, size)
    @staticmethod
    def disable():
        for i in range(0,16): mmw(mmGDS_VMID0_SIZE + 2 * i, 0x000)
    @staticmethod
    def info():
        for i in range(0,16): mmrp(mmGDS_VMID0_BASE + 2 * i)
        for i in range(0,16): mmrp(mmGDS_VMID0_SIZE + 2 * i)
        for i in range(0,16): mmrp(mmGDS_GWS_VMID0 +  i)

    class GWS:
        @staticmethod
        def enable(value=0x00400000):
            for i in range(0,16): mmw(mmGDS_GWS_VMID0 + i, value)
        @staticmethod
        def disable():
            for i in range(0,16): mmw(mmGDS_VMID0_SIZE + i, 0x000)
        @staticmethod
        def info():
            for i in range(0,16): mmrp(mmGDS_GWS_VMID0 +  i)
    gws = GWS()

gds = GDS()

def gdsw(start, dws, v=0): return gds.w(start,dws,v)
def gdsr0(start, dws): return gds.r0(start,dws)
def gdsr(start, dws): return gds.r(start,dws)

