#!/usr/bin/python
from __future__ import print_function
from db32 import *
import random
import logging
from chip_registers import *
from ip_gds import *
from ip_mm import *
from ip_rb import *
from ip_reg import *
from settings import *

class DCC:
    '''
    e.g.
    '''
    def __init__(self, fbSize=0, numChannels=0):
        self.fbSize=fbSize
        self.numChannels=numChannels
        if fbSize == 0:
            fb_location = mmr(mmGCMC_VM_FB_LOCATION_BASE)
            fb_size = mmr(mmGCMC_VM_FB_LOCATION_TOP)
            fb_location = fb_location << 24
            fb_size = ((fb_size << 24) | 0xffffff ) + 1  - fb_location
            self.fbSize = fb_size
        if numChannels == 0:
            if Settings.mAsic == navi48: self.numChannels = 16
            elif Settings.mAsic == navi44: self.numChannels = 8
            else: self.numChannels = GC__NUM_EA
        self.channelSize= self.fbSize // self.numChannels

    def info(self):
        mmrp(mmGL1A_COMPRESSION_MODE)
        mmrp(mmGL1XA_COMPRESSION_MODE)
        mmrp(mmGL2C_CTRL2)
        mmrp(mmTCP_COMPRESSION_CNTL)
        __gold='''
        hannel Size (MB)        GECC        MetaAddrOffset (Hex)
        1024    0   0x3FC
        1024    1   0x3BC
        1536    0   0x5F8
        1536    1   0x598
        2048    0   0x7F8
        2048    1   0x778
        3072    0   0xBF0
        3072    1   0xB30
        4096    0   0xFF0
        4096    1   0xEF0
        '''
        metaoffset = smn.regr32(0x490023d8)
        print(" %s MallChannelMetaAddressOffset"%Fmt.hex(metaoffset))
        metaoffsets     = {1024:0x3FC, 1536:0x5F8, 2048:0x7F8, 3072:0xBF0, 4096:0xFF0}
        metaoffsetsgecc = {1024:0x3BC, 1536:0x598, 2048:0x778, 3072:0xB30, 4096:0xEF0}
        _fbmb = self.fbSize >> 20
        if metaoffsets[_fbmb] != metaoffset   and metaoffsetsgecc[_fbmb] != metaoffset:
            print("Error, please check MallChannelMetaAddressOffset")
            print(__gold)

    def tcpmode(self, myode):
        mmw(mmTCP_COMPRESSION_CNTL, 0x8)

    def __PAtoNA(self, pa):
        '''Use the following formula to translate PA to NA.
           This has not considered the channel hashing functions.

           CH_ID = PA[44:8] % NUM_CHANNELS
           NA[44:8] = PA[44:8] / NUM_CHANNELS
        '''
        channelBlockPhysAddr = pa >> 8;
        channelId = channelBlockPhysAddr % self.numChannels
        normalizedAddr = (channelBlockPhysAddr // self.numChannels) << 8
        return (normalizedAddr, channelId)
    def __metaNA(self, dataNA, gecc):
        '''Use the following formula to translate dataNA to keyNA
           CH_SIZE = DRAMSize / NUM_CHANNELS
           GECC_RESERVATION_SIZE = CH_SIZE / 16 (Navi4m only)
           KeyNA = DataNA/256 + CH_SIZE*255/256 - GECC_RESERVATION_SIZE
        '''
        geccReservationSize = self.channelSize // 16 if gecc else 0;
        # chiplet: geccReservationSize = 0;
        keyNA = dataNA // 256 + self.channelSize * (256- 1) // 256 - geccReservationSize;
        return keyNA;
    def __NAtoPA(self, na, channelId):
        '''
           PA = {NA[44:8] * NUM_CHANNELS + CH_ID, NA[7:0]}
        '''
        physAddr = ((na >> 8) * self.numChannels + channelId) << 8
        physAddr = (physAddr&0xffffffffffff) + (na&0xff)
        return physAddr
    def metaPA(self, dataPA, gecc = 1):
        (dataNA, channelId)=self.__PAtoNA(dataPA);
        keyNA = self.__metaNA(dataNA, gecc);
        keyPA = self.__NAtoPA(keyNA, channelId);

        return keyPA;

#dcc = DCC(0x20000000, 16)
