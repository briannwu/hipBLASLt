#!/usr/bin/python
from settings import *

def list_fds():
    """List process currently open FDs and their target """
    if sys.platform != 'linux2':
        raise NotImplementedError('Unsupported platform: %s' % sys.platform)

    ret = {}
    base = '/proc/self/fd'
    for num in os.listdir(base):
        path = None
        try:
            path = os.readlink(os.path.join(base, num))
        except OSError as err:
            # Last FD is always the "listdir" one (which may be closed)
            if err.errno != errno.ENOENT:
                raise
        ret[int(num)] = path
    print( ret)
    return ret


class BitArray(object):
    def __init__(self, length, v = 0, little = True):
        self.values = bytearray(b"\x00" * (length // 8 + (1 if length % 8  else 0)))
        self.length = length
        self.little = little
        v = v & 0xffffffffffffffff
        for i in range(0, len(self.values)): self.values[i] =  (v >> (8*i) ) & 0xFF

    def __setitem__(self, index, value):
        value = int(bool(value)) << ( index % 8)
        mask = 0xff ^ ( index % 8)
        self.values[index // 8] &= mask
        self.values[index // 8] |= value
    def __getitem__(self, index):
        if index >= self.length: raise IndexError
        mask = 1 << ( index % 8)
        return bool(self.values[index // 8] & mask)
    @property
    def raw(self):
        v = 0
        for i in range(0, len(self.values)):  v = v | ((self.values[i] & 0xff)<< (8*i))
        return v

    @raw.setter
    def raw(self, v):
        for i in range(0, len(self.values)): self.values[i] =  (v >> (8*i) ) & 0xFF

    def __len__(self):
        return self.length

    def __repr__(self):
        #s = "{}".format("".join("{:b}".format(value) for value in self))
        s = "{}".format("".join("{:b}".format(self[i]) for i in range(0,self.length)))
        return s if self.little == False else s[::-1]

class BitStruct(object):
    #_fields = [
    #["ACP",4],
    #["VCN",1],
    #]
    def __init__(self):
        self._values = []
        for one in self._fields:
            self._values.append((one[0], BitArray(one[1])))
    def __setitem__(self, item, value):
        #self['DCE']
        if self.has_key(item):
            return self._set_value(item, value)
        raise AttributeError(str(item) + ' not found')
        #self.__dict__[item] = value

    def __getitem__(self, item):
        #self['DCE']
        if self.has_key(item): return self._get_value(item)
        return object.__getattribute__(self, item)

    def __getattr__(self, item):
        #.ACP
        if self.has_key(item): return self._get_value(item)
        return object.__getattribute__(self, item)
    def __setattr__(self, item, value):
        #.ACP
        if item == '_values':
            self.__dict__[item] = value
            return
        if self.has_key(item):
            return self._set_value(item, value)
        self.__dict__[item] = value

    def assign(self, s):
        if isinstance(s, str):
            if len(s) != self.__len__():
                raise ValueError( "The lenth of str must be %d, but it is %d"%(len(self), len(s)) )
            _start = 0
            for i in self._values:
                cur = s[_start:_start + len(i[1])]
                i[1].raw = int(cur, 2)
                _start = _start + len(i[1])
        else:
            raise NotImplementedError('Unsupported input: %s' %(str(type(s))))
    def _set_value(self, index, value):
        bits = self._get_bitarray(index)
        bits.raw = value
    def _get_value(self, index):
        bits = self._get_bitarray(index)
        return bits.raw
    def _get_bitarray(self, index):
        for i in self._values:
            if i[0] == index: return i[1]
        raise AttributeError('Not found')
    def has_key(self, index):
        for i in self._values:
            if i[0] == index: return True
        return False

    def __len__(self):
        _length = 0
        for i in self._values:
            _length = _length + len(i[1])
        return _length
    def readable(self):
        readable = 1
        if readable > 0: debestr = '-'.join([i[0] + ":" +  repr(i[1]) for i in self._values])
        return debestr
    def __repr__(self):
        debestr = ''.join([repr(i[1]) for i in self._values])
        return debestr
def bitCount(int_type):
     count = 0
     while(int_type):
         int_type &= int_type - 1
         count += 1
     return(count)
