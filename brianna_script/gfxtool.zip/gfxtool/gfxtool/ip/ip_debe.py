
from ip_util import *
from db32 import *
from collections import OrderedDict
from settings import *
from debe import *
if 'Debe' in globals().keys():
    pass
else:
    if GFX_IP_MAJOR == 12:
        from debe12 import *
    elif GFX_IP_MAJOR == 11:
        from debe11 import *
    elif GFX_IP_MAJOR == 10:
        if Settings.mAsic >= arden:
            from debe10_3 import *
        else:
            from debe10_1 import *
