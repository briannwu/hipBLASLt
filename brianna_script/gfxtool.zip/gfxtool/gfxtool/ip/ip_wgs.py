#!/usr/bin/python
from __future__ import print_function
from db32 import *
import random
import logging
from chip_registers import *
from ip_gds import *
from ip_mm import *
from ip_rb import *
from ip_reg import *
from settings import *

class WGS:
    '''
    e.g.
        sudo ./navi48 -e"with WGS(0,0) as wgs:  wgs.test_write_data(0xd000000000, 0xed)"
        sudo ./navi48 -e"with WGS(0,0) as wgs:  wgs.test_d2m(0xd000000000, 0xed)"
        sudo ./navi48 -e"with WGS(0,0) as wgs:  wgs.test_d2r(mmWGS_DATA5, 0xed)"
    '''
    def __init__(self, pipe, se = 0xff, **kwargs):
        self.pipe = pipe
        self.grbm_gfx_cntl = pipe | (1<<2)
        self.grbm_gfx_index = 0xe0000000
        if se < 4: 
            self.grbm_gfx_index = se << 16
        if 'select' in kwargs and kwargs['select']:
            self.enter()
    def __del__(self):
        self.exit()
    def __enter__(self):
        self.enter()
        return self 
    def __exit__(self, *args):
        self.exit()
    def enter(self):
        mmw(mmGRBM_GFX_CNTL, self.grbm_gfx_cntl)
        mmw(mmGRBM_GFX_INDEX, self.grbm_gfx_index)
        return self
    def exit(self):
        mmw(mmGRBM_GFX_CNTL, 0)
        mmw(mmGRBM_GFX_INDEX, 0xe0000000)
    def watch(self, **kwargs):
        reg.watch(mmWGS_STATUS, **kwargs)
    def softreset(self, **kwargs):
        mmw(mmGRBMH_SOFT_RESET, 1<<4)
        time.sleep(0.5)
        mmw(mmGRBMH_SOFT_RESET, 0)
    def reset(self, **kwargs):
        mmw(mmWGS_RS64_THREAD_CNTL, 0x10000)
        time.sleep(0.5)
        mmw(mmWGS_RS64_THREAD_CNTL, 0x4000000)

    def info(self):
        self.enter()
        mmrp(mmWGS_UCODE_VERS)
        mmrp(mmWGS_DEBUG)
        mmrp(mmWGS_ME1_UCODE_ADDR)
        mmrp(mmWGS_ME1_UCODE_CHKSUM)
        mmrp(mmWGS_IC_BASE_LO)
        mmrp(mmWGS_IC_BASE_HI)
        mmrp(mmWGS_IC_BASE_CNTL)
        mmrp(mmWGS_INT_INFO)
        mmrp(mmWGS_INT_STATUS)
        mmrp(mmWGS_IH_FREE_COUNT)
        mmrp(mmWGS_IQ_TIMER)
        mmrp(mmWGS_ME1_PIPE0_PRIORITY)
        mmrp(mmWGS_ME1_PIPE1_PRIORITY)
        mmrp(mmWGS_METADATA_BASE_ADDR_LO)
        mmrp(mmWGS_METADATA_BASE_ADDR_HI)
        mmrp(mmWGS_METADATA_CNTL)
        mmrp(mmWGS_MIE_LO)
        mmrp(mmCP_MEC_MIE_LO)
        mmrp(mmWGS_MIE_HI)
        mmrp(mmWGS_RS64_THREAD_CNTL)
        mmrp(mmWGS_STATUS)
        mmrp(mmWGS_BUSY_STAT)
        mmrp(mmWGS_BUSY_STAT2)
        pkts = [0]*17
        pkts[0] = mmr(mmWGS_GP0_LO)
        for i in range(0,16): pkts[i+1] = mmr(mmWGS_DATA1 +i)
        print("GP0_LO and WGS_DATA")
        hexprint(pkts)
    def interrupt(self, srcid=0xf0):
        self.enter()
        v = (1<<8) | (srcid & 0xff)
        mmw(mmWGS_INT_STATUS, v)
    def submit(self, packets):
        self.enter()
        hexprint(packets)
        mmw(mmWGS_RS64_THREAD_CNTL, 0x04000000)
        mmw(mmWGS_GP0_LO, packets[0])
        for i in range(0, len(packets)-1):
            mmw(mmWGS_DATA1 + i, packets[i+1])
        # trigger
        mmw(mmWGS_METADATA_CNTL, 0x810);  # EVENT1[11]=1, EVENT_MODE[5:4]=0x
        # Wait for WGS to complete packet
        if self.grbm_gfx_index == 0xe0000000:
            for se in RANGE_SE:
                mmw(mmGRBM_GFX_INDEX, se<<16)
                while (mmr(mmWGS_RS64_THREAD_CNTL) & 0xf) != 0x2:
                  pass
            mmw(mmGRBM_GFX_INDEX, 0xe0000000)
        else:
            while (mmr(mmWGS_RS64_THREAD_CNTL) & 0xf) != 0x2:
                pass
        '''
        WGS_RS64_THREAD_CNTL.MEC_STATUS[3:0] SETTING
        0   No FW activity
        1   FW completed Bootcode 
        2   FW completed Packet execution
        3   FW completed Interrupt handler
        4   FW ingested all Packet dwords
        '''
        mmw(mmWGS_RS64_THREAD_CNTL, 0x04000000)
    def test_copy_data(self, src, dst, **kwargs):
        dst_sel = 2 if not 'dst_sel' in kwargs  else kwargs['dst_sel'] #gl1
        src_sel = 2 if not 'src_sel' in kwargs  else kwargs['src_sel'] #gl1
        dst_scope = 3 if not 'dst_scope' in kwargs  else kwargs['dst_scope'] #gl1
        src_scope = 3 if not 'src_scope' in kwargs  else kwargs['src_scope'] #gl1
        qword = 0 if not 'qword' in kwargs else kwargs['qword'] 
        confirm = 0 if not 'confirm' in kwargs else kwargs['confirm']
        control = (confirm << 20)|(qword << 16)|(dst_sel << 8)|(dst_scope<<6) |(src_scope << 4)|(src_sel)
        if 'control' in kwargs: control = kwargs['control']
        packets = [0xc0044000, control, src&0xffffffff, (src>>32)&0xffffffff, dst&0xffffffff, (dst>>32)&0xffffffff]
        self.submit(packets)
    def test_write_data(self, data, dst, **kwargs):
        '''
        rely on wgs test firmware
        dst_sel:
        0=mem_mapped_registe mem_mapped_register.  (WGS resident GRBM/CSR registers only – see WGS MAS)
        1=reserved.
        2=gl1 
        3=reserved. 
        4=reserved.
        5=memory. (same as gl1) 6=memory_mapped_adc_persistent_state.

        Scope for write to GL1
        0 = CU (N/A to WGS)
        1 = SE
        2 = DEV
        3 = SYS
        '''
        dst_sel = 5 if not 'dst_sel' in kwargs  else kwargs['dst_sel']
        scope = 3 if not 'scope' in kwargs  else kwargs['scope']
        control = (scope <<25) | (1<<20) | (dst_sel<<8)
        packets = [0xc0033700, control, dst&0xffffffff, (dst>>32)&0xffffffff, data]
        self.submit(packets)
    def test_d2m(self, data, dst):
        self.test_write_data(dst, data, dst_sel=5, scope=3)
        mm.readp(dst)
    def test_d2r(self, data, dst):
        self.test_write_data(dst, data, dst_sel=0, scope=3)
        mmrp(dst)

#wgs0 = WGS(0,0xf)
#wgs1 = WGS(1,0xf)
wgs0 = WGS(0,0, select=0)
