#!/usr/bin/python
from db32 import *
from ip_reg import *
import time

class CGCG:
    @staticmethod
    def status():
        reg.dump(mmRLC_CGTT_MGCG_OVERRIDE);
        reg.dump(mmRLC_CGCG_CGLS_CTRL);
        reg.dump(mmRLC_MGCG_CTRL);
        reg.dump(mmCP_RB_WPTR_POLL_CNTL)
        reg.dump(mmCP_INT_CNTL)
        reg.dump(mmRLC_GPM_STAT)
        reg.dump(mmRLC_CLK_CNTL)

    #//gfxip/gfx9/doc/design/power/clock_gating/MI100_CG_sequence/en_GFXIP_cgcg_cgls.cpp
    @staticmethod
    def on():
       ##Safe Mode
       #mmw(mmSMUSVI0_TFN, 1)
       #mmrp(mmSMUSVI0_TEL_PLANE1)
       mmw(mmRLC_SAFE_MODE, 3)
       safemode = mmrp(mmRLC_SAFE_MODE)
       while safemode != 2:
           time.sleep(1)
           safemode = mmrp(mmRLC_SAFE_MODE)
       print("enter safemode")
       ##enable CGCG by
       ##//write cmd to clear cgcg ov
       ##//write cmd to clear cgls ov
       oldv = mmr(mmRLC_CGTT_MGCG_OVERRIDE)
       newv = oldv & (~ 0x18) # GFXIP_MGCG_OVERRIDE = 0 GFXIP_CGCG_OVERRIDE = 0
       mmw(mmRLC_CGTT_MGCG_OVERRIDE, newv)

       ## enable cgcg FSM
       mmw(mmRLC_CGCG_CGLS_CTRL,0x0020003f);

       ## set IDLE_POLL_COUNT
       mmw(mmCP_RB_WPTR_POLL_CNTL,0x00900100);

       ## enable interrupt for idle and busy
       ##CP_INT_CNTL.bits.CNTX_BUSY_INT_ENABLE = 0x1;
       ##CP_INT_CNTL.bits.CNTX_EMPTY_INT_ENABLE = 0x1;
       ##CP_INT_CNTL.bits.CMP_BUSY_INT_ENABLE = 0x1;
       #3CP_INT_CNTL.bits.GFX_IDLE_INT_ENABLE = 0x1;
       oldv = mmr(mmCP_INT_CNTL)
       newv = oldv | 0x3c0000
       mmw(mmCP_INT_CNTL, newv)

       mmw(mmRLC_SAFE_MODE, 1)
       safemode = mmrp(mmRLC_SAFE_MODE)
       while safemode != 0:
           time.sleep(1)
           safemode = mmrp(mmRLC_SAFE_MODE)
       print("leave safemode")
       with mystdin() as stdin :
         while True:
          char = stdin.getch()
          time.sleep(1)
          if(char == "q"): break
          v = mmr(mmRLC_GPM_STAT)
          #v1 = mmr(mmSMUSVI0_TEL_PLANE1)
          print("GFX_CLOCK_STATUS : %x"%((v & 4) >> 2))
          print("GFX_LS_STATUS: %x"%((v & 8)>>3))
          #print("SVI0_PLANE1_IDDCOR: %x"%(v1 & 0xff))
          print("")

    @staticmethod
    def off():
       '''
        1.  Enter RLC safemode
          a.  RLC_SAFE_MODE.bits.CMD = 0x1;
          b.  RLC_SAFE_MODE.bits.MESSAGE = 0x1;
        2.  Disable CGCG and CGLS
          a.  RLC_CGCG_CGLS_CTRL.bits.CGLS_EN = 0x0;
          b.  RLC_CGCG_CGLS_CTRL.bits.CGCG_EN = 0x0;
        3.  Disable 3DCGCG and 3DCGLS
          a.  RLC_CGCG_CGLS_CTRL_3D.bits.CGLS_EN = 0x0;
          b.  RLC_CGCG_CGLS_CTRL_3D.bits.CGCG_EN = 0x0;
        4.  Exit RLC safemode
          a.  RLC_SAFE_MODE.bits.CMD = 0x1;
          b.  RLC_SAFE_MODE.bits.MESSAGE = 0x0;
       '''
       mmw(mmRLC_SAFE_MODE, 3)
       safemode = mmrp(mmRLC_SAFE_MODE)
       while safemode != 2:
           time.sleep(1)
           safemode = mmrp(mmRLC_SAFE_MODE)
       print("enter safemode")

       oldv = mmr(mmRLC_CGCG_CGLS_CTRL)
       newv = oldv & (~3)
       mmw(mmRLC_CGCG_CGLS_CTRL, newv)

       #oldv = mmr(mmRLC_CGCG_CGLS_CTRL_3D)
       #newv = oldv & (~3)
       #mmw(mmRLC_CGCG_CGLS_CTRL_3D, newv)

       mmw(mmRLC_SAFE_MODE, 1)
       safemode = mmrp(mmRLC_SAFE_MODE)
       while safemode != 0:
           time.sleep(1)
           safemode = mmrp(mmRLC_SAFE_MODE)
       print("leave safemode")
       pass

class MGCG:
    @staticmethod
    def status():
        reg.dump(mmRLC_CGTT_MGCG_OVERRIDE);
        reg.dump(mmCP_MEM_SLP_CNTL);
        reg.dump(mmRLC_MEM_SLP_CNTL);
        reg.dump(mmRLC_GPM_STAT)
    @staticmethod
    def on():
        '''
        //gfxip/gfx9/doc/design/power/clock_gating/MI200_CG_sequence/en_GFXIP_mgcg_shls.cpp
        RLC_CGTT_MGCG_OVERRIDE RLC_CGTT_MGCG_OVERRIDE;
        RLC_CGTT_MGCG_OVERRIDE.u32All = reg_read(mmRLC_CGTT_MGCG_OVERRIDE);
        RLC_CGTT_MGCG_OVERRIDE.bits.RLC_CGTT_SCLK_OVERRIDE  = 0x0;
        RLC_CGTT_MGCG_OVERRIDE.bits.GRBM_CGTT_SCLK_OVERRIDE = 0x0;

        RLC_CGTT_MGCG_OVERRIDE.bits.GFXIP_MGCG_OVERRIDE     = 0x0;
        RLC_CGTT_MGCG_OVERRIDE.bits.GFXIP_MGLS_OVERRIDE     = 0x0;

        RLC_CGTT_MGCG_OVERRIDE.bits.GFXIP_FGCG_OVERRIDE     = 0x0;
        RLC_CGTT_MGCG_OVERRIDE.bits.ENABLE_CGTS_LEGACY      = 0x0;
        reg_write(mmRLC_CGTT_MGCG_OVERRIDE,RLC_CGTT_MGCG_OVERRIDE.u32All);


        CP_MEM_SLP_CNTL CP_MEM_SLP_CNTL;
        CP_MEM_SLP_CNTL.u32All = reg_read(mmCP_MEM_SLP_CNTL);
        CP_MEM_SLP_CNTL.bits.CP_MEM_LS_EN = 0x1;
        reg_write(mmCP_MEM_SLP_CNTL,CP_MEM_SLP_CNTL.u32All);

        RLC_MEM_SLP_CNTL RLC_MEM_SLP_CNTL;
        RLC_MEM_SLP_CNTL.u32All = reg_read(mmRLC_MEM_SLP_CNTL);
        RLC_MEM_SLP_CNTL.bits.RLC_MEM_LS_EN = 0x1;
        reg_write(mmRLC_MEM_SLP_CNTL,RLC_MEM_SLP_CNTL.u32All);
        '''
        v = mmr(mmRLC_CGTT_MGCG_OVERRIDE);
        v = v & (~( (1<<1) | (1<<5) | (1<<2) | (1<<6) | (1<<8) |(1<<16)))
        mmw(mmRLC_CGTT_MGCG_OVERRIDE, v)
        v = mmr(mmCP_MEM_SLP_CNTL)
        v = v | 1
        mmw(mmCP_MEM_SLP_CNTL, v)
        v = mmr(mmRLC_MEM_SLP_CNTL)
        v = v | 1
        mmw(mmRLC_MEM_SLP_CNTL,v)
    @staticmethod
    def off():
        '''
        1.  Set MGCG/MGLS override
          a.  RLC_CGTT_MGCG_OVERRIDE.bits.RLC_CGTT_SCLK_OVERRIDE= 0x1;
          b.  RLC_CGTT_MGCG_OVERRIDE.bits.GRBM_CGTT_SCLK_OVERRIDE= 0x1;
          c.  RLC_CGTT_MGCG_OVERRIDE.bits.GFXIP_MGCG_OVERRIDE= 0x1;
          d.  RLC_CGTT_MGCG_OVERRIDE.bits.GFXIP_MGLS_OVERRIDE= 0x1;
        2.  Disable CPF mgls
          a.  CP_MEM_SLP_CNTL.bits.CP_MEM_LS_EN = 0x0;
        3.  Disable RLC mgls
          a.  RLC_MEM_SLP_CNTL.bits.RLC_MEM_LS_EN = 0x0;
        '''
        oldv = mmr(mmRLC_CGTT_MGCG_OVERRIDE)
        newv = oldv | 0x2e
        mmw(mmRLC_CGTT_MGCG_OVERRIDE, newv)

        oldv = mmr(mmCP_MEM_SLP_CNTL)
        newv = oldv & (~1)
        mmw(mmCP_MEM_SLP_CNTL, newv)

        oldv = mmr(mmRLC_MEM_SLP_CNTL)
        newv = oldv & (~1)
        mmw(mmRLC_MEM_SLP_CNTL, newv)
        pass

class FGCG:
    @staticmethod
    def status():
        reg.dump(mmRLC_CGTT_MGCG_OVERRIDE);
        reg.dump(mmRLC_CLK_CNTL);
        reg.dump(mmRLC_GPM_STAT)
    @staticmethod
    def on():
        pass
    @staticmethod
    def off():
        '''
        1.  RLC_CGTT_MGCG_OVERRIDE.bits.GFXIP_FGCG_OVERRIDE= 0x1;
        2.  RLC_CLK_CNTL.bits.RLC_SRAM_CLK_GATER_OVERRIDE = 0x1;
        '''
        oldv = mmr(mmRLC_CGTT_MGCG_OVERRIDE)
        newv = oldv | 0x100
        mmw(mmRLC_CGTT_MGCG_OVERRIDE, newv)

        oldv = mmr(mmRLC_CLK_CNTL)
        newv = oldv | 0x100
        mmw(mmRLC_CLK_CNTL, newv)
cgcg=CGCG()
mgcg=MGCG()
fgcg=FGCG()
