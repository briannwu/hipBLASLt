import os,sys,inspect
from db32 import *
from ip_rb import *
class RBA(RB):
    def __init__(self, me=0,pipe=0,queue=0,vmid=0):
       RB.__init__(self, me,pipe,queue,vmid)
    def info(self):
       self.q.select()
       if self.q.me == 0 : self.infoGFX(self.q.pipe)
       else: self.infoCS()
    def infoGFX(self, rbi):
       _mmDOORBELL_CONTTROL = mmCP_RB_DOORBELL_CONTROL
       _control = mmrp(_mmDOORBELL_CONTTROL)
       _doorbell_offset = (_control &0x3ffffffc)>> 2
       _doorbell_en = (_control &0x40000000) >> 30
       print("DOORBELL:%X"% _doorbell_offset)
       mmrp(mmCP_GFX_HQD_ACTIVE)
       mmrp(mmCP_GFX_HQD_CNTL)
       _base = mmrp(mmCP_GFX_HQD_BASE) + (mmrp(mmCP_GFX_HQD_BASE_HI) << 32)
       _base = _base << 8
       _raddr = mmrp(mmCP_GFX_HQD_RPTR_ADDR) +  (mmrp(mmCP_GFX_HQD_RPTR_ADDR_HI) << 32)
       mmrp(mmCP_GFX_HQD_CSMD_RPTR)
       _rptr = mmrp(mmCP_GFX_HQD_RPTR)
       _wptr = mmrp(mmCP_GFX_HQD_WPTR)
       mmrp(mmCP_GFX_HQD_WPTR_HI)
       _waddr = mmrp(mmCP_RB_WPTR_POLL_ADDR_LO) +  (mmrp(mmCP_RB_WPTR_POLL_ADDR_HI) << 32)
       print("WPTR_POLL_ADDR:")
       _wptr2 = mm.readp(_waddr,8, 0)[0]
       if _wptr == 0 : _wptr = _wptr2
       print("CP_GFX_HQD_RPTR_ADDR:")
       _rptr2 = mm.readp(_raddr,2)[0]
       if _rptr == 0 : _rptr = _rptr2
       mmw(mmGRBM_GFX_CNTL, 0)
       print("RB_BASE:")
       mm.readp(_base)
       print("RB_BASE + WPTR - 8:")
       mm.readp(_base+_wptr*4 - 32)
       print("WPTR %X"%(_wptr))
       print("RPTR %X"%(_rptr))
       print("BASE %X"%(_base))
       self.rptr= _wptr
       self.wptr= _rptr
       self.base= _base
       print("To parse pm4 in the ring: -e'RB.parsePM4(0x%x, ndwords)'"%_base)
