#!/usr/bin/python3
#import commands

import os
import sys
import inspect
GFXTOOL_ROOT=os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
if os.path.exists(GFXTOOL_ROOT+"/asics/" + os.path.splitext(os.path.basename(__file__))[0]):
    sys.path.insert(0,GFXTOOL_ROOT+"/asics/" + os.path.splitext(os.path.basename(__file__))[0])
sys.path.insert(0, GFXTOOL_ROOT+"/ip/")
sys.path.insert(0, GFXTOOL_ROOT+"/asics/")
from optparse import OptionParser
from settings import *

MSG_USAGE = '''  -e'cmds'\n  -e 'reg.dumpCPheader()'
e.g.
  -e"mm.va2pa(0xf400010000, 2) -v 32"
  -e"help(gds);help(mm);"
  -e"help(Fmt);"
  -e"help(RB);help(CPDMA);help(CGCG);help(DB32Script)"
  help RB CPDMA MM CGCG GDS CFG SQ
'''
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-e', '--execute', dest='cmd', type='string' , default="")
optParser.add_option('-i', '--cs', dest='cs', type=int , default=-1)
optParser.add_option('--deviceid', dest='deviceid', type=int , default=-1)
optParser.add_option('-r', '--run', dest='rcmd', type='string' , default="")
optParser.add_option('-v', '--verbose', dest='verbose', type='string', default='25.4', help="-v a.b logger.level=a;Fmt.VERBOSE=b")
optParser.add_option('-q', '--queue', dest='queue_str', type='string', default="")
optParser.add_option('-s', '--script', dest='script', type='string', default="")
optParser.add_option('-S', '--Script', dest='Script', type='string', default="")
optParser.add_option('-D', '--define', dest='define', type='string', default="")
optParser.add_option('--XCCID', dest='xccid', type='string', default='0', help="xccid, 0,1,2,...7")
optParser.add_option('--AID', dest='aid', type=int, default=0, help="aid")
optParser.add_option('--filter0', dest='filter0', action="store_true", help="do not print if value==0")
optParser.add_option('--filterf', dest='filterf', action="store_true", help="do not print if value==0xffffffff")
optParser.add_option('--numformat', dest='numformat', type="string", help="the number format")
optParser.add_option('--ipython', dest='ipython', action="store_true", help="use ipython")
optParser.add_option('--parsereg', dest='parsereg', action="store_true", help="show fields of reg")
optParser.add_option('--mmcpdma', dest='mmcpdma', action="store_true", help="use pio cpdma for copying memory")
optParser.add_option('--wgp16', dest='wgp16', action="store_true", help="assume each sa has 16 wgp slots")
optParser.add_option('--logit', dest='logit', action="store_true", help="logit decorator")
optParser.add_option('--externaldb32', dest='externaldb32', action="store_true", help="use external executable db32")
optParser.add_option('--db32', dest='db32', type="string", default="so", help="select backend[so(dll), external, tcore]")
optParser.add_option('--ips', dest='ips', type="string", default="gfx", help="select ip to load, (gfx, all)")
optParser.add_option('--crest', dest='crest', type=int, default=0, help="crest mode")
optParser.add_option('-I', '--interactive', dest='interactive', action="store_true", help="interactive mode")
optParser.add_option('-c', '--dumpcolumns', dest='dumpcolumns', type=int, help="columns of registers",default=2)
optParser.add_option('-o', '--output', dest='output', type='string', help="output file name",default="dump.txt")
optParser.add_option('-a', '--asic', dest='asic', type='string' , default="")
optParser.add_option('-?', '--?', dest='help', type='string' , default="")
optParser.add_option('--regbase', dest='regbase', type=int, default=0, help="regbase")
options, args = optParser.parse_args(sys.argv[1:] if __name__ == '__main__' else [""])

Settings.loadVar(options.define)
Settings.mOptions = options
if '-' in options.xccid or ',' in options.xccid:
   pass
else:
    #Settings.loadVar("XCCID=%s"%options.xccid)
    gg.XCCID = int(options.xccid)
#Settings.loadVar("AID=%d"%options.aid)
gg.AID = options.aid
if options.externaldb32 : options.db32 = 'external'
if options.db32 == 'external':
    Settings.use_db32S()
if options.db32 == 'tcore':
    Settings.use_db32T()

if options.asic and os.path.exists(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))+"/asics/" + options.asic):
    sys.path.insert(0, os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))+"/asics/" + options.asic)
if __name__ != '__main__' and not options.asic : options.asic = os.path.splitext(os.path.basename(__file__))[0]
Settings.getAsicPath(options) #options.asic gets updated inside this func

def unzip_reg():
    import subprocess
    asic = options.asic #os.path.basename(sys.argv[0])
    asic_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))+"/asics/" + asic
    if (not os.path.exists(asic_path + "/chip_offset.py" )) :
        if not os.path.exists( asic_path + "/" + asic + ".reg.zip"):
            __fetchcmd = asic_path + "/fetch.py -r"
            err,r = subprocess.getstatusoutput(__fetchcmd)
        subprocess.run(['unzip', asic+'.reg.zip'], cwd=asic_path)

unzip_reg()

if options.interactive == True:
    import subprocess
    asic = os.path.basename(sys.argv[0])
    cmd0 =  "import os, sys"
    mydir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    asicpath = mydir +"/asics/" + asic
    settingpath = mydir + "/asics/"
    if os.path.exists(asicpath):
      cmd1 = "sys.path.insert(0,\"%s\")"%settingpath
    else: cmd1 = "\n"
    cmd1 = cmd1 + "\nfrom settings import *"
    if options.db32 == 'tcore':cmd1 = cmd1 + "\nSettings.use_db32T()"
    cmd2 = "from %s import *"%asic
    cmd3 = "Fmt.setverbose(%d)"%(int(options.verbose.split('.')[1]) if '.' in options.verbose else 4)
    cmd3 = cmd3 + "\n" + "logging.basicConfig(level=%d)"%(int(options.verbose.split('.')[0]))
    cmd4 = ""
    if(options.cs != -1 and options.cs != 0xffff):
      cmd4 = "db32I.CS(%d)\ndb32S.CS(%d)"%(options.cs,options.cs)
    cmd5 = ""
    if options.ipython == True :
      cmd5 = ("def int_formatter(i, pp, cycle):  pp.text(Fmt.hex(i)) \n\n"
              "get_ipython().display_formatter.formatters['text/plain'].for_type(int, int_formatter)\n")
    cmd = "\n".join((cmd0, cmd1, cmd2, cmd3, cmd4, cmd5))
    if sys.version_info.major == 2:
        subprocess.call([(mydir + "/bin/i")*(options.ipython == True) + "python2", "-i" , "-c" , cmd])
    else:
        subprocess.run([(mydir + "/bin/i")*(options.ipython == True) + "python3", "-i" , "-c" , cmd])
    exit(0)

from db32 import *

if __name__ == '__main__':
  def diag_help(*hs):
    myargs = hs
    if len(hs) == 0 : myargs = [i for i in args if i.lower() != 'help']
    if len(hs) == 0 and len(sys.argv) == 2: print(MSG_USAGE)
    for i in myargs:
        cmd = "help(%s)"%i
        exec(cmd)
else:
  def diag_help(*hs):
    interactive_msg = """
    diag_help()
    diag_help(mmr, mmw, dvd, dd, regw32, regr32)
    diag_help(db32I)
    diag_help(DB32Script)
    diag_help(RB, CPDMA, MM, CGCG, GDS, CFG, SQ)
    diag_help(Fmt)
    diag_help(db32mode)
    to use edc:
    from edc import edc
    edc.read_all()

    IMPORTANT: sys.displayhook output is hex number
    IMPORTANT: input is decimal number, use 0x for hex input
    """
    if(len(hs) == 0):    print(interactive_msg)
    else:
        for h in hs:help(h)

Settings.mParseReg = options.parsereg
Settings.mDumpColumns = options.dumpcolumns
Settings.mByCPDMA = options.mmcpdma
if options.wgp16: Fmt.wgp16()

if  __name__ == '__main__' and len(sys.argv) < 2:
    print (MSG_USAGE)
#elif __name__ == '__main__' and not sys.argv[1].startswith("-"):
elif __name__ == '__main__':
    #sys.argv includes all
    #args exclude - and --
    #cmd = sys.argv[1].lower()
    cmd = "" if len(args) == 0 else args[0].lower()
    #for i in range(2, len(sys.argv)):
    #    cmd = cmd + " " +  sys.argv[i]
    #options.cmd = cmd
    if cmd == 'gds' : from ip_gds import *
    elif cmd == 'mm' :from ip_mm import *
    elif cmd == 'cpdma' :from ip_cpdma import *
    elif cmd == 'rb' :from ip_rb import *
    elif cmd == 'sq' :from ip_sq import *
    elif cmd == 'pm' :from ip_pm import *
    elif cmd == 'cfg' :from ip_cfg import *
    elif cmd == 'harv' : from ip_harv import *
    elif cmd == 'wgs' : from ip_wgs import *
    elif cmd == 'dcc' : from ip_dcc import *
    elif cmd == 'reg' :
        from ip_reg import *
        REG.downloadRegisters()
    else:
        from ip_gds import *
        from ip_mm import *
        from ip_cpdma import *
        from ip_rb import *
        from ip_pm import *
        #from ip_pmc import *
        import ip_pmc as pmc
        from ip_cfg import *
        from ip_harv import *
        from ip_sq import *
        from ip_reg import *
        if GFX_IP_MAJOR >= 12:
            from ip_wgs import *
            from ip_dcc import *
        if cmd == 'help':
            diag_help()
            exit(0)
        elif cmd == 'cmd':
            options.cmd = CMD.cmd2func(' '.join([i for i in args[1:] if not i.startswith('-')]))
            pass
        else: pass
    if options.ips == 'all' :
        from ip_lsdma import *
        if var_exist('mmSDMA0_PIO_COMMAND'): from ip_sdma import *
        from ip_cs import *
        from ip_crest import *
else:
    from ip_gds import *
    from ip_mm import *
    from ip_cpdma import *
    from ip_rb import *
    from ip_pm import *
    #from ip_pmc import *
    import ip_pmc as pmc
    from ip_sq import *
    from ip_cfg import *
    from ip_harv import *
    if GFX_IP_MAJOR >= 12:
        from ip_wgs import *
        from ip_dcc import *
    if options.ips == 'all' :
        from ip_lsdma import *
        if var_exist('mmSDMA0_PIO_COMMAND'): from ip_sdma import *
        from ip_cs import *
        from ip_crest import *
from ip_reg import *
from ip_cfg import *
from ip_ih import *


def myrun(cmd):
    loc = {}
    exec(cmd, None, loc)
    for k, v in loc.items():
        globals()[k] = v

print("")

def runscript():
   globals()['ret'] = 1
   with open(options.script, 'r') as file:
     data = file.read()
   runrcmd(data)

def runrcmd(rcmd):
   _r = 0
   #s = DB32Script()
   #lcmd = s.formatcmd(rcmd)
   lcmd = rcmd
   myrun(lcmd)

def runecmd(cmd):
  if Settings.mDefaultdb32 == 'tcore':return  myrun(cmd)
  _r = 0
  try:
    #db32s = DB32Script()
    #db32s.myexec(cmd)
    #r = db32s.run()
    #rv = rvmaparray(r)
    #dumpmaparray(rv)
    #if len(rv) == 0 : print(r)
    with DB32Script() as s:
       s.myexec(cmd)
  except NameError as err:
    _r = 1
  finally: # !
    pass
  if _r == 1: myrun(options.cmd)

def help2cmd(topic):
    if not topic: return
    if topic == "d" or topic == "device" or topic == "devices":
        options.cmd = "cfg.devices()"
    elif is_number_try(topic) or (topic.startswith('mm')  and var_exist(topic)):
        options.cmd = "mmr(%s)"%topic
    else:
        options.cmd = "help(%s)"%topic

def on_all_devices(did, cmd):
    csids = cfg.devices(did);
    for csid in csids:
        db32I.CS(csid)
        #db32S.CS(csid)
        #runrmd(cmd)
        loc = {}
        exec(cmd, None, loc)
        #for k, v in loc.items():
        #    globals()[k] = v

def setXCC(xccid):
    gg.XCCID = xccid

def main_all_xccs():
    _allXCCs = []
    if '-' in options.xccid and ',' in options.xccid:
        print("not support both - and , in XCCID")
    elif '-' in options.xccid :
        _range = options.xccid.split('-')
        _allXCCs = list(range(int(_range[0]), int(_range[1])+1))
    elif ',' in options.xccid:
        _allXCCs = [int(i) for i in options.xccid.split(',')]

    for xccid in _allXCCs:
        setXCC(xccid)
        print("xcc%d:"%xccid)
        main()

def main_all_devices():
    did = options.deviceid
    csids = cfg.devices(did);
    for csid in csids:
        print("\n-i %d"%csid)
        if db32I: db32I.CS(csid)
        if db32S: db32S.CS(csid)
        #options.cs = csid
        main()
def main_all_devices_xccs():
    did = options.deviceid
    csids = cfg.devices(did);
    for csid in csids:
        print("\n-i %d"%csid)
        if db32I: db32I.CS(csid)
        if db32S: db32S.CS(csid)
        #options.cs = csid
        main_all_xccs()
def main():
    help2cmd(options.help)

    if len(options.queue_str) > 0:
      q = Q(options.queue_str)
      q.select()

    if options.script:
        runscript()

    if options.rcmd :
        runrcmd(options.rcmd)
    elif options.cmd :
        runecmd(options.cmd)
    else:
        if 'ret' in globals().keys() and  ret ==  1: return
        CFG.devices()
        REG.dumpStatus()

    if len(options.queue_str) > 0:
      q.done()

if options.Script:
    __folder = os.path.dirname(options.Script)
    __basename = os.path.basename(options.Script)
    if "." in __basename: __basename = os.path.splitext(__basename)[0]
    sys.path.insert(0, __folder)
    import importlib
    globals()[__basename] = importlib.import_module(__basename)
    if hasattr( globals()[__basename], 'exports'):
        _exports = globals()[__basename].exports
        if isinstance(_exports, dict):
            for k, v in globals()[__basename].exports.items():
                globals()[k] = v
        elif isinstance(_exports, list):
            for v in globals()[__basename].exports:
                globals()[v.__name__] = v
def is_number_try(val):
    try:
      numbase = 16 if val.startswith('0x') else 10
      int(val, numbase)
      return True
    except ValueError:
      return False

if __name__ == '__main__':
    #if(options.cs != -1 and options.cs != 0xffff):
    #    db32I.CS(options.cs)
    #    #db32S.CS(options.cs)
    if options.db32 == 'external':
        use_db32S()
    if options.db32 == 'tcore':
        use_db32T()

    if options.numformat != None : Fmt.setFmter(options.numformat)
    Fmt.setverbose(int(options.verbose.split('.')[1]) if '.' in options.verbose else 4)
    _loglevel = options.verbose.split('.')[0].lower()
    if 'info' in _loglevel: _loglevel = logging.INFO
    elif 'warning' in _loglevel: _loglevel = logging.WARNING
    elif 'debug' in _loglevel: _loglevel = logging.DEBUG
    Fmt.configlogger(int(_loglevel))
    if options.filter0 : Settings.FILTER0 = True
    if(options.cs == -1 and options.deviceid != -1) and ('-' in options.xccid or ',' in options.xccid):
      main_all_devices_xccs()
    elif(options.cs == -1 and options.deviceid != -1):
      main_all_devices()
    elif '-' in options.xccid or ',' in options.xccid:
      main_all_xccs()
    else:
      main()
else:
    import keyword
    def evalable(cmd):
        cmd = cmd.strip()
        if not cmd or '=' in cmd  : return False
        if cmd.startswith('print'): return False
        if keyword.iskeyword(cmd[0]) == True: return False
        return True
    class db32mode:
        @staticmethod
        def on():
            db32mode.mode = 1
            cmd = ""
            prompt = "---"
            inthemiddle = False
            print("IMPORTANT: sys.displayhook output is hex number")
            print("IMPORTANT: input is hex number for db32mode")
            print("IMPORTANT:   dvd 1000 32   # 1000 is 0x1000;32 is 0x32")
            print("IMPORTANT:   dvd (1000,32) # 1000 is 0x3e8; 32 is 0x20")
            while db32mode.mode == 1:
                if sys.version_info.major == 2:
                  cmd00 = raw_input(prompt)
                else: cmd00 = input(prompt)
                cmd0 = CMD.cmd2func(cmd00)
                #print("$$$$$$$$$$$$$ %s", cmd0)
                cmd = cmd + '\n' + cmd0 if cmd else cmd0
                if len(cmd0) == 0: inthemiddle = False
                elif keyword.iskeyword(cmd0.split()[0]) == True: inthemiddle =  True
                if inthemiddle == False:
                  if cmd.strip() == "quit" or cmd.strip() == 'q' or cmd.strip() == "quit()":
                      print("Quit from db32mode")
                      break;
                  try:
                    if evalable(cmd):
                        r = eval(cmd)
                        Fmt.display_as_hex(r)
                    else: exec(cmd)
                  except Exception as e: print(e)
                  cmd = ""
                  prompt = '---'
                else: # need more input
                  prompt = '...'
        @staticmethod
        def off():
            db32mode.mode = 0
    sys.displayhook=Fmt.display_as_hex
    logging.basicConfig(level=20)
    logging.getLogger().setLevel(20)
    diag_help()
