asicNone     = 0
carrizo      = 1
fiji         = 2
ellesmere    = 3
stoney       = 4
racerx       = 5
lexa         = 6
polaris22    = 7
greenland    = 8
raven1x      = 9
fireflight   = 10
raven2x      = 11
vega12       = 12
vega20       = 13
renoir       = 14
mi100        = 15
navi10       = 16
ariel        = 17
oberon       = 17
navi12       = 18
navi14       = 19
arden        = 20
navi21       = 21
navi22       = 22
navi23       = 23
navi24       = 24
mi200        = 25
sparkman     = 26
navi23       = 27
renoir       = 28
rembrandt    = 29
mi300        = 30
mero         = 1021
viola        = 215

navi31       = 301
navi32       = 302
navi33       = 303
phoenix      = 306
strix        = 315

navi44       = 404
navi48       = 408
navi44x2     = 442

generic = 0
dgpu = 1
apu = 2
A = 0
There = 0
ARE = 0
class tb :
    pending_finish = 0
def XccOffset(xccid): return xccid * 256 * 1024
def AidOffset(aid): return aid * 512 * 1024
def mmXccOffset(xccid): return xccid * 64 * 1024
def mmAidOffset(aid): return aid * 128 * 1024
def SmnOffset(xccid): return xccid * 0x80000000
def SmnAid(Aid): return ((Aid+4)<<32) if Aid > 0 else 0

class GlobalMutable(dict):
  def __getattr__(self, attr):
     return self[attr]
  def __setattr__(self, attr, value):
     self[attr] = value
gg = GlobalMutable({
    'XCCID':0,
    'AID':0
    })

def XCCID(a=None):
    if a == None: return gg.XCCID
    else: gg.XCCID = a
