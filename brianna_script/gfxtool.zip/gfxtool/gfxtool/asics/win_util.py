
import msvcrt

def mygetch(onechmode = True):
    """return input from stdin; if stdin has nothing, return ""
    Arg:
        onechmode == True:  return a ch
        onechmode == False:  return a strip line
    """
    if msvcrt.kbhit(): return msvcrt.getch().decode('ASCII') 
    return False
class mystdin(object):
    def __enter__(self):
        return self
    def __exit__(self, type, value, traceback):
        pass
    def getch(self):
        if msvcrt.kbhit(): return msvcrt.getch().decode('ASCII') 
        return False
def mygetch2():
    return mystdin().getch()

def press_any_key_exit(msg):
    pass
