from ip_util import *
class DebeGfx12(BitStruct):
    _fields = [
    ("SE3SA1WGP",8),
    ("SE3SA0WGP",8),
    ("SE3SA1RB",2),
    ("SE3SA0RB",2),
    ("SE3SA",2),
    ("SE2SA1WGP",8),
    ("SE2SA0WGP",8),
    ("SE2SA1RB",2),
    ("SE2SA0RB",2),
    ("SE2SA",2),
    ("SE1SA1WGP",8),
    ("SE1SA0WGP",8),
    ("SE1SA1RB",2),
    ("SE1SA0RB",2),
    ("SE1SA",2),
    ("SE0SA1WGP",8),
    ("SE0SA0WGP",8),
    ("SE0SA1RB",2),
    ("SE0SA0RB",2),
    ("SE0SA",2),
    ("GL2C",32),
    ("CPWD",4),
    ]

Debe=DebeGfx12
