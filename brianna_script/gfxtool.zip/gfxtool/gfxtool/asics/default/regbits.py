from settings import *
class BitStruct():
   import bitstruct as bs
   def __init__(self, *dwords):
           self._u32All = [0]*self._ndwords_
           if len(dwords) == 0 :
               self.parse()
               return
           if isinstance(dwords[0], list) or isinstance(dwords[0], tuple):
               for i, k in enumerate(dwords[0]): self.u32All[i] = k
           elif isinstance(dwords[0], str):
               import re
               strs = re.findall(r'(?:0[xX])?[0-9a-fA-F]+', dwords[0]) #dwords[0].split()
               for i, k in enumerate(strs): self.u32All[i] = int(k, 16)
           else:
               for i, k in enumerate(dwords): self.u32All[i] = k
           self.parse()
   def hexlist(self, _l):
           s = ' '.join("0x%x"%i for i in _l)
           return s
   def parse(self):
           self._img_rsrc =BitStruct.bs.pack("<" + "u32"*self._ndwords_, *tuple(self.u32All))
           self.bits = BitStruct.bs.unpack(self._packdes_, self._img_rsrc)
   def __repr__(self):
       #self.parse()
       if Settings.FILTER0:
           return '\n'.join(["%28s 0x%x"%(k[0], self.bits[i]) for i, k in enumerate(self._fields_) if self.bits[i] != 0])
       else:
           return '\n'.join(["%28s 0x%x"%(k[0], self.bits[i]) for i, k in enumerate(self._fields_)])

   def __setitem__(self, index, value):
       self._u32All[index] = value
       self.parse()
   def __getitem__(self, index):
       return self._u32All[index]

   def __len__(self):
        return self._ndwords_
   def __getattr__(self, attr):
       try:
          idx = next(i for i, k in enumerate(self._fields_) if k[0] == attr)
       except:
           raise AttributeError("%r object has no attribute %r" %
                 (self.__class__.__name__, attr))
       return self.bits[idx]

   @property
   def u32All(self):
      return self._u32All
   @u32All.setter
   def u32All(self, r):
       print("setter")
       pass
   @staticmethod
   def getpackdes(_fields_):
       des = ''.join("u%d"%k[2] for k in _fields_)
       ndwords = sum([k[2] for k in _fields_])
       return "<" + des, ndwords
