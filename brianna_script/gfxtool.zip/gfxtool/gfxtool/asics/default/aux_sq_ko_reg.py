from regbits import *
#import ip_util as util
from ctypes import *


class sq_buf_rsrc_t_gfx12 (BitStruct):
    _fields_ = [
        ('base_address',c_uint64,48),#//47:0
        ('stride',c_uint32,14),#//61:48
        ('swizzle_enable',c_uint32,2),#//63:62
        ('num_records',c_uint32,32),#//95:64
        ('dst_sel_x',c_uint32,3),#//98:96
        ('dst_sel_y',c_uint32,3),#//101:99
        ('dst_sel_z',c_uint32,3),#//104:102
        ('dst_sel_w',c_uint32,3),#//107:105
        ('format',c_uint32,6),#//113:108
        ('stride_scale',c_uint32,2),#//115:114
        ('_reserved_116_116',c_uint32,1),#
        ('index_stride',c_uint32,2),#//118:117
        ('add_tid_enable',c_uint32,1),#//119:119
        ('write_compress_enable',c_uint32,1),#//120:120
        ('compression_en',c_uint32,1),#//121:121
        ('compression_access_mode',c_uint32,2),#//123:122
        ('oob_select',c_uint32,2),#//125:124
        ('type',c_uint32,2),#//127:126
    ]
    _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)

class sq_buf_rsrc_t_gfx11 (BitStruct):
    _fields_ = [
        ('base_address', c_uint64, 48),
        ('stride', c_uint32, 14),
        #('cache_swizzle', c_uint32, 1),
        ('swizzle_enable', c_uint32, 2),
        ('num_records', c_uint32, 32),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('format', c_uint32, 6),
        ('_reserved_116_114', c_uint32, 3),
        ('index_stride', c_uint32, 2),
        ('add_tid_enable', c_uint32, 1),
        #('resource_level', c_uint32, 1),
        ('_reserved_123_120', c_uint32, 4),
        ('oob_select', c_uint32, 2),
        ('type', c_uint32, 2),
    ]
    _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)

class sq_img_rsrc_t_gfx12 (BitStruct):
       _fields_ = [
        ('base_address',c_uint64,40),#//39:0
        ('_reserved_43_40',c_uint32,4),#
        ('max_mip',c_uint32,5),#//48:44
        ('format',c_uint32,8),#//56:49
        ('base_level',c_uint32,5),#//61:57
        ('width',c_uint32,16),#//77:62
        ('height',c_uint32,16),#//93:78
        ('_reserved_95_94',c_uint32,2),#
        ('dst_sel_x',c_uint32,3),#//98:96
        ('dst_sel_y',c_uint32,3),#//101:99
        ('dst_sel_z',c_uint32,3),#//104:102
        ('dst_sel_w',c_uint32,3),#//107:105
        ('no_edge_clamp',c_uint32,1),#//108:108
        ('_reserved_110_109',c_uint32,2),#
        ('last_level',c_uint32,5),#//115:111
        ('sw_mode',c_uint32,5),#//120:116
        ('bc_swizzle',c_uint32,3),#//123:121
        ('type',c_uint32,4),#//127:124
        ('depth',c_uint32,14),#//141:128
        ('pitch_msb',c_uint32,2),#//143:142
        ('base_array',c_uint32,13),#//156:144
        ('base_array_msb',c_uint32,1),#//157:157
        ('_reserved_163_158',c_uint32,6),#
        ('uav3d',c_uint32,1),#//164:164
        ('min_lod_warn',c_uint32,13),#//177:165
        ('_reserved_179_178',c_uint32,2),#
        ('perf_mod',c_uint32,3),#//182:180
        ('corner_samples',c_uint32,1),#//183:183
        ('linked_resource',c_uint32,1),#//184:184
        ('_reserved_185_185',c_uint32,1),#
        ('min_lod',c_uint32,13),#//198:186
        ('_reserved_201_199',c_uint32,3),#
        ('iterate_256',c_uint32,1),#//202:202
        ('sample_pattern_offset',c_uint32,4),#//206:203
        ('max_uncompressed_block_size',c_uint32,1),#//207:207
        ('_reserved_208_208',c_uint32,1),#
        ('max_compressed_block_size',c_uint32,2),#//210:209
        ('_reserved_211_211',c_uint32,1),#
        ('write_compress_enable',c_uint32,1),#//212:212
        ('compression_en',c_uint32,1),#//213:213
        ('compression_access_mode',c_uint32,2),#//215:214
        ('_reserved_223_216',c_uint32,8),#
       ]
       _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)


class sq_img_rsrc_t_gfx11 (BitStruct):
       _fields_ = [
        ('base_address', c_uint64, 40),
        ('_reserved_46_40', c_uint32, 7),
        ('big_page', c_uint32, 1),
        ('max_mip', c_uint32, 4),
        ('format', c_uint32, 8),
        ('_reserved_61_60', c_uint32, 2),
        ('width', c_uint32, 14),
        ('_reserved_77_76', c_uint32, 2),
        ('height', c_uint32, 14),
        ('_reserved_95_92', c_uint32, 4),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('base_level', c_uint32, 4),
        ('last_level', c_uint32, 4),
        ('sw_mode', c_uint32, 5),
        ('bc_swizzle', c_uint32, 3),
        ('type', c_uint32, 4),
        ('depth', c_uint32, 13),
        ('pitch_13', c_uint32, 1),
        ('_reserved_143_142', c_uint32, 2),
        ('base_array', c_uint32, 13),
        ('_reserved_159_157', c_uint32, 3),
        ('array_pitch', c_uint32, 4),
        ('_reserved_167_164', c_uint32, 4),
        ('min_lod_warn', c_uint32, 12),
        ('perf_mod', c_uint32, 3),
        ('corner_samples', c_uint32, 1),
        ('linked_resource', c_uint32, 1),
        ('_reserved_185_185', c_uint32, 1),
        ('prt_default', c_uint32, 1),
        ('min_lod', c_uint32, 12),
        ('_reserved_201_199', c_uint32, 3),
        ('iterate_256', c_uint32, 1),
        ('sample_pattern_offset', c_uint32, 4),
        ('max_uncompressed_block_size', c_uint32, 2),
        ('max_compressed_block_size', c_uint32, 2),
        ('meta_pipe_aligned', c_uint32, 1),
        ('write_compress_enable', c_uint32, 1),
        ('compression_en', c_uint32, 1),
        ('alpha_is_on_msb', c_uint32, 1),
        ('color_transform', c_uint32, 1),
        ('meta_data_address', c_uint64, 40),
       ]
       _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)


class sq_buf_rsrc_t_gfx10 (BitStruct):
    _fields_ = [
        ('base_address', c_uint64, 48),
        ('stride', c_uint32, 14),
        ('cache_swizzle', c_uint32, 1),
        ('swizzle_enable', c_uint32, 1),
        ('num_records', c_uint32, 32),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('format', c_uint32, 7),
        ('_reserved_116_115', c_uint32, 2),
        ('index_stride', c_uint32, 2),
        ('add_tid_enable', c_uint32, 1),
        ('resource_level', c_uint32, 1),
        ('_reserved_123_121', c_uint32, 3),
        ('oob_select', c_uint32, 2),
        ('type', c_uint32, 2),
    ]
    _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)

#GFX7.3
class struct__sq_buf_rsrc_compat_b0_t (BitStruct):
    _fields_ = [
        ('base_address', c_uint64, 40),
        ('_reserved_45_40', c_uint32, 6),
        ('endian_swap', c_uint32, 2),
        ('stride', c_uint32, 14),
        ('cache_swizzle', c_uint32, 1),
        ('swizzle_enable', c_uint32, 1),
        ('num_records', c_uint32, 32),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('num_format', c_uint32, 3),
        ('data_format', c_uint32, 4),
        ('element_size', c_uint32, 2),
        ('index_stride', c_uint32, 2),
        ('add_tid_enable', c_uint32, 1),
        ('resource_level', c_uint32, 1),
        ('hash_enable', c_uint32, 1),
        ('heap', c_uint32, 1),
        ('mtype', c_uint32, 3),
        ('type', c_uint32, 2),
    ]
    _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)

#GFX7.6
class sq_buf_rsrc_compat_b1_t (BitStruct):
    _fields_ = [
        ('base_address', c_uint64, 40),
        ('_reserved_47_40', c_uint32, 8),
        ('stride', c_uint32, 14),
        ('cache_swizzle', c_uint32, 1),
        ('swizzle_enable', c_uint32, 1),
        ('num_records', c_uint32, 32),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('num_format', c_uint32, 3),
        ('data_format', c_uint32, 4),
        ('element_size', c_uint32, 2),
        ('index_stride', c_uint32, 2),
        ('add_tid_enable', c_uint32, 1),
        ('resource_level', c_uint32, 1),
        ('hash_enable', c_uint32, 1),
        ('heap', c_uint32, 1),
        ('mtype', c_uint32, 3),
        ('type', c_uint32, 2),
    ]
    _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)

class sq_img_rsrc_t_gfx10 (BitStruct):
       _fields_ = [
        ('base_address', c_uint64, 40),
        ('min_lod', c_uint32, 12),
        ('format', c_uint32, 9),
        ('_reserved_61_61', c_uint32, 1),
        ('width', c_uint32, 16),
        ('height', c_uint32, 16),
        ('_reserved_94_94', c_uint32, 1),
        ('resource_level', c_uint32, 1),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('base_level', c_uint32, 4),
        ('last_level', c_uint32, 4),
        ('sw_mode', c_uint32, 5),
        ('bc_swizzle', c_uint32, 3),
        ('type', c_uint32, 4),
        ('depth', c_uint32, 16),
        ('base_array', c_uint32, 16),
        ('array_pitch', c_uint32, 4),
        ('max_mip', c_uint32, 4),
        ('min_lod_warn', c_uint32, 12),
        ('perf_mod', c_uint32, 3),
        ('corner_samples', c_uint32, 1),
        ('linked_resource', c_uint32, 1),
        ('lod_hdw_cnt_en', c_uint32, 1),
        ('prt_default', c_uint32, 1),
        ('_reserved_190_187', c_uint32, 4),
        ('big_page', c_uint32, 1),
        ('counter_bank_id', c_uint32, 8),
        ('_reserved_201_200', c_uint32, 2),
        ('iterate_256', c_uint32, 1),
        ('_reserved_206_203', c_uint32, 4),
        ('max_uncompressed_block_size', c_uint32, 2),
        ('max_compressed_block_size', c_uint32, 2),
        ('meta_pipe_aligned', c_uint32, 1),
        ('write_compress_enable', c_uint32, 1),
        ('compression_en', c_uint32, 1),
        ('alpha_is_on_msb', c_uint32, 1),
        ('color_transform', c_uint32, 1),
        ('meta_data_address', c_uint64, 40),
       ]
       _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)


#GFX7.3
class sq_img_rsrc_compat_b0_t (BitStruct):
    _fields_ = [
        ('base_address', c_uint64, 40),
        ('min_lod', c_uint32, 12),
        ('data_format', c_uint32, 6),
        ('num_format', c_uint32, 4),
        ('mtype', c_uint32, 2),
        ('width', c_uint32, 14),
        ('height', c_uint32, 14),
        ('perf_mod', c_uint32, 3),
        ('resource_level', c_uint32, 1),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('base_level', c_uint32, 4),
        ('last_level', c_uint32, 4),
        ('tiling_index', c_uint32, 5),
        ('pow2pad', c_uint32, 1),
        ('mtype_hi', c_uint32, 1),
        ('nbc_tiling', c_uint32, 1),
        ('type', c_uint32, 4),
        ('depth', c_uint32, 13),
        ('pitch', c_uint32, 14),
        ('_reserved_159_155', c_uint32, 5),
        ('base_array', c_uint32, 13),
        ('last_array', c_uint32, 13),
        ('_reserved_191_186', c_uint32, 6),
        ('min_lod_warn', c_uint32, 12),
        ('counter_bank_id', c_uint32, 8),
        ('lod_hdw_cnt_en', c_uint32, 1),
        ('mip_base_address', c_uint32, 28),
        ('alt_tiling', c_uint32, 3),
        ('mip_packing', c_uint32, 1),
        ('endian_swap', c_uint32, 2),
        ('_reserved_255_247', c_uint32, 9),
    ]
    _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)

#GFX7.63
class sq_img_rsrc_compat_b1_t (BitStruct):
    _fields_ = [
        ('base_address', c_uint64, 40),
        ('min_lod', c_uint32, 12),
        ('data_format', c_uint32, 6),
        ('num_format', c_uint32, 4),
        ('mtype', c_uint32, 2),
        ('width', c_uint32, 14),
        ('height', c_uint32, 14),
        ('perf_mod', c_uint32, 3),
        ('resource_level', c_uint32, 1),
        ('dst_sel_x', c_uint32, 3),
        ('dst_sel_y', c_uint32, 3),
        ('dst_sel_z', c_uint32, 3),
        ('dst_sel_w', c_uint32, 3),
        ('base_level', c_uint32, 4),
        ('last_level', c_uint32, 4),
        ('tiling_index', c_uint32, 5),
        ('pow2pad', c_uint32, 1),
        ('mtype_hi', c_uint32, 1),
        ('nbc_tiling', c_uint32, 1),
        ('type', c_uint32, 4),
        ('depth', c_uint32, 13),
        ('pitch', c_uint32, 14),
        ('_reserved_155_155', c_uint32, 1),
        ('compression_enable', c_uint32, 1),
        ('_reserved_159_157', c_uint32, 3),
        ('base_array', c_uint32, 13),
        ('last_array', c_uint32, 13),
        ('_reserved_191_186', c_uint32, 6),
        ('min_lod_warn', c_uint32, 12),
        ('counter_bank_id', c_uint32, 8),
        ('lod_hdw_cnt_en', c_uint32, 1),
        ('meta_data_address', c_uint32, 32),
        ('_reserved_252_245', c_uint32, 8),
        ('alpha_is_on_msb', c_uint32, 1),
        ('color_transform', c_uint32, 1),
        ('_reserved_255_255', c_uint32, 1),
    ]
    _packdes_ , _ndwords_ = BitStruct.getpackdes( _fields_)

