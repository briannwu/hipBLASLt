import os
import io
import sys
import inspect
from amd_common import *
class Settings:
    mLoadFullRegisters = False
    mAsic = -1
    mAsicName = ""
    mAsicPath = ""
    mParseReg = False
    mDumpColumns = 2
    FILTER0 = False
    mByCPDMA = False
    mMajorVerion = 0
    mMinorVersion = 0
    mExternaldb32 = False
    mVars = {}
    mDefaultdb32 = 'so'
    mOptions = {}

    @staticmethod
    def getAsicPath(options):
        if len(Settings.mAsicPath) > 0 : return Settings.mAsicPath
        mydir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        asic = options.asic if options.asic else os.path.basename(sys.argv[0])
        #asic = os.path.splitext(os.path.basename(__file__))[0]
        asicpath = mydir +"/" + asic
        Settings.mAsicPath = asicpath
        Settings.setup(asic)
        if not options.asic: options.asic = asic
        if options.db32=="external": Settings.mExternaldb32 = True
        return asicpath
    @staticmethod
    def setup(asic):
        Settings.mAsicName = asic
        Settings.mAsic = globals()[asic]
        gfx10_3 = [navi21]
        gfx10_2 = [arden]
        gfx10_1 = [oberon, navi10, navi12, navi14, ariel]
        if  Settings.mAsic in gfx10_1: Settings.mMinorVersion = 1
        if  Settings.mAsic in gfx10_2: Settings.mMinorVersion = 2
        if  Settings.mAsic in gfx10_3: Settings.mMinorVersion = 3
    @staticmethod
    def loadVar(define):
        define=define.replace(" ", "\n");
        exec(define, None, Settings.mVars)
    @staticmethod
    def overwriteVar():
        for k, v in Settings.mVars.items():
            globals()[k] = v
        Settings.mMajorVerion = GC__TCORE_GFXIP_MAJOR_VERSION

    @staticmethod
    def wgp16():
        globals()['RANGE_WGP'] = list(range(0,16))

    @staticmethod
    def use_db32T():
       Settings.mDefaultdb32 = 'tcore'
    @staticmethod
    def use_db32S():
       Settings.mDefaultdb32 = 'external'
    @staticmethod
    def use_db32C():
       Settings.mDefaultdb32 = 'so'

