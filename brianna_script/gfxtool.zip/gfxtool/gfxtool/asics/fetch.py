#!/usr/bin/python3
import inspect
import sys
import os
import uuid
if sys.version_info.major == 2:
    import commands as subprocess
else:
    import subprocess
from optparse import OptionParser
MSG_USAGE = " "
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-a', '--asic', dest='asic', type='string' , default="")
optParser.add_option('-r', '--regs', dest='regs', action="store_true")
options, args = optParser.parse_args(sys.argv[1:])

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
asic = os.path.basename(currentdir)
asics = ["ariel", "arden", "vega20", "mi100", "navi14", "navi21", "mi200", "navi21", "navi23", "navi31"]
in_asic_folder = True if asic in asics else False
in_asic_folder = True if asic != "asics" else False
if not in_asic_folder:
     if options.asic in  asics: asic = options.asic
tmppath = currentdir + "/tmp" + str(uuid.uuid4())
if in_asic_folder:
   asic_path = currentdir
else:
   asic_path = currentdir + "/" + asic

def fetch1():
    cmd="wget --quiet http://ddavid-diag-mk.amd.com:8080/public/git/asics/%s/chip_registers.py -O %s/chip_registers_full.py" %(asic, asic_path)
    print(cmd)
    err,r = subprocess.getstatusoutput(cmd)
    print( err, r)
    return os.path.exists(asic_path+"/chip_registers_full.py")
def fetch():
    cmd = ''.join(("git init %s;"%tmppath,
            "cd %s;"%tmppath,
            "git config core.sparsecheckout true; echo 'asics/%s/chip_registers.py' >  .git/info/sparse-checkout ;"%asic,
            "git remote add origin greenland@ddavid-diag-mk.amd.com:/git; git pull origin artifacts;"))
    if in_asic_folder:
        cmd = cmd + "mv asics/%s/chip_registers.py ../chip_registers_full.py;" % asic
    else:
        cmd = cmd + "mv asics/%s/chip_registers.py ../%s/chip_registers_full.py;" % (asic,asic)
    cmd = cmd + " cd ..; rm -rf %s"%tmppath
    err,r = subprocess.getstatusoutput(cmd)
    print( err, r)

def fetch2():
    cmd="wget --quiet http://ddavid-diag-mk.amd.com:8080/public/git/asics/%s/%s.reg.zip -O %s/%s.reg.zip" %(asic, asic, asic_path, asic)
    print(cmd)
    err,r = subprocess.getstatusoutput(cmd)
    print( err, r)
    return os.path.exists(asic_path+"%s.reg.zip"%asic)

if options.regs:
    fetch2()
elif not fetch1(): fetch()
