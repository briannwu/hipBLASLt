#!/usr/bin/python
import sys
import os
import commands
from optparse import OptionParser
MSG_USAGE = " -i chip_offset.h -o chip_offset.py "
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-i', '--input', dest='input', type='string' , default="chip_offset.h")
optParser.add_option('-o', '--output', dest='output', type='string' , default="chip_offset.py")
optParser.add_option('-l', '--limit', dest='limit', type='int' , default=0x10000)
options, args = optParser.parse_args(sys.argv[1:])


def main():
    with open(options.input, 'r') as f:
      with open(options.output, 'w') as fo:
        data = f.readlines()
        regs= []
        for line in data :
            if not "#define" in line : continue
            _defines = line.split()
            if len(_defines) != 3 :
                continue
            variable = _defines[1]
            value = _defines[2]
            reg = [variable, value]
            intv = int(value, 16)
            if(intv < options.limit) and variable.startswith('mm'):
                regs.append(reg)
        for __i in range(0, len(regs)):
            fo.write("%s=%s\n"%(regs[__i][0], regs[__i][1]))
        fo.write("RegName={\n")
        for __i in range(0, len(regs)):
            fo.write("%s:\"%s\",\n"%(regs[__i][1], regs[__i][0]))
        fo.write("}\n")

main()
