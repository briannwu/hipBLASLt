#!/usr/bin/python
import sys
import os
import commands
from optparse import OptionParser
MSG_USAGE = " -i chip_offset.h -o chip_offset.py "
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-i', '--input', dest='input', type='string' , default="f32_me_defines.h")
optParser.add_option('-o', '--output', dest='output', type='string' , default="pm4_it_opcodes.py")
options, args = optParser.parse_args(sys.argv[1:])


def main():
    with open(options.input, 'r') as f:
        data = f.readlines()
        packets={}
        for line in data :
            if not ("#define F32_IT_" in line or "#define F32_It" in line): continue
            _defines = line.split()
            if len(_defines) != 3 :
                continue
            variable = _defines[1][4:]
            value = int(_defines[2], 16)
            packets[value] = variable
    with open(options.output, 'w') as fo:
        s = sorted(packets.items())
        for k, v in s:
            fo.write("%-30s=%s\n"%(v, hex(k)))
        fo.write("PM4_IT_NAME={\n")
        for k, v in s:
            fo.write("  %s:\"%s\",\n"%(hex(k),v))
        fo.write("}\n")

main()
