#!/usr/bin/python
#../preprocess_chip_register.py -i /home/david/working/git/trunk/external/amd/include/gpu/gfx/mi100/reg/chip_registers.h -o chip_registers.py -lpredefined
import sys
import os
if sys.version_info.major == 2:
    import commands as subprocess
else:
    import subprocess
from optparse import OptionParser
MSG_USAGE = " -i chip_offset.h -o chip_offset.py "
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-i', '--input', dest='input', type='string' , default="chip_registers.h")
optParser.add_option('-t', '--tempfile', dest='tempfile', type='string' , default="chip_registers.i")
optParser.add_option('-o', '--output', dest='output', type='string' , default="chip_registers.py")
optParser.add_option('-l', '--list', dest='list', type='string' , default="")
options, args = optParser.parse_args(sys.argv[1:])

ctypecmd = "~/tmps/python/ctypesgen/ctypesgen.py "

dlist= "CP_STAT CP_BUSY_STAT CP_STALLED_STAT1 CP_STALLED_STAT2 CP_STALLED_STAT3 CP_CPC_STATUS CP_CPC_BUSY_STAT CP_CPC_BUSY_STAT2 CP_CPC_STALLED_STAT1 GRBM_STATUS GRBM_STATUS2 GRBM_STATUS3"

if options.list =='predefined': options.list = dlist
def convert1():
    with open(options.input, 'r') as f:
      with open(options.tempfile, 'w') as fo:
        data = f.readlines()
        regs= []
        enableOutput = False
        enableFilter = False
        fo.write("#define LITTLEENDIAN_CPU\n")
        fo.write("#include <stdint.h>\n")
        if len(options.list) > 0 : enableFilter = True
        if enableFilter:
            for line in data :
                sline = line.strip()
                if sline.startswith('union'):
                    regName = sline.split()[1]
                    if regName in options.list: enableOutput = True
                elif sline == "};":
                    if enableOutput: fo.write(line)
                    enableOutput = False
                elif "bitfields," in sline:
                    line = line.replace("bitfields,","")
                if enableOutput: fo.write(line)
        else:
            for line in data :
                if "bitfields," in line:
                    line = line.replace("bitfields,","")
                fo.write(line)

def convert2():
    cmd = ctypecmd + options.tempfile + " -o " + options.output
    print cmd
    err,r = subprocess.getstatusoutput(cmd)
    print err, r

convert1()
convert2()
