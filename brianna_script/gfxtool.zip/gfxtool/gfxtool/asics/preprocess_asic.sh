#!/bin/bash
src_root=$1
asic=$(basename -- $PWD)
../preprocess_offset.py -i $src_root/external/amd/include/gpu/gfx/$asic/reg/chip_offset.h
../preprocess_chip_register.py -i $src_root/external/amd/include/gpu/gfx/$asic/reg/chip_registers.h -o chip_registers.py -lpredefined
../preprocess_chip_register.py -i $src_root/external/amd/include/gpu/gfx/$asic/reg/chip_registers.h -o chip_registers_full.py 
../preprocess_gc_features.bash $src_root/external/amd/include/gpu/gfx/$asic/features/gc_features.h
