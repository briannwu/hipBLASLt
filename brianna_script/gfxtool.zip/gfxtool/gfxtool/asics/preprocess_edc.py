#!/usr/bin/python
import sys
import os
import commands
from optparse import OptionParser
MSG_USAGE = " -e'cmds'"
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-e', '--execute', dest='cmd', type='string' , default="")
optParser.add_option('-i', '--input', dest='input', type='string' , default="chip_shift.h")
options, args = optParser.parse_args(sys.argv[1:])

#{TCC_CACHE_DATA: ['mmTCC_DSM_CNTL','0',    #TCC_DSM_CNTL__CACHE_DATA_IRRITATOR_DATA_SEL__SHIFT,TCC_DSM_CNTL__CACHE_DATA_IRRITATOR_SINGLE_WRITE__SHIFT
#                   'mmTCC_DSM_CNTL2', '0',  #TCC_DSM_CNTL2__CACHE_DATA_ENABLE_ERROR_INJECT__SHIFT, TCC_DSM_CNTL2__CACHE_DATA_SELECT_INJECT_DELAY__SHIFT
#                   'mmTCC_DSM_CNTL2', '26'  #TCC_DSM_CNTL2__INJECT_DELAY__SHIFT
#                  ]
#
srams = {}
delays = {}
blks= {}

def sanity(name):
    name = name.replace("SEL_DSM_", "")
    name = name.replace("_DSM", "")
    name = name.replace("__IRRITATOR_DATA__SHIFT", "")
    if name == "SQ_LDS": name = "SQ_LDS_D"
    if name[-1:] == "_": name = name[:-1]
    return name

def num3d(num):
    if num == None: return None
    v = int(num, 16)
    return "%2d"%v

def main():
    print("#!/usr/bin/python")
    print("from chip_offset import *")
    print("")
    with open(options.input, 'r') as f:
        data = f.readlines()
        for line in data :
            if not "DSM_CNTL" in line and not "ECC_CNTL" in line: continue
            if not "__" in line : continue
            line = line.strip()
            _name = ""
            _defines = line.split()
            if len(_defines) != 3: continue
            __shift = _defines[2]
            __macro = _defines[1]
            __name = ""
            if "DSM_CNTL" in __macro:
                __blk =  __macro.split("_DSM_CNTL")[0] + "_"
            else:
                __blk =  __macro.split("_ECC_CNTL")[0] + "_"
            __reg = __macro.split("__")[0]
            __field = __macro.split("__")[1]

            if "IRRITATOR_DATA_SEL__SHIFT" in __macro  or "IRRITATOR_DATA__SHIFT" in __macro or "IRRITATOR_DATA" in __macro :
                if __field == "SEL_DSM_LDS_IRRITATOR_DATA0" or __field == "SEL_DSM_LDS_IRRITATOR_DATA1":
                    __name = "SQ_LDS_D"
                elif __field == "SEL_DSM_LDS_IRRITATOR_DATA2" or __field == "SEL_DSM_LDS_IRRITATOR_DATA3":
                    __name = "SQ_LDS_I"
                else:
                    __name = __blk + __field.split("_IRRITATOR_DATA")[0]
                    __name = sanity(__name)
                if __name in srams:
                    pass
                else:
                    srams[__name] =["mm"+__reg, __shift, None, None, None, None, None, None]
                    blks[__name] = __blk
            # SINGLE_WRITE
            # : _IRRITATOR_SINGLE_WRITE__SHIFT
            # : GCEA_DSM_CNTLB__MAM_D0MEM_ENABLE_SINGLE_WRITE__SHIFT
            # : ATC_L2_CACHE_4K_DSM_CNTL__ENABLE_SINGLE_WRITE__SHIFT
            # : TCI_DSM_CNTL__WRITE_RAM_IRRITATOR_SINGLE_WRITE__SHIFT
            elif "_IRRITATOR_SINGLE_WRITE__SHIFT" in __macro or "ENABLE_SINGLE_WRITE" in __macro:
                if "LDS_ENABLE_SINGLE_WRITE01" == __field:
                    __name = "SQ_LDS_D"
                elif "LDS_ENABLE_SINGLE_WRITE23" == __field:
                    __name = "SQ_LDS_I"
                elif "_IRRITATOR_SINGLE_WRITE" in __field:
                    __name = __blk + __field.split("_IRRITATOR_SINGLE_WRITE")[0]
                elif "_ENABLE_SINGLE_WRITE" in __field:
                    __name = __blk + __field.split("_ENABLE_SINGLE_WRITE")[0]
                elif "ENABLE_SINGLE_WRITE" in __field:
                    __name = __blk + __field.split("ENABLE_SINGLE_WRITE")[0]
                __name = sanity(__name)
                if __name in srams:
                   _single_write_offset = int(__shift,16)
                   _single_write_offset_expect = int(srams[__name][1], 16) + 2
                   if _single_write_offset !=  _single_write_offset_expect:
                      print("SINGLE_WRITE__SHIFT error : Actual %s , Expect %d" %(_single_write_offset, _single_write_offset_expect), "Error in name(%s) __field(%s) __blk(%s) __macro(%s)"%(__name, __field, __blk, __macro))
                   else:
                       srams[__name][6] = "mm"+__reg
                       srams[__name][7] = __shift
                else:
                   print("Error in name(%s) __field(%s) __blk(%s) __macro(%s)"%(__name, __field, __blk, __macro))
            elif "_SINGLE_WRITE" in __macro:
                __name = __blk + __field.split("_SINGLE_WRITE")[0]
                __name = sanity(__name)
                print("Error " + __macro)
                if __name in srams:
                    pass
                else:
                    pass

            elif "ENABLE_ERROR_INJECT__SHIFT" in __macro:
                if "_ENABLE_ERROR_INJECT" in __field:
                    __name = __blk + __field.split("_ENABLE_ERROR_INJECT")[0]
                else:
                    __name = __blk + __field.split("ENABLE_ERROR_INJECT")[0]
                __name = sanity(__name)
                if __name in srams:
                    srams[__name] [2]  = "mm"+__reg
                    srams[__name] [3]  = __shift
                else:
                   print("ENABLE_ERROR_INJECT__SHIFT Error in name(%s) __field(%s) __blk(%s) __macro(%s)"%(__name, __field, __blk, __macro))
            elif "SELECT_INJECT_DELAY__SHIFT" in __macro:
                __name = __blk + __field.split("SELECT_INJECT_DELAY")[0]
                __name = sanity(__name)
                if __name in srams:
                    pass
                else:
                    pass
            elif "INJECT_DELAY__SHIFT" in __macro:
                __name =  __field.split("_INJECT_DELAY")[0]
                if __name == "INJECT_DELAY": __name = ""
                __name = sanity(__name)
                if __name == "CPC": __name = ""
                if __name == "CPF": __name = ""
                if __name == "CPG": __name = ""
                if __name + "_"  == __blk:
                    __name = ""
                __name = __blk + __name
                if __name in delays:
                    print ("delays error" , __name, __blk)
                else:
                    delays[__name] = ["mm"+__reg, __shift]
                    pass
            else:
                pass
                #print ("error in ", line)

        if 'SQ_LDS_D' in srams:
             srams['SQ_LDS_I'] = srams['SQ_LDS_D'][:]
             blks['SQ_LDS_I'] = blks['SQ_LDS_D']
             srams['SQ_LDS_I'][1] = "0x%08x"%(int(srams['SQ_LDS_I'][1],16) +3)
             srams['SQ_LDS_I'][3] = "0x%08x"%(int(srams['SQ_LDS_I'][3],16) +3)
        for key, value in srams.iteritems():
            __blk = blks[key]
            if __blk in delays:
                value[4] = delays[__blk][0]
                value[5] = delays[__blk][1]
        #print(srams)
        #print len(srams)
        #print(delays)
        #print len(delays)

        keyidx = 0
        for key in sorted(srams):
            value = srams[key]
            __upperKey = key.upper()
            __lowerKey = key.lower()
            print("%s = %d"%( __upperKey, keyidx))
            print("%s = %d"%( __lowerKey, keyidx))
            keyidx = keyidx + 1
        print("%s = %d"%("sram_max_id", keyidx))

        print "SRAM_NAME = { "
        for key in sorted(srams):
            value = srams[key]
            __upperKey = key.upper()
            __lowerKey = key.lower()
            print('     %s : "%s",' % ( __upperKey, __upperKey))
        print("}")

        print "SRAM_ID = { "
        for key in sorted(srams):
            value = srams[key]
            __upperKey = key.upper()
            __lowerKey = key.lower()
            print('     "%s" : %s,' % ( __upperKey, __upperKey))
        print("}")
        edc_comments = """
# cntl1   IRRITATOR_DATA_SEL:2
#            POSSIBLE VALUES:
#              00 - DSM_DATA_SEL_DISABLE : Disable irritation for this storage element
#              01 - DSM_DATA_SEL_0 : Enable irritation and select irritator bit 0, for irritation
#              02 - DSM_DATA_SEL_1 : Enable irritation and select irritator bit 1, for irritation
#              03 - DSM_DATA_SEL_BOTH : Enable irritation and select irritator bits 0+1, for irritation
# cntl1   ENABLE_SINGLE_WRITE:1
# cntl2   ENABLE_ERROR_INJECT:2
#            POSSIBLE VALUES:
#              00 - DSM_ENABLE_ERROR_INJECT_FED_IN : Enable FED in error injection
#              01 - DSM_ENABLE_ERROR_INJECT_SINGLE : Enable single error injection
#              02 - DSM_ENABLE_ERROR_INJECT_UNCORRECTABLE : Enable double/uncorrectable error injection
#              03 - DSM_ENABLE_ERROR_INJECT_UNCORRECTABLE_LIMITED : Enable double/uncorrectable error injection and limit error injection to 7 events
#          INJECT_DELAY:1
#delayctnl INJECT_DELAY
"""

        print(edc_comments)
        print("DSM_OFFSET = {")
        for key in sorted(srams):
            value = srams[key]
            v = "    %-24s: [%24s, %s,%24s, %s,%24s, %s,%24s, %s]," % ( key, value[0], num3d(value[1]), value[6], num3d(value[7]), value[2], num3d(value[3]),value[4],num3d(value[5]))
            print(v)
        print("}")
        for key, value in srams.iteritems():
            if value[6] == None: print(key, value)
main()
