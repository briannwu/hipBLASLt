#!/usr/bin/python
from chip_offset import *

ATC_L2_CACHE_2M = 0
atc_l2_cache_2m = 0
ATC_L2_CACHE_32K = 1
atc_l2_cache_32k = 1
ATC_L2_CACHE_4K = 2
atc_l2_cache_4k = 2
CP_CPC_CPC0 = 3
cp_cpc_cpc0 = 3
CP_CPC_CPC1 = 4
cp_cpc_cpc1 = 4
CP_CPC_CPC2 = 5
cp_cpc_cpc2 = 5
CP_CPC_CPC3 = 6
cp_cpc_cpc3 = 6
CP_CPC_CPC4 = 7
cp_cpc_cpc4 = 7
CP_CPC_CPC5 = 8
cp_cpc_cpc5 = 8
CP_CPC_CPC6 = 9
cp_cpc_cpc6 = 9
CP_CPC_CPC7 = 10
cp_cpc_cpc7 = 10
CP_CPC_CPC8 = 11
cp_cpc_cpc8 = 11
CP_CPF_CPF0 = 12
cp_cpf_cpf0 = 12
CP_CPF_CPF1 = 13
cp_cpf_cpf1 = 13
CP_CPF_CPF2 = 14
cp_cpf_cpf2 = 14
CP_CPG_CPG0 = 15
cp_cpg_cpg0 = 15
CP_CPG_CPG1 = 16
cp_cpg_cpg1 = 16
CP_CPG_CPG2 = 17
cp_cpg_cpg2 = 17
GCEA_DRAMRD_CMDMEM = 18
gcea_dramrd_cmdmem = 18
GCEA_DRAMRD_PAGEMEM = 19
gcea_dramrd_pagemem = 19
GCEA_DRAMWR_CMDMEM = 20
gcea_dramwr_cmdmem = 20
GCEA_DRAMWR_DATAMEM = 21
gcea_dramwr_datamem = 21
GCEA_DRAMWR_PAGEMEM = 22
gcea_dramwr_pagemem = 22
GCEA_GMIRD_CMDMEM = 23
gcea_gmird_cmdmem = 23
GCEA_GMIRD_PAGEMEM = 24
gcea_gmird_pagemem = 24
GCEA_GMIWR_CMDMEM = 25
gcea_gmiwr_cmdmem = 25
GCEA_GMIWR_DATAMEM = 26
gcea_gmiwr_datamem = 26
GCEA_GMIWR_PAGEMEM = 27
gcea_gmiwr_pagemem = 27
GCEA_IORD_CMDMEM = 28
gcea_iord_cmdmem = 28
GCEA_IOWR_CMDMEM = 29
gcea_iowr_cmdmem = 29
GCEA_IOWR_DATAMEM = 30
gcea_iowr_datamem = 30
GCEA_MAM_A0MEM = 31
gcea_mam_a0mem = 31
GCEA_MAM_A1MEM = 32
gcea_mam_a1mem = 32
GCEA_MAM_A2MEM = 33
gcea_mam_a2mem = 33
GCEA_MAM_A3MEM = 34
gcea_mam_a3mem = 34
GCEA_MAM_AFMEM = 35
gcea_mam_afmem = 35
GCEA_MAM_D0MEM = 36
gcea_mam_d0mem = 36
GCEA_MAM_D1MEM = 37
gcea_mam_d1mem = 37
GCEA_MAM_D2MEM = 38
gcea_mam_d2mem = 38
GCEA_MAM_D3MEM = 39
gcea_mam_d3mem = 39
GCEA_RRET_TAGMEM = 40
gcea_rret_tagmem = 40
GCEA_WRET_TAGMEM = 41
gcea_wret_tagmem = 41
GC_CANE_IREQ0_CMDMEM = 42
gc_cane_ireq0_cmdmem = 42
GC_CANE_IREQ1_CMDMEM = 43
gc_cane_ireq1_cmdmem = 43
GC_CANE_IREQ1_DATAMEM = 44
gc_cane_ireq1_datamem = 44
GC_CANE_SDPS_DATAMEM = 45
gc_cane_sdps_datamem = 45
GC_CANE_SDPS_REQMEM = 46
gc_cane_sdps_reqmem = 46
GDS_GDS_INPUT_QUEUE = 47
gds_gds_input_queue = 47
GDS_GDS_MEM = 48
gds_gds_mem = 48
GDS_GDS_PHY_CMD_RAM = 49
gds_gds_phy_cmd_ram = 49
GDS_GDS_PHY_DATA_RAM = 50
gds_gds_phy_data_ram = 50
GDS_GDS_PIPE_MEM = 51
gds_gds_pipe_mem = 51
RLC_RLCG_INSTR_RAM = 52
rlc_rlcg_instr_ram = 52
RLC_RLCG_SCRATCH_RAM = 53
rlc_rlcg_scratch_ram = 53
RLC_RLCV_INSTR_RAM = 54
rlc_rlcv_instr_ram = 54
RLC_RLCV_SCRATCH_RAM = 55
rlc_rlcv_scratch_ram = 55
RLC_RLC_SPM_SCRATCH_RAM = 56
rlc_rlc_spm_scratch_ram = 56
RLC_RLC_SPM_SE0_SCRATCH_RAM = 57
rlc_rlc_spm_se0_scratch_ram = 57
RLC_RLC_SPM_SE1_SCRATCH_RAM = 58
rlc_rlc_spm_se1_scratch_ram = 58
RLC_RLC_SPM_SE2_SCRATCH_RAM = 59
rlc_rlc_spm_se2_scratch_ram = 59
RLC_RLC_SPM_SE3_SCRATCH_RAM = 60
rlc_rlc_spm_se3_scratch_ram = 60
RLC_RLC_SRM_ADDR_RAM = 61
rlc_rlc_srm_addr_ram = 61
RLC_RLC_SRM_DATA_RAM = 62
rlc_rlc_srm_data_ram = 62
RLC_RLC_TCTAG_RAM = 63
rlc_rlc_tctag_ram = 63
SPI_SPI_GDS_EXPREQ_MEM = 64
spi_spi_gds_expreq_mem = 64
SPI_SPI_LIFE_CNT_MEM = 65
spi_spi_life_cnt_mem = 65
SPI_SPI_SR_MEM = 66
spi_spi_sr_mem = 66
SPI_SPI_WB_GRANT_30_MEM = 67
spi_spi_wb_grant_30_mem = 67
SQC_DATA_BANK_RAM = 68
sqc_data_bank_ram = 68
SQC_DATA_CU0_UTCL1_LFIFO = 69
sqc_data_cu0_utcl1_lfifo = 69
SQC_DATA_CU0_WRITE_DATA_BUF = 70
sqc_data_cu0_write_data_buf = 70
SQC_DATA_CU1_UTCL1_LFIFO = 71
sqc_data_cu1_utcl1_lfifo = 71
SQC_DATA_CU1_WRITE_DATA_BUF = 72
sqc_data_cu1_write_data_buf = 72
SQC_DATA_CU2_UTCL1_LFIFO = 73
sqc_data_cu2_utcl1_lfifo = 73
SQC_DATA_CU2_WRITE_DATA_BUF = 74
sqc_data_cu2_write_data_buf = 74
SQC_DATA_CU3_UTCL1_LFIFO = 75
sqc_data_cu3_utcl1_lfifo = 75
SQC_DATA_CU3_WRITE_DATA_BUF = 76
sqc_data_cu3_write_data_buf = 76
SQC_DATA_DIRTY_BIT_RAM = 77
sqc_data_dirty_bit_ram = 77
SQC_DATA_HIT_FIFO = 78
sqc_data_hit_fifo = 78
SQC_DATA_MISS_FIFO = 79
sqc_data_miss_fifo = 79
SQC_DATA_TAG_RAM = 80
sqc_data_tag_ram = 80
SQC_INST_BANK_RAM = 81
sqc_inst_bank_ram = 81
SQC_INST_MISS_FIFO = 82
sqc_inst_miss_fifo = 82
SQC_INST_TAG_RAM = 83
sqc_inst_tag_ram = 83
SQC_INST_UTCL1_LFIFO = 84
sqc_inst_utcl1_lfifo = 84
SQC_INST_UTCL1_MISS_FIFO = 85
sqc_inst_utcl1_miss_fifo = 85
SQ_LDS_D = 86
sq_lds_d = 86
SQ_LDS_I = 87
sq_lds_i = 87
SQ_SGPR = 88
sq_sgpr = 88
SQ_SP = 89
sq_sp = 89
TA_TA_FS_AFIFO_HI = 90
ta_ta_fs_afifo_hi = 90
TA_TA_FS_AFIFO_LO = 91
ta_ta_fs_afifo_lo = 91
TA_TA_FS_CFIFO = 92
ta_ta_fs_cfifo = 92
TA_TA_FS_DFIFO = 93
ta_ta_fs_dfifo = 93
TA_TA_FX_LFIFO = 94
ta_ta_fx_lfifo = 94
TCA_HOLE_FIFO_SED = 95
tca_hole_fifo_sed = 95
TCA_REQ_FIFO_SED = 96
tca_req_fifo_sed = 96
TCC_CACHE_DATA = 97
tcc_cache_data = 97
TCC_CACHE_DATA_BANK_0_1 = 98
tcc_cache_data_bank_0_1 = 98
TCC_CACHE_DATA_BANK_0_2 = 99
tcc_cache_data_bank_0_2 = 99
TCC_CACHE_DATA_BANK_0_3 = 100
tcc_cache_data_bank_0_3 = 100
TCC_CACHE_DATA_BANK_1_0 = 101
tcc_cache_data_bank_1_0 = 101
TCC_CACHE_DATA_BANK_1_1 = 102
tcc_cache_data_bank_1_1 = 102
TCC_CACHE_DATA_BANK_1_2 = 103
tcc_cache_data_bank_1_2 = 103
TCC_CACHE_DATA_BANK_1_3 = 104
tcc_cache_data_bank_1_3 = 104
TCC_CACHE_DIRTY_BANK_0 = 105
tcc_cache_dirty_bank_0 = 105
TCC_CACHE_DIRTY_BANK_1 = 106
tcc_cache_dirty_bank_1 = 106
TCC_CACHE_TAG_PROBE_FIFO = 107
tcc_cache_tag_probe_fifo = 107
TCC_HIGH_RATE_TAG = 108
tcc_high_rate_tag = 108
TCC_IN_USE_DEC = 109
tcc_in_use_dec = 109
TCC_IN_USE_TRANSFER = 110
tcc_in_use_transfer = 110
TCC_LATENCY_FIFO = 111
tcc_latency_fifo = 111
TCC_LATENCY_FIFO_NEXT_RAM = 112
tcc_latency_fifo_next_ram = 112
TCC_LOW_RATE_TAG = 113
tcc_low_rate_tag = 113
TCC_OUTPUT_FIFOS = 114
tcc_output_fifos = 114
TCC_RETURN_CONTROL = 115
tcc_return_control = 115
TCC_RETURN_DATA = 116
tcc_return_data = 116
TCC_SRC_FIFO = 117
tcc_src_fifo = 117
TCC_UC_ATOMIC_FIFO = 118
tcc_uc_atomic_fifo = 118
TCC_WRITE_CACHE_READ = 119
tcc_write_cache_read = 119
TCC_WRITE_EARLY_RETURN = 120
tcc_write_early_return = 120
TCC_WRITE_RETURN = 121
tcc_write_return = 121
TCI_WRITE_RAM = 122
tci_write_ram = 122
TCP_CACHE_RAM = 123
tcp_cache_ram = 123
TCP_CMD_FIFO = 124
tcp_cmd_fifo = 124
TCP_DB_RAM = 125
tcp_db_ram = 125
TCP_GATCL1_TCP_GATCL1 = 126
tcp_gatcl1_tcp_gatcl1 = 126
TCP_LFIFO_RAM = 127
tcp_lfifo_ram = 127
TCP_UTCL1_LFIFO0 = 128
tcp_utcl1_lfifo0 = 128
TCP_UTCL1_LFIFO1 = 129
tcp_utcl1_lfifo1 = 129
TCP_VM_FIFO = 130
tcp_vm_fifo = 130
TCX_GROUP0_SED = 131
tcx_group0_sed = 131
TCX_GROUP10_SED = 132
tcx_group10_sed = 132
TCX_GROUP13_SED = 133
tcx_group13_sed = 133
TCX_GROUP14_SED = 134
tcx_group14_sed = 134
TCX_GROUP1_SED = 135
tcx_group1_sed = 135
TCX_GROUP2_SED = 136
tcx_group2_sed = 136
TCX_GROUP4_SED = 137
tcx_group4_sed = 137
TCX_GROUP5_SED = 138
tcx_group5_sed = 138
TCX_GROUP6_SED = 139
tcx_group6_sed = 139
TCX_GROUP8_SED = 140
tcx_group8_sed = 140
TCX_GROUP9_SED = 141
tcx_group9_sed = 141
TD_TD_CS_FIFO = 142
td_td_cs_fifo = 142
TD_TD_SS_FIFO_HI = 143
td_td_ss_fifo_hi = 143
TD_TD_SS_FIFO_LO = 144
td_td_ss_fifo_lo = 144
UTCL2_MEM = 145
utcl2_mem = 145
VML2_MEM = 146
vml2_mem = 146
VML2_WALKER_MEM = 147
vml2_walker_mem = 147
sram_max_id = 148
SRAM_NAME = {
     ATC_L2_CACHE_2M : "ATC_L2_CACHE_2M",
     ATC_L2_CACHE_32K : "ATC_L2_CACHE_32K",
     ATC_L2_CACHE_4K : "ATC_L2_CACHE_4K",
     CP_CPC_CPC0 : "CP_CPC_CPC0",
     CP_CPC_CPC1 : "CP_CPC_CPC1",
     CP_CPC_CPC2 : "CP_CPC_CPC2",
     CP_CPC_CPC3 : "CP_CPC_CPC3",
     CP_CPC_CPC4 : "CP_CPC_CPC4",
     CP_CPC_CPC5 : "CP_CPC_CPC5",
     CP_CPC_CPC6 : "CP_CPC_CPC6",
     CP_CPC_CPC7 : "CP_CPC_CPC7",
     CP_CPC_CPC8 : "CP_CPC_CPC8",
     CP_CPF_CPF0 : "CP_CPF_CPF0",
     CP_CPF_CPF1 : "CP_CPF_CPF1",
     CP_CPF_CPF2 : "CP_CPF_CPF2",
     CP_CPG_CPG0 : "CP_CPG_CPG0",
     CP_CPG_CPG1 : "CP_CPG_CPG1",
     CP_CPG_CPG2 : "CP_CPG_CPG2",
     GCEA_DRAMRD_CMDMEM : "GCEA_DRAMRD_CMDMEM",
     GCEA_DRAMRD_PAGEMEM : "GCEA_DRAMRD_PAGEMEM",
     GCEA_DRAMWR_CMDMEM : "GCEA_DRAMWR_CMDMEM",
     GCEA_DRAMWR_DATAMEM : "GCEA_DRAMWR_DATAMEM",
     GCEA_DRAMWR_PAGEMEM : "GCEA_DRAMWR_PAGEMEM",
     GCEA_GMIRD_CMDMEM : "GCEA_GMIRD_CMDMEM",
     GCEA_GMIRD_PAGEMEM : "GCEA_GMIRD_PAGEMEM",
     GCEA_GMIWR_CMDMEM : "GCEA_GMIWR_CMDMEM",
     GCEA_GMIWR_DATAMEM : "GCEA_GMIWR_DATAMEM",
     GCEA_GMIWR_PAGEMEM : "GCEA_GMIWR_PAGEMEM",
     GCEA_IORD_CMDMEM : "GCEA_IORD_CMDMEM",
     GCEA_IOWR_CMDMEM : "GCEA_IOWR_CMDMEM",
     GCEA_IOWR_DATAMEM : "GCEA_IOWR_DATAMEM",
     GCEA_MAM_A0MEM : "GCEA_MAM_A0MEM",
     GCEA_MAM_A1MEM : "GCEA_MAM_A1MEM",
     GCEA_MAM_A2MEM : "GCEA_MAM_A2MEM",
     GCEA_MAM_A3MEM : "GCEA_MAM_A3MEM",
     GCEA_MAM_AFMEM : "GCEA_MAM_AFMEM",
     GCEA_MAM_D0MEM : "GCEA_MAM_D0MEM",
     GCEA_MAM_D1MEM : "GCEA_MAM_D1MEM",
     GCEA_MAM_D2MEM : "GCEA_MAM_D2MEM",
     GCEA_MAM_D3MEM : "GCEA_MAM_D3MEM",
     GCEA_RRET_TAGMEM : "GCEA_RRET_TAGMEM",
     GCEA_WRET_TAGMEM : "GCEA_WRET_TAGMEM",
     GC_CANE_IREQ0_CMDMEM : "GC_CANE_IREQ0_CMDMEM",
     GC_CANE_IREQ1_CMDMEM : "GC_CANE_IREQ1_CMDMEM",
     GC_CANE_IREQ1_DATAMEM : "GC_CANE_IREQ1_DATAMEM",
     GC_CANE_SDPS_DATAMEM : "GC_CANE_SDPS_DATAMEM",
     GC_CANE_SDPS_REQMEM : "GC_CANE_SDPS_REQMEM",
     GDS_GDS_INPUT_QUEUE : "GDS_GDS_INPUT_QUEUE",
     GDS_GDS_MEM : "GDS_GDS_MEM",
     GDS_GDS_PHY_CMD_RAM : "GDS_GDS_PHY_CMD_RAM",
     GDS_GDS_PHY_DATA_RAM : "GDS_GDS_PHY_DATA_RAM",
     GDS_GDS_PIPE_MEM : "GDS_GDS_PIPE_MEM",
     RLC_RLCG_INSTR_RAM : "RLC_RLCG_INSTR_RAM",
     RLC_RLCG_SCRATCH_RAM : "RLC_RLCG_SCRATCH_RAM",
     RLC_RLCV_INSTR_RAM : "RLC_RLCV_INSTR_RAM",
     RLC_RLCV_SCRATCH_RAM : "RLC_RLCV_SCRATCH_RAM",
     RLC_RLC_SPM_SCRATCH_RAM : "RLC_RLC_SPM_SCRATCH_RAM",
     RLC_RLC_SPM_SE0_SCRATCH_RAM : "RLC_RLC_SPM_SE0_SCRATCH_RAM",
     RLC_RLC_SPM_SE1_SCRATCH_RAM : "RLC_RLC_SPM_SE1_SCRATCH_RAM",
     RLC_RLC_SPM_SE2_SCRATCH_RAM : "RLC_RLC_SPM_SE2_SCRATCH_RAM",
     RLC_RLC_SPM_SE3_SCRATCH_RAM : "RLC_RLC_SPM_SE3_SCRATCH_RAM",
     RLC_RLC_SRM_ADDR_RAM : "RLC_RLC_SRM_ADDR_RAM",
     RLC_RLC_SRM_DATA_RAM : "RLC_RLC_SRM_DATA_RAM",
     RLC_RLC_TCTAG_RAM : "RLC_RLC_TCTAG_RAM",
     SPI_SPI_GDS_EXPREQ_MEM : "SPI_SPI_GDS_EXPREQ_MEM",
     SPI_SPI_LIFE_CNT_MEM : "SPI_SPI_LIFE_CNT_MEM",
     SPI_SPI_SR_MEM : "SPI_SPI_SR_MEM",
     SPI_SPI_WB_GRANT_30_MEM : "SPI_SPI_WB_GRANT_30_MEM",
     SQC_DATA_BANK_RAM : "SQC_DATA_BANK_RAM",
     SQC_DATA_CU0_UTCL1_LFIFO : "SQC_DATA_CU0_UTCL1_LFIFO",
     SQC_DATA_CU0_WRITE_DATA_BUF : "SQC_DATA_CU0_WRITE_DATA_BUF",
     SQC_DATA_CU1_UTCL1_LFIFO : "SQC_DATA_CU1_UTCL1_LFIFO",
     SQC_DATA_CU1_WRITE_DATA_BUF : "SQC_DATA_CU1_WRITE_DATA_BUF",
     SQC_DATA_CU2_UTCL1_LFIFO : "SQC_DATA_CU2_UTCL1_LFIFO",
     SQC_DATA_CU2_WRITE_DATA_BUF : "SQC_DATA_CU2_WRITE_DATA_BUF",
     SQC_DATA_CU3_UTCL1_LFIFO : "SQC_DATA_CU3_UTCL1_LFIFO",
     SQC_DATA_CU3_WRITE_DATA_BUF : "SQC_DATA_CU3_WRITE_DATA_BUF",
     SQC_DATA_DIRTY_BIT_RAM : "SQC_DATA_DIRTY_BIT_RAM",
     SQC_DATA_HIT_FIFO : "SQC_DATA_HIT_FIFO",
     SQC_DATA_MISS_FIFO : "SQC_DATA_MISS_FIFO",
     SQC_DATA_TAG_RAM : "SQC_DATA_TAG_RAM",
     SQC_INST_BANK_RAM : "SQC_INST_BANK_RAM",
     SQC_INST_MISS_FIFO : "SQC_INST_MISS_FIFO",
     SQC_INST_TAG_RAM : "SQC_INST_TAG_RAM",
     SQC_INST_UTCL1_LFIFO : "SQC_INST_UTCL1_LFIFO",
     SQC_INST_UTCL1_MISS_FIFO : "SQC_INST_UTCL1_MISS_FIFO",
     SQ_LDS_D : "SQ_LDS_D",
     SQ_LDS_I : "SQ_LDS_I",
     SQ_SGPR : "SQ_SGPR",
     SQ_SP : "SQ_SP",
     TA_TA_FS_AFIFO_HI : "TA_TA_FS_AFIFO_HI",
     TA_TA_FS_AFIFO_LO : "TA_TA_FS_AFIFO_LO",
     TA_TA_FS_CFIFO : "TA_TA_FS_CFIFO",
     TA_TA_FS_DFIFO : "TA_TA_FS_DFIFO",
     TA_TA_FX_LFIFO : "TA_TA_FX_LFIFO",
     TCA_HOLE_FIFO_SED : "TCA_HOLE_FIFO_SED",
     TCA_REQ_FIFO_SED : "TCA_REQ_FIFO_SED",
     TCC_CACHE_DATA : "TCC_CACHE_DATA",
     TCC_CACHE_DATA_BANK_0_1 : "TCC_CACHE_DATA_BANK_0_1",
     TCC_CACHE_DATA_BANK_0_2 : "TCC_CACHE_DATA_BANK_0_2",
     TCC_CACHE_DATA_BANK_0_3 : "TCC_CACHE_DATA_BANK_0_3",
     TCC_CACHE_DATA_BANK_1_0 : "TCC_CACHE_DATA_BANK_1_0",
     TCC_CACHE_DATA_BANK_1_1 : "TCC_CACHE_DATA_BANK_1_1",
     TCC_CACHE_DATA_BANK_1_2 : "TCC_CACHE_DATA_BANK_1_2",
     TCC_CACHE_DATA_BANK_1_3 : "TCC_CACHE_DATA_BANK_1_3",
     TCC_CACHE_DIRTY_BANK_0 : "TCC_CACHE_DIRTY_BANK_0",
     TCC_CACHE_DIRTY_BANK_1 : "TCC_CACHE_DIRTY_BANK_1",
     TCC_CACHE_TAG_PROBE_FIFO : "TCC_CACHE_TAG_PROBE_FIFO",
     TCC_HIGH_RATE_TAG : "TCC_HIGH_RATE_TAG",
     TCC_IN_USE_DEC : "TCC_IN_USE_DEC",
     TCC_IN_USE_TRANSFER : "TCC_IN_USE_TRANSFER",
     TCC_LATENCY_FIFO : "TCC_LATENCY_FIFO",
     TCC_LATENCY_FIFO_NEXT_RAM : "TCC_LATENCY_FIFO_NEXT_RAM",
     TCC_LOW_RATE_TAG : "TCC_LOW_RATE_TAG",
     TCC_OUTPUT_FIFOS : "TCC_OUTPUT_FIFOS",
     TCC_RETURN_CONTROL : "TCC_RETURN_CONTROL",
     TCC_RETURN_DATA : "TCC_RETURN_DATA",
     TCC_SRC_FIFO : "TCC_SRC_FIFO",
     TCC_UC_ATOMIC_FIFO : "TCC_UC_ATOMIC_FIFO",
     TCC_WRITE_CACHE_READ : "TCC_WRITE_CACHE_READ",
     TCC_WRITE_EARLY_RETURN : "TCC_WRITE_EARLY_RETURN",
     TCC_WRITE_RETURN : "TCC_WRITE_RETURN",
     TCI_WRITE_RAM : "TCI_WRITE_RAM",
     TCP_CACHE_RAM : "TCP_CACHE_RAM",
     TCP_CMD_FIFO : "TCP_CMD_FIFO",
     TCP_DB_RAM : "TCP_DB_RAM",
     TCP_GATCL1_TCP_GATCL1 : "TCP_GATCL1_TCP_GATCL1",
     TCP_LFIFO_RAM : "TCP_LFIFO_RAM",
     TCP_UTCL1_LFIFO0 : "TCP_UTCL1_LFIFO0",
     TCP_UTCL1_LFIFO1 : "TCP_UTCL1_LFIFO1",
     TCP_VM_FIFO : "TCP_VM_FIFO",
     TCX_GROUP0_SED : "TCX_GROUP0_SED",
     TCX_GROUP10_SED : "TCX_GROUP10_SED",
     TCX_GROUP13_SED : "TCX_GROUP13_SED",
     TCX_GROUP14_SED : "TCX_GROUP14_SED",
     TCX_GROUP1_SED : "TCX_GROUP1_SED",
     TCX_GROUP2_SED : "TCX_GROUP2_SED",
     TCX_GROUP4_SED : "TCX_GROUP4_SED",
     TCX_GROUP5_SED : "TCX_GROUP5_SED",
     TCX_GROUP6_SED : "TCX_GROUP6_SED",
     TCX_GROUP8_SED : "TCX_GROUP8_SED",
     TCX_GROUP9_SED : "TCX_GROUP9_SED",
     TD_TD_CS_FIFO : "TD_TD_CS_FIFO",
     TD_TD_SS_FIFO_HI : "TD_TD_SS_FIFO_HI",
     TD_TD_SS_FIFO_LO : "TD_TD_SS_FIFO_LO",
     UTCL2_MEM : "UTCL2_MEM",
     VML2_MEM : "VML2_MEM",
     VML2_WALKER_MEM : "VML2_WALKER_MEM",
}
SRAM_ID = {
     "ATC_L2_CACHE_2M" : ATC_L2_CACHE_2M,
     "ATC_L2_CACHE_32K" : ATC_L2_CACHE_32K,
     "ATC_L2_CACHE_4K" : ATC_L2_CACHE_4K,
     "CP_CPC_CPC0" : CP_CPC_CPC0,
     "CP_CPC_CPC1" : CP_CPC_CPC1,
     "CP_CPC_CPC2" : CP_CPC_CPC2,
     "CP_CPC_CPC3" : CP_CPC_CPC3,
     "CP_CPC_CPC4" : CP_CPC_CPC4,
     "CP_CPC_CPC5" : CP_CPC_CPC5,
     "CP_CPC_CPC6" : CP_CPC_CPC6,
     "CP_CPC_CPC7" : CP_CPC_CPC7,
     "CP_CPC_CPC8" : CP_CPC_CPC8,
     "CP_CPF_CPF0" : CP_CPF_CPF0,
     "CP_CPF_CPF1" : CP_CPF_CPF1,
     "CP_CPF_CPF2" : CP_CPF_CPF2,
     "CP_CPG_CPG0" : CP_CPG_CPG0,
     "CP_CPG_CPG1" : CP_CPG_CPG1,
     "CP_CPG_CPG2" : CP_CPG_CPG2,
     "GCEA_DRAMRD_CMDMEM" : GCEA_DRAMRD_CMDMEM,
     "GCEA_DRAMRD_PAGEMEM" : GCEA_DRAMRD_PAGEMEM,
     "GCEA_DRAMWR_CMDMEM" : GCEA_DRAMWR_CMDMEM,
     "GCEA_DRAMWR_DATAMEM" : GCEA_DRAMWR_DATAMEM,
     "GCEA_DRAMWR_PAGEMEM" : GCEA_DRAMWR_PAGEMEM,
     "GCEA_GMIRD_CMDMEM" : GCEA_GMIRD_CMDMEM,
     "GCEA_GMIRD_PAGEMEM" : GCEA_GMIRD_PAGEMEM,
     "GCEA_GMIWR_CMDMEM" : GCEA_GMIWR_CMDMEM,
     "GCEA_GMIWR_DATAMEM" : GCEA_GMIWR_DATAMEM,
     "GCEA_GMIWR_PAGEMEM" : GCEA_GMIWR_PAGEMEM,
     "GCEA_IORD_CMDMEM" : GCEA_IORD_CMDMEM,
     "GCEA_IOWR_CMDMEM" : GCEA_IOWR_CMDMEM,
     "GCEA_IOWR_DATAMEM" : GCEA_IOWR_DATAMEM,
     "GCEA_MAM_A0MEM" : GCEA_MAM_A0MEM,
     "GCEA_MAM_A1MEM" : GCEA_MAM_A1MEM,
     "GCEA_MAM_A2MEM" : GCEA_MAM_A2MEM,
     "GCEA_MAM_A3MEM" : GCEA_MAM_A3MEM,
     "GCEA_MAM_AFMEM" : GCEA_MAM_AFMEM,
     "GCEA_MAM_D0MEM" : GCEA_MAM_D0MEM,
     "GCEA_MAM_D1MEM" : GCEA_MAM_D1MEM,
     "GCEA_MAM_D2MEM" : GCEA_MAM_D2MEM,
     "GCEA_MAM_D3MEM" : GCEA_MAM_D3MEM,
     "GCEA_RRET_TAGMEM" : GCEA_RRET_TAGMEM,
     "GCEA_WRET_TAGMEM" : GCEA_WRET_TAGMEM,
     "GC_CANE_IREQ0_CMDMEM" : GC_CANE_IREQ0_CMDMEM,
     "GC_CANE_IREQ1_CMDMEM" : GC_CANE_IREQ1_CMDMEM,
     "GC_CANE_IREQ1_DATAMEM" : GC_CANE_IREQ1_DATAMEM,
     "GC_CANE_SDPS_DATAMEM" : GC_CANE_SDPS_DATAMEM,
     "GC_CANE_SDPS_REQMEM" : GC_CANE_SDPS_REQMEM,
     "GDS_GDS_INPUT_QUEUE" : GDS_GDS_INPUT_QUEUE,
     "GDS_GDS_MEM" : GDS_GDS_MEM,
     "GDS_GDS_PHY_CMD_RAM" : GDS_GDS_PHY_CMD_RAM,
     "GDS_GDS_PHY_DATA_RAM" : GDS_GDS_PHY_DATA_RAM,
     "GDS_GDS_PIPE_MEM" : GDS_GDS_PIPE_MEM,
     "RLC_RLCG_INSTR_RAM" : RLC_RLCG_INSTR_RAM,
     "RLC_RLCG_SCRATCH_RAM" : RLC_RLCG_SCRATCH_RAM,
     "RLC_RLCV_INSTR_RAM" : RLC_RLCV_INSTR_RAM,
     "RLC_RLCV_SCRATCH_RAM" : RLC_RLCV_SCRATCH_RAM,
     "RLC_RLC_SPM_SCRATCH_RAM" : RLC_RLC_SPM_SCRATCH_RAM,
     "RLC_RLC_SPM_SE0_SCRATCH_RAM" : RLC_RLC_SPM_SE0_SCRATCH_RAM,
     "RLC_RLC_SPM_SE1_SCRATCH_RAM" : RLC_RLC_SPM_SE1_SCRATCH_RAM,
     "RLC_RLC_SPM_SE2_SCRATCH_RAM" : RLC_RLC_SPM_SE2_SCRATCH_RAM,
     "RLC_RLC_SPM_SE3_SCRATCH_RAM" : RLC_RLC_SPM_SE3_SCRATCH_RAM,
     "RLC_RLC_SRM_ADDR_RAM" : RLC_RLC_SRM_ADDR_RAM,
     "RLC_RLC_SRM_DATA_RAM" : RLC_RLC_SRM_DATA_RAM,
     "RLC_RLC_TCTAG_RAM" : RLC_RLC_TCTAG_RAM,
     "SPI_SPI_GDS_EXPREQ_MEM" : SPI_SPI_GDS_EXPREQ_MEM,
     "SPI_SPI_LIFE_CNT_MEM" : SPI_SPI_LIFE_CNT_MEM,
     "SPI_SPI_SR_MEM" : SPI_SPI_SR_MEM,
     "SPI_SPI_WB_GRANT_30_MEM" : SPI_SPI_WB_GRANT_30_MEM,
     "SQC_DATA_BANK_RAM" : SQC_DATA_BANK_RAM,
     "SQC_DATA_CU0_UTCL1_LFIFO" : SQC_DATA_CU0_UTCL1_LFIFO,
     "SQC_DATA_CU0_WRITE_DATA_BUF" : SQC_DATA_CU0_WRITE_DATA_BUF,
     "SQC_DATA_CU1_UTCL1_LFIFO" : SQC_DATA_CU1_UTCL1_LFIFO,
     "SQC_DATA_CU1_WRITE_DATA_BUF" : SQC_DATA_CU1_WRITE_DATA_BUF,
     "SQC_DATA_CU2_UTCL1_LFIFO" : SQC_DATA_CU2_UTCL1_LFIFO,
     "SQC_DATA_CU2_WRITE_DATA_BUF" : SQC_DATA_CU2_WRITE_DATA_BUF,
     "SQC_DATA_CU3_UTCL1_LFIFO" : SQC_DATA_CU3_UTCL1_LFIFO,
     "SQC_DATA_CU3_WRITE_DATA_BUF" : SQC_DATA_CU3_WRITE_DATA_BUF,
     "SQC_DATA_DIRTY_BIT_RAM" : SQC_DATA_DIRTY_BIT_RAM,
     "SQC_DATA_HIT_FIFO" : SQC_DATA_HIT_FIFO,
     "SQC_DATA_MISS_FIFO" : SQC_DATA_MISS_FIFO,
     "SQC_DATA_TAG_RAM" : SQC_DATA_TAG_RAM,
     "SQC_INST_BANK_RAM" : SQC_INST_BANK_RAM,
     "SQC_INST_MISS_FIFO" : SQC_INST_MISS_FIFO,
     "SQC_INST_TAG_RAM" : SQC_INST_TAG_RAM,
     "SQC_INST_UTCL1_LFIFO" : SQC_INST_UTCL1_LFIFO,
     "SQC_INST_UTCL1_MISS_FIFO" : SQC_INST_UTCL1_MISS_FIFO,
     "SQ_LDS_D" : SQ_LDS_D,
     "SQ_LDS_I" : SQ_LDS_I,
     "SQ_SGPR" : SQ_SGPR,
     "SQ_SP" : SQ_SP,
     "TA_TA_FS_AFIFO_HI" : TA_TA_FS_AFIFO_HI,
     "TA_TA_FS_AFIFO_LO" : TA_TA_FS_AFIFO_LO,
     "TA_TA_FS_CFIFO" : TA_TA_FS_CFIFO,
     "TA_TA_FS_DFIFO" : TA_TA_FS_DFIFO,
     "TA_TA_FX_LFIFO" : TA_TA_FX_LFIFO,
     "TCA_HOLE_FIFO_SED" : TCA_HOLE_FIFO_SED,
     "TCA_REQ_FIFO_SED" : TCA_REQ_FIFO_SED,
     "TCC_CACHE_DATA" : TCC_CACHE_DATA,
     "TCC_CACHE_DATA_BANK_0_1" : TCC_CACHE_DATA_BANK_0_1,
     "TCC_CACHE_DATA_BANK_0_2" : TCC_CACHE_DATA_BANK_0_2,
     "TCC_CACHE_DATA_BANK_0_3" : TCC_CACHE_DATA_BANK_0_3,
     "TCC_CACHE_DATA_BANK_1_0" : TCC_CACHE_DATA_BANK_1_0,
     "TCC_CACHE_DATA_BANK_1_1" : TCC_CACHE_DATA_BANK_1_1,
     "TCC_CACHE_DATA_BANK_1_2" : TCC_CACHE_DATA_BANK_1_2,
     "TCC_CACHE_DATA_BANK_1_3" : TCC_CACHE_DATA_BANK_1_3,
     "TCC_CACHE_DIRTY_BANK_0" : TCC_CACHE_DIRTY_BANK_0,
     "TCC_CACHE_DIRTY_BANK_1" : TCC_CACHE_DIRTY_BANK_1,
     "TCC_CACHE_TAG_PROBE_FIFO" : TCC_CACHE_TAG_PROBE_FIFO,
     "TCC_HIGH_RATE_TAG" : TCC_HIGH_RATE_TAG,
     "TCC_IN_USE_DEC" : TCC_IN_USE_DEC,
     "TCC_IN_USE_TRANSFER" : TCC_IN_USE_TRANSFER,
     "TCC_LATENCY_FIFO" : TCC_LATENCY_FIFO,
     "TCC_LATENCY_FIFO_NEXT_RAM" : TCC_LATENCY_FIFO_NEXT_RAM,
     "TCC_LOW_RATE_TAG" : TCC_LOW_RATE_TAG,
     "TCC_OUTPUT_FIFOS" : TCC_OUTPUT_FIFOS,
     "TCC_RETURN_CONTROL" : TCC_RETURN_CONTROL,
     "TCC_RETURN_DATA" : TCC_RETURN_DATA,
     "TCC_SRC_FIFO" : TCC_SRC_FIFO,
     "TCC_UC_ATOMIC_FIFO" : TCC_UC_ATOMIC_FIFO,
     "TCC_WRITE_CACHE_READ" : TCC_WRITE_CACHE_READ,
     "TCC_WRITE_EARLY_RETURN" : TCC_WRITE_EARLY_RETURN,
     "TCC_WRITE_RETURN" : TCC_WRITE_RETURN,
     "TCI_WRITE_RAM" : TCI_WRITE_RAM,
     "TCP_CACHE_RAM" : TCP_CACHE_RAM,
     "TCP_CMD_FIFO" : TCP_CMD_FIFO,
     "TCP_DB_RAM" : TCP_DB_RAM,
     "TCP_GATCL1_TCP_GATCL1" : TCP_GATCL1_TCP_GATCL1,
     "TCP_LFIFO_RAM" : TCP_LFIFO_RAM,
     "TCP_UTCL1_LFIFO0" : TCP_UTCL1_LFIFO0,
     "TCP_UTCL1_LFIFO1" : TCP_UTCL1_LFIFO1,
     "TCP_VM_FIFO" : TCP_VM_FIFO,
     "TCX_GROUP0_SED" : TCX_GROUP0_SED,
     "TCX_GROUP10_SED" : TCX_GROUP10_SED,
     "TCX_GROUP13_SED" : TCX_GROUP13_SED,
     "TCX_GROUP14_SED" : TCX_GROUP14_SED,
     "TCX_GROUP1_SED" : TCX_GROUP1_SED,
     "TCX_GROUP2_SED" : TCX_GROUP2_SED,
     "TCX_GROUP4_SED" : TCX_GROUP4_SED,
     "TCX_GROUP5_SED" : TCX_GROUP5_SED,
     "TCX_GROUP6_SED" : TCX_GROUP6_SED,
     "TCX_GROUP8_SED" : TCX_GROUP8_SED,
     "TCX_GROUP9_SED" : TCX_GROUP9_SED,
     "TD_TD_CS_FIFO" : TD_TD_CS_FIFO,
     "TD_TD_SS_FIFO_HI" : TD_TD_SS_FIFO_HI,
     "TD_TD_SS_FIFO_LO" : TD_TD_SS_FIFO_LO,
     "UTCL2_MEM" : UTCL2_MEM,
     "VML2_MEM" : VML2_MEM,
     "VML2_WALKER_MEM" : VML2_WALKER_MEM,
}

# cntl1   IRRITATOR_DATA_SEL:2
#            POSSIBLE VALUES:
#              00 - DSM_DATA_SEL_DISABLE : Disable irritation for this storage element
#              01 - DSM_DATA_SEL_0 : Enable irritation and select irritator bit 0, for irritation
#              02 - DSM_DATA_SEL_1 : Enable irritation and select irritator bit 1, for irritation
#              03 - DSM_DATA_SEL_BOTH : Enable irritation and select irritator bits 0+1, for irritation
# cntl1   ENABLE_SINGLE_WRITE:1
# cntl2   ENABLE_ERROR_INJECT:2
#            POSSIBLE VALUES:
#              00 - DSM_ENABLE_ERROR_INJECT_FED_IN : Enable FED in error injection
#              01 - DSM_ENABLE_ERROR_INJECT_SINGLE : Enable single error injection
#              02 - DSM_ENABLE_ERROR_INJECT_UNCORRECTABLE : Enable double/uncorrectable error injection
#              03 - DSM_ENABLE_ERROR_INJECT_UNCORRECTABLE_LIMITED : Enable double/uncorrectable error injection and limit error injection to 7 events
#          INJECT_DELAY:1
#delayctnl INJECT_DELAY

DSM_OFFSET = {
    ATC_L2_CACHE_2M         : [mmATC_L2_CACHE_2M_DSM_CNTL,  6,mmATC_L2_CACHE_2M_DSM_CNTL,  8,mmATC_L2_CACHE_2M_DSM_CNTL,  9,mmATC_L2_CACHE_2M_DSM_CNTL,  0],
    ATC_L2_CACHE_32K        : [mmATC_L2_CACHE_32K_DSM_CNTL,  6,mmATC_L2_CACHE_32K_DSM_CNTL,  8,mmATC_L2_CACHE_32K_DSM_CNTL,  9,mmATC_L2_CACHE_32K_DSM_CNTL,  0],
    ATC_L2_CACHE_4K         : [mmATC_L2_CACHE_4K_DSM_CNTL,  6,mmATC_L2_CACHE_4K_DSM_CNTL,  8,mmATC_L2_CACHE_4K_DSM_CNTL,  9,mmATC_L2_CACHE_4K_DSM_CNTL,  0],
    CP_CPC_CPC0             : [       mmCP_CPC_DSM_CNTL,  0,       mmCP_CPC_DSM_CNTL,  2,      mmCP_CPC_DSM_CNTL2,  0,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPC_CPC1             : [       mmCP_CPC_DSM_CNTL,  3,       mmCP_CPC_DSM_CNTL,  5,      mmCP_CPC_DSM_CNTL2,  3,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPC_CPC2             : [       mmCP_CPC_DSM_CNTL,  6,       mmCP_CPC_DSM_CNTL,  8,      mmCP_CPC_DSM_CNTL2,  6,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPC_CPC3             : [       mmCP_CPC_DSM_CNTL,  9,       mmCP_CPC_DSM_CNTL, 11,      mmCP_CPC_DSM_CNTL2,  9,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPC_CPC4             : [       mmCP_CPC_DSM_CNTL, 12,       mmCP_CPC_DSM_CNTL, 14,      mmCP_CPC_DSM_CNTL2, 12,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPC_CPC5             : [       mmCP_CPC_DSM_CNTL, 15,       mmCP_CPC_DSM_CNTL, 17,      mmCP_CPC_DSM_CNTL2, 15,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPC_CPC6             : [       mmCP_CPC_DSM_CNTL, 18,       mmCP_CPC_DSM_CNTL, 20,      mmCP_CPC_DSM_CNTL2, 18,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPC_CPC7             : [       mmCP_CPC_DSM_CNTL, 21,       mmCP_CPC_DSM_CNTL, 23,      mmCP_CPC_DSM_CNTL2, 21,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPC_CPC8             : [       mmCP_CPC_DSM_CNTL, 24,       mmCP_CPC_DSM_CNTL, 26,      mmCP_CPC_DSM_CNTL2, 24,     mmCP_CPC_DSM_CNTL2A,  0],
    CP_CPF_CPF0             : [       mmCP_CPF_DSM_CNTL,  0,       mmCP_CPF_DSM_CNTL,  2,      mmCP_CPF_DSM_CNTL2,  0,     mmCP_CPF_DSM_CNTL2A,  0],
    CP_CPF_CPF1             : [       mmCP_CPF_DSM_CNTL,  3,       mmCP_CPF_DSM_CNTL,  5,      mmCP_CPF_DSM_CNTL2,  3,     mmCP_CPF_DSM_CNTL2A,  0],
    CP_CPF_CPF2             : [       mmCP_CPF_DSM_CNTL,  6,       mmCP_CPF_DSM_CNTL,  8,      mmCP_CPF_DSM_CNTL2,  6,     mmCP_CPF_DSM_CNTL2A,  0],
    CP_CPG_CPG0             : [       mmCP_CPG_DSM_CNTL,  0,       mmCP_CPG_DSM_CNTL,  2,      mmCP_CPG_DSM_CNTL2,  0,     mmCP_CPG_DSM_CNTL2A,  0],
    CP_CPG_CPG1             : [       mmCP_CPG_DSM_CNTL,  3,       mmCP_CPG_DSM_CNTL,  5,      mmCP_CPG_DSM_CNTL2,  3,     mmCP_CPG_DSM_CNTL2A,  0],
    CP_CPG_CPG2             : [       mmCP_CPG_DSM_CNTL,  6,       mmCP_CPG_DSM_CNTL,  8,      mmCP_CPG_DSM_CNTL2,  6,     mmCP_CPG_DSM_CNTL2A,  0],
    GCEA_DRAMRD_CMDMEM      : [         mmGCEA_DSM_CNTL,  0,         mmGCEA_DSM_CNTL,  2,        mmGCEA_DSM_CNTL2,  0,        mmGCEA_DSM_CNTL2, 26],
    GCEA_DRAMRD_PAGEMEM     : [        mmGCEA_DSM_CNTLA,  0,        mmGCEA_DSM_CNTLA,  2,       mmGCEA_DSM_CNTL2A,  0,        mmGCEA_DSM_CNTL2, 26],
    GCEA_DRAMWR_CMDMEM      : [         mmGCEA_DSM_CNTL,  3,         mmGCEA_DSM_CNTL,  5,        mmGCEA_DSM_CNTL2,  3,        mmGCEA_DSM_CNTL2, 26],
    GCEA_DRAMWR_DATAMEM     : [         mmGCEA_DSM_CNTL,  6,         mmGCEA_DSM_CNTL,  8,        mmGCEA_DSM_CNTL2,  6,        mmGCEA_DSM_CNTL2, 26],
    GCEA_DRAMWR_PAGEMEM     : [        mmGCEA_DSM_CNTLA,  3,        mmGCEA_DSM_CNTLA,  5,       mmGCEA_DSM_CNTL2A,  3,        mmGCEA_DSM_CNTL2, 26],
    GCEA_GMIRD_CMDMEM       : [         mmGCEA_DSM_CNTL, 15,         mmGCEA_DSM_CNTL, 17,        mmGCEA_DSM_CNTL2, 15,        mmGCEA_DSM_CNTL2, 26],
    GCEA_GMIRD_PAGEMEM      : [        mmGCEA_DSM_CNTLA, 15,        mmGCEA_DSM_CNTLA, 17,       mmGCEA_DSM_CNTL2A, 15,        mmGCEA_DSM_CNTL2, 26],
    GCEA_GMIWR_CMDMEM       : [         mmGCEA_DSM_CNTL, 18,         mmGCEA_DSM_CNTL, 20,        mmGCEA_DSM_CNTL2, 18,        mmGCEA_DSM_CNTL2, 26],
    GCEA_GMIWR_DATAMEM      : [         mmGCEA_DSM_CNTL, 21,         mmGCEA_DSM_CNTL, 23,        mmGCEA_DSM_CNTL2, 21,        mmGCEA_DSM_CNTL2, 26],
    GCEA_GMIWR_PAGEMEM      : [        mmGCEA_DSM_CNTLA, 18,        mmGCEA_DSM_CNTLA, 20,       mmGCEA_DSM_CNTL2A, 18,        mmGCEA_DSM_CNTL2, 26],
    GCEA_IORD_CMDMEM        : [        mmGCEA_DSM_CNTLA,  6,        mmGCEA_DSM_CNTLA,  8,       mmGCEA_DSM_CNTL2A,  6,        mmGCEA_DSM_CNTL2, 26],
    GCEA_IOWR_CMDMEM        : [        mmGCEA_DSM_CNTLA,  9,        mmGCEA_DSM_CNTLA, 11,       mmGCEA_DSM_CNTL2A,  9,        mmGCEA_DSM_CNTL2, 26],
    GCEA_IOWR_DATAMEM       : [        mmGCEA_DSM_CNTLA, 12,        mmGCEA_DSM_CNTLA, 14,       mmGCEA_DSM_CNTL2A, 12,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_A0MEM          : [        mmGCEA_DSM_CNTLB, 12,        mmGCEA_DSM_CNTLB, 14,       mmGCEA_DSM_CNTL2B, 12,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_A1MEM          : [        mmGCEA_DSM_CNTLB, 15,        mmGCEA_DSM_CNTLB, 17,       mmGCEA_DSM_CNTL2B, 15,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_A2MEM          : [        mmGCEA_DSM_CNTLB, 18,        mmGCEA_DSM_CNTLB, 20,       mmGCEA_DSM_CNTL2B, 18,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_A3MEM          : [        mmGCEA_DSM_CNTLB, 21,        mmGCEA_DSM_CNTLB, 23,       mmGCEA_DSM_CNTL2B, 21,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_AFMEM          : [        mmGCEA_DSM_CNTLB, 24,        mmGCEA_DSM_CNTLB, 26,       mmGCEA_DSM_CNTL2B, 24,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_D0MEM          : [        mmGCEA_DSM_CNTLB,  0,        mmGCEA_DSM_CNTLB,  2,       mmGCEA_DSM_CNTL2B,  0,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_D1MEM          : [        mmGCEA_DSM_CNTLB,  3,        mmGCEA_DSM_CNTLB,  5,       mmGCEA_DSM_CNTL2B,  3,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_D2MEM          : [        mmGCEA_DSM_CNTLB,  6,        mmGCEA_DSM_CNTLB,  8,       mmGCEA_DSM_CNTL2B,  6,        mmGCEA_DSM_CNTL2, 26],
    GCEA_MAM_D3MEM          : [        mmGCEA_DSM_CNTLB,  9,        mmGCEA_DSM_CNTLB, 11,       mmGCEA_DSM_CNTL2B,  9,        mmGCEA_DSM_CNTL2, 26],
    GCEA_RRET_TAGMEM        : [         mmGCEA_DSM_CNTL,  9,         mmGCEA_DSM_CNTL, 11,        mmGCEA_DSM_CNTL2,  9,        mmGCEA_DSM_CNTL2, 26],
    GCEA_WRET_TAGMEM        : [         mmGCEA_DSM_CNTL, 12,         mmGCEA_DSM_CNTL, 14,        mmGCEA_DSM_CNTL2, 12,        mmGCEA_DSM_CNTL2, 26],
    GC_CANE_IREQ0_CMDMEM    : [      mmGC_CANE_DSM_CNTL,  0,      mmGC_CANE_DSM_CNTL,  2,     mmGC_CANE_DSM_CNTL2,  0,     mmGC_CANE_DSM_CNTL2, 26],
    GC_CANE_IREQ1_CMDMEM    : [      mmGC_CANE_DSM_CNTL,  3,      mmGC_CANE_DSM_CNTL,  5,     mmGC_CANE_DSM_CNTL2,  3,     mmGC_CANE_DSM_CNTL2, 26],
    GC_CANE_IREQ1_DATAMEM   : [      mmGC_CANE_DSM_CNTL,  6,      mmGC_CANE_DSM_CNTL,  8,     mmGC_CANE_DSM_CNTL2,  6,     mmGC_CANE_DSM_CNTL2, 26],
    GC_CANE_SDPS_DATAMEM    : [      mmGC_CANE_DSM_CNTL, 12,      mmGC_CANE_DSM_CNTL, 14,     mmGC_CANE_DSM_CNTL2, 12,     mmGC_CANE_DSM_CNTL2, 26],
    GC_CANE_SDPS_REQMEM     : [      mmGC_CANE_DSM_CNTL,  9,      mmGC_CANE_DSM_CNTL, 11,     mmGC_CANE_DSM_CNTL2,  9,     mmGC_CANE_DSM_CNTL2, 26],
    GDS_GDS_INPUT_QUEUE     : [          mmGDS_DSM_CNTL,  3,          mmGDS_DSM_CNTL,  5,         mmGDS_DSM_CNTL2,  3,         mmGDS_DSM_CNTL2, 26],
    GDS_GDS_MEM             : [          mmGDS_DSM_CNTL,  0,          mmGDS_DSM_CNTL,  2,         mmGDS_DSM_CNTL2,  0,         mmGDS_DSM_CNTL2, 26],
    GDS_GDS_PHY_CMD_RAM     : [          mmGDS_DSM_CNTL,  6,          mmGDS_DSM_CNTL,  8,         mmGDS_DSM_CNTL2,  6,         mmGDS_DSM_CNTL2, 26],
    GDS_GDS_PHY_DATA_RAM    : [          mmGDS_DSM_CNTL,  9,          mmGDS_DSM_CNTL, 11,         mmGDS_DSM_CNTL2,  9,         mmGDS_DSM_CNTL2, 26],
    GDS_GDS_PIPE_MEM        : [          mmGDS_DSM_CNTL, 12,          mmGDS_DSM_CNTL, 14,         mmGDS_DSM_CNTL2, 12,         mmGDS_DSM_CNTL2, 26],
    RLC_RLCG_INSTR_RAM      : [          mmRLC_DSM_CNTL,  0,          mmRLC_DSM_CNTL,  2,         mmRLC_DSM_CNTL2,  0,         mmRLC_DSM_CNTL2, 26],
    RLC_RLCG_SCRATCH_RAM    : [          mmRLC_DSM_CNTL,  3,          mmRLC_DSM_CNTL,  5,         mmRLC_DSM_CNTL2,  3,         mmRLC_DSM_CNTL2, 26],
    RLC_RLCV_INSTR_RAM      : [          mmRLC_DSM_CNTL,  6,          mmRLC_DSM_CNTL,  8,         mmRLC_DSM_CNTL2,  6,         mmRLC_DSM_CNTL2, 26],
    RLC_RLCV_SCRATCH_RAM    : [          mmRLC_DSM_CNTL,  9,          mmRLC_DSM_CNTL, 11,         mmRLC_DSM_CNTL2,  9,         mmRLC_DSM_CNTL2, 26],
    RLC_RLC_SPM_SCRATCH_RAM : [          mmRLC_DSM_CNTL, 15,          mmRLC_DSM_CNTL, 17,         mmRLC_DSM_CNTL2, 15,         mmRLC_DSM_CNTL2, 26],
    RLC_RLC_SPM_SE0_SCRATCH_RAM: [       mmRLC_DSM_CNTLA,  0,         mmRLC_DSM_CNTLA,  2,        mmRLC_DSM_CNTL2A,  0,         mmRLC_DSM_CNTL2, 26],
    RLC_RLC_SPM_SE1_SCRATCH_RAM: [       mmRLC_DSM_CNTLA,  3,         mmRLC_DSM_CNTLA,  5,        mmRLC_DSM_CNTL2A,  3,         mmRLC_DSM_CNTL2, 26],
    RLC_RLC_SPM_SE2_SCRATCH_RAM: [       mmRLC_DSM_CNTLA,  6,         mmRLC_DSM_CNTLA,  8,        mmRLC_DSM_CNTL2A,  6,         mmRLC_DSM_CNTL2, 26],
    RLC_RLC_SPM_SE3_SCRATCH_RAM: [       mmRLC_DSM_CNTLA,  9,         mmRLC_DSM_CNTLA, 11,        mmRLC_DSM_CNTL2A,  9,         mmRLC_DSM_CNTL2, 26],
    RLC_RLC_SRM_ADDR_RAM    : [          mmRLC_DSM_CNTL, 21,          mmRLC_DSM_CNTL, 23,         mmRLC_DSM_CNTL2, 21,         mmRLC_DSM_CNTL2, 26],
    RLC_RLC_SRM_DATA_RAM    : [          mmRLC_DSM_CNTL, 18,          mmRLC_DSM_CNTL, 20,         mmRLC_DSM_CNTL2, 18,         mmRLC_DSM_CNTL2, 26],
    RLC_RLC_TCTAG_RAM       : [          mmRLC_DSM_CNTL, 12,          mmRLC_DSM_CNTL, 14,         mmRLC_DSM_CNTL2, 12,         mmRLC_DSM_CNTL2, 26],
    SPI_SPI_GDS_EXPREQ_MEM  : [          mmSPI_DSM_CNTL,  3,          mmSPI_DSM_CNTL,  5,         mmSPI_DSM_CNTL2, 10,                    None, None],
    SPI_SPI_LIFE_CNT_MEM    : [          mmSPI_DSM_CNTL, 12,          mmSPI_DSM_CNTL, 14,         mmSPI_DSM_CNTL2, 19,                    None, None],
    SPI_SPI_SR_MEM          : [          mmSPI_DSM_CNTL,  0,          mmSPI_DSM_CNTL,  2,         mmSPI_DSM_CNTL2,  0,                    None, None],
    SPI_SPI_WB_GRANT_30_MEM : [          mmSPI_DSM_CNTL,  6,          mmSPI_DSM_CNTL,  8,         mmSPI_DSM_CNTL2, 13,                    None, None],
    SQC_DATA_BANK_RAM       : [         mmSQC_DSM_CNTLA, 24,         mmSQC_DSM_CNTLB, 26,        mmSQC_DSM_CNTL2B, 24,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_CU0_UTCL1_LFIFO: [          mmSQC_DSM_CNTL,  6,          mmSQC_DSM_CNTL,  8,         mmSQC_DSM_CNTL2,  6,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_CU0_WRITE_DATA_BUF: [          mmSQC_DSM_CNTL,  3,          mmSQC_DSM_CNTL,  5,         mmSQC_DSM_CNTL2,  3,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_CU1_UTCL1_LFIFO: [          mmSQC_DSM_CNTL, 12,          mmSQC_DSM_CNTL, 14,         mmSQC_DSM_CNTL2, 12,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_CU1_WRITE_DATA_BUF: [          mmSQC_DSM_CNTL,  9,          mmSQC_DSM_CNTL, 11,         mmSQC_DSM_CNTL2,  9,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_CU2_UTCL1_LFIFO: [          mmSQC_DSM_CNTL, 18,          mmSQC_DSM_CNTL, 20,         mmSQC_DSM_CNTL2, 18,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_CU2_WRITE_DATA_BUF: [          mmSQC_DSM_CNTL, 15,          mmSQC_DSM_CNTL, 17,         mmSQC_DSM_CNTL2, 15,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_CU3_UTCL1_LFIFO: [          mmSQC_DSM_CNTL, 24,          mmSQC_DSM_CNTL, 26,        mmSQC_DSM_CNTL2E,  3,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_CU3_WRITE_DATA_BUF: [          mmSQC_DSM_CNTL, 21,          mmSQC_DSM_CNTL, 23,        mmSQC_DSM_CNTL2E,  0,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_DIRTY_BIT_RAM  : [         mmSQC_DSM_CNTLA, 21,         mmSQC_DSM_CNTLB, 23,        mmSQC_DSM_CNTL2B, 21,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_HIT_FIFO       : [         mmSQC_DSM_CNTLA, 15,         mmSQC_DSM_CNTLB, 17,        mmSQC_DSM_CNTL2B, 15,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_MISS_FIFO      : [         mmSQC_DSM_CNTLA, 18,         mmSQC_DSM_CNTLB, 20,        mmSQC_DSM_CNTL2B, 18,         mmSQC_DSM_CNTL2, 26],
    SQC_DATA_TAG_RAM        : [         mmSQC_DSM_CNTLA, 12,         mmSQC_DSM_CNTLB, 14,        mmSQC_DSM_CNTL2B, 12,         mmSQC_DSM_CNTL2, 26],
    SQC_INST_BANK_RAM       : [         mmSQC_DSM_CNTLA,  9,         mmSQC_DSM_CNTLB, 11,        mmSQC_DSM_CNTL2B,  9,         mmSQC_DSM_CNTL2, 26],
    SQC_INST_MISS_FIFO      : [         mmSQC_DSM_CNTLA,  6,         mmSQC_DSM_CNTLB,  8,        mmSQC_DSM_CNTL2B,  6,         mmSQC_DSM_CNTL2, 26],
    SQC_INST_TAG_RAM        : [         mmSQC_DSM_CNTLA,  0,         mmSQC_DSM_CNTLB,  2,        mmSQC_DSM_CNTL2B,  0,         mmSQC_DSM_CNTL2, 26],
    SQC_INST_UTCL1_LFIFO    : [          mmSQC_DSM_CNTL,  0,          mmSQC_DSM_CNTL,  2,         mmSQC_DSM_CNTL2,  0,         mmSQC_DSM_CNTL2, 26],
    SQC_INST_UTCL1_MISS_FIFO: [         mmSQC_DSM_CNTLA,  3,         mmSQC_DSM_CNTLB,  5,        mmSQC_DSM_CNTL2B,  3,         mmSQC_DSM_CNTL2, 26],
    SQ_LDS_D                : [           mmSQ_DSM_CNTL, 16,           mmSQ_DSM_CNTL, 18,          mmSQ_DSM_CNTL2,  3,          mmSQ_DSM_CNTL2, 26],
    SQ_LDS_I                : [           mmSQ_DSM_CNTL, 19,           mmSQ_DSM_CNTL, 18,          mmSQ_DSM_CNTL2,  6,          mmSQ_DSM_CNTL2, 26],
    SQ_SGPR                 : [           mmSQ_DSM_CNTL,  8,           mmSQ_DSM_CNTL, 10,          mmSQ_DSM_CNTL2,  0,          mmSQ_DSM_CNTL2, 26],
    SQ_SP                   : [           mmSQ_DSM_CNTL, 24,           mmSQ_DSM_CNTL, 26,          mmSQ_DSM_CNTL2,  9,          mmSQ_DSM_CNTL2, 26],
    TA_TA_FS_AFIFO_HI       : [           mmTA_DSM_CNTL, 18,           mmTA_DSM_CNTL, 20,          mmTA_DSM_CNTL2, 18,          mmTA_DSM_CNTL2, 26],
    TA_TA_FS_AFIFO_LO       : [           mmTA_DSM_CNTL, 15,           mmTA_DSM_CNTL, 17,          mmTA_DSM_CNTL2, 15,          mmTA_DSM_CNTL2, 26],
    TA_TA_FS_CFIFO          : [           mmTA_DSM_CNTL, 12,           mmTA_DSM_CNTL, 14,          mmTA_DSM_CNTL2, 12,          mmTA_DSM_CNTL2, 26],
    TA_TA_FS_DFIFO          : [           mmTA_DSM_CNTL,  0,           mmTA_DSM_CNTL,  2,          mmTA_DSM_CNTL2,  0,          mmTA_DSM_CNTL2, 26],
    TA_TA_FX_LFIFO          : [           mmTA_DSM_CNTL,  9,           mmTA_DSM_CNTL, 11,          mmTA_DSM_CNTL2,  9,          mmTA_DSM_CNTL2, 26],
    TCA_HOLE_FIFO_SED       : [          mmTCA_DSM_CNTL,  0,          mmTCA_DSM_CNTL,  2,         mmTCA_DSM_CNTL2,  0,         mmTCA_DSM_CNTL2, 26],
    TCA_REQ_FIFO_SED        : [          mmTCA_DSM_CNTL,  3,          mmTCA_DSM_CNTL,  5,         mmTCA_DSM_CNTL2,  3,         mmTCA_DSM_CNTL2, 26],
    TCC_CACHE_DATA          : [          mmTCC_DSM_CNTL,  0,          mmTCC_DSM_CNTL,  2,         mmTCC_DSM_CNTL2,  0,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DATA_BANK_0_1 : [          mmTCC_DSM_CNTL,  3,          mmTCC_DSM_CNTL,  5,         mmTCC_DSM_CNTL2,  3,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DATA_BANK_0_2 : [         mmTCC_DSM_CNTL3,  0,         mmTCC_DSM_CNTL3,  2,         mmTCC_DSM_CNTL3, 12,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DATA_BANK_0_3 : [         mmTCC_DSM_CNTL3,  3,         mmTCC_DSM_CNTL3,  5,         mmTCC_DSM_CNTL3, 15,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DATA_BANK_1_0 : [          mmTCC_DSM_CNTL,  6,          mmTCC_DSM_CNTL,  8,         mmTCC_DSM_CNTL2,  6,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DATA_BANK_1_1 : [          mmTCC_DSM_CNTL,  9,          mmTCC_DSM_CNTL, 11,         mmTCC_DSM_CNTL2,  9,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DATA_BANK_1_2 : [         mmTCC_DSM_CNTL3,  6,         mmTCC_DSM_CNTL3,  8,         mmTCC_DSM_CNTL3, 18,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DATA_BANK_1_3 : [         mmTCC_DSM_CNTL3,  9,         mmTCC_DSM_CNTL3, 11,         mmTCC_DSM_CNTL3, 21,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DIRTY_BANK_0  : [          mmTCC_DSM_CNTL, 12,          mmTCC_DSM_CNTL, 14,         mmTCC_DSM_CNTL2, 12,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_DIRTY_BANK_1  : [          mmTCC_DSM_CNTL, 15,          mmTCC_DSM_CNTL, 17,         mmTCC_DSM_CNTL2, 15,         mmTCC_DSM_CNTL2, 26],
    TCC_CACHE_TAG_PROBE_FIFO: [         mmTCC_DSM_CNTLA, 15,         mmTCC_DSM_CNTLA, 17,        mmTCC_DSM_CNTL2A, 24,         mmTCC_DSM_CNTL2, 26],
    TCC_HIGH_RATE_TAG       : [          mmTCC_DSM_CNTL, 18,          mmTCC_DSM_CNTL, 20,         mmTCC_DSM_CNTL2, 18,         mmTCC_DSM_CNTL2, 26],
    TCC_IN_USE_DEC          : [          mmTCC_DSM_CNTL, 24,          mmTCC_DSM_CNTL, 26,        mmTCC_DSM_CNTL2A,  0,         mmTCC_DSM_CNTL2, 26],
    TCC_IN_USE_TRANSFER     : [          mmTCC_DSM_CNTL, 27,          mmTCC_DSM_CNTL, 29,        mmTCC_DSM_CNTL2A,  3,         mmTCC_DSM_CNTL2, 26],
    TCC_LATENCY_FIFO        : [         mmTCC_DSM_CNTLA, 18,         mmTCC_DSM_CNTLA, 20,        mmTCC_DSM_CNTL2B,  0,         mmTCC_DSM_CNTL2, 26],
    TCC_LATENCY_FIFO_NEXT_RAM: [         mmTCC_DSM_CNTLA, 12,         mmTCC_DSM_CNTLA, 14,        mmTCC_DSM_CNTL2B,  3,         mmTCC_DSM_CNTL2, 26],
    TCC_LOW_RATE_TAG        : [          mmTCC_DSM_CNTL, 21,          mmTCC_DSM_CNTL, 23,         mmTCC_DSM_CNTL2, 21,         mmTCC_DSM_CNTL2, 26],
    TCC_OUTPUT_FIFOS        : [         mmTCC_DSM_CNTLA, 27,         mmTCC_DSM_CNTLA, 29,        mmTCC_DSM_CNTL2A, 27,         mmTCC_DSM_CNTL2, 26],
    TCC_RETURN_CONTROL      : [         mmTCC_DSM_CNTLA, 24,         mmTCC_DSM_CNTLA, 26,        mmTCC_DSM_CNTL2A,  9,         mmTCC_DSM_CNTL2, 26],
    TCC_RETURN_DATA         : [         mmTCC_DSM_CNTLA, 21,         mmTCC_DSM_CNTLA, 23,        mmTCC_DSM_CNTL2A,  6,         mmTCC_DSM_CNTL2, 26],
    TCC_SRC_FIFO            : [         mmTCC_DSM_CNTLA,  0,         mmTCC_DSM_CNTLA,  2,        mmTCC_DSM_CNTL2A, 21,         mmTCC_DSM_CNTL2, 26],
    TCC_UC_ATOMIC_FIFO      : [         mmTCC_DSM_CNTLA,  3,         mmTCC_DSM_CNTLA,  5,        mmTCC_DSM_CNTL2A, 12,         mmTCC_DSM_CNTL2, 26],
    TCC_WRITE_CACHE_READ    : [         mmTCC_DSM_CNTLA,  9,         mmTCC_DSM_CNTLA, 11,        mmTCC_DSM_CNTL2A, 18,         mmTCC_DSM_CNTL2, 26],
    TCC_WRITE_EARLY_RETURN  : [        mmTCC_DSM_CNTL2B, 15,        mmTCC_DSM_CNTL2B, 17,                    None, None,         mmTCC_DSM_CNTL2, 26],
    TCC_WRITE_RETURN        : [         mmTCC_DSM_CNTLA,  6,         mmTCC_DSM_CNTLA,  8,        mmTCC_DSM_CNTL2A, 15,         mmTCC_DSM_CNTL2, 26],
    TCI_WRITE_RAM           : [          mmTCI_DSM_CNTL,  0,          mmTCI_DSM_CNTL,  2,         mmTCI_DSM_CNTL2,  0,         mmTCI_DSM_CNTL2, 26],
    TCP_CACHE_RAM           : [          mmTCP_DSM_CNTL,  0,          mmTCP_DSM_CNTL,  2,         mmTCP_DSM_CNTL2,  0,         mmTCP_DSM_CNTL2, 26],
    TCP_CMD_FIFO            : [          mmTCP_DSM_CNTL,  6,          mmTCP_DSM_CNTL,  8,         mmTCP_DSM_CNTL2,  6,         mmTCP_DSM_CNTL2, 26],
    TCP_DB_RAM              : [          mmTCP_DSM_CNTL, 12,          mmTCP_DSM_CNTL, 14,         mmTCP_DSM_CNTL2, 12,         mmTCP_DSM_CNTL2, 26],
    TCP_GATCL1_TCP_GATCL1   : [   mmTCP_GATCL1_DSM_CNTL,  0,   mmTCP_GATCL1_DSM_CNTL,  2,                    None, None,                    None, None],
    TCP_LFIFO_RAM           : [          mmTCP_DSM_CNTL,  3,          mmTCP_DSM_CNTL,  5,         mmTCP_DSM_CNTL2,  3,         mmTCP_DSM_CNTL2, 26],
    TCP_UTCL1_LFIFO0        : [          mmTCP_DSM_CNTL, 15,          mmTCP_DSM_CNTL, 17,         mmTCP_DSM_CNTL2, 15,         mmTCP_DSM_CNTL2, 26],
    TCP_UTCL1_LFIFO1        : [          mmTCP_DSM_CNTL, 18,          mmTCP_DSM_CNTL, 20,         mmTCP_DSM_CNTL2, 18,         mmTCP_DSM_CNTL2, 26],
    TCP_VM_FIFO             : [          mmTCP_DSM_CNTL,  9,          mmTCP_DSM_CNTL, 11,         mmTCP_DSM_CNTL2,  9,         mmTCP_DSM_CNTL2, 26],
    TCX_GROUP0_SED          : [          mmTCX_DSM_CNTL,  0,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP10_SED         : [          mmTCX_DSM_CNTL, 20,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP13_SED         : [          mmTCX_DSM_CNTL, 26,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP14_SED         : [          mmTCX_DSM_CNTL, 28,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP1_SED          : [          mmTCX_DSM_CNTL,  2,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP2_SED          : [          mmTCX_DSM_CNTL,  4,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP4_SED          : [          mmTCX_DSM_CNTL,  8,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP5_SED          : [          mmTCX_DSM_CNTL, 10,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP6_SED          : [          mmTCX_DSM_CNTL, 12,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP8_SED          : [          mmTCX_DSM_CNTL, 16,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TCX_GROUP9_SED          : [          mmTCX_DSM_CNTL, 18,          mmTCX_DSM_CNTL, 30,         mmTCX_DSM_CNTL2, 0,         mmTCX_DSM_CNTL2, 26],
    TD_TD_CS_FIFO           : [           mmTD_DSM_CNTL,  6,           mmTD_DSM_CNTL,  8,         mmTD_DSM_CNTL2,  6,          mmTD_DSM_CNTL2, 26],
    TD_TD_SS_FIFO_HI        : [           mmTD_DSM_CNTL,  3,           mmTD_DSM_CNTL,  5,         mmTD_DSM_CNTL2,  3,          mmTD_DSM_CNTL2, 26],
    TD_TD_SS_FIFO_LO        : [           mmTD_DSM_CNTL,  0,           mmTD_DSM_CNTL,  2,         mmTD_DSM_CNTL2,  0,          mmTD_DSM_CNTL2, 26],
    UTCL2_MEM               : [    mmUTCL2_MEM_ECC_CNTL,  6,    mmUTCL2_MEM_ECC_CNTL,  8,    mmUTCL2_MEM_ECC_CNTL,  9,    mmUTCL2_MEM_ECC_CNTL,  0],
    VML2_MEM                : [     mmGCVML2_MEM_ECC_CNTL,  6,     mmGCVML2_MEM_ECC_CNTL,  8,     mmGCVML2_MEM_ECC_CNTL,  9,     mmGCVML2_MEM_ECC_CNTL,  0],
    VML2_WALKER_MEM         : [mmGCVML2_WALKER_MEM_ECC_CNTL,  6,mmGCVML2_WALKER_MEM_ECC_CNTL,  8,mmGCVML2_WALKER_MEM_ECC_CNTL,  9,mmGCVML2_WALKER_MEM_ECC_CNTL,  0],
}
