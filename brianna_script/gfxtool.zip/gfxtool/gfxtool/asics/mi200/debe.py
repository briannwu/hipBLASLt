from ip_util import *
class DebeMi200(BitStruct):
    _fields = [
    ["SPARE",19],
    ["ACP"     ,4],
    ["VCE"     ,2],
    ["UVD"     ,1],
    ["DCE"     ,6],
    ["SPARE2" ,16],
    ["TCC"     ,16],
    ["SE7SH0CU",16],
    ["SE6SH0CU",16],
    ["SE5SH0CU",16],
    ["SE4SH0CU",16],
    ["SE3SH0CU",16],
    ["SE2SH0CU",16],
    ["SE1SH0CU",16],
    ["SE0SH0CU",16],
    ]

Debe = DebeMi200
