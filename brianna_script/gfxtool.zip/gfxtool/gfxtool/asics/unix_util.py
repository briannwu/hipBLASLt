import os, sys
import termios, tty

def mygetch(onechmode = True):
    """return input from stdin; if stdin has nothing, return ""
    Arg:
        onechmode == True:  return a ch
        onechmode == False:  return a strip line
    """
    def isData():
      import select
      return select.select([sys.stdin], [], [], 0) == ([sys.stdin], [], [])
    if not isData(): return ""
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    tty.setcbreak(sys.stdin.fileno())
    try:
        tty.setraw(sys.stdin.fileno(), termios.TCSANOW)
        if onechmode == True: ch = sys.stdin.read(1)
        else: ch = sys.stdin.readline().strip()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch
class mystdin(object):
    def __init__(self, mode=0):
        self.mode = mode
    def __enter__(self):
        if self.mode == 0:
            self.old_settings = termios.tcgetattr(sys.stdin)# it is optional
            tty.setcbreak(sys.stdin.fileno())
        return self
    def __exit__(self, type, value, traceback):
        if self.mode == 0:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_settings) # it is optional
        pass
    def getch(self):
        import select
        if select.select([sys.stdin], [], [], 0) == ([sys.stdin], [], []):
            return sys.stdin.read(1)
        return False
def mygetch2():
    return mystdin().getch()

def press_any_key_exit(msg):
  fd = sys.stdin.fileno()
  old_ttyinfo = termios.tcgetattr(fd)
  new_ttyinfo = old_ttyinfo[:]
  new_ttyinfo[3] &= ~termios.ICANON
  new_ttyinfo[3] &= ~termios.ECHO
  termios.tcsetattr(fd, termios.TCSANOW, new_ttyinfo)
  os.read(fd, 7)
  termios.tcsetattr(fd, termios.TCSANOW, old_ttyinfo)


