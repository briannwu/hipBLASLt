#!/bin/bash
if [ x$1 != x ]
then
input=$1
else
input=gc_features.h
fi
echo "from amd_common import *" > gc_features.py
head -n -1 $input | tail -n +3  | awk '{if($1=="#define") printf "%s = %s\n", $2,  $3 }' >> gc_features.py
sed -i "s/\/\//#/g" gc_features.py
