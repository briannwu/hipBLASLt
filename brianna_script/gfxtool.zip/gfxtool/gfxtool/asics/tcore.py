import tcoredrv

PageTableLocation = 0

def i32(x): return (x&0x80000000 and -2*0x40000000 or 0) + int(x&0x7fffffff)
def i64(x): return (x&0x8000000000000000 and -2*0x4000000000000000 or 0) + long(x&0x7fffffffffffffff)

####
# Heap Class
####

class TCoreHeap:
    """ Represents a TCore Heap """
    pyDev      = 0
    phys_addr  = 0
    size       = 0
    type       = 0

    def __init__(self, pyDev, phys_addr, size, type):
        self.pyDev      = pyDev
        self.phys_addr  = phys_addr
        self.size       = size
        self.type       = type

    def Display(self):
        print ("------------------------------")
        print ("| pyDev      : %0x" % self.pyDev)
        print ("| phys_addr  : %0x" % self.phys_addr)
        print ("| size       : %0x" % self.size)
        print ("| type       : %0x" % self.type)
        print ("------------------------------")
    
    def Read(self, offset):
        value = tcoredrv.heapread(self.pyDev, i64(self.phys_addr), i64(offset))
        return value

    def Write(self, offset, value):
        tcoredrv.heapwrite(self.pyDev, i64(self.phys_addr), i64(offset), i32(value))
    
    def BlockRead(self, offset, size):
        value = tcoredrv.heapblockread(self.pyDev, i64(self.phys_addr), i32(offset), i32(size))
        return value

    def BlockWrite(self, offset, dataStr):
        if dataStr[0:1] == "0x":
            print ("Format error, only hex string:  ")
            print ("format value = \"0x[1-9a_f]+\"")
            return
        dataStr = dataStr[2:].lower()
        
        if len(dataStr) == 0:
            print ("data is empty")
            return
        
        if  len(dataStr) / 2 + offset  >= self.size:
            print ("input data exceed heap size")
            return 
        
        for letter in dataStr:
            if letter not in  [chr(i) for i in range(ord('0'), ord('9')+1) + range(ord('a'), ord('f')+1)]:
                print ("invalid letter %s in %s" % (letter, dataStr))

        if (len(dataStr) % 2 != 0):
            dataStr = "0" + dataStr
            
        tcoredrv.heapblockwrite(self.pyDev, i64(self.phys_addr), i32(offset), dataStr)



    def DumpRange(self, base_offset, size):
        if base_offset+size <= self.size:
            for offset in range(size/4):
                if offset%8 == 0:
                    print ("")
                    print ("[%16.16x] : " % (base_offset + offset*4))
                print ("%8x" % self.Read(i64(base_offset + offset*4)))

    def AddressInHeap(self, address):
        (found, offset) = tcoredrv.heapaddrcheck(self.pyDev, i64(self.phys_addr), i64(address))
        return (found, offset)

class TCoreDevice:
    """ Represents a TCore-accessible device """

    ###
    # Device type
    DeviceType_GPU   = 0
    DeviceType_Audio = 1
    DeviceType_CEC   = 2
    DeviceType_GPU1   = 3
    DeviceType_Other = 100


#####
# Display/Dump functions
####
    def __init__(self, pyDev):
        self.pyDev = pyDev

    def DumpHeapList(self):
        result = tcoredrv.heaplistquery(self.pyDev)

        for listitem in result:
            print ("------------------------------")
            print ("| phys_addr  : %0x" % listitem[0])
            print ("| size       : %0x" % listitem[1])
            print ("| type       : %0x" % listitem[2])
            print ("------------------------------")

    def DumpReg(self, offset):
        value = tcoredrv.regread(self.pyDev, offset)
        print ("mmreg[%0x] = %0x" % (offset, value))    

    def VidmemDumpIndirect(self):
        vidmem_size = (tcoredrv.regread(self.pyDev, 0x5428)*1024*1024)
        for offset in range(vidmem_size):
            tcoredrv.regwrite(self.pyDev, 0x0, i32((offset*4 | 0x80000000)))
            tcoredrv.regwrite(self.pyDev, 0x18, i32((offset*4 & 0x80000000) >> 31))
            print ("[%8.8x] : %8.8x" % (offset*4, tcoredrv.regread(self.pyDev, 0x4)))

    def VidmemDumpIndirectRange(self, base_offset, size):
        vidmem_size = (tcoredrv.regread(self.pyDev, 0x5428)*1024*1024)
        if base_offset + size <= vidmem_size:
            for offset in range(size/4):
                tcoredrv.regwrite(self.pyDev, 0x0, i32((base_offset + offset*4) | 0x80000000))
                tcoredrv.regwrite(self.pyDev, 0x18, i32(((base_offset + offset*4) & 0x80000000) >> 31))
                if offset%8 == 0:
                    print ("")
                    print ("[%8.8x] : " % (base_offset + offset*4))
                print ("%8.8x" % (tcoredrv.regread(self.pyDev, 0x4)))

        
####
# Access functions
####
    def RegRead(self, offset):
        value = tcoredrv.regread(self.pyDev, i32(offset))
        return value

    def RegWrite(self, offset, value):
        tcoredrv.regwrite(self.pyDev, i32(offset), i32(value))

    def GpuCfgRegRead(self, 
                      offset):
        value = tcoredrv.gpu_cfg_reg_read( self.pyDev,
                                           i32( offset ) )
        return value

    def PciCfgRegRead( self,
                       pci_domain,
                       pci_bus,
                       pci_device,
                       pci_function,
                       offset ):
        value = tcoredrv.pci_cfg_reg_read( self.pyDev,
                                           i32( pci_domain ),
                                           i32( pci_bus ),
                                           i32( pci_device ),
                                           i32( pci_function ),
                                           i32( offset ) )
        return value

    def PciCfgRegWrite( self,
                        pci_domain,
                        pci_bus,
                        pci_device,
                        pci_function,
                        offset, 
                        value ):
        tcoredrv.pci_cfg_reg_write( self.pyDev,
                                    i32( pci_domain ),
                                    i32( pci_bus ),
                                    i32( pci_device ),
                                    i32( pci_function ),
                                    i32( offset ),
                                    i32( value ) )

    def GetPciDomain   ( self ):
        return tcoredrv.get_pci_domain  ( self.pyDev )

    def GetPciBus     ( self ):
        return tcoredrv.get_pci_bus     ( self.pyDev )

    def GetPciDevice  ( self ):
        return tcoredrv.get_pci_device  ( self.pyDev )

    def GetPciFunction( self ):
        return tcoredrv.get_pci_function( self.pyDev )


    def GetHeapList(self):
        myHeapList = []
        result = tcoredrv.heaplistquery(self.pyDev)
        for listitem in result:
            newHeap = TCoreHeap(self.pyDev, listitem[0], listitem[1], listitem[2])
            myHeapList.append(newHeap)
        return myHeapList

    def GetHeap(self, heap_id):
        heap_info = tcoredrv.getheap(self.pyDev, i64(heap_id))
        newHeap = TCoreHeap(self.pyDev, heap_info[0], heap_info[1], heap_info[2])
        return newHeap

    def CheckGRBMStatus(self):
        value = RegRead(RegOffset("mmGRBM_STATUS"))
        print ("GRBM_STATUS = 0x%x" % value)
        if value & 0x80000000 :
            print ("GUI Active")
        if value & 0x40000000 :
            print ("CB Busy")
        if value & 0x20000000 :
            print ("CP Busy")
        if value & 0x10000000 :
            print ("CP Coherency Busy")
        if value & 0x04000000 :
            print ("DB Busy")
        if value & 0x02000000 :
            print ("PA Busy")
        if value & 0x01000000 :
            print ("SC Busy")
        if value & 0x00800000 :
            print ("SPI Busy")
        if value & 0x00100000 :
            print ("SX Busy")
        if value & 0x00080000 :
            print ("IA Busy")
        if value & 0x00040000 :
            print ("IA Busy No DMA")
        if value & 0x00020000 :
            print ("VGT Busy")
        if value & 0x00008000 :
            print ("GDS Busy")
        if value & 0x00004000 :
            print ("TA Busy")
        if value & 0x00002000 :
            print ("CB Clean")
        if value & 0x00001000 :
            print ("DB Clean")
        if value & 0x00000800 :
            print ("SX Clean")
        if value & 0x00000400 :
            print ("GRBM EE Busy")
        if value & 0x00000200 :
            print ("GDS DMA Request Pending")
        if value & 0x00000100 :
            print ("PF Request Pending")
        if value & 0x00000080 :
            print ("CF Request Pending")
        if value & 0x00000040 :
            print ("Ring1 Request Pending")
        if value & 0x00000020 :
            print ("SRBM Request Pending")
        if value & 0x00000010 :
            print ("Ring2 Request Pending")

        print ("CMDFIFO Available 0x%x" % (value & 0xf))

    def RegOffset(self, name):
        return tcoredrv.getregoffset(self.pyDev, name)

    def GetHeapFromPhysAddress(self, address):
        for heap in GetHeapList() :
            (found, offset) = heap.AddressInHeap(address)
            if (found):
                return heap

#
# Functions to complete an MC Address Lookup
#


    def InContextVMAperture(self, VMID, address):
        aperture_start_reg = "mmVM_CONTEXT%0d_PAGE_TABLE_START_ADDR" % VMID
        aperture_end_reg   = "mmVM_CONTEXT%0d_PAGE_TABLE_END_ADDR" % VMID
        aperture_start_addr = (RegRead(RegOffset(aperture_start_reg)) << 12)
        aperture_end_addr   = (RegRead(RegOffset(aperture_end_reg)) << 12)

        if (address >= aperture_start_addr and
            address <= aperture_end_addr) :
            return 1
        else :
            return 0

    def SystemMapped(self, address):
        l1_tlb_cntl = RegRead(RegOffset("mmMC_VM_MX_L1_TLB_CNTL"))
        l1_tlb_cntl_sys_mode = (l1_tlb_cntl & 0x18) >> 3

        if (l1_tlb_cntl_sys_mode == 0) :
            return 0
        elif (l1_tlb_cntl_sys_mode == 1) :
            return 1
        else :
            system_aperture_base = (RegRead(RegOffset("mmMC_VM_SYSTEM_APERTURE_LOW_ADDR")) << 12)
            system_aperture_end  = i64((RegRead(RegOffset("mmMC_VM_SYSTEM_APERTURE_HIGH_ADDR")) << 12))

            if (l1_tlb_cntl_sys_mode == 2) :
                if (i64(address) >= i64(system_aperture_base)) and (i64(address) <= i64(system_aperture_end)) :
                    return 1
            else :
                if (address <= system_aperture_base) or (address >= system_aperture_end) :
                    return 1

        return 0

    def InVidmemAperture(self, address):
        vidmem_aperture = RegRead(RegOffset("mmMC_VM_FB_LOCATION"))
        vidmem_aperture_base = ((vidmem_aperture & 0xffff) << 24)
        vidmem_aperture_end  = ((vidmem_aperture & 0xffff0000) << 8)

#    print ("--Checking vidimem aperture--"
#    print ("address : 0x%0x" % address
#    print ("base    : 0x%0x" % vidmem_aperture_base
#    print ("end     : 0x%0x" % vidmem_aperture_end
        
        if (i64(address) >= i64(vidmem_aperture_base)) and (i64(address) <= i64(vidmem_aperture_end)) :
#        print ("in vidmem aperture"
            return 1
        else :
#        print ("outside vidmem aperture"
            return 0

    def GetHeapFromMCAddress(self, VMID, address):

        print ("Resolving VMID(%d) Address(0x%08x)" % (VMID, address))
        
        adm_mode = ((RegRead(RegOffset("mmMC_VM_MX_L1_TLB_CNTL")) & 0x40) >> 6)
        heap_list = GetHeapList()

#    print ("adm_mode = %d" % adm_mode
        
        if (VMID != 0) and (adm_mode == 1) :
            if (InContextVMAperture(VMID, address)) :
                # need to do a VM lookup
                print ("Mapped space VMID(%0d)" % VMID)
                (heap, offset) = ResolveVirtMCAddress(VMID, address)
                return (heap, offset)
            else :
                print ("Fault: VMID(%0d) not in VM aperture" % VMID)
                return None
        elif (SystemMapped(address)) :
            if (InContextVMAperture(VMID, address)) :
                print ("Priveledge Mapped space VMID0")
                # need to do a VM lookup
                (heap, offset) = ResolveVirtMCAddress(VMID, address)
                return (heap, offset)
            else :
                print ("Fault: VMID0 mapped but not in aperture")
                return None
            
        elif (InVidmemAperture(address)) :
            # get vidmem 
            print ("Vidmem Physical")
            for heap in heap_list :
                if heap.type == 2 :
                    vidmem_aperture = RegRead(RegOffset("mmMC_VM_FB_LOCATION"))
                    vidmem_aperture_base = ((vidmem_aperture & 0xffff) << 24)
                    offset = address - vidmem_aperture_base
                    return (heap, offset)
        else :
            # find physical sysmem heap
            print ("Sysmem Physical")

            for heap in heap_list :
                if heap.type == 4 :
                    (found, offset) = heap.AddressInHeap(address)
                    if found :
                        return (heap, offset)
                    
            return None

    def ResolveVirtMCAddress(self, VMID, address):
        """ We have pre-qualified this address to fall in the VM aperture for the VMID """

        pt_base_addr_reg = "mmVM_CONTEXT%0d_PAGE_TABLE_BASE_ADDR" % VMID
        pt_base_addr = i64((RegRead(RegOffset(pt_base_addr_reg)) << 12))
        pt_heap = None

        aperture_start_reg = "mmVM_CONTEXT%0d_PAGE_TABLE_START_ADDR" % VMID
        aperture_start_addr = (RegRead(RegOffset(aperture_start_reg)) << 12)
        pte_offset = i64((((address - aperture_start_addr) & 0xfffffffffffff000) >> 12) * 8)

        print ("PT location              : 0x%0x" % pt_base_addr)
        print ("PTE offset in page table : 0x%0x" % pte_offset)
        heap_list = GetHeapList()

        ### Now we need to grab the heap where the page table lives
        if (InVidmemAperture(pt_base_addr)) :
            ### The PT is in vidmem
            for heap in heap_list :
                if heap.type == 2 :
                    vidmem_aperture = RegRead(RegOffset("mmMC_VM_FB_LOCATION"))
                    vidmem_aperture_base = ((vidmem_aperture & 0xffff) << 24)
                    pt_heap_offset = i64(pt_base_addr - vidmem_aperture_base)
                    pt_heap = heap

        else :
            for heap in heap_list :
                (found, pt_heap_offset) = heap.AddressInHeap(pt_base_addr)
                if found :
                    pt_heap = heap

#    print ("--Found PT heap--"
#    pt_heap.Display()

        ## Read the page table entry from the page table
        if pt_heap :
            pte_lo = pt_heap.Read(pt_heap_offset + pte_offset)
            pte_hi = pt_heap.Read(pt_heap_offset + pte_offset+4)

            print ("PT offset in heap        : 0x%0x" % pt_heap_offset)
            print ("PTE [%8.8x:%8.8x]" % (pte_hi, pte_lo))

            ## Decode the PTE
            pte_valid = (pte_lo & 0x1)
            pte_system = ((pte_lo & 0x2) >> 1)
            pte_fragment = ((pte_lo & 0xf80) >> 7)
            phys_addr = i64(  ( (pte_hi & 0xff) << 32) | ( (pte_lo & 0xfffff000) )  )

            print ("PTE phys_addr            : 0x%0x" % phys_addr)
            print ("PTE valid                : %d" % pte_valid)
            print ("PTE system               : %d" % pte_system)

#        print ("Searching for matching phys heap..."
            ## now that we have the physical address, we need to get the physical heap
            if pte_system == 0 :
                ### This is in Vidmem
                for heap in heap_list :
                    if heap.type == 2 :
                        ## now we have the actual heap, we can return with the offset
                        offset = phys_addr
                        return (heap, i64(offset))
            else :
                for heap in heap_list :
                    if heap.type == 1 or heap.type == 4 :
#                    print ("  Checking heap..."
#                    heap.Display()
                        (found, offset) = heap.AddressInHeap(phys_addr)
                        if found :
                            return (heap, i64(offset))
                        
        print ("ERROR: Matching physical heap not found!")
        return (None, 0)

def GetGPU():
    # DeviceType_GPU
    return TCoreDevice( tcoredrv.getPyDev(TCoreDevice.DeviceType_GPU, 0, 0) );

def GetVirtGPU(vfid):
    # DeviceType_GPU
    return TCoreDevice( tcoredrv.getPyDev(TCoreDevice.DeviceType_GPU, 1, vfid) );
    

def GetAudio():
    # DeviceType_Audio
    return TCoreDevice( tcoredrv.getPyDev(TCoreDevice.DeviceType_Audio, 0, 0) );

def GetCEC():
    # DeviceType_CEC
    return TCoreDevice( tcoredrv.getPyDev(TCoreDevice.DeviceType_CEC, 0, 0) );

def GetGPU1():
    # DeviceType_CEC
    return TCoreDevice( tcoredrv.getPyDev(TCoreDevice.DeviceType_GPU1, 0, 0) );
