#!/usr/bin/python3
import sys
import os
import inspect
from optparse import OptionParser
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir+"/asics/default")
sys.path.append(parentdir+"/asics")
if os.path.exists(parentdir+"/asics/" + os.path.basename(sys.argv[0])):
    sys.path.insert(0,parentdir+"/asics/" + os.path.basename(sys.argv[0]))
from settings import *


MSG_USAGE =''' -e'cmds'
cmd:
    edc.uei.dsmInject(sram_name)  : inject uncorrectable error to sram_name
    edc.fei.dsmInject(sram_name)  : inject fed error to sram_name
    edc.sei.dsmInject(sram_name)  : inject single error to sram_name
    edc.DSM.list()                : list all the ecc/parity sram
    edc.read_all()                : read out all counters
    edc.setup_edc_mode(gb_edc_mode_value) : write gb_edc_mode_value to register gb_edc_mode
    edc.setup_edc_mode0()         : counter mode, no interrup
    edc.setup_edc_mode1()         : interrupte mode, no propergation
    edc.setup_edc_mode2()         : interrupte mode, with propergation
    edc.clear_all()               : set all dsm/edc register to 0
    edc.setup_fue_cntl(cp, sq,sqc): write cp to cp_fue_cntl, write sq to sq_fue_cntl, write sqc to sqc_fue_cntl
example:
./dsm_inject.py -e "edc.uei.dsmInject(tcc_return_data)"
./dsm_inject.py -e "edc.DSM.list()"
./dsm_inject.py -e "edc.read_all()"
'''
optParser = OptionParser(MSG_USAGE)
optParser.add_option('-e', '--execute', dest='cmd', type='string' , default="")
optParser.add_option('-i', '--cs', dest='cs', type=int , default=-1)
optParser.add_option('--deviceid', dest='deviceid', type=int , default=-1)
optParser.add_option('-v', '--verbose', dest='verbose', type='string', default='30.3', help="-v a.b logger.level=a;Fmt.VERBOSE=b")
optParser.add_option('--XCCID', dest='xccid', type='string', default='0', help="xccid, 0,1,2,...7")
optParser.add_option('--filter0', dest='filter0', action="store_true", help="do not print if value==0")
optParser.add_option('--filterf', dest='filterf', action="store_true", help="do not print if value==0xffffffff")
optParser.add_option('--parsereg', dest='parsereg', action="store_true", help="show fields of reg")
optParser.add_option('--numformat', dest='numformat', type="string", default='%x', help="the number format")
optParser.add_option('--dumpcolumns', dest='dumpcolumns', type=int, help="columns of registers",default=2)
#optParser.add_option('--externaldb32', dest='externaldb32', action="store_true", default=True, help="use external executable db32")
optParser.add_option('--db32', dest='db32', type="string", default="so", help="select backend[so(dll), external, tcore]")
optParser.add_option('--logit', dest='logit', action="store_true", help="logit decorator")
optParser.add_option('-a', '--asic', dest='asic', type='string' , default="")
optParser.add_option('--regbase', dest='regbase', type=int, default=0, help="regbase")
options, args = optParser.parse_args(sys.argv[1:])

Settings.mOptions = options
#Settings.loadVar("XCCID=%d"%options.xccid)
if options.filter0 : Settings.FILTER0 = True
Settings.mDumpColumns = options.dumpcolumns
Settings.getAsicPath(options)
Settings.mParseReg = options.parsereg
if '-' in options.xccid or ',' in options.xccid:
    pass
else:
    gg.XCCID = int(options.xccid)
def setXCC(xccid):
    gg.XCCID = xccid
from edc_reg import *
import edc

if options.numformat != None : edc.Fmt.setFmter(options.numformat)
edc.Fmt.setverbose(int(options.verbose.split('.')[1]) if '.' in options.verbose else 4)
edc.logging.basicConfig(level=int(options.verbose.split('.')[0]))
if(options.cs != -1):
    edc.db32I.CS(options.cs)
    edc.db32S.CS(options.cs)
#if options.externaldb32 :
if options.db32 == 'external':
    #edc.no_Cdb()
    edc.Settings.use_db32S()
    edc.use_db32S()

if len(sys.argv) <2:
    print (MSG_USAGE)
    exit(1)
if not sys.argv[1].startswith("-"):
    cmd = sys.argv[1]
    for i in range(2, len(sys.argv)):
        cmd = cmd + " " +  sys.argv[i]
    options.cmd = cmd

#perseshGFX9("mmr(mmCC_GC_SHADER_ARRAY_CONFIG)\nmmr(mmCC_GC_SHADER_ARRAY_CONFIG)")

def main():
    exec (options.cmd)

def main_all_xccs():
    _allXCCs = []
    if '-' in options.xccid and ',' in options.xccid:
        print("not support both - and , in XCCID")
    elif '-' in options.xccid :
        _range = options.xccid.split('-')
        _allXCCs = list(range(int(_range[0]), int(_range[1])+1))
    elif ',' in options.xccid:
        _allXCCs = [int(i) for i in options.xccid.split(',')]

    for xccid in _allXCCs:
        setXCC(xccid)
        print("xcc%d:"%xccid)
        main()

def main_all_devices():
    did = options.deviceid
    csids = edc.cfg.devices(did);
    for csid in csids:
        print("\n-i %d"%csid)
        if edc.db32I: edc.db32I.CS(csid)
        if edc.db32S: edc.db32S.CS(csid)
        #options.cs = csid
        main()
def main_all_devices_xccs():
    did = options.deviceid
    csids = edc.cfg.devices(did);
    for csid in csids:
        print("\n-i %d"%csid)
        if edc.db32I: edc.db32I.CS(csid)
        if edc.db32S: edc.db32S.CS(csid)
        #options.cs = csid
        main_all_xccs()

if(options.cs == -1 and options.deviceid != -1) and ('-' in options.xccid or ',' in options.xccid):
      main_all_devices_xccs()
elif(options.cs == -1 and options.deviceid != -1):
      main_all_devices()
elif '-' in options.xccid or ',' in options.xccid:
      main_all_xccs()
else:
      main()
