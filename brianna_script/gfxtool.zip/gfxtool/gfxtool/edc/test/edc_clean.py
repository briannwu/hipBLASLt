#!/usr/bin/python
import os
import commands
import edc

edc.clear_all()
