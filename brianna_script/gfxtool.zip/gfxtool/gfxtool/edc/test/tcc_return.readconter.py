#!/usr/bin/python
import os
import commands
import edc

edc.tcc_edc_read_all()
