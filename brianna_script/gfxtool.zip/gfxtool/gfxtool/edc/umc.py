from db32 import *
from edc_reg import *

class UMC:
    @staticmethod
    def mode0():
        # silient
        vMCUMC_CONFIG=0x85
        values=[]
        for i in mcumc_configs:
            old = smn.regr32(i)
            smn.regw32(i, vMCUMC_CONFIG)
            new = smn.regr32(i)
            values.append("%x: %x %x"%(i, old, new))
        print("mcumc_configs", values)
    @staticmethod
    def dsmInject2():
        vfeisrameccwrpctrl=0x2202
        values=[]
        for i in feisrameccwrpctrls:
            smn.regw32(i, vfeisrameccwrpctrl)
            v = smn.regr32(i)
            values.append("%x %x"%(i, v))
        print("vfeisrameccwrpctrl", values)

    @staticmethod
    def inject2():
        UMC.mode0()
        UMC.dsmInject2()

    @staticmethod
    def clear():
        for i in mcumc_configs:
            smn.regw32(i,0)
        for i in feisrameccwrpctrls:
            smn.regw32(i, 0)
    @staticmethod
    def counter():
        vFeiSramEccWrpCtrl  = UserList()
        vWdbSramEccWrpCtrl  = UserList()
        vRdRspSramEccWrpCtrl = UserList()
        for r in FeiSramEccWrpCtrl: vFeiSramEccWrpCtrl.append(smn.regr32(r) & 0x30000)
        for r in RdRspSramEccWrpCtrl: vRdRspSramEccWrpCtrl.append(smn.regr32(r) & 0x30000)
        for r in WdbSramEccWrpCtrl: vWdbSramEccWrpCtrl.append(smn.regr32(r) & 0xff0000)
        vFeiSramEccWrpCtrl.print()
        vWdbSramEccWrpCtrl.print()
        vRdRspSramEccWrpCtrl.print()


