#!/usr/bin/python
import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir + "/ip")
sys.path.insert(0,parentdir)
from db32 import *
from edc_reg import *
import edc_cnt as cnt
import os
from ip_reg import *
from ip_cfg import *
from umc import *

def info():
    reg.dump(mmGB_EDC_MODE)
    reg.dump(mmGCEA_SDP_ARB_FINAL)
    reg.dump(mmGCEA_ERR_STATUS)
    reg.dump(mmGRBM_DSM_BYPASS)
def enable_fatal():
    v = mmr(mmGCEA_SDP_ARB_FINAL)
    v = (3 << 25) | v
    mmw(mmGCEA_SDP_ARB_FINAL, v)
def disable_fatal():
    v = mmr(mmGCEA_SDP_ARB_FINAL)
    v = (~(3 << 25) ) & v
    mmw(mmGCEA_SDP_ARB_FINAL, v)

def setup_edc_mode(edc_mode = 0 ):
    mmw(mmGB_EDC_MODE, edc_mode)

def setup_fue_cntl(cp = 0, sq = 0, sqc = 0):
    mmw(mmCP_EDC_FUE_CNTL, cp)
    mmw(mmSQ_EDC_FUE_CNTL, sq)
    mmw(mmSQC_EDC_FUE_CNTL, sqc)

def setup_grbm_dsm_bypass(v = 7):
    mmw(mmGRBM_DSM_BYPASS, v)
#counter mode
def setup_edc_mode0():
    setup_edc_mode()
    setup_fue_cntl()

#FUE Interrupt mode, no propogate
def setup_edc_mode1():
    setup_edc_mode(0x20120000)
    setup_fue_cntl(0xFF,0xFFFF0000, 0xFFFF0000)

#FUE Interrupt mode, propogate
def setup_edc_mode2():
    setup_edc_mode(0x20200000)
    setup_fue_cntl(0xFF,0xFFFF0000, 0xFFFF0000)

#EDC Interrupt mode, propogate
def setup_edc_mode3():
    setup_edc_mode(0x20200000)
    setup_fue_cntl(0x0,0x0, 0x0)

#EDC counting mode, propogate
def setup_edc_mode4():
    setup_edc_mode(0x20100000)
    setup_fue_cntl(0x0,0x0, 0x0)

def setup_fue_mode(): setup_edc_mode1()
#EDC counting mode, propogate, count fed as sei
def setup_fed_mode():
    setup_edc_mode(0x20010000)
    setup_fue_cntl(0x0,0x0, 0x0)

def disable_edc():
    mmw(mmCC_GC_EDC_CONFIG, 2)
def enable_dsm():
    mmw(mmCC_GC_EDC_CONFIG, 4)

class Mode:
    '''
    EDC mode DIS_EDC DED_MODE PROP_FED GATE_FUE BYPASS COUNT_FED_OUT    Description
    A        1       X        X        X        0      X
    B        1       X        X        X        1      X
    C        0       0        0        0        0      0
    D        0       1        1        1        0      0
    E        0       2        1        1        0      0/1

    A: Silent Correct B:EDC_OFF C:Local Count  D:FUE_Is_Fatal E:Propagate Poisoned Data
    DIS_EDC: disable counters
    '''
    @staticmethod
    def slient_correct():
        mmw(mmCC_GC_EDC_CONFIG, 2)
        mmw(mmGB_EDC_MODE, 0)
    @staticmethod
    def edc_off():
        mmw(mmCC_GC_EDC_CONFIG, 2)
        mmw(mmGB_EDC_MODE, 0x80000000)
    @staticmethod
    def local_count():
        mmw(mmCC_GC_EDC_CONFIG, 0)
        mmw(mmGB_EDC_MODE, 0)
    @staticmethod
    def fue_is_fatal():
        mmw(mmCC_GC_EDC_CONFIG, 0)
        mmw(mmGB_EDC_MODE, 0x20120000)
    @staticmethod
    def propagate_poison():
        mmw(mmCC_GC_EDC_CONFIG, 0)
        mmw(mmGB_EDC_MODE, 0x20230000)
    @staticmethod
    def A(): Mode.slient_correct()
    @staticmethod
    def B(): Mode.edc_off()
    @staticmethod
    def C(): Mode.local_count()
    @staticmethod
    def D(): Mode.fue_is_fatal()
    @staticmethod
    def E(): Mode.propagate_poison()
#####################         DSM         ###############################
class DSM:
    injectError_DISABLE = 0
    injectError_BIT0 = 1
    injectError_BIT1 = 2
    injectError_BIT01 = 3
    DSM_ERR_FEI = 0
    DSM_ERR_SEI = 1
    DSM_ERR_UEI = 2
    DSM_ERR_UEI_LIMITED = 3

    def __init__(self, bits = injectError_BIT01, err=DSM_ERR_UEI, single=0, delay=0):
        self.__bits = bits
        self.__err = err
        self.__single = single
        self.__delay = delay
        #mmw(mmCC_GC_EDC_CONFIG, 0)
        mmw(mmCC_GC_EDC_CONFIG, 4)

    # cntl1   IRRITATOR_DATA_SEL:2
    #            POSSIBLE VALUES:
    #              00 - DSM_DATA_SEL_DISABLE : Disable irritation for this storage element
    #              01 - DSM_DATA_SEL_0 : Enable irritation and select irritator bit 0, for irritation
    #              02 - DSM_DATA_SEL_1 : Enable irritation and select irritator bit 1, for irritation
    #              03 - DSM_DATA_SEL_BOTH : Enable irritation and select irritator bits 0+1, for irritation
    # cntl1   ENABLE_SINGLE_WRITE:1
    # cntl2   ENABLE_ERROR_INJECT:2
    #            POSSIBLE VALUES:
    #              00 - DSM_ENABLE_ERROR_INJECT_FED_IN : Enable FED in error injection
    #              01 - DSM_ENABLE_ERROR_INJECT_SINGLE : Enable single error injection
    #              02 - DSM_ENABLE_ERROR_INJECT_UNCORRECTABLE : Enable double/uncorrectable error injection
    #              03 - DSM_ENABLE_ERROR_INJECT_UNCORRECTABLE_LIMITED : Enable double/uncorrectable error injection and limit error injection to 7 events
    #          INJECT_DELAY:1
    #delayctnl INJECT_DELAY
    def injectError(self, cntl, off0, singlewrite_cntl, singlewrite_off, cntl2, off2, delayctnl, delayoff):
       setup_grbm_dsm_bypass()
       old0 = mmr(cntl)  &  (~(7 << off0))
       # currently, the cntl == singlewrite_cntl
       mmw(cntl, (self.__bits<< off0) | (self.__single << (singlewrite_off)) | old0 )

       if self.__delay > 0 :
           if cntl2 == delayctnl :
               old2 = mmr(cntl2) & ( ~(7 << off2))
               mmw(cntl2, (self.__err<<off2) | (1 << (off2+2)) | (self.__delay << delayoff) | old2)
           else:
               old2 = mmr(cntl2) & ( ~(7 << off2))
               mmw(cntl2, (self.__err<<off2) | (1 << (off2+2))  | old2)
               old3 = mmr(delayctnl) &  (~(63 << delayoff))
               mmw(delayctnl, (self.__delay << delayoff) | old3)
       else:
           old2 = mmr(cntl2) & ( ~(7 << off2))
           mmw(cntl2, (self.__err<<off2) | old2)

    def dsmInject(self, sram, grbm_gfx_index = 0xe0000000):
        if sram in [ATC_L2_CACHE_2M, ATC_L2_CACHE_4K, VML2_WALKER_MEM,VML2_MEM]:
            return self.dsmInject2(sram, grbm_gfx_index)
        sramId = sram_max_id
        dsmOff =  None
        if(isinstance(sram,(int))):
            sramId = sram
        else:
            sramId = SRAM_ID[sram.upper()]
        if sramId >= sram_max_id:
            print("No such sram")
            return
        dsmOff = DSM_OFFSET[sramId]
        for i in range(0,4):
            if dsmOff[i] == None:
                print("%d in %s not defined" % (i, SRAM_NAME[sramId]))
                return
        mmw(mmGRBM_GFX_INDEX, grbm_gfx_index)
        self.injectError(*dsmOff)
        mmw(mmGRBM_GFX_INDEX, 0xe0000000)
    def dsmInjectVML2(self, sram, index = 0xe0000000):
        indexer = {mmGCVML2_MEM_ECC_CNTL:mmGCVML2_MEM_ECC_INDEX,
                mmGCVML2_WALKER_MEM_ECC_CNTL:mmGCVML2_WALKER_MEM_ECC_INDEX,
                mmATC_L2_CACHE_2M_DSM_CNTL:mmATC_L2_CACHE_2M_DSM_INDEX,
                mmATC_L2_CACHE_4K_DSM_CNTL:mmATC_L2_CACHE_4K_DSM_INDEX
                }
        sramId = sram_max_id
        dsmOff =  None
        if isNumber(sram):
            sramId = sram
        else:
            sramId = SRAM_ID[sram.upper()]
        if sramId >= sram_max_id:
            print("No such sram")
            return
        dsmOff = DSM_OFFSET[sramId]
        for i in range(0,4):
            if dsmOff[i] == None:
                print("%d in %s not defined" % (i, SRAM_NAME[sramId]))
                return
        myIndexer = indexer[dsmOff[0]]
        if isNumber(index) and index != 0xe0000000:
            mmw(myIndexer, index)
            self.injectError(*dsmOff)
        elif  index == 'all' or index == 0xe0000000:
            for i in range(0,32):
                mmw(myIndexer, i)
                self.injectError(*dsmOff)


    #@classmethod
    @staticmethod
    def list():
        for key, value in SRAM_NAME.items():
            print(value.lower())
    @staticmethod
    def clear():
        clear_dsm()
    @staticmethod
    def info():
        read_dsm()


#####################         DSM         ###############################
def dsm_read_all():
    db32s = DB32Script(db32=db32S)
    db32s.mmr(mmGB_EDC_MODE)
    db32s.mmr(mmCC_GC_EDC_CONFIG)
    db32s.mmr(mmSQ_EDC_FUE_CNTL)
    db32s.mmr(mmSQC_EDC_FUE_CNTL)
    db32s.mmr(mmCP_EDC_FUE_CNTL)
    db32s.mmr(mmATC_L2_CACHE_2M_DSM_CNTL )
    db32s.mmr(mmATC_L2_CACHE_4K_DSM_CNTL )
    db32s.mmr(mmCP_CPC_DSM_CNTL )
    db32s.mmr(mmCP_CPC_DSM_CNTL2 )
    db32s.mmr(mmCP_CPC_DSM_CNTL2A )
    db32s.mmr(mmCP_CPF_DSM_CNTL )
    db32s.mmr(mmCP_CPF_DSM_CNTL2 )
    db32s.mmr(mmCP_CPF_DSM_CNTL2A )
    db32s.mmr(mmCP_CPG_DSM_CNTL )
    db32s.mmr(mmCP_CPG_DSM_CNTL2 )
    db32s.mmr(mmCP_CPG_DSM_CNTL2A )
    db32s.mmr(mmGDS_DSM_CNTL )
    db32s.mmr(mmGDS_DSM_CNTL2 )
    db32s.mmr(mmPA_SC_DSM_CNTL )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTL )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTL2 )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTL2A )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTL2B )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTLA )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTLB )
    db32s.pershGFX9  (mmSPI_DSM_CNTL )
    db32s.pershGFX9  (mmSPI_DSM_CNTL2 )
    db32s.persqcGFX9 (mmSQC_DSM_CNTL )
    db32s.persqcGFX9 (mmSQC_DSM_CNTL2 )
    db32s.persqcGFX9 (mmSQC_DSM_CNTL2A )
    db32s.persqcGFX9 (mmSQC_DSM_CNTL2B )
    db32s.persqcGFX9 (mmSQC_DSM_CNTLA )
    db32s.persqcGFX9 (mmSQC_DSM_CNTLB )
    db32s.percuGFX9  (mmSQ_DSM_CNTL )
    db32s.percuGFX9  (mmSQ_DSM_CNTL2 )
    db32s.percuGFX9  (mmTA_DSM_CNTL )
    db32s.percuGFX9  (mmTA_DSM_CNTL2 )
    db32s.pertciGFX9 (mmTCA_DSM_CNTL )
    db32s.pertciGFX9 (mmTCA_DSM_CNTL2 )
    db32s.pertccGFX9 (mmTCC_DSM_CNTL )
    db32s.pertccGFX9 (mmTCC_DSM_CNTL2 )
    db32s.pertccGFX9 (mmTCC_DSM_CNTL2A )
    db32s.pertccGFX9 (mmTCC_DSM_CNTL2B )
    db32s.pertccGFX9 (mmTCC_DSM_CNTLA )
    #db32s.pertccGFX9 (mmTCC_DSM_CNTLB )
    db32s.pertciGFX9 (mmTCI_DSM_CNTL )
    db32s.pertciGFX9 (mmTCI_DSM_CNTL2 )
    db32s.percuGFX9  (mmTCP_DSM_CNTL )
    db32s.percuGFX9  (mmTCP_DSM_CNTL2 )
    db32s.percuGFX9  (mmTCP_GATCL1_DSM_CNTL )
    db32s.percuGFX9  (mmTD_DSM_CNTL )
    db32s.percuGFX9  (mmTD_DSM_CNTL2)
    db32s.perL2(mmGCVML2_MEM_ECC_CNTL,mmGCVML2_MEM_ECC_INDEX,127)
    db32s.perL2(mmGCVML2_WALKER_MEM_ECC_CNTL,mmGCVML2_WALKER_MEM_ECC_INDEX,127)
    db32s.perL2(mmATC_L2_CACHE_2M_DSM_CNTL,mmATC_L2_CACHE_2M_DSM_INDEX,127)
    db32s.perL2(mmATC_L2_CACHE_4K_DSM_CNTL,mmATC_L2_CACHE_4K_DSM_INDEX,127)
    r = db32s.run()
    rv = db32s.db32.rvmaparray(r)
    if Settings.mParseReg: REG.dumpmaparray2(rv)
    dumpmaparray(rv)

def clear_dsm():
    db32s = DB32Script(db32=db32S)
    db32s.mmw(mmGRBM_GFX_INDEX, 0xe0000000)
    db32s.mmw(mmGRBM_DSM_BYPASS, 0)
    db32s.mmw(mmGB_EDC_MODE, 0)
    db32s.mmw(mmSQ_EDC_FUE_CNTL, 0)
    db32s.mmw(mmSQC_EDC_FUE_CNTL, 0)
    db32s.mmw(mmCP_EDC_FUE_CNTL, 0)
    db32s.mmw(mmATC_L2_CACHE_2M_DSM_CNTL ,0)
    db32s.mmw(mmATC_L2_CACHE_4K_DSM_CNTL ,0)
    db32s.mmw(mmCP_CPC_DSM_CNTL ,0)
    db32s.mmw(mmCP_CPC_DSM_CNTL2 ,0)
    db32s.mmw(mmCP_CPC_DSM_CNTL2A ,0)
    db32s.mmw(mmCP_CPF_DSM_CNTL ,0)
    db32s.mmw(mmCP_CPF_DSM_CNTL2 ,0)
    db32s.mmw(mmCP_CPF_DSM_CNTL2A ,0)
    db32s.mmw(mmCP_CPG_DSM_CNTL ,0)
    db32s.mmw(mmCP_CPG_DSM_CNTL2 ,0)
    db32s.mmw(mmCP_CPG_DSM_CNTL2A ,0)
    db32s.mmw(mmGDS_DSM_CNTL ,0)
    db32s.mmw(mmGDS_DSM_CNTL2 ,0)
    db32s.mmw(mmPA_SC_DSM_CNTL ,0)
    db32s.pereaGFX9  ('mmw(mmGCEA_DSM_CNTL ,0)')
    db32s.pereaGFX9  ('mmw(mmGCEA_DSM_CNTL2 ,0)')
    db32s.pereaGFX9  ('mmw(mmGCEA_DSM_CNTL2A ,0)')
    db32s.pereaGFX9  ('mmw(mmGCEA_DSM_CNTL2B ,0)')
    db32s.pereaGFX9  ('mmw(mmGCEA_DSM_CNTLA ,0)')
    db32s.pereaGFX9  ('mmw(mmGCEA_DSM_CNTLB ,0)')
    db32s.pershGFX9  ('mmw(mmSPI_DSM_CNTL ,0)')
    db32s.pershGFX9  ('mmw(mmSPI_DSM_CNTL2 ,0)')
    db32s.persqcGFX9 ('mmw(mmSQC_DSM_CNTL ,0)')
    db32s.persqcGFX9 ('mmw(mmSQC_DSM_CNTL2 ,0)')
    db32s.persqcGFX9 ('mmw(mmSQC_DSM_CNTL2A ,0)')
    db32s.persqcGFX9 ('mmw(mmSQC_DSM_CNTL2B ,0)')
    db32s.persqcGFX9 ('mmw(mmSQC_DSM_CNTLA ,0)')
    db32s.persqcGFX9 ('mmw(mmSQC_DSM_CNTLB ,0)')
    db32s.percuGFX9  ('mmw(mmSQ_DSM_CNTL ,0)')
    db32s.percuGFX9  ('mmw(mmSQ_DSM_CNTL2 ,0)')
    db32s.percuGFX9  ('mmw(mmTA_DSM_CNTL ,0)')
    db32s.percuGFX9  ('mmw(mmTA_DSM_CNTL2 ,0)')
    db32s.pertciGFX9 ('mmw(mmTCA_DSM_CNTL ,0)')
    db32s.pertciGFX9 ('mmw(mmTCA_DSM_CNTL2 ,0)')
    db32s.pertccGFX9 ('mmw(mmTCC_DSM_CNTL ,0)')
    db32s.pertccGFX9 ('mmw(mmTCC_DSM_CNTL2 ,0)')
    db32s.pertccGFX9 ('mmw(mmTCC_DSM_CNTL2A ,0)')
    db32s.pertccGFX9 ('mmw(mmTCC_DSM_CNTL2B ,0)')
    db32s.pertccGFX9 ('mmw(mmTCC_DSM_CNTLA ,0)')
    #db32s.pertccGFX9 ('mmw(mmTCC_DSM_CNTLB ,0)')
    db32s.pertciGFX9 ('mmw(mmTCI_DSM_CNTL ,0)')
    db32s.pertciGFX9 ('mmw(mmTCI_DSM_CNTL2 ,0)')
    db32s.percuGFX9  ('mmw(mmTCP_DSM_CNTL ,0)')
    db32s.percuGFX9  ('mmw(mmTCP_DSM_CNTL2 ,0)')
    db32s.percuGFX9  ('mmw(mmTCP_GATCL1_DSM_CNTL ,0)')
    db32s.percuGFX9  ('mmw(mmTD_DSM_CNTL ,0)')
    db32s.percuGFX9  ('mmw(mmTD_DSM_CNTL2,0)')
    db32s.mmr(mmGRBM_DSM_BYPASS)
    db32s.mmr(mmGB_EDC_MODE)
    db32s.mmr(mmSQ_EDC_FUE_CNTL)
    db32s.mmr(mmSQC_EDC_FUE_CNTL)
    db32s.mmr(mmCP_EDC_FUE_CNTL)
    db32s.mmr(mmATC_L2_CACHE_2M_DSM_CNTL )
    db32s.mmr(mmATC_L2_CACHE_4K_DSM_CNTL )
    db32s.mmr(mmCP_CPC_DSM_CNTL )
    db32s.mmr(mmCP_CPC_DSM_CNTL2 )
    db32s.mmr(mmCP_CPC_DSM_CNTL2A )
    db32s.mmr(mmCP_CPF_DSM_CNTL )
    db32s.mmr(mmCP_CPF_DSM_CNTL2 )
    db32s.mmr(mmCP_CPF_DSM_CNTL2A )
    db32s.mmr(mmCP_CPG_DSM_CNTL )
    db32s.mmr(mmCP_CPG_DSM_CNTL2 )
    db32s.mmr(mmCP_CPG_DSM_CNTL2A )
    db32s.mmr(mmGDS_DSM_CNTL )
    db32s.mmr(mmGDS_DSM_CNTL2 )
    db32s.mmr(mmPA_SC_DSM_CNTL )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTL )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTL2 )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTL2A )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTL2B )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTLA )
    db32s.pereaGFX9  (mmGCEA_DSM_CNTLB )
    db32s.pershGFX9  (mmSPI_DSM_CNTL )
    db32s.pershGFX9  (mmSPI_DSM_CNTL2 )
    db32s.persqcGFX9 (mmSQC_DSM_CNTL )
    db32s.persqcGFX9 (mmSQC_DSM_CNTL2 )
    db32s.persqcGFX9 (mmSQC_DSM_CNTL2A )
    db32s.persqcGFX9 (mmSQC_DSM_CNTL2B )
    db32s.persqcGFX9 (mmSQC_DSM_CNTLA )
    db32s.persqcGFX9 (mmSQC_DSM_CNTLB )
    db32s.percuGFX9  (mmSQ_DSM_CNTL )
    db32s.percuGFX9  (mmSQ_DSM_CNTL2 )
    db32s.percuGFX9  (mmTA_DSM_CNTL )
    db32s.percuGFX9  (mmTA_DSM_CNTL2 )
    db32s.pertciGFX9 (mmTCA_DSM_CNTL )
    db32s.pertciGFX9 (mmTCA_DSM_CNTL2 )
    db32s.pertccGFX9 (mmTCC_DSM_CNTL )
    db32s.pertccGFX9 (mmTCC_DSM_CNTL2 )
    db32s.pertccGFX9 (mmTCC_DSM_CNTL2A )
    db32s.pertccGFX9 (mmTCC_DSM_CNTL2B )
    db32s.pertccGFX9 (mmTCC_DSM_CNTLA )
    #db32s.pertccGFX9 (mmTCC_DSM_CNTLB )
    db32s.pertciGFX9 (mmTCI_DSM_CNTL )
    db32s.pertciGFX9 (mmTCI_DSM_CNTL2 )
    db32s.percuGFX9  (mmTCP_DSM_CNTL )
    db32s.percuGFX9  (mmTCP_DSM_CNTL2 )
    db32s.percuGFX9  (mmTCP_GATCL1_DSM_CNTL )
    db32s.percuGFX9  (mmTD_DSM_CNTL )
    db32s.percuGFX9  (mmTD_DSM_CNTL2)
    r = db32s.run()
    rv = db32s.db32.rvmaparray(r)
    dumpmaparray(rv)
    '''
    mmw(mmMMEA0_DSM_CNTL ,0)
    mmw(mmMMEA0_DSM_CNTL2 ,0)
    mmw(mmMMEA0_DSM_CNTL2A ,0)
    mmw(mmMMEA0_DSM_CNTL2B ,0)
    mmw(mmMMEA0_DSM_CNTLA ,0)
    mmw(mmMMEA0_DSM_CNTLB ,0)
    mmw(mmMMEA1_DSM_CNTL ,0)
    mmw(mmMMEA1_DSM_CNTL2 ,0)
    mmw(mmMMEA1_DSM_CNTL2A ,0)
    mmw(mmMMEA1_DSM_CNTL2B ,0)
    mmw(mmMMEA1_DSM_CNTLA ,0)
    mmw(mmMMEA1_DSM_CNTLB ,0)
    '''
def clear_all(clear_value=0):
    cnt.clear(clear_value)
    clear_dsm()

def read_dsm():
        return dsm_read_all()
def read_edc_cntl():
        db32s = DB32Script(db32=db32S)
        db32s.mmr(mmGRBM_DSM_BYPASS)
        db32s.mmr(mmGB_EDC_MODE)
        db32s.mmr(mmCC_GC_EDC_CONFIG)
        db32s.mmr(mmCP_EDC_FUE_CNTL)
        db32s.percuGFX9(mmSQ_EDC_FUE_CNTL)
        db32s.persqcGFX9(mmSQC_EDC_FUE_CNTL)
        db32s.pereaGFX9(mmGCEA_ERR_STATUS)
        db32s.mmr(mmGCEA_SDP_ARB_FINAL)
        r = db32s.run()
        rv = db32s.db32.rvmaparray(r)
        if Settings.mParseReg: REG.dumpmaparray2(rv)
        dumpmaparray(rv)
        #per SQC

def read_all():
    read_edc_cntl()
    cnt.read()

def list_sram():
    for sram in SRAM_ID:
        print(sram)
uei = DSM(3, 2, 0, 0)
fei = DSM(1, 0, 0, 0)
sei = DSM(1, 1, 0, 0)

def myexec(cmd):
    exec(cmd)
