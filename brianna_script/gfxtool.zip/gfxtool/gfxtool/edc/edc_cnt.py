#!/usr/bin/python
import os,sys,inspect
from db32 import *
from edc_reg import *
from ip_reg import *

def clear_cnt_general(clear_value=0):
    db32s = DB32Script(db32=db32S)
    db32s.mmw(mmCPF_EDC_TAG_CNT,clear_value)
    db32s.mmw(mmCPF_EDC_ROQ_CNT,clear_value)
    db32s.mmw(mmCPG_EDC_TAG_CNT,clear_value)
    db32s.mmw(mmCPG_EDC_DMA_CNT,clear_value)
    db32s.mmw(mmCPC_EDC_SCRATCH_CNT,clear_value)
    db32s.mmw(mmCPC_EDC_UCODE_CNT,clear_value)
    db32s.mmw(mmDC_EDC_STATE_CNT,clear_value)
    db32s.mmw(mmDC_EDC_CSINVOC_CNT,clear_value)
    db32s.mmw(mmDC_EDC_RESTORE_CNT,clear_value)
    db32s.mmw(mmGDS_EDC_CNT,clear_value)
    db32s.mmw(mmGDS_EDC_GRBM_CNT,clear_value)
    db32s.mmw(mmGDS_EDC_OA_PHY_CNT,clear_value)
    db32s.mmw(mmGDS_EDC_OA_PIPE_CNT,clear_value)
    db32s.pershGFX9("mmw(mmSPI_EDC_CNT, 0x%x)"%clear_value)
    db32s.percuGFX9("mmw(mmSQ_EDC_CNT, 0x%x)"%clear_value)
    db32s.percuGFX9("mmw(mmTA_EDC_CNT, 0x%x)"%clear_value)
    db32s.percuGFX9("mmw(mmTD_EDC_CNT, 0x%x)"%clear_value)
    db32s.percuGFX9("mmw(mmTCP_EDC_CNT_NEW, 0x%x)"%clear_value)
    db32s.persqcGFX9("mmw(mmSQC_EDC_CNT, 0x%x)"%clear_value)
    db32s.persqcGFX9("mmw(mmSQC_EDC_CNT2, 0x%x)"%clear_value)
    db32s.persqcGFX9("mmw(mmSQC_EDC_CNT3, 0x%x)"%clear_value)
    if var_exist('mmSQC_EDC_PARITY_CNT3'):db32s.persqcGFX9("mmw(mmSQC_EDC_PARITY_CNT3,0x%x)"%clear_value)
    db32s.pertccGFX9("mmw(mmTCC_EDC_CNT, 0x%x)"%clear_value)
    db32s.pertccGFX9("mmw(mmTCC_EDC_CNT2, 0x%x)"%clear_value)
    db32s.pereaGFX9("mmw(mmGCEA_EDC_CNT, 0x%x)"%clear_value)
    db32s.pereaGFX9("mmw(mmGCEA_EDC_CNT2, 0x%x)"%clear_value)
    if var_exist('mmGCEA_EDC_CNT3'):db32s.pereaGFX9("mmw(mmGCEA_EDC_CNT3,0x%x)"%clear_value)
    db32s.pertcaGFX9("mmw(mmTCA_EDC_CNT, 0x%x)"%clear_value)
    db32s.pertciGFX9("mmw(mmTCI_EDC_CNT, 0x%x)"%clear_value)
    if var_exist('mmRLC_EDC_CNT'):db32s.mmw(mmRLC_EDC_CNT,clear_value)
    if var_exist('mmRLC_EDC_CNT2'):db32s.mmw(mmRLC_EDC_CNT2,clear_value)
    vmClearValue = (clear_value & 0xf000) | 0x10000
    vmClearValue2 = (clear_value & 0xf000)
    atcClearValue = (clear_value & 0x1e000) | 0x1000
    atcClearValue2 = (clear_value & 0x1e000)
    db32s.perutcl2GFX9("mmw(mmUTCL2_MEM_ECC_CNTL, 0x%x)"%(vmClearValue))
    db32s.perutcl2GFX9("mmw(mmUTCL2_MEM_ECC_CNTL, 0x%x)"%(vmClearValue2))
    db32s.perL2("mmw(mmGCVML2_MEM_ECC_CNTL, 0x%x)" % vmClearValue, mmGCVML2_MEM_ECC_INDEX, 127)
    db32s.perL2("mmw(mmGCVML2_MEM_ECC_CNTL, 0x%x)" % vmClearValue2, mmGCVML2_MEM_ECC_INDEX, 127)
    db32s.perL2("mmw(mmGCVML2_WALKER_MEM_ECC_CNTL, 0x%x)" % vmClearValue, mmGCVML2_WALKER_MEM_ECC_INDEX,127)
    db32s.perL2("mmw(mmGCVML2_WALKER_MEM_ECC_CNTL, 0x%x)" % vmClearValue2, mmGCVML2_WALKER_MEM_ECC_INDEX,127)
    db32s.perL2("mmw(mmATC_L2_CACHE_2M_DSM_CNTL, 0x%x)" % atcClearValue, mmATC_L2_CACHE_2M_DSM_INDEX,127)
    db32s.perL2("mmw(mmATC_L2_CACHE_2M_DSM_CNTL, 0x%x)" % atcClearValue2, mmATC_L2_CACHE_2M_DSM_INDEX,127)
    db32s.perL2("mmw(mmATC_L2_CACHE_4K_DSM_CNTL, 0x%x)" % atcClearValue, mmATC_L2_CACHE_4K_DSM_INDEX,127)
    db32s.perL2("mmw(mmATC_L2_CACHE_4K_DSM_CNTL, 0x%x)" % atcClearValue2, mmATC_L2_CACHE_4K_DSM_INDEX,127)
    if var_exist('mmATC_L2_CACHE_32K_DSM_CNTL'):
        db32s.perL2("mmw(mmATC_L2_CACHE_32K_DSM_CNTL, 0x%x)" % atcClearValue, mmATC_L2_CACHE_32K_DSM_INDEX,127)
        db32s.perL2("mmw(mmATC_L2_CACHE_32K_DSM_CNTL, 0x%x)" % atcClearValue2, mmATC_L2_CACHE_32K_DSM_INDEX,127)
    db32s.mmw(mmCP_FATAL_ERROR,clear_value)
    db32s.mmw(0x75E3,0)#db32s.mmr(mmDF_PIE_AON_DfDbgStatusRegister)
    r = db32s.run()

def read_cnt_general():
    db32s = DB32Script(db32=db32S)
    db32s.mmr(mmCPF_EDC_TAG_CNT)
    db32s.mmr(mmCPF_EDC_ROQ_CNT)
    db32s.mmr(mmCPG_EDC_TAG_CNT)
    db32s.mmr(mmCPG_EDC_DMA_CNT)
    db32s.mmr(mmCPC_EDC_SCRATCH_CNT)
    db32s.mmr(mmCPC_EDC_UCODE_CNT)
    db32s.mmr(mmDC_EDC_STATE_CNT)
    db32s.mmr(mmDC_EDC_CSINVOC_CNT)
    db32s.mmr(mmDC_EDC_RESTORE_CNT)
    db32s.mmr(mmGDS_EDC_CNT)
    db32s.mmr(mmGDS_EDC_GRBM_CNT)
    db32s.mmr(mmGDS_EDC_OA_PHY_CNT)
    db32s.mmr(mmGDS_EDC_OA_PIPE_CNT)
    db32s.pershGFX9("mmr(mmSPI_EDC_CNT)")
    db32s.percuGFX9(mmSQ_EDC_CNT)
    db32s.percuGFX9(mmTA_EDC_CNT)
    db32s.percuGFX9(mmTD_EDC_CNT)
    db32s.percuGFX9(mmTCP_EDC_CNT_NEW)
    db32s.persqcGFX9(mmSQC_EDC_CNT)
    db32s.persqcGFX9(mmSQC_EDC_CNT2)
    db32s.persqcGFX9(mmSQC_EDC_CNT3)
    if var_exist('mmSQC_EDC_PARITY_CNT3'):db32s.persqcGFX9(mmSQC_EDC_PARITY_CNT3)
    db32s.pertccGFX9(mmTCC_EDC_CNT)
    db32s.pertccGFX9(mmTCC_EDC_CNT2)
    db32s.pereaGFX9(mmGCEA_EDC_CNT)
    db32s.pereaGFX9(mmGCEA_EDC_CNT2)
    if var_exist('mmGCEA_EDC_CNT3'):db32s.pereaGFX9(mmGCEA_EDC_CNT3)
    db32s.pertcaGFX9(mmTCA_EDC_CNT)
    db32s.pertciGFX9(mmTCI_EDC_CNT)
    if var_exist('mmRLC_EDC_CNT'):db32s.mmr(mmRLC_EDC_CNT)
    if var_exist('mmRLC_EDC_CNT2'):db32s.mmr(mmRLC_EDC_CNT2)
    db32s.perutcl2GFX9(mmUTCL2_MEM_ECC_CNTL)
    db32s.perL2(mmGCVML2_MEM_ECC_CNTL,mmGCVML2_MEM_ECC_INDEX,127)
    db32s.perL2(mmGCVML2_WALKER_MEM_ECC_CNTL,mmGCVML2_WALKER_MEM_ECC_INDEX,127)
    db32s.perL2(mmATC_L2_CACHE_2M_DSM_CNTL,mmATC_L2_CACHE_2M_DSM_INDEX,127)
    db32s.perL2(mmATC_L2_CACHE_4K_DSM_CNTL,mmATC_L2_CACHE_4K_DSM_INDEX,127)
    if var_exist('mmATC_L2_CACHE_32K_DSM_CNTL'):
        db32s.perL2(mmATC_L2_CACHE_32K_DSM_CNTL,mmATC_L2_CACHE_32K_DSM_INDEX,127)
    db32s.mmr(mmCP_FATAL_ERROR)
    db32s.mmr(0x75E3)#db32s.mmr(mmDF_PIE_AON_DfDbgStatusRegister)
    r = db32s.run()
    rv = db32s.db32.rvmaparray(r)
    def filterBits(reg, mask):
        if reg in rv:
            ll = rv[reg]
            for i in range(len(ll)): ll[i] = ll[i] & mask
    if True:
        filterBits(mmGCVML2_MEM_ECC_CNTL, 0xf000)
        filterBits(mmGCVML2_WALKER_MEM_ECC_CNTL, 0xf000)
        filterBits(mmATC_L2_CACHE_2M_DSM_CNTL, 0x1e000)
        filterBits(mmATC_L2_CACHE_4K_DSM_CNTL, 0x1e000)
        filterBits(mmATC_L2_CACHE_32K_DSM_CNTL, 0x1e000)
    if Settings.mParseReg: REG.dumpmaparray2(rv)
    dumpmaparray(rv)
    counters = 0
    for i, (k, a) in enumerate(rv.items()):
        for v in a:
            if v !=0: counters = counters + 1
    if counters == 0:
        Fmt.good("\nNo ECC ERROR")
    else:
        Fmt.warn("\nGOT ECC ERRORs")
    return counters

def clear_cnt_lo_mi300(clear_value=0):
    with DB32Script(False, db32=db32S) as db32s:
        db32s.mmw        (mmATC_L2_UE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmCPC_UE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmCPF_UE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmCPG_UE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmGC_CANE_UE_ERR_STATUS_LO, clear_value)
        db32s.pereaGFX9  ("mmw(mmGCEA_UE_ERR_STATUS_LO, 0x%x)" % clear_value)
        db32s.mmw        (mmGDS_UE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmIH_UE_STATUS_LO, clear_value)
        db32s.percuGFX9  ("mmw(mmLDS_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        #db32s.mmw        (mmMM_CANE_UE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA0_UE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA1_UE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA2_UE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA3_UE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA4_UE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmRLC_UE_ERR_STATUS_LOW, clear_value)
        db32s.mmw        (mmSDMA_UE_ERR_STATUS_LO, clear_value)
        db32s.percuGFX9  ("mmw(mmSP0_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSP1_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSPI_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.persqcGFX9 ("mmw(mmSQC_UE_EDC_LO,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSQ_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.mmw        (mmTA_UE_EDC_LO, clear_value)
        db32s.pertcaGFX9 ("mmw(mmTCA_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.pertccGFX9 ("mmw(mmTCC_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTCI_UE_EDC_LO_REG,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmTCP_UE_EDC_LO_REG,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTCX_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTD_UE_EDC_LO,0x%x)" %  clear_value)
        db32s.perutcl2GFX9("mmw(mmUTCL2_UE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.perL2      ("mmw(mmGCVML2_UE_ERR_STATUS_LO,0x%x)" %  clear_value, mmGCVML2_MEM_ECC_INDEX, 127)
        db32s.perL2      ("mmw(mmGCVML2_WALKER_UE_ERR_STATUS_LO,0x%x)" %  clear_value, mmGCVML2_WALKER_MEM_ECC_INDEX,127)

        db32s.mmw        (mmATC_L2_CE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmCPC_CE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmCPF_CE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmCPG_CE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmGC_CANE_CE_ERR_STATUS_LO, clear_value)
        db32s.pereaGFX9  ("mmw(mmGCEA_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.mmw        (mmGDS_CE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        #(mmIH_UE_STATUS_LO, clear_value)
        db32s.percuGFX9  ("mmw(mmLDS_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        #db32s.mmw        (mmMM_CANE_CE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA0_CE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA1_CE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA2_CE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA3_CE_ERR_STATUS_LO, clear_value)
        #db32s.mmw        (mmMMEA4_CE_ERR_STATUS_LO, clear_value)
        db32s.mmw        (mmRLC_CE_ERR_STATUS_LOW, clear_value)
        #db32s.mmw        #(mmSDMA_CE_ERR_STATUS_LO, clear_value)
        db32s.percuGFX9  ("mmw(mmSP0_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSP1_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSPI_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.persqcGFX9 ("mmw(mmSQC_CE_EDC_LO,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSQ_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        #db32s.mmw        (mmTA_CE_EDC_LO, clear_value)
        db32s.pertcaGFX9 #(mmTCA_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.pertccGFX9 ("mmw(mmTCC_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTCI_CE_EDC_LO_REG,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmTCP_CE_EDC_LO_REG,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTCX_CE_ERR_STATUS_LO,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTD_CE_EDC_LO,0x%x)" %  clear_value)
        db32s.perutcl2GFX9("mmw(mmUTCL2_CE_ERR_STATUS_LO, 0x%x)" % clear_value)
        db32s.perL2      ("mmw(mmGCVML2_CE_ERR_STATUS_LO, 0x%x)" % clear_value, mmGCVML2_MEM_ECC_INDEX, 127)
        db32s.perL2      ("mmw(mmGCVML2_WALKER_CE_ERR_STATUS_LO,0x%x)" % clear_value,  mmGCVML2_WALKER_MEM_ECC_INDEX,127)
    pass


def clear_cnt_mi300(clear_value=0):
    clear_cnt_lo_mi300(clear_value)
    with DB32Script(False, db32=db32S) as db32s:
        db32s.mmw        (mmATC_L2_UE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmCPC_UE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmCPF_UE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmCPG_UE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmGC_CANE_UE_ERR_STATUS_HI, clear_value)
        db32s.pereaGFX9  ("mmw(mmGCEA_UE_ERR_STATUS_HI, 0x%x)" % clear_value)
        db32s.mmw        (mmGDS_UE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmIH_UE_STATUS_HI, clear_value)
        db32s.percuGFX9  ("mmw(mmLDS_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        #db32s.mmw        (mmMM_CANE_UE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA0_UE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA1_UE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA2_UE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA3_UE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA4_UE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmRLC_UE_ERR_STATUS_HIGH, clear_value)
        db32s.mmw        (mmSDMA_UE_ERR_STATUS_HI, clear_value)
        db32s.percuGFX9  ("mmw(mmSP0_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSP1_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSPI_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.persqcGFX9 ("mmw(mmSQC_UE_EDC_HI,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSQ_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.mmw        (mmTA_UE_EDC_HI, clear_value)
        db32s.pertcaGFX9 ("mmw(mmTCA_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.pertccGFX9 ("mmw(mmTCC_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTCI_UE_EDC_HI_REG,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmTCP_UE_EDC_HI_REG,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTCX_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTD_UE_EDC_HI,0x%x)" %  clear_value)
        db32s.perutcl2GFX9("mmw(mmUTCL2_UE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.perL2      ("mmw(mmGCVML2_UE_ERR_STATUS_HI,0x%x)" %  clear_value, mmGCVML2_MEM_ECC_INDEX, 127)
        db32s.perL2      ("mmw(mmGCVML2_WALKER_UE_ERR_STATUS_HI,0x%x)" %  clear_value, mmGCVML2_WALKER_MEM_ECC_INDEX,127)

        db32s.mmw        (mmATC_L2_CE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmCPC_CE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmCPF_CE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmCPG_CE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmGC_CANE_CE_ERR_STATUS_HI, clear_value)
        db32s.pereaGFX9  ("mmw(mmGCEA_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.mmw        (mmGDS_CE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        #(mmIH_UE_STATUS_HI, clear_value)
        db32s.percuGFX9  ("mmw(mmLDS_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        #db32s.mmw        (mmMM_CANE_CE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA0_CE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA1_CE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA2_CE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA3_CE_ERR_STATUS_HI, clear_value)
        #db32s.mmw        (mmMMEA4_CE_ERR_STATUS_HI, clear_value)
        db32s.mmw        (mmRLC_CE_ERR_STATUS_HIGH, clear_value)
        #db32s.mmw        #(mmSDMA_CE_ERR_STATUS_HI, clear_value)
        db32s.percuGFX9  ("mmw(mmSP0_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSP1_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSPI_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.persqcGFX9 ("mmw(mmSQC_CE_EDC_HI,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmSQ_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        #db32s.mmw        (mmTA_CE_EDC_HI, clear_value)
        db32s.pertcaGFX9 #(mmTCA_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.pertccGFX9 ("mmw(mmTCC_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTCI_CE_EDC_HI_REG,0x%x)" %  clear_value)
        db32s.percuGFX9  ("mmw(mmTCP_CE_EDC_HI_REG,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTCX_CE_ERR_STATUS_HI,0x%x)" %  clear_value)
        db32s.pertciGFX9 ("mmw(mmTD_CE_EDC_HI,0x%x)" %  clear_value)
        db32s.perutcl2GFX9("mmw(mmUTCL2_CE_ERR_STATUS_HI, 0x%x)" % clear_value)
        db32s.perL2      ("mmw(mmGCVML2_CE_ERR_STATUS_HI, 0x%x)" % clear_value, mmGCVML2_MEM_ECC_INDEX, 127)
        db32s.perL2      ("mmw(mmGCVML2_WALKER_CE_ERR_STATUS_HI,0x%x)" % clear_value,  mmGCVML2_WALKER_MEM_ECC_INDEX,127)
    pass

def read_cnt_lo_mi300(db32s, checkCE = True, checkUE=True, **kwargs):
      checksdma = True if not 'checksdma' in kwargs else kwargs['checksdma']
      checksdma = True if not 'sdma' in kwargs else kwargs['sdma']
      myaid = gg.XCCID // 2
      if checkUE:
        db32s.mmr        (mmATC_L2_UE_ERR_STATUS_LO)
        db32s.mmr        (mmCPC_UE_ERR_STATUS_LO)
        db32s.mmr        (mmCPF_UE_ERR_STATUS_LO)
        db32s.mmr        (mmCPG_UE_ERR_STATUS_LO)
        db32s.mmr        (mmGC_CANE_UE_ERR_STATUS_LO)
        db32s.pereaGFX9  (mmGCEA_UE_ERR_STATUS_LO)
        db32s.mmr        (mmGDS_UE_ERR_STATUS_LO)
        db32s.mmr        (mmIH_UE_STATUS_LO)
        db32s.percuGFX9  (mmLDS_UE_ERR_STATUS_LO)
        #db32s.mmr        (mmMM_CANE_UE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA0_UE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA1_UE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA2_UE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA3_UE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA4_UE_ERR_STATUS_LO)
        db32s.mmr        (mmRLC_UE_ERR_STATUS_LOW)
        if checksdma:
            db32s.mmr        (mmSDMA_UE_ERR_STATUS_LO       + mmAidOffset(myaid))
            db32s.mmr        (mmSDMA_UE_ERR_STATUS_LO_alt_1 + mmAidOffset(myaid))
            db32s.mmr        (mmSDMA_UE_ERR_STATUS_LO_alt_2 + mmAidOffset(myaid))
            db32s.mmr        (mmSDMA_UE_ERR_STATUS_LO_alt_3 + mmAidOffset(myaid))
        db32s.percuGFX9  (mmSP0_UE_ERR_STATUS_LO)
        db32s.percuGFX9  (mmSP1_UE_ERR_STATUS_LO)
        db32s.percuGFX9  (mmSPI_UE_ERR_STATUS_LO)
        db32s.persqcGFX9 (mmSQC_UE_EDC_LO)
        db32s.percuGFX9  (mmSQ_UE_ERR_STATUS_LO)
        db32s.mmr        (mmTA_UE_EDC_LO)
        db32s.pertcaGFX9 (mmTCA_UE_ERR_STATUS_LO)
        db32s.pertccGFX9 (mmTCC_UE_ERR_STATUS_LO)
        db32s.pertciGFX9 (mmTCI_UE_EDC_LO_REG)
        db32s.percuGFX9  (mmTCP_UE_EDC_LO_REG)
        db32s.pertciGFX9 (mmTCX_UE_ERR_STATUS_LO)
        db32s.pertciGFX9 (mmTD_UE_EDC_LO)
        db32s.perutcl2GFX9(mmUTCL2_UE_ERR_STATUS_LO)
        db32s.perL2      (mmGCVML2_UE_ERR_STATUS_LO, mmGCVML2_MEM_ECC_INDEX, 127)
        db32s.perL2      (mmGCVML2_WALKER_UE_ERR_STATUS_LO, mmGCVML2_WALKER_MEM_ECC_INDEX,127)

      if checkCE:
        db32s.mmr        (mmATC_L2_CE_ERR_STATUS_LO)
        db32s.mmr        (mmCPC_CE_ERR_STATUS_LO)
        db32s.mmr        (mmCPF_CE_ERR_STATUS_LO)
        db32s.mmr        (mmCPG_CE_ERR_STATUS_LO)
        db32s.mmr        (mmGC_CANE_CE_ERR_STATUS_LO)
        db32s.pereaGFX9  (mmGCEA_CE_ERR_STATUS_LO)
        db32s.mmr        (mmGDS_CE_ERR_STATUS_LO)
        #db32s.mmr        #(mmIH_UE_STATUS_LO)
        db32s.percuGFX9  (mmLDS_CE_ERR_STATUS_LO)
        #db32s.mmr        (mmMM_CANE_CE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA0_CE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA1_CE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA2_CE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA3_CE_ERR_STATUS_LO)
        #db32s.mmr        (mmMMEA4_CE_ERR_STATUS_LO)
        db32s.mmr        (mmRLC_CE_ERR_STATUS_LOW)
        #db32s.mmr        #(mmSDMA_CE_ERR_STATUS_LO)
        db32s.percuGFX9  (mmSP0_CE_ERR_STATUS_LO)
        db32s.percuGFX9  (mmSP1_CE_ERR_STATUS_LO)
        db32s.percuGFX9  (mmSPI_CE_ERR_STATUS_LO)
        db32s.persqcGFX9 (mmSQC_CE_EDC_LO)
        db32s.percuGFX9  (mmSQ_CE_ERR_STATUS_LO)
        #db32s.mmr        (mmTA_CE_EDC_LO)
        db32s.pertcaGFX9 #(mmTCA_CE_ERR_STATUS_LO)
        db32s.pertccGFX9 (mmTCC_CE_ERR_STATUS_LO)
        db32s.pertciGFX9 (mmTCI_CE_EDC_LO_REG)
        db32s.percuGFX9  (mmTCP_CE_EDC_LO_REG)
        db32s.pertciGFX9 (mmTCX_CE_ERR_STATUS_LO)
        db32s.pertciGFX9 (mmTD_CE_EDC_LO)
        db32s.perutcl2GFX9(mmUTCL2_CE_ERR_STATUS_LO)
        db32s.perL2      (mmGCVML2_CE_ERR_STATUS_LO, mmGCVML2_MEM_ECC_INDEX, 127)
        db32s.perL2      (mmGCVML2_WALKER_CE_ERR_STATUS_LO, mmGCVML2_WALKER_MEM_ECC_INDEX,127)

def read_cnt_hi_mi300(db32s, checkCE = True, checkUE=True, **kwargs):
      checksdma = True if not 'checksdma' in kwargs else kwargs['checksdma']
      checksdma = True if not 'sdma' in kwargs else kwargs['sdma']
      myaid = gg.XCCID // 2
      if checkUE:
        db32s.mmr        (mmATC_L2_UE_ERR_STATUS_HI)
        db32s.mmr        (mmCPC_UE_ERR_STATUS_HI)
        db32s.mmr        (mmCPF_UE_ERR_STATUS_HI)
        db32s.mmr        (mmCPG_UE_ERR_STATUS_HI)
        db32s.mmr        (mmGC_CANE_UE_ERR_STATUS_HI)
        db32s.pereaGFX9  (mmGCEA_UE_ERR_STATUS_HI)
        db32s.mmr        (mmGDS_UE_ERR_STATUS_HI)
        db32s.mmr        (mmIH_UE_STATUS_HI)
        db32s.percuGFX9  (mmLDS_UE_ERR_STATUS_HI)
        #db32s.mmr        (mmMM_CANE_UE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA0_UE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA1_UE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA2_UE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA3_UE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA4_UE_ERR_STATUS_HI)
        db32s.mmr        (mmRLC_UE_ERR_STATUS_HIGH)
        if checksdma    : 
            db32s.mmr        (mmSDMA_UE_ERR_STATUS_HI       + AidOffset(myaid)//4)
            db32s.mmr        (mmSDMA_UE_ERR_STATUS_HI_alt_1 + AidOffset(myaid)//4)
            db32s.mmr        (mmSDMA_UE_ERR_STATUS_HI_alt_2 + AidOffset(myaid)//4)
            db32s.mmr        (mmSDMA_UE_ERR_STATUS_HI_alt_3 + AidOffset(myaid)//4)
        db32s.percuGFX9  (mmSP0_UE_ERR_STATUS_HI)
        db32s.percuGFX9  (mmSP1_UE_ERR_STATUS_HI)
        db32s.percuGFX9  (mmSPI_UE_ERR_STATUS_HI)
        db32s.persqcGFX9 (mmSQC_UE_EDC_HI)
        db32s.percuGFX9  (mmSQ_UE_ERR_STATUS_HI)
        db32s.mmr        (mmTA_UE_EDC_HI)
        db32s.pertcaGFX9 (mmTCA_UE_ERR_STATUS_HI)
        db32s.pertccGFX9 (mmTCC_UE_ERR_STATUS_HI)
        db32s.pertciGFX9 (mmTCI_UE_EDC_HI_REG)
        db32s.percuGFX9  (mmTCP_UE_EDC_HI_REG)
        db32s.pertciGFX9 (mmTCX_UE_ERR_STATUS_HI)
        db32s.pertciGFX9 (mmTD_UE_EDC_HI)
        db32s.perutcl2GFX9(mmUTCL2_UE_ERR_STATUS_HI)
        db32s.perL2      (mmGCVML2_UE_ERR_STATUS_HI, mmGCVML2_MEM_ECC_INDEX, 127)
        db32s.perL2      (mmGCVML2_WALKER_UE_ERR_STATUS_HI, mmGCVML2_WALKER_MEM_ECC_INDEX,127)

      if checkCE:
        db32s.mmr        (mmATC_L2_CE_ERR_STATUS_HI)
        db32s.mmr        (mmCPC_CE_ERR_STATUS_HI)
        db32s.mmr        (mmCPF_CE_ERR_STATUS_HI)
        db32s.mmr        (mmCPG_CE_ERR_STATUS_HI)
        db32s.mmr        (mmGC_CANE_CE_ERR_STATUS_HI)
        db32s.pereaGFX9  (mmGCEA_CE_ERR_STATUS_HI)
        db32s.mmr        (mmGDS_CE_ERR_STATUS_HI)
        #db32s.mmr        #(mmIH_UE_STATUS_HI)
        db32s.percuGFX9  (mmLDS_CE_ERR_STATUS_HI)
        #db32s.mmr        (mmMM_CANE_CE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA0_CE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA1_CE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA2_CE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA3_CE_ERR_STATUS_HI)
        #db32s.mmr        (mmMMEA4_CE_ERR_STATUS_HI)
        db32s.mmr        (mmRLC_CE_ERR_STATUS_HIGH)
        #db32s.mmr        #(mmSDMA_CE_ERR_STATUS_HI)
        db32s.percuGFX9  (mmSP0_CE_ERR_STATUS_HI)
        db32s.percuGFX9  (mmSP1_CE_ERR_STATUS_HI)
        db32s.percuGFX9  (mmSPI_CE_ERR_STATUS_HI)
        db32s.persqcGFX9 (mmSQC_CE_EDC_HI)
        db32s.percuGFX9  (mmSQ_CE_ERR_STATUS_HI)
        #db32s.mmr        (mmTA_CE_EDC_HI)
        db32s.pertcaGFX9 #(mmTCA_CE_ERR_STATUS_HI)
        db32s.pertccGFX9 (mmTCC_CE_ERR_STATUS_HI)
        db32s.pertciGFX9 (mmTCI_CE_EDC_HI_REG)
        db32s.percuGFX9  (mmTCP_CE_EDC_HI_REG)
        db32s.pertciGFX9 (mmTCX_CE_ERR_STATUS_HI)
        db32s.pertciGFX9 (mmTD_CE_EDC_HI)
        db32s.perutcl2GFX9(mmUTCL2_CE_ERR_STATUS_HI)
        db32s.perL2      (mmGCVML2_CE_ERR_STATUS_HI, mmGCVML2_MEM_ECC_INDEX, 127)
        db32s.perL2      (mmGCVML2_WALKER_CE_ERR_STATUS_HI, mmGCVML2_WALKER_MEM_ECC_INDEX,127)
def read_cnt_mi300_mmhub(myaid, checkCE = True, checkUE=True, **kwargs):
      NUM_INST = 5
      mmea_ce_err_status_hi = [0x61058, 0x61558, 0x61a58, 0x61f58, 0x62458]
      mmea_ue_err_status_hi = [0x6101c, 0x6151c, 0x61a1c, 0x61f1c, 0x6241c]
      mmea_ce_err_status_lo = [0x61050, 0x61550, 0x61a50, 0x61f50, 0x62450]
      mmea_ue_err_status_lo = [0x61018, 0x61518, 0x61a18, 0x61f18, 0x62418]
      for i in range(0,NUM_INST):
          mmea_ce_err_status_hi[i] = (mmea_ce_err_status_hi[i] + myaid*512*1024) // 4
          mmea_ue_err_status_hi[i] = (mmea_ue_err_status_hi[i] + myaid*512*1024) // 4
          mmea_ce_err_status_lo[i] = (mmea_ce_err_status_lo[i] + myaid*512*1024) // 4
          mmea_ue_err_status_lo[i] = (mmea_ue_err_status_lo[i] + myaid*512*1024) // 4
      vea_ce_err_status_hi = [0]*5
      vea_ue_err_status_hi = [0]*5
      vea_ce_err_status_lo = [0]*5
      vea_ue_err_status_lo = [0]*5
      rv_cehi = {}
      rv_celo = {}
      rv_uehi = {}
      rv_uelo = {}
      mydb32 = Cdb32(xccid=0)
      if checkCE:
         for i in range(0,NUM_INST):
             vea_ce_err_status_hi[i] = mydb32.mmr(mmea_ce_err_status_hi[i])
             vea_ce_err_status_lo[i] = mydb32.mmr(mmea_ce_err_status_lo[i])
         rv_cehi = { 0x61058//4:vea_ce_err_status_hi}
         rv_celo = { 0x61050//4:vea_ce_err_status_lo}
      if checkUE:
         for i in range(0,NUM_INST):
             vea_ue_err_status_hi[i] = mydb32.mmr(mmea_ue_err_status_hi[i])
             vea_ue_err_status_lo[i] = mydb32.mmr(mmea_ue_err_status_lo[i])
         rv_uehi = {0x6101c//4: vea_ue_err_status_hi}
         rv_uelo = {0x61018//4:vea_ue_err_status_lo}
      return (rv_celo, rv_cehi, rv_uelo, rv_uehi) 
   
def read_cnt_mi300_dfcs(myaid, checkCE = True, checkUE=True, **kwargs):
    NUM_INST = 32
    vDF_CS_MCA_STATUST0 = [0] * 32
    ooDF_CS_MCA_STATUST0 = [
     0x1f000008  ,0x1f000108  ,0x1f000208  ,0x1f000308  ,
     0x1f000408  ,0x1f000508  ,0x1f000608  ,0x1f000708  ,
     0x1f000808  ,0x1f000908  ,0x1f000a08  ,0x1f000b08  ,
     0x1f000c08  ,0x1f000d08  ,0x1f000e08  ,0x1f000f08  ,
     0x1f001008  ,0x1f001108  ,0x1f001208  ,0x1f001308  ,
     0x1f001408  ,0x1f001508  ,0x1f001608  ,0x1f001708  ,
     0x1f001808  ,0x1f001908  ,0x1f001a08  ,0x1f001b08  ,
     0x1f001c08  ,0x1f001d08  ,0x1f001e08  ,0x1f001f08  ]
    myaidoffset =  SmnAid(myaid)
    for i in range(0, NUM_INST):
        vDF_CS_MCA_STATUST0[i] = smn.regr32(ooDF_CS_MCA_STATUST0[i] + myaidoffset) 
    return {0x1f000008//4:vDF_CS_MCA_STATUST0}

def read_cnt_mi300_smump(myaid, checkCE = True, checkUE=True, **kwargs):
    ooSMU_MP1_MCA_STATUST1 = 0x3b30408
    ooSMU_MP1_MCA_STATUST0 = 0x3830408
    myaidoffset =  SmnAid(myaid)
    v0 = smn.regr32(ooSMU_MP1_MCA_STATUST0 + myaidoffset)
    v1 = smn.regr32(ooSMU_MP1_MCA_STATUST1 + myaidoffset)
    return {ooSMU_MP1_MCA_STATUST0//4:[v0], ooSMU_MP1_MCA_STATUST1//4:[v1]}
def read_cnt_mi300_dfpie(myaid, checkCE = True, checkUE=True, **kwargs):
    myaidoffset =  SmnAid(myaid)
    ooDF_PIE_AON_MCPIE_STATUST0 = 0x1f007908 
    oodf_cs_aon_hardwareassertstatuslow   = 0x490038f0
    oodf_gcm_aon_hardwareassertstatushigh = 0x490038f4
    ooDF_CCM_CPU_PG_DfDbgStatusRegister = 0x4900538c
    ooreg = [0x1f007908, 0x490038f0, 0x490038f4, 0x4900538c]
    vvreg = [0,0,0,0]
    names = ["DF_PIE_AON_MCPIE_STATUST0_0x1f007908", "df_cs_aon_hardwareassertstatuslow_0x490038f0", "df_gcm_aon_hardwareassertstatushigh_0x490038f4", "DF_CCM_CPU_PG_DfDbgStatusRegister_0x4900538c"]
    myret = {}
    for i in range(0,4):
        vvreg[i] =[smn.regr32(ooreg[i] + myaidoffset)]
        myret[names[i]] = vvreg[i]
    return myret
    
def read_cnt_mi300_hdp(myaid, checkCE = True, checkUE=True, **kwargs):
    mmhdp_ue_error_status_lo = 0x406c //4
    mmhdp_ue_error_status_hi = 0x4070 //4
    vlo = mmr(mmhdp_ue_error_status_lo)
    vhi = mmr(mmhdp_ue_error_status_hi)
    return {"mmhdp_ue_error_status_lo":[vlo], "mmhdp_ue_error_status_hi":[vhi]}

def read_cnt_mi300_nbif(myaid, checkCE = True, checkUE=True, **kwargs):
    '''
    PCIe-nBIF_MCA_SYNDT0                   0x13b17030
    PCIe-nBIF_MCA_DESTATT0                 0x13b17040
    PCIe-nBIF_MCA_IPID                     0x13b17028
    PCIe-nBIF_MCA_ADDRT0                   0x13b17010
    PCIe-nBIF_MCA_DEADDRT0                 0x13b17048
    
    PCIe-nBIF_MCA_STATUST0                 0x13b17008
    bifl_ras_central_status                0x10139040
    gdcsoc_ras_central_status              0x1418040 
    gdcsoc_ras_leaf0_status                0x14180c0 
    gdcsoc_ras_leaf1_status                0x14180c4 
    gdcsoc_ras_leaf2_status                0x14180c8 
    gdcsoc_ras_leaf3_status                0x14180cc 
    gdcsoc_ras_leaf4_status                0x14180d0 
    gdcsoc_ras_leaf5_status                0x14180d4 
    gdcsoc_ras_leaf6_status                0x14180d8 
    gdcsoc_ras_leaf7_status                0x14180dc 
    gdcsoc_ras_leaf8_status                0x14180e0 
    bifl_ras_leaf0_status                  0x101390c0
    bifl_ras_leaf1_status                  0x101390c4
    bifl_ras_leaf2_status                  0x101390c8
    bifl_ras_leaf3_status                  0x101390cc
    bifl_ras_leaf4_status                  0x101390d0
    bifl_ras_leaf5_status                  0x101390d4
    ras_global_status_lo                   0x13b20020
    parity_error_status_corr_grp0          0x13b2006c
    parity_error_status_corr_grp1          0x13b20070
    parity_error_status_corr_grp2          0x13b20074
    parity_error_status_corr_grp3          0x13b20078
    parity_error_status_corr_grp4          0x13b2007c
    parity_error_status_corr_grp5          0x13b20080
    parity_error_status_corr_grp6          0x13b20084
    parity_error_status_corr_grp7          0x13b20088
    parity_error_status_corr_grp8          0x13b2008c
    parity_error_status_corr_grp10         0x13b20094
    parity_error_status_corr_grp11         0x13b20098
    parity_error_status_uncorr_grp0        0x13b20028
    parity_error_status_uncorr_grp1        0x13b2002c
    parity_error_status_uncorr_grp2        0x13b20030
    parity_error_status_uncorr_grp3        0x13b20034
    parity_error_status_uncorr_grp4        0x13b20038
    parity_error_status_uncorr_grp5        0x13b2003c
    parity_error_status_uncorr_grp6        0x13b20040
    parity_error_status_uncorr_grp7        0x13b20044
    parity_error_status_uncorr_grp8        0x13b20048
    parity_error_status_uncorr_grp10       0x13b20050
    parity_error_status_uncorr_grp11       0x13b20054
    parity_error_status_ucp_grp0           0x13b200fc
    parity_error_status_ucp_grp1           0x13b20100
    parity_error_status_ucp_grp2           0x13b20104
    parity_error_status_ucp_grp3           0x13b20108
    parity_error_status_ucp_grp4           0x13b2010c
    parity_error_status_ucp_grp5           0x13b20110
    parity_error_status_ucp_grp6           0x13b20114
    parity_error_status_ucp_grp7           0x13b20118
    parity_error_status_ucp_grp8           0x13b2011c
    parity_error_status_ucp_grp10          0x13b20124
    parity_error_status_ucp_grp11          0x13b20128
    iohc_interrupt_eoi                     0x13b10120
    iohc_feature_cntl2                     0x13b10130
    '''
    ooreg = [ 
    0x13b17008 ,# PCIe-nBIF_MCA_STATUST0             
    0x10139040 ,# bifl_ras_central_status            
    0x1418040  ,# gdcsoc_ras_central_status          
    0x14180c0  ,# gdcsoc_ras_leaf0_status            
    0x14180c4  ,# gdcsoc_ras_leaf1_status            
    0x14180c8  ,# gdcsoc_ras_leaf2_status            
    0x14180cc  ,# gdcsoc_ras_leaf3_status            
    0x14180d0  ,# gdcsoc_ras_leaf4_status            
    0x14180d4  ,# gdcsoc_ras_leaf5_status            
    0x14180d8  ,# gdcsoc_ras_leaf6_status            
    0x14180dc  ,# gdcsoc_ras_leaf7_status            
    0x14180e0  ,# gdcsoc_ras_leaf8_status            
    0x101390c0 ,# bifl_ras_leaf0_status              
    0x101390c4 ,# bifl_ras_leaf1_status              
    0x101390c8 ,# bifl_ras_leaf2_status              
    0x101390cc ,# bifl_ras_leaf3_status              
    0x101390d0 ,# bifl_ras_leaf4_status              
    0x101390d4 ,# bifl_ras_leaf5_status              
    0x13b20020 ,# ras_global_status_lo               
    0x13b2006c ,# parity_error_status_corr_grp0      
    0x13b20070 ,# parity_error_status_corr_grp1      
    0x13b20074 ,# parity_error_status_corr_grp2      
    0x13b20078 ,# parity_error_status_corr_grp3      
    0x13b2007c ,# parity_error_status_corr_grp4      
    0x13b20080 ,# parity_error_status_corr_grp5      
    0x13b20084 ,# parity_error_status_corr_grp6      
    0x13b20088 ,# parity_error_status_corr_grp7      
    0x13b2008c ,# parity_error_status_corr_grp8      
    0x13b20094 ,# parity_error_status_corr_grp10     
    0x13b20098 ,# parity_error_status_corr_grp11     
    0x13b20028 ,# parity_error_status_uncorr_grp0    
    0x13b2002c ,# parity_error_status_uncorr_grp1    
    0x13b20030 ,# parity_error_status_uncorr_grp2    
    0x13b20034 ,# parity_error_status_uncorr_grp3    
    0x13b20038 ,# parity_error_status_uncorr_grp4    
    0x13b2003c ,# parity_error_status_uncorr_grp5    
    0x13b20040 ,# parity_error_status_uncorr_grp6    
    0x13b20044 ,# parity_error_status_uncorr_grp7    
    0x13b20048 ,# parity_error_status_uncorr_grp8    
    0x13b20050 ,# parity_error_status_uncorr_grp10   
    0x13b20054 ,# parity_error_status_uncorr_grp11   
    0x13b200fc ,# parity_error_status_ucp_grp0       
    0x13b20100 ,# parity_error_status_ucp_grp1       
    0x13b20104 ,# parity_error_status_ucp_grp2       
    0x13b20108 ,# parity_error_status_ucp_grp3       
    0x13b2010c ,# parity_error_status_ucp_grp4       
    0x13b20110 ,# parity_error_status_ucp_grp5       
    0x13b20114 ,# parity_error_status_ucp_grp6       
    0x13b20118 ,# parity_error_status_ucp_grp7       
    0x13b2011c ,# parity_error_status_ucp_grp8       
    0x13b20124 ,# parity_error_status_ucp_grp10      
    0x13b20128 # parity_error_status_ucp_grp11      
    ]
    vvreg = [0] * len(ooreg)
    myret = {}
    for i in range(0, len(ooreg)):
        vvreg[i] = smn.regr32(ooreg[i])
        myret[ooreg[i]//4] = [vvreg[i]]
    return myret

def read_cnt_mi300_athub(myaid, checkCE = True, checkUE=True, **kwargs):
    ooreg = [
            ("atc_ats_status"            ,0x30a4      ),
            ("ats_logging"               ,0x315c      ),
            ("rpb_error_status"          ,0x462ac     ),
            ("rpb_iowrite_fatal_log0"    ,0x46264     ),
            ("rpb_iowrite_fatal_log1"    ,0x46268     ),
            ("rpb_iowrite_fatal_log2"    ,0x4626c     ),
            ("rpb_iowrite_fatal_log3"    ,0x46270     ),
            ("rpb_rdrsp_fatal_log0"      ,0x46274     ),
            ("rpb_rdrsp_fatal_log1"      ,0x46278     ),
            ("rpb_invprg_fatal_log0"     ,0x4627c     ),
            ("rpb_invprg_fatal_log1"     ,0x46280     ),
            #("atc_ats_fault_status_info" ,0x30cc      ),
            #("atc_ats_fault_status_info2",0x30d0      ),
            #("atc_ats_fault_status_addr" ,0x30dc      ),
            ]
    vvreg = [0] * len(ooreg)
    myret = {}
    for i in range(0, len(ooreg)):
        vvreg[i] = regr32(ooreg[i][1])
        myret[ooreg[i][1]//4] = [vvreg[i]]
    return myret
def read_cnt_mi300_lsdma(myaid, checkCE = True, checkUE=True, **kwargs):
    pass
def read_cnt_mi300_mall(myaid, checkCE = True, checkUE=True, **kwargs):
    myaidoffset =  SmnAid(myaid)
    NUM_INST = 32
    #DF_MALL_AON:MCMALL_STATUST0 
    ooreg= [ 0x1f005908,             0x1f005a08,             0x1f005b08,             0x1f005c08,
             0x1f005d08,             0x1f005e08,             0x1f005f08,             0x1f006008,
             0x1f006108,             0x1f006208,             0x1f006308,             0x1f006408,
             0x1f006508,             0x1f006608,             0x1f006708,             0x1f006808,
             0x1f006908,             0x1f006a08,             0x1f006b08,             0x1f006c08,
             0x1f006d08,             0x1f006e08,             0x1f006f08,             0x1f007008,
             0x1f007108,             0x1f007208,             0x1f007308,             0x1f007408,
             0x1f007508,             0x1f007608,             0x1f007708,             0x1f007808
            ] 
    myret = {}
    vvreg = [0] * NUM_INST
    for i in range(0,NUM_INST):
        vvreg[i] =smn.regr32(ooreg[i] + myaidoffset)
    myret["DF_MALL_AON:MCMALL_STATUST0"] = vvreg
    return myret
def read_cnt_mi300_mmutcl2(myaid, checkCE = True, checkUE=True, **kwargs):
    pass
def read_cnt_mi300_umc(myaid, checkCE = True, checkUE=True, **kwargs):
    myaidoffset =  SmnAid(myaid)
    NUM_INST = 32
    #MCA_UMC_UMC:MCUMC_STATUST0
    ooreg = [ 
     0x90f08,   0x91f08,      0x92f08,   0x93f08, 
     0x190f08,  0x191f08,     0x192f08,  0x193f08, 
     0x290f08,  0x291f08,     0x292f08,  0x293f08,
     0x390f08,  0x391f08,     0x392f08,  0x393f08,
     0x490f08,  0x491f08,     0x492f08,  0x493f08,
     0x590f08,  0x591f08,     0x592f08,  0x593f08,
     0x690f08,  0x691f08,     0x692f08,  0x693f08,
     0x790f08,  0x791f08,     0x792f08,  0x793f08
    ]
    myret = {}
    vvreg = [0] * NUM_INST
    for i in range(0,NUM_INST):
        vvreg[i] =smn.regr32(ooreg[i] + myaidoffset)
    myret["MCA_UMC_UMC:MCUMC_STATUST0"] = vvreg
    return myret
def read_cnt_mi300_usr(myaid, checkCE = True, checkUE=True, **kwargs):
    myaidoffset =  SmnAid(myaid)
    #MCA_CP_USR_GCD_CP_USR:MCCP_USR_STATUST0
    ooregs = [
            ("MCA_CP_USR_GCD_CP_USR:MCCP_USR_STATUST0", [0x1c300208, 0x1c310208]),
            ("MCA_DP_USR_GCD_DP_USR:MCDP_USR_STATUST0", [0x1b310108, 0x1b410108, 0x1b510108, 0x1b610108])
            ]
    myret = {}
    for ooreg_ in ooregs:
        ooreg = ooreg_[1]
        vvreg = [0] * len(ooreg) 
        for i in range(0, len(ooreg)):
            vvreg[i] =smn.regr32(ooreg[i] + myaidoffset)
        myret[ooreg_[0]] = vvreg
    return myret
    pass
def read_cnt_mi300_vcn(myaid, checkCE = True, checkUE=True, **kwargs):
    pass
def read_cnt_mi300_xgmi(myaid, checkCE = True, checkUE=True, **kwargs):
    myaidoffset =  SmnAid(myaid)
    NUM_INST =2
    #MCA_XGMI_PCS_XGMI:MCPCS_XGMI_STATUST0 
    ooreg = [0x11a09208, 0x11b09208]
    myret = {}
    vvreg = [0] * NUM_INST
    for i in range(0,NUM_INST):
        vvreg[i] =smn.regr32(ooreg[i] + myaidoffset)
    myret["MCA_XGMI_PCS_XGMI:MCPCS_XGMI_STATUST0 "] = vvreg
    return myret
def read_cnt_mi300(**kwargs):
    ''' read ras counter
    edc.cnt.read(gfx=1,mmhub=1,dfcs=1,dfpie=1,hdp=1,nbif=1,smump=1,athub=1,mall=1,mmutcl2=1,umc=1,usr=1,xgmi=1)
    edc.cnt.read(all=1)
    edc.cnt.read() # gfx==1, all other ip ==0
    '''
    check_gfx = True
    check_mmhub = False 
    check_dfcs = False 
    check_dfpie = False 
    check_hdp = False 
    check_nbif= False 
    check_smump = False 
    check_athub = False

    check_mall = False
    check_mmutcl2 = False
    check_umc = False
    check_usr = False
    check_vcn = False
    check_xgmi = False
    check_lsdma = False

    check_ce = True
    check_ue = True 
    detail   = False
    check_all = False
    if 'checkce' in kwargs : check_ce = kwargs['checkce']
    if 'checkue' in kwargs : check_ue = kwargs['checkue']
    if 'detail' in kwargs : detail= kwargs['detail']
    if 'gfx' in kwargs : check_gfx= kwargs['gfx']
    if 'mmhub' in kwargs : check_mmhub= kwargs['mmhub']
    if 'dfcs' in kwargs : check_dfcs = kwargs['dfcs']
    if 'dfpie' in kwargs : check_dfpie = kwargs['dfpie']
    if 'hdp' in kwargs : check_hdp= kwargs['hdp']
    if 'nbif' in kwargs : check_nbif= kwargs['nbif']
    if 'smump' in kwargs : check_smump= kwargs['smump']
    if 'athub' in kwargs : check_athub= kwargs['athub']
    if 'lsdma' in kwargs : check_lsdma= kwargs['lsdma']
    if 'mall' in kwargs : check_mall = kwargs['mall']
    if 'mmutcl2' in kwargs : check_mmutcl2= kwargs['mmutcl2']
    if 'umc' in kwargs : check_umc = kwargs['umc']
    if 'usr' in kwargs : check_usr = kwargs['usr']
    if 'vcn' in kwargs : check_vcn = kwargs['vcn']
    if 'xgmi' in kwargs : check_xgmi = kwargs['xgmi']
    if 'all' in kwargs : check_all = kwargs['all']
    if check_all:
        check_gfx = True
        check_mmhub = True 
        check_dfcs = True 
        check_dfpie = True 
        check_hdp = True 
        check_nbif= True 
        check_smump = True 
        check_athub = True
        check_mall = True
        check_mmutcl2 = True
        check_umc = True
        check_usr = True
        check_vcn = True
        check_xgmi = True
        check_lsdma = True

    if True:
       mmPARTITION_COMPUTE_CAP = 0x3a04 //4
       xccbits = (mmr(mmPARTITION_COMPUTE_CAP) >> 10) & 0xff
       if ((1<<gg.XCCID) & xccbits) == 0 : check_gfx = False
    if (((1<<gg.XCCID) & xccbits) == 0) and  check_gfx: Fmt.warn("GC does not exist on %d"%gg.XCCID)
    rv_cehi = {}
    rv_celo = {}
    rv_uehi = {}
    rv_uelo = {}
    counters = 0
    count_ue = 0
    count_ce = 0
    count_fe = 0
    counters_gfx = 0 
    counters_mmhub = 0 
    counters_dfcs = 0
    counters_dfpie = 0
    counters_hdp = 0
    counters_nbif= 0 
    counters_smump = 0 
    counters_athub = 0
    counters_mall = 0
    counters_mmutcl2 = 0
    counters_umc = 0
    counters_usr = 0
    counters_xgmi = 0

    counters_lsdma = 0
    counters_vcn = 0

    if check_gfx:
        if check_ce:
            with DB32Script(db32=db32S) as db32s_cehi:
                read_cnt_hi_mi300(db32s_cehi, True, False, **kwargs)
            with DB32Script(db32=db32S) as db32s_celo:
                read_cnt_lo_mi300(db32s_celo, True, False, **kwargs)
            rv_cehi = db32s_cehi.db32.rvmaparray(db32s_cehi.last_output)
            rv_celo = db32s_celo.db32.rvmaparray(db32s_celo.last_output)
        if check_ue:
            with DB32Script(db32=db32S) as db32s_uehi:
                read_cnt_hi_mi300(db32s_uehi, False, True, **kwargs)
            with DB32Script(db32=db32S) as db32s_uelo:
                read_cnt_lo_mi300(db32s_uelo, False, True, **kwargs)
            rv_uehi = db32s_uehi.db32.rvmaparray(db32s_uehi.last_output)
            rv_uelo = db32s_uelo.db32.rvmaparray(db32s_uelo.last_output)
    if check_mmhub:
       (tmp_celo, tmp_cehi, tmp_uelo, tmp_uehi) = read_cnt_mi300_mmhub(gg.XCCID//2, True, True)
       rv_celo.update(tmp_celo)
       rv_cehi.update(tmp_cehi)
       rv_uelo.update(tmp_uelo)
       rv_uehi.update(tmp_uehi)
    rv = rv_cehi | rv_celo | rv_uehi | rv_uelo
    filterf = Settings.mOptions.filterf 
    def countnonzero(mylist):
        mycount = 0
        for v in mylist:
            if v == 0xffffffff and filterf: continue
            if v !=0: 
                mycount = mycount + 1 
        return mycount
    for i, (k, a) in enumerate(rv_cehi.items()):
        for v in a:
            if v == 0xffffffff and filterf: continue
            if v !=0: 
                count_ce = count_ce + ((v>>23)&7)
    for i, (k, a) in enumerate(rv_uehi.items()):
        for v in a:
            if v == 0xffffffff and filterf: continue
            if v !=0:
                count_ue = count_ue + ((v>>23)&7)
                count_fe = count_fe + ((v>>26)&7)
    for i, (k, a) in enumerate(rv.items()):
        for v in a:
            if v == 0xffffffff and filterf: continue
            if v !=0:
                counters_gfx = counters_gfx + 1
    def check_mca(myip_func):
       mycnt = 0
       mymca = myip_func(gg.XCCID//2, True, True)
       for i, (k, a) in enumerate(mymca.items()):
           mycnt = mycnt + countnonzero(a)
       return (mymca, mycnt)
    if check_dfcs:
     if gg.XCCID in [0,2,4]: # AID reg
       dfcs = read_cnt_mi300_dfcs(gg.XCCID//2, True, True)
       for i, (k, a) in enumerate(dfcs.items()):
           counters_dfcs = counters_dfcs + countnonzero(a)
    if check_dfpie:
     if gg.XCCID in [0,2,4]: # AID reg
       dfpie = read_cnt_mi300_dfpie(gg.XCCID//2, True, True)
       for i, (k, a) in enumerate(dfpie.items()):
           counters_dfpie = counters_dfpie + countnonzero(a)
    if check_athub:
     if gg.XCCID in [0]: # AID0 reg
       rasathub = read_cnt_mi300_athub(0, True, True)
       for i, (k, a) in enumerate(rasathub.items()):
           counters_athub = counters_athub + countnonzero(a)
    if check_hdp:
     if gg.XCCID in [0]: # AID0 reg
       rashdp = read_cnt_mi300_hdp(0, True, True)
       for i, (k, a) in enumerate(rashdp.items()):
           counters_hdp = counters_hdp + countnonzero(a)
    if check_nbif:
     if gg.XCCID in [0]: # AID0 reg
       rasnbif = read_cnt_mi300_nbif(0, True, True)
       for i, (k, a) in enumerate(rasnbif.items()):
           counters_nbif = counters_nbif + countnonzero(a)
    if check_smump:
     if gg.XCCID in [0,2,4]: # AID reg
       smump = read_cnt_mi300_smump(gg.XCCID//2, True, True)
       for i, (k, a) in enumerate(smump.items()):
           counters_smump = counters_smump + countnonzero(a)
    if check_mall:
     if gg.XCCID in [0,2,4]: # AID reg
         (rasmall, counters_mall) = check_mca(read_cnt_mi300_mall)
    if check_umc:
     if gg.XCCID in [0,2,4]: # AID reg
         (rasumc, counters_umc) = check_mca(read_cnt_mi300_umc)
    if check_xgmi:
     if gg.XCCID in [0,2,4]: # AID reg
         (rasxgmi, counters_xgmi) = check_mca(read_cnt_mi300_xgmi)
    if check_usr:
     if gg.XCCID in [0,2,4]: # AID reg
         (rasusr, counters_usr) = check_mca(read_cnt_mi300_usr)
    counters = counters_gfx + counters_dfcs + counters_dfpie + counters_hdp + counters_nbif + counters_smump + counters_mmhub
    counters = counters +  counters_athub + counters_lsdma + counters_mall + counters_mmutcl2 + counters_umc + counters_usr +  counters_vcn + counters_xgmi

    if counters == 0:
        Fmt.good("\nPass : No ECC ERROR")
    else:
        if detail:
           if counters_gfx >0 or counters_mmhub >0:
               Fmt.error("GFX or mmhub error")
               hexprint(rv)
           if counters_dfcs > 0: 
               Fmt.error("dfcs error")
               hexprint(dfcs) 
           if counters_dfpie > 0:
               Fmt.error("dfpie error")
               hexprint(dfpie) 
           if counters_athub > 0:
               Fmt.error("athub error")
               hexprint(rasathub) 
           if counters_hdp > 0:
               Fmt.error("hdp error")
               hexprint(hdp) 
           if counters_nbif > 0:
               Fmt.error("nbif error")
               hexprint(nbif) 
           if counters_smump > 0:
               Fmt.error("smump error")
               hexprint(smump) 
           if counters_mall> 0:
               Fmt.error("mallerror")
               hexprint(rasmall) 
           if counters_umc> 0:
               Fmt.error("umc error")
               hexprint(rasumc) 
           if counters_xgmi> 0:
               Fmt.error("xgmi error")
               hexprint(rasxgmi) 
           if counters_usr > 0:
               Fmt.error("usr error")
               hexprint(rasusr) 
        Fmt.warn("\nFail : GOT ECC ERRORs %d non-zero registers" % counters)
        if count_ce > 0: Fmt.warn("Checkras Result: SRAM correctable   errors detected, Total CeCnt(%d)"%count_ce)
        if count_ue > 0: Fmt.warn("Checkras Result: SRAM uncorrectable errors detected, Total UeCnt(%d)"%count_ue)
        if count_fe > 0: Fmt.warn("Checkras Result: SRAM uncorrectable errors detected, Total FedCnt(%d)"%count_fe)
    return counters

if GC__VARIANT == mi300:
    read = read_cnt_mi300
    clear = clear_cnt_mi300
else:
    read = read_cnt_general
    clear = clear_cnt_general

def read_interrupt():
    pwrmgt_int = smn.mmr(0x900b208//4) #RSMU_PWRMGT_INTR_STATUS_GC
    if pwrmgt_int != 0 : print("RSMU_PWRMGT_INTR_STATUS_GC : 0x%x"%pwrmgt_int)

def read_sq(*cus):
    print("")
    cumask = [False] * 64
    if(len(cus) == 0):
         cumask = [True]*64
    else:
        if isinstance(cus[0], tuple) :
            if len(cus[0]) == 0: cumask = [True]*64
            for cu in cus[0] : cumask[cu] = True
        else:
            for cu in cus : cumask[cu] = True
    # keep GPIO 15 high, set GPIO 14 to high as the start of the pulse of check
    mmw(0x16942, 0x0000C000)
    db32s = DB32Script(db32=db32S)
    db32s.percuGFX9(mmSQ_EDC_CNT)
    r = db32s.run()
    rv = db32s.db32.rvmaparray(r)
    dumpmaparray(rv)
    isPass = True
    for i in range(0, 64):
        value  =  rv[mmSQ_EDC_CNT][i]
        if cumask[i] and value > 0:
           isPass = False
    gpio = mmr(0x16942)
    if isPass :
        mmw(0x16942, 0x0000C000) ## pass => GPIO 6 = low
        print("PASS")
    else:
        gpio = gpio & (~(1<<15))
        gpio = (1<<14) | gpio
        db32s.mmw(0x16942, 0x0000C040) # fail = > GPIO 6 = high
        db32s.run()
        print("FAIL")

def loop_read_sq(t, *cus):
    while True:
        char = mygetch()
        if t != 0 : time.sleep(t)
        if(char == "q"): break
        read_sq(*cus)

def tcc_edc_read_all():
    for i in range(0,15):
        tcc_edc_read(i)

